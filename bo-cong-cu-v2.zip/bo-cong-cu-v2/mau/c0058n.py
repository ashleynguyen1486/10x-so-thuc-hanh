import sys; sys.path.insert(0, '/tmp/f30/b')
import tpl
from tpl import page, cover, disclaimer, build
from vnkeep import keep
tpl.CSS = tpl.CSS.replace('url(lato', 'url(file:///tmp/f30/b/lato')
SP = '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
N = '0058'
P = []
add = lambda inner, **k: P.append(page(len(P) + 1, N, inner, **k))

P.append(cover(N, ['XÂY DỰNG', 'CÔNG KHAI'],
  'Chia sẻ điều mình học. Mỗi tuần một điều, từ dự án học.',
  'Phương pháp luận: ý tưởng chia sẻ quá trình làm việc của Austin Kleon, nghiên cứu về hiệu ứng chuẩn bị để giảng lại, áp dụng cho nhịp chia sẻ hằng tuần trong hành trình 20 phút học mỗi ngày của Mùa 3.',
  'Nguồn gốc: Kleon (2014), Nestojko và cộng sự (2014), Fiorella và Mayer (2013). 10X Excellence Hub biên soạn lại với ví dụ công việc. Người viết: Trường.'))

add('''<h1>BẢN TIN HỌC TẬP, SỐ 1</h1>
<div class="lead">Thứ Hai 21.06.2027, Ngày Báo chí Cách mạng Việt Nam. Tuần này mỗi người viết "bản tin" đầu tiên về điều mình học.</div>
<div style="border-top:3pt double #7b1f23;border-bottom:1pt solid #7b1f23;padding:8pt 0 6pt;margin:6pt 0 10pt;display:flex;justify-content:space-between;align-items:baseline">
<span style="font-weight:900;font-size:20pt;color:#7b1f23;letter-spacing:.5pt">BẢN TIN HỌC TẬP CỦA TÔI</span><span style="font-size:9pt;color:#666">Số 1 · tuần 21.06 đến 26.06.2027</span></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16pt;font-size:10pt;line-height:16pt">
<div style="border-right:.5pt solid #ccc;padding-right:14pt"><div style="font-weight:900;font-size:13pt;color:#1a1a1a;line-height:17pt;margin-bottom:4pt">Một câu hỏi giúp ứng viên nói cụ thể</div>
<p>Tuần này tôi học được cách hỏi lại khi ứng viên trả lời chung chung. Trước đây tôi hay chuyển sang câu khác. Giờ tôi đề nghị ứng viên kể đúng một lần cụ thể, có thời gian và kết quả.</p>
<p style="font-size:8.5pt;color:#666;font-style:italic">Bài mẫu minh hoạ của một người làm nhân sự.</p></div>
<div><div style="font-weight:700;font-size:9pt;color:#7b1f23;text-transform:uppercase;margin-bottom:4pt">Trong số này</div>
<ul class="b" style="font-size:9.5pt"><li>Chia sẻ được gì, giữ riêng gì</li><li>Năm câu cho một bài chia sẻ</li><li>Vì sao chuẩn bị để giảng lại giúp nhớ ý chính</li><li>Nhìn lại mười hai tuần Mùa 3</li></ul></div></div>
<p style="margin-top:12pt">Nghề báo có những chuẩn mực mà ai làm việc với thông tin cũng nên học: kiểm tra trước khi chia sẻ, viết rõ cho người đọc, tôn trọng điều không được phép công bố. Nhân Ngày Báo chí Cách mạng Việt Nam, Công thức #0058 mượn những chuẩn mực đó cho một việc gần với mỗi người: viết ra và chia sẻ điều mình đã học.</p>
<div class="box"><div class="h">Ý chính của tuần này</div><div class="c">
<p>Mỗi tuần chia sẻ <b>một điều đã học</b> từ dự án học, với nhóm của mình hoặc cộng đồng 10X. Chọn điều an toàn để chia sẻ, viết ngắn năm câu, chuẩn bị như thể sắp giảng lại, đón nhận phản hồi. Không khoe kết quả, chỉ kể điều mình hiểu ra. Tuần này cũng nhìn lại mười hai tuần của Mùa 3.</p></div></div>''')

ch = [('1', 'You don\'t have to be a genius.', 'Không cần là thiên tài mới có điều đáng chia sẻ'),
      ('2', 'Think process, not product.', 'Chia sẻ quá trình, không chỉ sản phẩm cuối cùng'),
      ('3', 'Share something small every day.', 'Chia sẻ phần nhỏ một cách đều đặn'),
      ('4', 'Open up your cabinet of curiosities.', 'Mở "tủ sưu tập" những điều mình thấy hay'),
      ('5', 'Tell good stories.', 'Kể câu chuyện về công việc một cách hấp dẫn'),
      ('6', 'Teach what you know.', 'Dạy lại điều mình biết'),
      ('7', 'Don\'t turn into human spam.', 'Đừng biến mình thành người chỉ quảng cáo bản thân'),
      ('8', 'Learn to take a punch.', 'Học cách đón nhận phản hồi trái chiều'),
      ('9', 'Sell out.', 'Dám nhận giá trị từ công việc của mình'),
      ('10', 'Stick around.', 'Kiên trì, đừng bỏ cuộc sớm')]
add('''<h1>AUSTIN KLEON, "SHOW YOUR WORK!"</h1>
<div class="sub">Workman Publishing, 2014. Tên đầy đủ: "Show Your Work! 10 Ways to Share Your Creativity and Get Discovered".</div>
<p>Austin Kleon là tác giả và nghệ sĩ người Mỹ. "Show Your Work!" là cuốn sách mỏng gồm mười chương, mỗi chương một lời khuyên về việc chia sẻ công việc sáng tạo. Sách viết cho người làm sáng tạo, nhưng nhiều ý dùng tốt cho người đi làm đang học một kỹ năng mới.</p>
<table class="t" style="font-size:9pt;line-height:13pt"><tr><th style="width:7%">#</th><th style="width:40%">Tên chương (gốc)</th><th>Diễn giải ngắn</th></tr>''' +
 ''.join(f'<tr><td class="k">{a}</td><td><i>{b}</i></td><td>{c}</td></tr>' for a, b, c in ch) + '''</table>
<p>Tuần này dùng bốn ý: chương 1, 2, 3 và 6, cùng lời nhắc ở chương 7. Diễn giải là tóm tắt của 10X Excellence Hub, không phải bản dịch nguyên văn.</p>''')

add('''<h1>XÂY DỰNG CÔNG KHAI TRONG CÔNG VIỆC</h1>
<div class="sub">Nói ra điều mình đang học, với những người dùng được hoặc góp ý được.</div>
<table class="t"><tr><th style="width:50%">Xây dựng công khai là</th><th>Xây dựng công khai không phải</th></tr>
<tr><td>Kể điều mình hiểu ra, kèm một ví dụ</td><td>Khoe kết quả, khoe chứng chỉ</td></tr>
<tr><td>Chia sẻ với nhóm, buổi họp, cộng đồng 10X</td><td>Đăng mọi điều lên mạng xã hội</td></tr>
<tr><td>Mỗi tuần một điều nhỏ, đều đặn</td><td>Một bài dài thật hoàn hảo, rồi im lặng</td></tr>
<tr><td>Có câu hỏi mời góp ý</td><td>Chỉ để nhận lời khen</td></tr>
<tr><td>Tôn trọng bảo mật của công ty và khách hàng</td><td>Kể chuyện nội bộ, đưa số liệu thật</td></tr></table>
<h2>Ba lợi ích, nói ở mức đúng mực</h2>
<ul class="b"><li><b>Cho chính mình:</b> chuẩn bị để giải thích giúp tìm ra ý chính và sắp xếp kiến thức (trang 5).</li>
<li><b>Cho nhóm:</b> một cách làm tốt hơn được dùng chung sớm hơn, thay vì nằm trong sổ của một người.</li>
<li><b>Cho việc học tiếp:</b> phản hồi chỉ ra điều mình còn thiếu, đúng như nguồn bằng chứng thứ ba của tuần #0057.</li></ul>
<p>Tài liệu này không hứa hẹn rằng chia sẻ sẽ mang lại cơ hội hay sự công nhận cụ thể nào. Điều tuần này nhắm tới đơn giản hơn: học sâu hơn, và giúp người bên cạnh.</p>
<div class="box"><div class="h">Liên hệ với các tuần trước</div><div class="c"><p>Kỹ thuật Feynman (#0028) luyện giảng lại một khái niệm bằng lời đơn giản. Hộp thẻ (#0055) giữ ý tưởng bằng lời của mình. Tuần #0058 đưa lời giảng đó ra với người thật, trong công việc thật.</p></div></div>''')

add('''<h1>NESTOJKO VÀ CỘNG SỰ, 2014</h1>
<div class="sub">"Expecting to Teach Enhances Learning and Organization of Knowledge in Free Recall of Text Passages", Memory &amp; Cognition, 42(7).</div>
<p>John Nestojko, Dung Bui, Nate Kornell và Elizabeth Bjork thực hiện hai thí nghiệm với sinh viên Đại học California, Los Angeles. Người tham gia đọc một bài viết trong thời gian giới hạn và không được ghi chép. Một nhóm được dặn chuẩn bị để làm bài kiểm tra; nhóm kia được dặn chuẩn bị để dạy lại cho một bạn khác. Cuối cùng không ai phải dạy: cả hai nhóm làm cùng một bài kiểm tra.</p>
<table class="t"><tr><th style="width:18%"></th><th style="width:41%">Thí nghiệm 1</th><th>Thí nghiệm 2</th></tr>
<tr><td class="k">Người tham gia</td><td>56 sinh viên</td><td>44 sinh viên</td></tr>
<tr><td class="k">Bài đọc</td><td>Khoảng 1.500 chữ, về chiến tranh Krym trong phim và trong lịch sử</td><td>Khoảng 1.300 chữ, về sự phát triển của não</td></tr>
<tr><td class="k">Thời gian đọc</td><td>10 phút</td><td>9 phút</td></tr>
<tr><td class="k">Kết quả</td><td>Nhóm chuẩn bị để dạy nhớ nhiều ý hơn, trình bày mạch lạc hơn, trả lời đúng nhiều câu hơn, rõ nhất ở ý chính</td><td>Lợi thế chủ yếu ở ý chính; với chi tiết, hai nhóm gần như ngang nhau</td></tr></table>
<h2>Vì sao?</h2>
<p>Nhóm tác giả cho rằng khi biết mình sẽ phải giải thích, người học chủ động tìm ý chính và sắp xếp kiến thức thành một mạch, thay vì cố nhớ từng chi tiết rời rạc.</p>
<p class="note">Thông tin về số người, độ dài bài đọc và thời gian lấy theo bản toàn văn của bài báo. Kết quả là trung bình của nhóm, trong điều kiện phòng thí nghiệm với bài đọc ngắn.</p>''')

add('''<h1>FIORELLA VÀ MAYER, 2013</h1>
<div class="sub">Giảng lại thật. "The Relative Benefits of Learning by Teaching and Teaching Expectancy", Contemporary Educational Psychology.</div>
<p>Logan Fiorella và Richard Mayer so sánh ba cách học: học để làm bài kiểm tra, chuẩn bị để dạy lại, và chuẩn bị rồi giảng lại thật bằng một đoạn ghi hình ngắn.</p>
<table class="t"><tr><th style="width:34%">Cách học</th><th style="width:33%">Kiểm tra ngay sau đó</th><th>Kiểm tra một tuần sau</th></tr>
<tr><td class="k">Chuẩn bị để làm bài kiểm tra</td><td>Thấp hơn</td><td>Thấp hơn</td></tr>
<tr><td class="k">Chuẩn bị để dạy lại</td><td>Tốt hơn</td><td>Lợi thế mờ đi</td></tr>
<tr><td class="k">Chuẩn bị và giảng lại thật</td><td>Tốt hơn</td><td>Tốt nhất</td></tr></table>
<p class="note">Bảng trên là tóm tắt hướng kết quả theo các bài tổng quan của chính tác giả Fiorella, không phải số liệu gốc.</p>
<h2>Gợi ý cho tuần này</h2>
<p>Hai nghiên cứu gợi ý một trình tự hợp lý: chuẩn bị như thể sắp giảng lại (Thứ Năm, viết ba ý chính), rồi chia sẻ thật với người khác. Bước chia sẻ thật có thể là một bài viết năm câu, hai phút trong buổi họp, hay một cuộc trò chuyện với đồng nghiệp.</p>
<div class="box"><div class="h">Phạm vi của bằng chứng</div><div class="c"><p>Các nghiên cứu này làm với sinh viên, bài học ngắn, trong phòng thí nghiệm. Chúng không cho một con số áp dụng cho mọi người. Tài liệu này chỉ dùng hướng chung: chuẩn bị để giải thích và giải thích thật đều là những cách học tích cực.</p></div></div>''')

add('''<h1>CHIA SẺ ĐƯỢC GÌ, GIỮ RIÊNG GÌ</h1>
<div class="sub">Bảng chọn ba vùng và một phép thử.</div>
<table class="t"><tr><th style="width:22%">Vùng</th><th style="width:40%">Gồm những gì</th><th>Ví dụ</th></tr>
<tr><td class="k">1. Chia sẻ được</td><td>Cách làm, phương pháp; bài học từ sai sót của chính mình (kể ở mức chung); tài liệu công khai; câu hỏi đang tìm lời đáp</td><td>"Bảng tổng hợp có thể nhóm theo tháng chỉ với hai bước."</td></tr>
<tr><td class="k">2. Làm mờ rồi chia sẻ</td><td>Ví dụ từ công việc thật sau khi bỏ tên khách hàng, dự án, con số; mẫu biểu đã xoá dữ liệu; ảnh chụp đã che thông tin</td><td>"Một khách hàng sản xuất giảm đơn hàng đáng kể" thay cho tên và con số thật</td></tr>
<tr><td class="k">3. Giữ riêng</td><td>Thông tin khách hàng, hợp đồng, giá, số liệu chưa công bố; tài liệu có quy định bảo mật; nhận xét về người khác</td><td>Mọi điều còn phân vân: hỏi quản lý trực tiếp trước</td></tr></table>
<div class="q"><div class="t">"Nếu khách hàng hoặc quản lý của mình đọc bài này, họ có thấy thoải mái không?"</div><div class="s">Phép thử trước khi chia sẻ. Chưa chắc thì chuyển xuống một vùng.</div></div>
<h2>Áp dụng cho cộng đồng 10X</h2>
<p>Những gì chia sẻ trong 10X Excellence Hub cũng chỉ nên là cách làm và bài học. Câu chia sẻ Ngày 2 chỉ ghi <b>loại thông tin</b> mình giữ riêng (ví dụ "số liệu của khách hàng"), không ghi nội dung.</p>
<p class="note">Khi có quy định riêng của công ty về truyền thông hay mạng xã hội, quy định của công ty được ưu tiên.</p>''')

parts = [('1', 'Câu mở', 'Nói thẳng điều đã học', '"Tuần này tôi học được cách dùng bảng tổng hợp để xem chi phí theo bộ phận và tháng."'),
         ('2', 'Tình huống trước đó', 'Cho thấy giá trị của điều mới', '"Trước đây tôi lọc dữ liệu rồi cộng tay, mất gần một giờ mỗi lần."'),
         ('3', 'Cách làm', 'Đủ để người khác tự thử', '"Giờ chỉ cần kéo hai cột vào đúng chỗ."'),
         ('4', 'Lời mời dùng chung', 'Biến bài chia sẻ thành sự giúp đỡ', '"Ai cũng làm báo cáo theo bộ phận, tôi có thể chỉ trong 10 phút."'),
         ('5', 'Điều còn chưa chắc', 'Mở cửa cho phản hồi', '"Khi dữ liệu thêm dòng mới, có cách nào để bảng tự cập nhật không?"')]
add('''<h1>GIẢI PHẪU MỘT BÀI CHIA SẺ</h1>
<div class="sub">Năm phần, mỗi phần một câu. Bài mẫu minh hoạ của một người làm kế toán.</div>
<table class="t" style="font-size:9pt;line-height:13pt"><tr><th style="width:6%">#</th><th style="width:20%">Phần</th><th style="width:24%">Nhiệm vụ</th><th>Câu mẫu</th></tr>''' +
 ''.join(f'<tr><td class="k">{a}</td><td><b>{b}</b></td><td>{c}</td><td><i>{d}</i></td></tr>' for a, b, c, d in parts) + '''</table>
<h2>Năm câu hỏi của người viết</h2>
<p>Người làm báo kiểm tra một bản tin bằng những câu hỏi cơ bản. Tuần này mượn tinh thần đó: mình đã học được điều gì; trong tình huống nào; vì sao có ích cho người khác; áp dụng như thế nào; điều gì còn chưa chắc. Năm câu trả lời cũng chính là năm phần của bài.</p>
<h2>Vì sao ngắn?</h2>
<p>Một bài năm câu được đọc hết. Có nhiều điều muốn nói thì chia thành nhiều tuần: đó cũng là nhịp chia sẻ đều đặn, đúng với lời khuyên "chia sẻ phần nhỏ một cách đều đặn" của Kleon.</p>
<div class="box"><div class="h">Đọc lại trước khi gửi</div><div class="c"><ul class="b"><li>Không có tên khách hàng, dự án, con số nội bộ.</li><li>Có một ví dụ hoặc một bước cụ thể.</li><li>Có một câu hỏi thật ở cuối.</li><li>Không có câu tự khen.</li></ul></div></div>''')

add('''<h1>PHẢN HỒI VÀ NHỊP CHIA SẺ</h1>
<div class="sub">Sau khi chia sẻ, phản hồi quay lại thành việc học.</div>
<table class="t"><tr><th style="width:30%">Tình huống</th><th>Cách đón nhận</th></tr>
<tr><td class="k">Chưa ai trả lời</td><td>Bình thường. Phản hồi thường đến chậm. Lợi ích của việc chuẩn bị để giải thích vẫn còn nguyên.</td></tr>
<tr><td class="k">Có người góp thêm cách khác</td><td>Cảm ơn, ghi vào thẻ ghi chú, nối với thẻ cũ. Thử trong 20 phút học tuần sau.</td></tr>
<tr><td class="k">Có góp ý trái chiều</td><td>Cảm ơn trước, giải thích sau. Hỏi thêm một câu để hiểu rõ, không tranh luận trong nhóm chat.</td></tr>
<tr><td class="k">Có người dùng thử và hỏi lại</td><td>Đó là dấu hiệu bài chia sẻ có ích. Một cuộc trao đổi ngắn trực tiếp thường nhanh hơn nhắn tin.</td></tr></table>
<h2>Đặt nhịp chia sẻ</h2>
<p>Một nhịp tốt có ba phần: <b>khi nào</b> (một thời điểm cố định mỗi tuần), <b>ở đâu</b> (một nơi quen thuộc), <b>bao nhiêu</b> (mỗi lần một điều). Ví dụ: "chiều Thứ Năm mỗi tuần, một điều đã học, gửi nhóm chat của phòng". Gắn nhịp này cạnh khung dọn bốn ngăn của tuần #0056 là cách dễ nhớ.</p>
<h2>Nhịp chia sẻ và vòng tự đánh giá</h2>
<p>Mỗi lần chia sẻ, câu hỏi cuối bài là một lời xin phản hồi nhỏ. Sau một tháng, những phản hồi đó trở thành bằng chứng cho vòng tự đánh giá đã đặt ở tuần #0057.</p>''')

add('''<h1>LỚP MỚI CỦA HÀNH TRÌNH</h1>
<div class="sub">Mùa 3 "Học nhanh, nhớ lâu": thói quen then chốt, rồi 20 phút học có chủ đích.</div>
<p>Mười một tuần trước tập trung vào việc học của mỗi người: chọn kỹ năng và dự án học, những cách học có bằng chứng, cách ghi chép và sắp xếp, nâng tầng câu hỏi, tự đánh giá. Tuần #0058 thêm lớp cuối của chuỗi kỹ thuật: <b>đưa điều mình học ra ngoài</b>, mỗi tuần một lần.</p>
<table class="t"><tr><th style="width:24%">Thành phần</th><th>Trong tuần này</th></tr>
<tr><td class="k">Thói quen then chốt</td><td>Giữ nguyên, bảng hành trình ở Ngày 2</td></tr>
<tr><td class="k">20 phút học</td><td>Dùng để chọn, viết, chuẩn bị giảng lại điều sẽ chia sẻ</td></tr>
<tr><td class="k">Kỹ năng và dự án học</td><td>Nguồn của mọi bài chia sẻ</td></tr>
<tr><td class="k">Hộp thẻ, PARA</td><td>Phản hồi đi vào thẻ; bài chia sẻ lưu trong thư mục dự án học</td></tr>
<tr><td class="k">Nhịp chia sẻ</td><td>Lưu cho cả hành trình (Ngày 5)</td></tr></table>
<h2>Phiên bản 10X của chính mình</h2>
<p>Ở đầu Mùa 3, kỹ năng đang học chỉ là một dòng trên sổ thực hành. Cuối mùa, nó có sản phẩm, có thẻ ghi chú, có một mức thạo chứng minh bằng bằng chứng, và giờ có những đồng nghiệp đã dùng được điều mình học. Không cần một con số để thấy tiến bộ: những việc đó đã có thật.</p>
<div class="box"><div class="h">Lưu cho cả hành trình</div><div class="c"><p>Ngày 1 hiện lại thói quen, kỹ năng và dự án học (#0047). Ngày 6 gom lại mọi điều đã lưu trong Mùa 3, từ kỹ năng và dự án học (#0047), cách tự kiểm tra, trang Cornell, bộ ba kỹ năng, cung điện trí nhớ, cách trộn, bản đồ, câu hỏi khép buổi học, quy ước hộp thẻ, thư mục dự án học, vòng tự đánh giá đến nhịp chia sẻ (#0058), cùng tổng số ngày giữ thói quen.</p></div></div>''')

wk = [('Chọn hướng đi', [('0047', 'Học chuyên sâu tự định hướng', 'Kỹ năng và dự án học của quý 2'), ('0050', 'Xếp chồng kỹ năng', 'Kỹ năng đang học trong toàn bộ bộ kỹ năng')]),
      ('Học sao cho nhớ', [('0048', 'Truy hồi chủ động', 'Tự kiểm tra thay cho đọc lại'), ('0051', 'Cung điện trí nhớ', 'Ý chính gắn vào những điểm dừng quen'), ('0052', 'Học xen kẽ và khó khăn có ích', 'Trộn dạng bài, chấp nhận cảm giác khó'), ('0053', 'Bản đồ tư duy', 'Một buổi học trên một trang')]),
      ('Giữ và sắp xếp kiến thức', [('0049', 'Ghi chép Cornell', 'Trang ghi có câu hỏi gợi nhớ'), ('0055', 'Zettelkasten', 'Thẻ viết bằng lời mình, nối với thẻ cũ'), ('0056', 'Phương pháp PARA', 'Bốn ngăn cho tài liệu học')]),
      ('Hiểu sâu, tự đánh giá, chia sẻ', [('0054', 'Phân loại Bloom', 'Câu hỏi ở những tầng cao hơn'), ('0057', 'Dunning-Kruger và tự đánh giá', 'Cảm giác cạnh bằng chứng'), ('0058', 'Xây dựng công khai', 'Mỗi tuần chia sẻ một điều')])]
rows = ''
for name, items in wk:
    for i, (n, t, d) in enumerate(items):
        rows += f'<tr>{f"<td class=k rowspan={len(items)}>{name}</td>" if i == 0 else ""}<td>#{n}</td><td><b>{t}</b></td><td>{d}</td></tr>'
add(f'''<h1>MƯỜI HAI TUẦN MÙA 3</h1>
<div class="sub">05.04 đến 26.06.2027, nhìn theo bốn chặng.</div>
<table class="t" style="font-size:9pt;line-height:13pt"><tr><th style="width:22%">Chặng</th><th style="width:10%">Tuần</th><th style="width:32%">Công thức</th><th>Lớp thêm cho 20 phút học</th></tr>{rows}</table>
<p>Mười hai tuần có hai kỳ nghỉ lễ (Giỗ Tổ Hùng Vương, 30.4 và 1.5) và những tuần cuối quý dồn dập. Thói quen then chốt vẫn đi qua tất cả, và giờ mang theo một kỹ năng đang lớn lên từng tuần.</p>
<p class="note">Bảng tóm tắt nội dung các tuần của Mùa 3. Nội dung chi tiết của từng tuần xem trong tài liệu công thức của tuần đó.</p>''')

add('''<h1>ÁP DỤNG THEO VỊ TRÍ CÔNG VIỆC</h1>
<div class="sub">Một điều chia sẻ được, một nơi chia sẻ, một điều giữ riêng.</div>
<table class="t" style="font-size:9pt;line-height:13pt"><tr><th style="width:13%">Vị trí</th><th style="width:33%">Điều chia sẻ được</th><th style="width:22%">Nơi chia sẻ</th><th>Giữ riêng</th></tr>
<tr><td class="k">Quản lý</td><td>Ba câu hỏi mở dùng trong buổi kèm cặp một một</td><td>Họp quản lý cấp trung</td><td>Nội dung trao đổi với từng nhân viên</td></tr>
<tr><td class="k">Kinh doanh</td><td>Cách mở đầu bài thuyết trình bằng vấn đề của khách hàng</td><td>Họp sáng của nhóm</td><td>Tên khách hàng, giá chào</td></tr>
<tr><td class="k">Kế toán</td><td>Hai bước lập bảng tổng hợp theo bộ phận</td><td>Nhóm chat phòng kế toán</td><td>Số liệu chi phí thật</td></tr>
<tr><td class="k">Nhân sự</td><td>Câu hỏi đào sâu khi ứng viên trả lời chung chung</td><td>Nhóm tuyển dụng</td><td>Hồ sơ, kết quả của ứng viên</td></tr>
<tr><td class="k">Kỹ thuật</td><td>Cách đọc nhanh một đoạn bản vẽ điện</td><td>Buổi giao ca</td><td>Tài liệu kỹ thuật có quy định bảo mật</td></tr>
<tr><td class="k">Chăm sóc khách hàng</td><td>Câu kết email có bước tiếp theo và thời hạn</td><td>Cộng đồng 10X</td><td>Nội dung khiếu nại thật</td></tr></table>
<p>Các ví dụ chỉ mang tính gợi ý. Mỗi người chia sẻ từ dự án học của chính mình, theo quy định của công ty.</p>''')

days = [
 ('Thứ Hai 21.06', 'Nơi chia sẻ', 'Chọn nơi chia sẻ, ba điều đã học, chọn điều đầu tiên', '20 phút'),
 ('Thứ Ba 22.06', 'Ranh giới', 'Xếp ba điều vào ba vùng, viết lại cho an toàn, bảng hành trình', '20 phút'),
 ('Thứ Tư 23.06', 'Viết bài', 'Bài chia sẻ năm câu, tiêu đề ngắn', '20 phút'),
 ('Thứ Năm 24.06', 'Giảng lại', 'Ba ý chính như thể sắp giảng lại, rồi chia sẻ thật', '20 phút'),
 ('Thứ Sáu 25.06', 'Phản hồi và nhịp', 'Cảm ơn, ghi điều học thêm, đặt nhịp chia sẻ', '20 phút'),
 ('Thứ Bảy 26.06', 'Nhìn lại Mùa 3', 'Bảng gom Mùa 3, điều tự hào, điều mang vào tuần khép mùa', '25 phút')]
r = ''.join(f'<tr><td class="k">{a}</td><td><b>{b}</b></td><td>{c}</td><td>{d}</td></tr>' for a, b, c, d in days)
add(f'''<h1>LỘ TRÌNH 6 NGÀY</h1>
<div class="lead">Từ Thứ Hai 21.06 đến Thứ Bảy 26.06.2027. Chủ Nhật nghỉ, hoặc làm bù một ngày còn thiếu.</div>
<table class="t"><tr><th style="width:19%">Ngày</th><th style="width:20%">Trọng tâm</th><th>Việc chính</th><th style="width:13%">Thời lượng</th></tr>{r}</table>
<div class="box"><div class="h">Cách làm bài mỗi ngày</div><div class="c"><ul class="b">
<li>Làm ngay sau thói quen then chốt, trong khung 20 phút học của Mùa 3.</li>
<li>Mở sổ thực hành tại <b>10xexcellence.co/so-thuc-hanh</b>, chọn tuần 21.06 và đúng ngày.</li>
<li>Điền vào các ô, sổ tự ghép câu chia sẻ ở cuối trang. Dán vào bình luận bài hôm đó, rồi bấm Đánh dấu đã chia sẻ.</li>
<li>Tuần này bảng hành trình nằm ở Ngày 2.</li>
<li>Đủ 6 ngày, thẻ thành tích dải đỏ với tổng số ngày giữ thói quen hiện ra trên sổ để tải về.</li></ul></div></div>
<p class="note">Thứ Hai 21.06 là Ngày Báo chí Cách mạng Việt Nam. Tuần sau, Thứ Hai 28.06 là Ngày Gia đình Việt Nam; quý 2 khép lại Thứ Tư 30.06.</p>''')

def day(d, tag, tm, title, tagline, body):
    return f'''<div class="dh"><div><div class="d">{d}</div><div class="tag">{tag}</div></div><div class="tm">Thời lượng<b>{tm}</b></div></div>
<div class="dt">{title}</div><div class="di">{tagline}</div>{body}'''
def ci(t): return f'<div class="ci"><b>Câu chia sẻ mẫu:</b> {t}</div>'

add(day('THỨ 2', 'Nơi chia sẻ · 21.06', '20 phút', 'Chọn nơi chia sẻ và điều đầu tiên', 'Điều nhỏ cũng đáng chia sẻ.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Ngay sau thói quen then chốt, mở sổ thực hành, xem lại kỹ năng và dự án học. Người mới viết cả hai.</li>
<li>Chọn nơi chia sẻ phù hợp nhất.</li>
<li>Viết ba điều đã học từ dự án học, chọn một điều để chia sẻ đầu tiên.</li></ol>
<table class="t"><tr><th style="width:32%">Nơi chia sẻ</th><th>Hợp khi</th></tr>
<tr><td class="k">Nhóm của mình</td><td>Mọi người dùng được ngay điều mình học</td></tr>
<tr><td class="k">Buổi họp tuần</td><td>Nói hai phút, có thể hỏi đáp trực tiếp</td></tr>
<tr><td class="k">Một đồng nghiệp học cùng</td><td>Muốn trao đổi hai chiều, ít áp lực</td></tr>
<tr><td class="k">Cộng đồng 10X</td><td>Chỉ chia sẻ cách làm và bài học</td></tr></table>''' +
 ci('"Tôi sẽ chia sẻ điều mình học với nhóm của tôi. Điều đầu tiên: câu hỏi đào sâu khi ứng viên trả lời chung chung."')))

add(day('THỨ 3', 'Ranh giới · 22.06', '20 phút', 'Chia sẻ được gì, giữ riêng gì?', 'Chưa chắc thì chuyển xuống một vùng.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Xếp ba điều đã viết hôm qua vào ba vùng (trang 7).</li>
<li>Với điều thuộc vùng 2, viết lại ví dụ sau khi làm mờ.</li>
<li>Ghi lại loại thông tin mình giữ riêng.</li>
<li>Đánh dấu bảng hành trình.</li></ol>
<table class="t"><tr><th style="width:46%">Trước khi làm mờ</th><th>Sau khi làm mờ</th></tr>
<tr><td>"Khách hàng A ở Bình Dương giảm 18% đơn hàng"</td><td>"Một khách hàng sản xuất giảm đơn hàng đáng kể"</td></tr>
<tr><td>"Ứng viên Nguyễn Văn B trả lời..."</td><td>"Một ứng viên vị trí kinh doanh trả lời..."</td></tr></table>''' +
 ci('"Điều tôi chia sẻ được: cách hỏi lại khi ứng viên trả lời chung chung. Điều tôi giữ riêng: hồ sơ và kết quả phỏng vấn của ứng viên."')))

add(day('THỨ 4', 'Viết bài · 23.06', '20 phút', 'Giải phẫu một bài chia sẻ ngắn', 'Năm phần, mỗi phần một câu.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Lấy điều đã chọn ở vùng 1 hoặc vùng 2.</li>
<li>Viết bài theo năm phần (trang 8).</li>
<li>Đọc lại bằng phép thử, đặt một tiêu đề ngắn.</li></ol>
<div class="box"><div class="h">Bài mẫu của một người làm nhân sự</div><div class="c"><p><b>Một câu hỏi giúp ứng viên nói cụ thể.</b> Tuần này tôi học được cách hỏi lại khi ứng viên trả lời chung chung. Trước đây tôi hay chuyển sang câu khác và thiếu thông tin để đánh giá. Giờ tôi đề nghị ứng viên kể đúng một lần cụ thể. Ai cần bộ câu hỏi, tôi gửi ngay. Khi ứng viên vẫn trả lời chung chung lần hai, mọi người hỏi tiếp thế nào?</p></div></div>''' +
 ci('"Bài chia sẻ đầu tiên của tôi đã có bản nháp: Một câu hỏi giúp ứng viên nói cụ thể."')))

add(day('THỨ 5', 'Giảng lại · 24.06', '20 phút', 'Chuẩn bị như thể sắp giảng lại', 'Chuẩn bị để giải thích, rồi giải thích thật.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Đọc lại bản nháp, hình dung mình sắp giải thích cho một đồng nghiệp mới.</li>
<li>Viết ba ý chính người nghe cần nhớ, theo đúng trình tự.</li>
<li>Sửa bản nháp nếu cần, rồi chia sẻ ở nơi đã chọn.</li></ol>
<table class="t"><tr><th style="width:12%">#</th><th>Ba ý chính (ví dụ)</th></tr>
<tr><td class="k">1</td><td>Đề nghị ứng viên kể đúng một lần cụ thể</td></tr>
<tr><td class="k">2</td><td>Hỏi thời gian và kết quả của lần đó</td></tr>
<tr><td class="k">3</td><td>Ghi lại nguyên văn câu trả lời để đánh giá</td></tr></table>
<p>Chia sẻ trong buổi họp hay nói trực tiếp đều được tính.</p>''' +
 ci('"Tôi đã chia sẻ bài Một câu hỏi giúp ứng viên nói cụ thể với nhóm của tôi. Ba ý chính khi chuẩn bị để giảng lại: hỏi một lần cụ thể; hỏi thời gian và kết quả; ghi lại nguyên văn."')))

add(day('THỨ 6', 'Phản hồi và nhịp · 25.06', '20 phút', 'Phản hồi làm bài học sâu hơn', 'Cảm ơn trước, giải thích sau.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Xem lại phản hồi đã nhận (nếu có), cảm ơn người góp ý.</li>
<li>Ghi lại một điều học thêm nhờ phản hồi, đưa vào hộp thẻ hoặc thư mục dự án học.</li>
<li>Đặt nhịp chia sẻ: khi nào, ở đâu, mỗi lần một điều.</li></ol>
<div class="box"><div class="h">Nếu chưa có phản hồi</div><div class="c"><p>Ghi điều mình hiểu rõ hơn khi chuẩn bị để giảng lại. Một lời nhắc nhẹ, hoặc hỏi trực tiếp một người, là hoàn toàn bình thường.</p></div></div>
<table class="t"><tr><th style="width:30%">Nhịp mẫu</th><th>Chi tiết</th></tr>
<tr><td class="k">Khi nào</td><td>Chiều Thứ Năm mỗi tuần</td></tr><tr><td class="k">Ở đâu</td><td>Nhóm chat của phòng</td></tr><tr><td class="k">Bao nhiêu</td><td>Một điều đã học, năm câu</td></tr></table>''' +
 ci('"Nhịp chia sẻ của tôi: chiều Thứ Năm mỗi tuần, một điều đã học, gửi nhóm chat của phòng. Điều tôi học thêm nhờ phản hồi: hỏi ứng viên kể một lần cụ thể có thời gian và kết quả."')))

add(day('THỨ 7', 'Nhìn lại Mùa 3 · 26.06', '25 phút', 'Nhìn lại mười hai tuần Mùa 3', 'Mỗi chặng đều có một phần công sức của chính mình.',
 '''<h2>Sáng nay (15 phút)</h2><ol class="n">
<li>Đọc lại bảng gom Mùa 3 trên sổ thực hành.</li>
<li>Chọn chặng mình thấy tiến nhiều nhất, viết điều tự hào nhất về Mùa 3 và một điều mang vào tuần khép mùa.</li></ol>
<h2>Trước khi nghỉ Chủ Nhật (10 phút)</h2>
<ol class="n"><li>In trang Mùa 3 (trang 20 hoặc phiếu Ngày 6), điền và kẹp vào thư mục dự án học, cạnh bảng đối chiếu của tuần #0057.</li></ol>
<div class="box"><div class="h">Từ Thứ Hai 28.06</div><div class="c"><p>Tuần khép Mùa 3. Ngày Gia đình Việt Nam 28.06; quý 2 khép lại Thứ Tư 30.06. Dự án học của quý 2 đi tới đích.</p></div></div>''' +
 ci('"Mùa 3 của tôi: có bộ câu hỏi phỏng vấn đầu tiên do chính mình soạn. Điều tôi mang vào tuần khép mùa: hoàn thiện dự án học và trình bày cho trưởng nhóm."')))

stg = ['Chọn hướng đi', 'Học sao cho nhớ', 'Giữ và sắp xếp kiến thức', 'Hiểu sâu, tự đánh giá, chia sẻ']
add(f'''<h1>CÔNG CỤ IN ĐƯỢC: TRANG MÙA 3</h1>
<div class="sub">Điền, kẹp vào thư mục dự án học. Dòng cuối dùng cho tuần khép mùa.</div>
<div style="border:1.2pt solid #7b1f23;padding:9pt 11pt">
<div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-weight:900;font-size:14pt;color:#7b1f23">MÙA 3 · HỌC NHANH, NHỚ LÂU</div><div style="font-size:8pt;color:#666">05.04 đến 26.06.2027</div></div>
<table class="t" style="font-size:9pt;margin:6pt 0">{''.join(f'<tr><td class="k" style="width:30%">{l}</td><td style="height:19pt"></td></tr>' for l in ['Kỹ năng đang học', 'Dự án học (sản phẩm, ngày)', 'Mức thạo theo bằng chứng', 'Nhịp chia sẻ', 'Tổng số ngày giữ thói quen'])}</table>
<table class="t" style="font-size:9pt;margin-bottom:0"><tr><th style="width:30%">Chặng</th><th>Một điều tôi giữ lại từ chặng này</th></tr>{''.join(f'<tr><td class="k">{s}</td><td style="height:22pt"></td></tr>' for s in stg)}</table></div>
<div style="margin-top:11pt;border:1pt dashed #7b1f23;padding:8pt 12pt">
<div style="font-weight:900;font-size:11pt;color:#7b1f23">BA BÀI CHIA SẺ TIẾP THEO</div>
<table class="t" style="font-size:9pt;margin:5pt 0 0">{''.join(f'<tr><td class="k" style="width:22%">Tuần {i}</td><td style="height:19pt"></td></tr>' for i in range(1, 4))}</table></div>''')

add('''<h1>NỐI SANG TUẦN KHÉP MÙA</h1>
<div class="sub">Từ Thứ Hai 28.06.2027.</div>
<p>Tuần sau là tuần cuối của Mùa 3 và của quý 2. Thứ Hai 28.06 là Ngày Gia đình Việt Nam; Thứ Tư 30.06 quý 2 khép lại. Dự án học chọn từ đầu tháng 4 đi tới đích, và mỗi người nhìn lại kỹ năng của mình đã thay đổi ra sao sau một quý. Công thức của tuần sẽ được giới thiệu vào sáng Thứ Hai.</p>
<table class="t"><tr><th style="width:24%"></th><th style="width:38%">Tuần #0058</th><th>Tuần khép mùa</th></tr>
<tr><td class="k">Câu hỏi</td><td>Chia sẻ điều mình học thế nào?</td><td>Một quý học có chủ đích đã mang lại gì?</td></tr>
<tr><td class="k">Điều đi tiếp</td><td colspan="2">Thói quen then chốt, 20 phút học, kỹ năng và dự án học, thư mục dự án học, vòng tự đánh giá, nhịp chia sẻ</td></tr></table>
<h2>Một chuẩn bị nhỏ</h2>
<p>Mở thư mục "Sản phẩm" của dự án học, xem còn bước nào cần làm để hoàn thành trước 30.06. Ghi bước đó vào sổ đầu dòng cho sáng Thứ Hai.</p>
<div class="q"><div class="t">"Điều mình học trở nên vững hơn khi mình nói nó ra cho người khác hiểu."</div>
<div class="s">Tinh thần của Công thức #0058</div></div>''')

src = ('Các trích dẫn, số liệu và ví dụ được tổng hợp từ các nguồn công khai bao gồm: '
 'Kleon, A. (2014), <i>Show Your Work! 10 Ways to Share Your Creativity and Get Discovered</i>, Workman Publishing; '
 'Nestojko, J. F., Bui, D. C., Kornell, N. và Bjork, E. L. (2014), "Expecting to Teach Enhances Learning and Organization of Knowledge in Free Recall of Text Passages", <i>Memory &amp; Cognition</i>, 42(7), 1038 đến 1048; '
 'Fiorella, L. và Mayer, R. E. (2013), "The Relative Benefits of Learning by Teaching and Teaching Expectancy", <i>Contemporary Educational Psychology</i>, 38(4), 281 đến 288; '
 'Fiorella, L., "Learning by Teaching", bài tổng quan trên trang tài nguyên giảng dạy của Đại học New Hampshire. '
 'Liên hệ với các tuần trước trong cùng bộ tài liệu: Feynman (#0028), các tuần #0047 đến #0057 của Mùa 3 (tóm tắt theo nội dung tài liệu của từng tuần). '
 'Tên chương sách được diễn giải ngắn, không phải bản dịch nguyên văn. Các câu trong ngoặc kép là câu mẫu hoặc diễn giải. Các ví dụ công việc và tình huống do 10X Excellence Hub biên soạn.')
P.append(disclaimer(len(P) + 1, N, 'Công thức #' + N + ': Xây dựng công khai, chia sẻ điều mình học', src))

sys.path.insert(0, SP + '/w0058n'); from nbnum import nb
P = [nb(keep(x)) for x in P]
out = f'{SP}/w0058n/formula/10XHub_CongThuc_0058_Xay Dung Cong Khai_VN.pdf'
over = build(P, f'{SP}/w0058n/formula/0058.html', out)
print('pages', len(P), 'overflow', over)
