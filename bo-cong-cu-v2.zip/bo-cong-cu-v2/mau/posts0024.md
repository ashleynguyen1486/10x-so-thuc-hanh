## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 26/10)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0024_Quan Ly Nang Luong_VN.pdf (tài liệu đầy đủ của Công thức #0024)
@pdf 10XHub_NangLuong_PhieuNgay1_do-nang-luong.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0024.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** THỜI GIAN CÓ HẠN, NĂNG LƯỢNG THÌ LÀM MỚI ĐƯỢC

Tuần trước, cả nhóm đã đọc lại những ngày lỡ, viết ba kế hoạch Nếu... thì... cho ngày lịch dồn, ngày đi công tác và lúc bị chen ngang, dùng thử chúng trong tuần và dựng một tấm thẻ trên bàn làm việc. Ba kế hoạch đó vẫn nằm trên sổ thực hành và tiếp tục làm việc của chúng: bảo vệ thói quen trong ngày khó. Tuần này quay sang ngày bình thường.

**Nếu mới tham gia:** hôm nay chỉ cần hai việc. Mở sổ thực hành Ngày 1, viết câu bản sắc và một thói quen then chốt nhỏ trong công việc. Sau đó chấm năng lượng của mình ba lần trong ngày theo hướng dẫn bên dưới. Không cần biết gì về các tuần trước, ngày mai các anh chị và các bạn đã dùng được ngay con số của hôm nay.

**Hai cách nhìn một ngày làm việc**

- Nhìn theo thời gian: ngày nào cũng có 8 giờ làm việc, giờ nào cũng như giờ nào. Nhìn theo năng lượng: có giờ làm một việc khó thấy nhẹ, có giờ đọc một trang tài liệu cũng thấy nặng.
- Nhìn theo thời gian: thói quen đặt vào giờ còn trống. Nhìn theo năng lượng: thói quen đặt vào giờ mình làm tốt nhất.
- Nhìn theo thời gian: thiếu giờ thì làm thêm giờ. Nhìn theo năng lượng: làm việc theo từng phiên, xen kẽ những lần nghỉ ngắn để làm đầy lại.
- Nhìn theo thời gian: lịch kín là lịch tốt. Nhìn theo năng lượng: lịch tốt là lịch đặt đúng việc vào đúng lúc.

Cách nhìn thứ hai đến từ Jim Loehr và Tony Schwartz trong cuốn The Power of Full Engagement (2003). Hai tác giả lập luận rằng thời gian là nguồn lực có hạn, còn năng lượng là nguồn lực có thể làm mới. Năm 2007, Schwartz và Catherine McCarthy viết tiếp ý này trên Harvard Business Review với bài "Manage Your Energy, Not Your Time", tạm dịch: quản lý năng lượng, không chỉ quản lý thời gian.

Họ mô tả bốn nguồn năng lượng trong công việc: thể chất, cảm xúc, trí tuệ và ý nghĩa. Sáu ngày tuần này đi qua cả bốn, và tất cả đều quay về một điểm: đặt thói quen then chốt vào chỗ mình có nhiều năng lượng nhất.

**Lưu ý trước khi bắt đầu:** tuần này nói về năng lượng ở mức thói quen làm việc: chọn giờ, nghỉ ngắn, cách nhìn một tình huống, lý do giữ thói quen. Đây không phải lời khuyên về sức khỏe. Ai có vấn đề sức khỏe cần quan tâm thì nên trao đổi với bác sĩ hoặc chuyên gia.

**Sáu ngày của tuần này**

Thứ Hai đo năng lượng ba lần. Thứ Ba tìm giờ vàng và dời thói quen vào. Thứ Tư thêm nghỉ ngắn có chủ đích. Thứ Năm một việc tiếp sức cảm xúc. Thứ Sáu nối thói quen với điều mình thấy có ý nghĩa. Thứ Bảy sắp lịch năng lượng cho tuần sau. Chủ Nhật nghỉ.

**Ngày 1 (khoảng 15 phút, chia ba lần): Đo năng lượng**

1. Đặt ba lời nhắc trên điện thoại: khoảng 9 giờ, 13 giờ và 16 giờ.
2. Mỗi lần nhắc, dừng lại một phút và chấm năng lượng theo thang 1 đến 5. Một là rất uể oải, khó tập trung. Ba là bình thường. Năm là tỉnh táo, làm việc khó vẫn thấy nhẹ.
3. Ghi thêm một dòng: lúc năng lượng cao nhất và thấp nhất, mình đang làm việc gì.

Con số một ngày chưa nói được nhiều. Nhưng đặt nó cạnh trí nhớ về năm ngày làm việc gần nhất, ngày mai sẽ đủ để tìm ra giờ vàng của mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-1. Thói quen đã chọn ở các tuần trước sẽ tự hiện lại.

Chia sẻ hôm nay: "Thói quen tôi đang giữ: .... Năng lượng hôm nay: 9 giờ ..., 13 giờ ..., 16 giờ ... (thang 5).". Ai chưa chấm đủ ba lần thì chia sẻ những lần đã chấm, cuối ngày bổ sung nha.


## Bài 2: Ngày 2 (Thứ Ba 27/10)
@img 2_gio-vang
@pdf 10XHub_NangLuong_PhieuNgay2_gio-vang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: GIỜ VÀNG CỦA MÌNH NẰM Ở ĐÂU?

Bài hôm nay là một chuỗi câu hỏi. Mỗi câu chỉ cần trả lời trong đầu vài giây, nhưng đi hết chuỗi, phần lớn mọi người sẽ thấy giờ vàng của mình hiện ra khá rõ.

**Câu hỏi 1: Con số hôm qua cao nhất vào lúc nào?**

Nhìn lại ba con số đã chấm. Rồi tự hỏi: hôm qua có phải một ngày bình thường không? Nếu hôm qua có một cuộc họp căng thẳng hay một chuyến đi xa, con số có thể lệch.

**Câu hỏi 2: Tuần trước, việc khó nhất mình làm xong vào giờ nào?**

Báo cáo khó viết, cuộc gọi khó nói, bảng số liệu khó đối chiếu. Phần lớn chúng ta làm xong việc khó vào một khung giờ khá giống nhau mỗi ngày, dù chưa bao giờ để ý.

**Câu hỏi 3: Giờ nào mình hay mở điện thoại mà không có lý do?**

Đây là câu hỏi ngược. Khung giờ tay tự tìm đến điện thoại thường là khung năng lượng đang xuống. Giờ vàng thường nằm cách xa khung đó.

**Câu hỏi 4: Giờ vàng đó hiện đang dùng cho việc gì?**

Câu hỏi này hay làm nhiều người bất ngờ. Không ít người dành giờ tỉnh táo nhất cho việc trả lời thư và duyệt chứng từ, rồi để việc cần suy nghĩ nhất vào cuối chiều.

**Câu hỏi 5: Thói quen then chốt đang nằm ở đâu so với giờ vàng?**

Trong bài viết trên Harvard Business Review, Schwartz và McCarthy nhắc đến nhịp làm việc theo chu kỳ khoảng 90 đến 120 phút, trong đó cơ thể đi từ trạng thái nhiều năng lượng xuống thấp dần. Không cần đo chính xác chu kỳ của mình. Chỉ cần biết: trong ngày có những khung giờ làm việc khó thấy nhẹ hơn, và thói quen then chốt nên được ưu tiên vào đó.

**Sau năm câu hỏi**

Có bốn khả năng. Thói quen đã nằm trong giờ vàng: giữ nguyên và bảo vệ khung giờ đó trên lịch. Dời vào được: từ ngày mai làm trong giờ vàng. Dời được một phần: làm phiên bản tối thiểu trong giờ vàng, phần còn lại làm sau. Chưa dời được vì giờ vàng kín lịch cố định: chọn khung cao thứ hai.

**Ngày 2 (20 phút)**

1. Trên sổ thực hành, đánh dấu những khung giờ mình thường tỉnh táo nhất trong tuần.
2. Viết giờ vàng của mình: khung giờ cao nhất, lặp lại nhiều ngày nhất.
3. Quyết định dời thói quen then chốt vào giờ vàng và sửa lời nhắc trên lịch ngay hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-2.

Chia sẻ hôm nay: "Giờ vàng của tôi: .... Từ ngày mai tôi làm thói quen trong khung giờ này.". Giờ vàng của mỗi người mỗi khác, đọc bình luận của nhau sẽ thấy điều đó rất rõ nha.


## Bài 3: Ngày 3 (Thứ Tư 28/10)
@img 3_nghi-ngan
@pdf 10XHub_NangLuong_PhieuNgay3_nghi-ngan.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NĂM PHÚT NGHỈ CÓ CHỦ ĐÍCH

Làm liền một mạch từ sáng đến trưa nghe có vẻ chăm chỉ. Nhưng phần lớn chúng ta đều biết cảm giác của giờ thứ ba liên tục trước màn hình: đọc một đoạn ba lần vẫn chưa hiểu.

Schwartz và McCarthy đề xuất nghỉ ngắn nhưng đều đặn, khoảng mỗi 90 đến 120 phút. Trong bài viết năm 2007, họ kể về một chương trình quản lý năng lượng thử nghiệm với 106 nhân viên tại 12 chi nhánh của ngân hàng Wachovia ở miền nam bang New Jersey (Mỹ). Theo số liệu các tác giả công bố, trong ba tháng đầu, nhóm tham gia có mức tăng doanh thu từ cho vay so với cùng kỳ năm trước cao hơn nhóm đối chứng 13 điểm phần trăm, và mức tăng từ tiền gửi cao hơn 20 điểm phần trăm. Đây là số liệu của một chương trình trong một doanh nghiệp, do chính các tác giả báo cáo, nên nên đọc như một ví dụ minh hoạ hơn là một kết luận chung.

Điều quan trọng với hành trình của chúng ta là chữ "có chủ đích". Nghỉ có chủ đích khác với lướt điện thoại: mình chọn trước cách nghỉ, và cách nghỉ đó làm đầy lại, không lấy thêm sự chú ý.

**Danh sách nghỉ ngắn trong giờ làm việc**

Chọn một cách hợp với chỗ làm của mình:

1. Đứng dậy đi lại: một vòng hành lang, lên xuống một tầng cầu thang. Hợp với người ngồi nhiều: kế toán, kỹ thuật, thiết kế.
2. Nhìn xa, uống nước: rời mắt khỏi màn hình, nhìn ra cửa sổ, rót một ly nước. Hợp với người làm việc với số liệu, văn bản dài.
3. Hít thở chậm: ngồi thẳng, thở chậm vài nhịp, không mở điện thoại. Hợp với ngày nhiều cuộc gọi, chăm sóc khách hàng.
4. Trò chuyện ngắn: hỏi thăm một đồng nghiệp vài câu, không bàn việc. Hợp với người làm việc một mình nhiều giờ.

Và ba điều không tính là nghỉ có chủ đích: lướt mạng xã hội, đọc tin tức, mở hộp thư "xem nhanh". Ba việc này vẫn lấy đi sự chú ý, chỉ là theo một hướng khác.

**Đặt nghỉ ngắn ở đâu trong hành trình**

Chỗ tốt nhất là ngay sau thói quen then chốt. Làm xong phiên trong giờ vàng, nghỉ năm phút, rồi mới sang việc tiếp theo. Thói quen có điểm kết thúc rõ ràng, và phiên làm việc sau bắt đầu với năng lượng tốt hơn.

**Ngày 3 (15 phút)**

1. Bấm bảng hành trình cho những ngày đã làm thói quen từ Thứ Hai đến nay.
2. Chọn một cách nghỉ ngắn và quyết định nghỉ sau việc gì.
3. Thử ngay: bấm đồng hồ năm phút trên sổ, rời màn hình và nghỉ đúng như đã chọn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-3.

Chia sẻ hôm nay: "Sau ..., tôi nghỉ ngắn bằng cách ...". Ai thấy năm phút là lâu thì bắt đầu với ba phút cũng được nha.


## Bài 4: Ngày 4 (Thứ Năm 29/10)
@img 4_tiep-suc
@pdf 10XHub_NangLuong_PhieuNgay4_tiep-suc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BA ỐNG KÍNH CHO MỘT CUỘC GỌI KHÓ

Mười giờ sáng, bạn Vy ở bộ phận chăm sóc khách hàng nhận một cuộc gọi. Vy là nhân vật minh hoạ, nhưng cuộc gọi thì rất thật: khách hàng nói gay gắt vì đơn hàng giao trễ hai ngày, giọng mỗi lúc một to.

Cuộc gọi kết thúc sau 15 phút. Vy giải quyết được việc, nhưng ngồi xuống thì thấy cả buổi sáng như đã cạn. Phiên thói quen đặt lúc 10 giờ 30, đọc lại ba phản hồi tích cực của khách để rút kinh nghiệm, bỗng trở nên rất nặng.

Đây là năng lượng cảm xúc, nguồn thứ hai trong bốn nguồn của Loehr và Schwartz. Một cảm xúc tiêu cực kéo dài không làm mình mệt về thể chất, nhưng lấy đi rất nhiều năng lượng để làm việc khác.

Trong bài viết trên Harvard Business Review, Schwartz và McCarthy gợi ý nhìn lại tình huống qua ba "ống kính". Vy thử cả ba:

**Ống kính ngược: người kia sẽ nói gì, và điều họ nói đúng ở điểm nào?** Khách hàng có lẽ sẽ nói: "Tôi đã hứa với khách của tôi là hàng về Thứ Hai. Giờ tôi phải gọi xin lỗi họ." Điều khách nói đúng: đơn hàng trễ thật. Vy cũng nhận ra cơn giận không nhắm vào cá nhân mình, khách đang chịu áp lực từ phía sau.

**Ống kính xa: sáu tháng nữa nhìn lại, chuyện này còn quan trọng đến đâu?** Một cuộc gọi khó trong hàng trăm cuộc gọi. Điều còn lại sau sáu tháng là khách hàng đó có tiếp tục đặt hàng hay không, và điều này phụ thuộc vào cách Vy xử lý hôm nay nhiều hơn là vào 15 phút căng thẳng.

**Ống kính rộng: dù kết quả ra sao, mình học được gì?** Vy ghi lại một câu: báo trước cho khách ngay khi biết đơn có nguy cơ trễ, đừng chờ khách gọi.

Ba câu hỏi mất chưa đến năm phút. Vy đứng dậy rót một ly nước, quay lại bàn và làm phiên thói quen, muộn hơn dự kiến 10 phút nhưng vẫn làm.

**Việc tiếp sức thứ hai: một lời cảm ơn cụ thể**

Cuối buổi sáng, Vy nhắn cho anh Tuấn bên kho vận: "Cảm ơn anh đã gọi lại cho khách trước 10 giờ, nhờ vậy em có thông tin chính xác để trả lời." Schwartz và McCarthy xếp việc bày tỏ sự ghi nhận vào nhóm việc tiếp sức cảm xúc, và lời cảm ơn càng cụ thể thì càng có giá trị: ai, việc gì, việc đó giúp được điều gì.

**Ngày 4 (20 phút)**

1. Ghi lại một tình huống gần đây làm mình hụt năng lượng.
2. Chọn một ống kính và viết điều mình thấy khi nhìn qua đó.
3. Gửi một lời cảm ơn cụ thể cho một đồng nghiệp hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-4.

Chia sẻ hôm nay: "Tôi nhìn lại tình huống ... qua .... Lời cảm ơn hôm nay: ...". Không cần kể chi tiết tình huống, một dòng ngắn là đủ nha.


## Bài 5: Ngày 5 (Thứ Sáu 30/10)
@img 5_y-nghia
@pdf 10XHub_NangLuong_PhieuNgay5_y-nghia.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MỘT LÁ THƯ NGẮN VỀ LÝ DO GIỮ THÓI QUEN

Nguồn năng lượng thứ tư trong mô hình của Loehr và Schwartz là ý nghĩa: cảm giác việc mình làm phục vụ một điều quan trọng với mình. Trong bài viết năm 2007, Schwartz và McCarthy gợi ý dành thời gian cho những việc mình làm tốt nhất và thấy đáng làm nhất. Khi một thói quen được nối với điều đó, những ngày không có hứng, mình vẫn có một lý do để bắt đầu.

Bài hôm nay đi theo dạng một lá thư mẫu. Người viết là một kế toán tổng hợp, thói quen then chốt của chị là mỗi sáng 20 phút đối chiếu số liệu trước khi mở hộp thư. Lá thư viết cho chính mình của một năm sau.

**Thư mẫu**

"Gửi tôi của tháng 10 năm sau,

Tuần này tôi tìm ra giờ vàng của mình là 8 giờ đến 9 giờ 30, và dời 20 phút đối chiếu vào đó. Nhưng hôm nay tôi muốn ghi lại vì sao tôi giữ thói quen này, để những sáng không muốn làm, tôi đọc lại.

Tôi giữ thói quen này vì các bạn ở phòng kinh doanh. Mỗi lần số liệu công nợ sai, các bạn phải gọi xin lỗi khách. Hai mươi phút mỗi sáng của tôi là bớt đi một cuộc gọi như vậy.

Tôi giữ thói quen này vì nó dùng đúng điểm mạnh của tôi: tỉ mỉ và kiên nhẫn với con số. Đó là việc tôi làm tốt và thấy đáng làm.

Và tôi giữ thói quen này vì một năm nữa, tôi muốn đủ tự tin để nhận phần lập báo cáo quản trị cho ban giám đốc.

Nếu đọc thư này vào một ngày đã bỏ thói quen, thì cứ bắt đầu lại bằng phiên bản tối thiểu: kiểm tra một khoản chênh lệch."

**Viết thư của mình**

Lá thư không cần dài như vậy. Ba câu hỏi dưới đây là đủ để viết một đoạn ngắn:

1. Ai được lợi khi mình giữ thói quen này? Một đồng nghiệp, một nhóm, một khách hàng.
2. Thói quen này dùng điểm mạnh nào của mình?
3. Một năm nữa, nhờ thói quen này, mình mong làm được điều gì?

Sau đó gom lại thành một câu: "Tôi giữ thói quen này vì ...". Câu này viết vào mặt sau tấm thẻ trên bàn, ngay dưới câu bản sắc.

**Ngày 5 (20 phút)**

1. Trả lời ba câu hỏi trên sổ thực hành.
2. Viết câu ý nghĩa của mình.
3. Ai muốn thì viết thêm một lá thư ngắn như thư mẫu, giữ riêng cho mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-5.

Chia sẻ hôm nay: "Tôi giữ thói quen ... vì ...". Lá thư là của riêng mỗi người, chỉ cần chia sẻ câu ý nghĩa thôi nha.


## Bài 6: Ngày 6 (Thứ Bảy 31/10)
@img 6_lich-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_NangLuong_PhieuNgay6_lich-tuan.pdf (phiếu thực hành và lịch năng lượng tuần để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: SẮP TUẦN SAU THEO NĂNG LƯỢNG

Năm ngày vừa qua cho mỗi người bốn câu trả lời: giờ vàng, một cách nghỉ ngắn, một cách tiếp sức cảm xúc và một câu ý nghĩa. Hôm nay đặt tất cả lên lịch của tuần sau.

**Bảng chọn: ba kiểu giờ vàng**

Chọn kiểu gần với mình nhất, rồi sắp tuần sau theo gợi ý.

**Kiểu 1: năng lượng cao vào buổi sáng.**
- Thói quen then chốt và việc cần tập trung nhất đặt trước 11 giờ.
- Họp, trao đổi, việc hành chính dời sang buổi chiều.
- Hộp thư mở sau phiên thói quen, không mở trước.
- Nghỉ ngắn ngay sau phiên buổi sáng và giữa buổi chiều.

**Kiểu 2: năng lượng cao vào buổi chiều.**
- Buổi sáng làm việc nhẹ: trả lời thư, sắp xếp tài liệu, cuộc gọi ngắn.
- Thói quen then chốt và việc khó đặt sau giờ nghỉ trưa, khi năng lượng đã lên.
- Kế hoạch Nếu... thì... cho buổi chiều cần chắc hơn, vì cuối ngày dễ có việc gấp chen vào.

**Kiểu 3: năng lượng thay đổi theo ngày.**
- Mỗi chiều Chủ Nhật dành 10 phút xem lịch tuần, chọn giờ vàng cho từng ngày.
- Ngày có ca, có lịch đi công tác: dùng kế hoạch Nếu... thì... và phiên bản tối thiểu.
- Giữ một mốc cố định nhỏ mỗi ngày, ví dụ làm thói quen ngay sau khi đến chỗ làm.

Ở cả ba kiểu, có hai việc giống nhau: một việc khó được dời vào giờ vàng, và một việc nhẹ được dời ra khỏi giờ vàng. Hai việc dời chỗ đó thường tạo khác biệt lớn hơn việc cố làm nhiều hơn.

**Sáng nay (15 phút)**

1. Chọn kiểu giờ vàng của mình.
2. Viết một việc khó dời vào giờ vàng tuần sau, và một việc nhẹ dời ra khỏi giờ vàng.
3. Đặt khung giờ vàng lặp lại trên lịch từ Thứ Hai đến Thứ Bảy tuần sau. Phiếu Ngày 6 có trang lịch năng lượng để in.

**Trước khi nghỉ Chủ Nhật (10 phút)**

Bấm nốt bảng hành trình của tuần, kể cả ngày chỉ làm phiên bản tối thiểu.

Tuần sau, Công thức #0025 về Công việc sâu sẽ nâng chính thói quen này thành một khối làm việc sâu được bảo vệ trong lịch, đặt đúng vào giờ vàng vừa tìm ra.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0024-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi giữ thói quen ... ngày. Tuần sau giờ vàng của tôi: ..., nghỉ ngắn bằng cách ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Năng lượng cho thói quen: sáu cột T2 đến T7 cao dần theo những ngày đã giữ thói quen, kèm giờ vàng của mình. Nhập tên, tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật là ngày làm đầy năng lượng cho cả tuần sau, các anh chị và các bạn nghỉ ngơi trọn vẹn nha. Chuỗi thói quen không bị tính là lỡ.
