## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 14/12)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0031_Kaizen_VN.pdf (tài liệu đầy đủ của Công thức #0031)
@pdf 10XHub_Kaizen_PhieuNgay1_nhin-lai.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0031.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** KAIZEN: NHÌN LẠI NĂM 2026 ĐỂ TỐT HƠN MỘT CHÚT

**Hai chữ, một cách làm việc**

Kaizen là một từ tiếng Nhật ghép từ hai chữ. "Kai" nghĩa là thay đổi. "Zen" nghĩa là tốt. Ghép lại, Kaizen thường được hiểu là thay đổi để tốt hơn, và trong quản trị, là cải tiến liên tục bằng những bước nhỏ, do chính những người đang làm công việc đó thực hiện mỗi ngày.

Từ này được biết đến rộng rãi bên ngoài Nhật Bản nhờ cuốn sách "Kaizen: The Key to Japan's Competitive Success" của Masaaki Imai, xuất bản năm 1986. Imai mô tả cách các doanh nghiệp Nhật, trong đó Toyota là ví dụ quen thuộc nhất, xây dựng năng lực cạnh tranh không chỉ bằng những bước nhảy lớn về công nghệ, mà bằng hàng nghìn cải tiến nhỏ của nhân viên ở mọi cấp.

Ba ý chính trong cách hiểu Kaizen:

- **Nhỏ:** một cải tiến tốt là cải tiến làm được ngay, không cần ngân sách hay phê duyệt.
- **Liên tục:** cải tiến không phải một dự án có ngày kết thúc, mà là một thói quen của tổ chức.
- **Mọi người:** người hiểu rõ nhất một công việc là người đang làm nó mỗi ngày.

Với các anh chị và các bạn đã đi cùng hành trình thói quen từ tháng 10, ba ý này rất quen. Một thói quen nhỏ, giữ đều mỗi ngày, mỗi tuần thêm một lớp. Hành trình này vốn đã là một dạng Kaizen cho chính mình.

Tuần trước, cả nhóm đã gom và khép những việc dở dang, rồi thêm cho thói quen một nghi thức kết thúc ngày. Nghi thức đó tiếp tục chạy mỗi chiều. Tuần này là tuần nhiều công ty họp tổng kết năm, nên cũng là lúc hợp lý để mỗi người nhìn lại năm của chính mình theo tinh thần cải tiến: không tìm lỗi, mà tìm những điều đã tốt hơn, rồi chọn một bước nhỏ tiếp theo.

**Nếu mới tham gia:** tuần này không cần biết gì về các tuần trước. Hôm nay viết một thói quen nhỏ mình muốn giữ mỗi ngày làm việc vào sổ thực hành, rồi nhìn lại năm 2026 và viết ba việc mình đã làm tốt hơn năm trước. Từ Thứ Ba, cả nhóm sẽ cải tiến thói quen đó từng bước nhỏ.

**Một phép tính, và một lưu ý**

Phép tính sau thường được dùng để minh hoạ tinh thần Kaizen: nếu mỗi ngày tốt hơn 1%, sau 365 ngày, 1,01 mũ 365 xấp xỉ 37,8 lần. Nếu mỗi ngày kém đi 1%, 0,99 mũ 365 chỉ còn khoảng 0,03.

Cần nói rõ: đây chỉ là một phép tính minh hoạ, không phải một lời hứa. Năng lực con người không tăng theo cấp số nhân đều đặn như vậy. Giá trị của phép tính nằm ở chỗ khác: nó cho thấy những thay đổi rất nhỏ, khi được giữ đủ lâu, có ý nghĩa lớn hơn mình tưởng.

**Sáu ngày của tuần**

- Thứ Hai: nhìn lại năm 2026, ba việc mình đã làm tốt hơn.
- Thứ Ba: chọn một cải tiến nhỏ nhất cho thói quen then chốt.
- Thứ Tư: chạy một vòng Kế hoạch, Thực hiện, Kiểm tra, Điều chỉnh trong một ngày.
- Thứ Năm: cải tiến chỗ làm việc theo tinh thần 5S, phiên bản nhỏ.
- Thứ Sáu: xin một góp ý từ đồng nghiệp.
- Thứ Bảy: sổ cải tiến năm 2026.

**Ngày 1 (25 phút): Ba việc mình đã làm tốt hơn**

1. Mở sổ thực hành, kiểm tra dòng "Thói quen đang giữ". Người mới điền câu bản sắc và thói quen ở hai ô bên dưới.
2. Nhớ lại cách mình làm việc vào tháng 12 năm 2025. Mình xử lý báo cáo thế nào, họp ra sao, quản lý thời gian thế nào?
3. So với hiện tại, viết ba việc mình đã làm tốt hơn. Càng cụ thể càng tốt: "trả lời khách hàng trong ngày thay vì hai ngày", không phải "làm việc tốt hơn".
4. Với mỗi việc, ghi một điều đã giúp mình tốt hơn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-1.

Chia sẻ hôm nay: "Năm 2026, ba việc tôi đã làm tốt hơn: ...; ...; ...". Bình luận kèm câu này để cả nhóm cùng nhìn lại một năm đã qua nha.


## Bài 2: Ngày 2 (Thứ Ba 15/12)
@img 2_cai-tien-nho
@pdf 10XHub_Kaizen_PhieuNgay2_cai-tien-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CẢI TIẾN NHỎ NHẤT CHO THÓI QUEN

Một cải tiến theo tinh thần Kaizen nhỏ đến mức nào? Đủ nhỏ để làm được ngay sáng mai, không cần hỏi ai, không cần mua gì. Hôm nay là một danh sách gợi ý theo năm hướng, mỗi hướng kèm ví dụ ở nhiều vị trí công việc.

**1. Bớt một bước**

Đếm các bước phải làm trước khi bắt đầu thói quen, rồi bỏ một bước.

- Quản lý: ghim tệp kế hoạch tuần lên thanh tác vụ, khỏi phải tìm trong thư mục.
- Kế toán: lưu sẵn bộ lọc báo cáo công nợ, khỏi chọn lại mỗi chiều.

**2. Đổi thời điểm**

Dời thói quen sang khung giờ ít bị chen ngang hơn, dù chỉ mười lăm phút.

- Kinh doanh: gọi khách hàng lúc 8 giờ 45 thay vì 9 giờ 30, trước khi họp giao ban.
- Kỹ thuật: ghi điểm cải tiến ngay khi nhận ca, không đợi cuối ca.

**3. Đổi chỗ**

Một chỗ ngồi, một phòng họp nhỏ, một góc bàn riêng có thể giúp đầu óc vào việc nhanh hơn.

- Nhân sự: viết ghi nhận nhân viên ở phòng họp nhỏ trống buổi sáng thay vì tại bàn gần lối đi.

**4. Thêm một tín hiệu**

Một vật hoặc một lời nhắc đặt đúng chỗ.

- Chăm sóc khách hàng: dán tờ giấy ghi chú "một bài học" ở mép màn hình.
- Mọi vị trí: đặt lịch hẹn lặp lại có tên thói quen.

**5. Đo lại**

Thêm một con số đơn giản để thấy tiến độ.

- Kinh doanh: ghi số khách hàng đã gọi mỗi ngày trên một tờ giấy.
- Quản lý: ghi số phút làm việc sâu thật sự, không phải số phút ngồi vào bàn.

**Cách chọn**

Đọc lại bảng hành trình các tuần qua. Ngày nào lỡ thói quen, và vì sao? Cải tiến tốt nhất thường nằm ngay chỗ thói quen hay bị vấp. Chọn một hướng, viết một cải tiến, và tự hỏi: sáng mai làm được ngay không? Nếu câu trả lời là "phải chuẩn bị thêm", cải tiến đó vẫn còn quá lớn. Thu nhỏ tiếp.

Một lưu ý quan trọng: tuần này chỉ chọn một cải tiến. Kaizen không phải thay đổi nhiều điều cùng lúc, mà là thay đổi đúng một điều, xem kết quả, rồi mới đến điều tiếp theo.

**Ngày 2 (20 phút)**

1. Đọc lại bảng hành trình, tìm chỗ thói quen hay bị vấp.
2. Chọn một trong năm hướng.
3. Viết đúng một cải tiến nhỏ nhất, làm được ngay sáng mai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-2.

Chia sẻ hôm nay: "Thói quen của tôi: .... Cải tiến nhỏ nhất tuần này: ...".


## Bài 3: Ngày 3 (Thứ Tư 16/12)
@img 3_pdca
@pdf 10XHub_Kaizen_PhieuNgay3_pdca.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: MỘT VÒNG PDCA TRONG MỘT NGÀY

Hôm nay đi theo dạng hỏi đáp, vì chu trình PDCA nghe quen nhưng ít khi được dùng cho một việc nhỏ như thói quen cá nhân.

**Hỏi: PDCA là gì?**

Đáp: Là bốn bước của một vòng cải tiến, viết tắt từ bốn chữ cái đầu trong tiếng Anh: Kế hoạch, Thực hiện, Kiểm tra, Điều chỉnh. Ý tưởng gốc thường được gắn với Walter Shewhart, nhà thống kê làm việc tại Bell Labs, và được W. Edwards Deming phổ biến, đặc biệt tại Nhật Bản từ những năm 1950. Vì vậy chu trình còn được gọi là vòng tròn Deming. Về sau, chính Deming thích dùng chữ "Nghiên cứu" thay cho "Kiểm tra", để nhấn mạnh việc học từ kết quả.

**Hỏi: Một vòng PDCA có cần cả tháng không?**

Đáp: Với dự án lớn, có thể. Với một cải tiến nhỏ cho thói quen, một ngày là đủ. Sáng lập kế hoạch, trong ngày thực hiện, cuối ngày kiểm tra, và quyết định cho ngày mai.

**Hỏi: Kế hoạch cho một cải tiến nhỏ gồm những gì?**

Đáp: Ba dòng. Mình sẽ thay đổi điều gì. Mình mong điều gì xảy ra. Mình sẽ đo bằng cách nào. Ví dụ: "Ghim tệp kế hoạch lên thanh tác vụ. Mong vào việc nhanh hơn. Đo số phút từ lúc ngồi xuống đến lúc viết dòng đầu tiên."

**Hỏi: Kiểm tra bằng gì khi không có số liệu?**

Đáp: Bằng một so sánh đơn giản với hôm qua. Hôm qua mất mười hai phút để vào việc, hôm nay mất bốn phút. Hoặc một câu nhận xét: hôm nay có bị chen ngang không, có thấy dễ bắt đầu hơn không. Bảng hành trình tuần này nằm ngay ở Ngày 3, bấm các ngày đã làm thói quen để có thêm một nguồn so sánh.

**Hỏi: Kiểm tra xong thì làm gì?**

Đáp: Chọn một trong ba hướng. Chuẩn hoá: cải tiến có tác dụng, giữ lại thành cách làm mới. Điều chỉnh: có tác dụng một phần, sửa lại và thử tiếp ngày mai. Bỏ: không có tác dụng, quay lại cách cũ và chọn cải tiến khác. Cả ba hướng đều là kết quả tốt, vì mình đã học được điều gì đó.

**Hỏi: Nếu cải tiến không có tác dụng, có phải là thất bại không?**

Đáp: Không. Trong tinh thần Kaizen, một thử nghiệm nhỏ cho kết quả rõ ràng, dù là "không hiệu quả", vẫn có giá trị. Điều cần tránh là không kiểm tra, cứ thế làm tiếp mà không biết thay đổi có giúp gì không.

**Ngày 3 (30 phút, chia trong ngày)**

1. Sáng: viết kế hoạch ba dòng cho cải tiến đã chọn hôm qua.
2. Trong ngày: thực hiện cải tiến khi làm thói quen.
3. Cuối ngày: ghi kết quả so với hôm qua.
4. Chọn: chuẩn hoá, điều chỉnh hay bỏ. Bấm bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-3.

Chia sẻ hôm nay: "Vòng PDCA hôm nay, tôi thử: .... Kết quả: .... Quyết định: ...".


## Bài 4: Ngày 4 (Thứ Năm 17/12)
@img 4_5s
@pdf 10XHub_Kaizen_PhieuNgay4_5s.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: TRƯỚC VÀ SAU MỘT BUỔI 5S NHỎ

5S là một trong những công cụ cải tiến quen thuộc nhất ở các nhà máy và văn phòng tại Việt Nam. Năm chữ S trong tiếng Việt: Sàng lọc, Sắp xếp, Sạch sẽ, Săn sóc, Sẵn sàng. Hôm nay dùng 5S ở quy mô nhỏ nhất: chỗ làm việc của chính mình, để thói quen then chốt dễ bắt đầu hơn. Mỗi chữ S được mô tả bằng một cặp trước và sau.

**Sàng lọc: giữ lại điều cần, bỏ điều không cần**

Trước: trên bàn có ba chồng tài liệu, hai chồng là hồ sơ của các dự án đã kết thúc.
Sau: hồ sơ cũ được lưu trữ, trên bàn chỉ còn tài liệu của tuần này.

**Sắp xếp: mỗi vật có một chỗ cố định**

Trước: mỗi sáng mất vài phút tìm sổ ghi chép và bút.
Sau: sổ và bút luôn nằm bên phải bàn phím, ai nhìn cũng biết.

**Sạch sẽ: làm sạch để phát hiện vấn đề**

Trước: màn hình máy tính có hơn năm mươi biểu tượng, tệp mới tải về nằm lẫn với tệp cũ.
Sau: chỉ còn ba thư mục: Đang làm, Tham khảo, Lưu trữ.

**Săn sóc: duy trì ba S đầu bằng một quy định nhỏ**

Trước: dọn bàn một lần, hai tuần sau mặt bàn lại bừa như cũ.
Sau: năm phút cuối ngày dọn bàn, ghép vào nghi thức kết thúc ngày của tuần trước.

**Sẵn sàng: biến việc duy trì thành thói quen**

Trước: dọn dẹp khi nào thấy bừa.
Sau: Thứ Sáu nào cũng dành mười phút rà lại thư mục và mặt bàn.

**Vì sao 5S liên quan đến thói quen then chốt**

Mỗi lần phải tìm tài liệu, dọn bàn hay đóng bớt cửa sổ trên máy tính trước khi bắt đầu là một lần thói quen có thể bị hoãn. Tuần #0022, cả nhóm đã nói về việc giảm ma sát. 5S là cách giảm ma sát một cách có hệ thống, đến từ chính lĩnh vực quản trị vận hành.

Hôm nay không cần làm đủ năm chữ S. Chọn một góc nhỏ liên quan trực tiếp đến thói quen: mặt bàn, màn hình máy tính, hay thư mục dự án. Chụp một tấm ảnh trước, làm hai mươi phút, chụp một tấm sau. Ảnh chỉ để mình tự so sánh, không cần đăng.

**Ngày 4 (20 đến 30 phút)**

1. Chọn một góc làm việc liên quan đến thói quen then chốt.
2. Ghi lại hiện trạng trước khi làm.
3. Làm Sàng lọc, Sắp xếp, Sạch sẽ trong hai mươi phút.
4. Viết một quy định nhỏ để duy trì, ghép vào nghi thức kết thúc ngày.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-4.

Chia sẻ hôm nay: "Cải tiến 5S hôm nay: .... Trước: .... Sau: ...".


## Bài 5: Ngày 5 (Thứ Sáu 18/12)
@img 5_gop-y
@pdf 10XHub_Kaizen_PhieuNgay5_gop-y.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: XIN MỘT GÓP Ý TỪ ĐỒNG NGHIỆP

Trong tinh thần Kaizen, người nhìn thấy cơ hội cải tiến không nhất thiết là chính mình. Thường là người làm việc cùng mình mỗi ngày. Hôm nay mỗi người gửi một lời xin góp ý ngắn đến một đồng nghiệp. Dưới đây là một lá thư mẫu, có thể gửi qua tin nhắn nội bộ hoặc nói trực tiếp.

*Chào anh Tuấn,*

*Cuối năm rồi, em đang nhìn lại cách mình làm việc trong năm 2026 để chuẩn bị cho năm tới. Mấy tháng nay em giữ một thói quen là gửi báo cáo tiến độ dự án cho cả nhóm mỗi chiều Thứ Sáu.*

*Anh làm việc với em nhiều nhất, nên em muốn hỏi anh một câu thôi: có một điều nhỏ nào em có thể làm khác đi để bản báo cáo đó giúp ích cho anh nhiều hơn không?*

*Anh trả lời một câu ngắn là đủ, khi nào tiện cũng được. Em cảm ơn anh nhiều.*

**Vì sao lá thư được viết như vậy**

- **Hỏi về một việc cụ thể.** "Anh thấy em làm việc thế nào?" quá rộng, người nghe khó trả lời. "Bản báo cáo chiều Thứ Sáu" là một việc cụ thể, dễ góp ý.
- **Hỏi một điều nhỏ.** "Một điều nhỏ có thể làm khác đi" nhẹ nhàng hơn nhiều so với "điểm yếu của em là gì". Câu hỏi nhỏ thường nhận được câu trả lời thật.
- **Hướng về tương lai.** Hỏi điều có thể làm khác đi, không hỏi điều đã làm sai.
- **Không tạo áp lực.** "Một câu ngắn là đủ, khi nào tiện cũng được" giúp người nhận dễ trả lời.

**Khi nhận được góp ý**

Chỉ cần làm ba việc: cảm ơn, ghi lại nguyên văn, và chọn xem góp ý đó có thể thành cải tiến nhỏ cho tuần sau không. Không cần giải thích hay tranh luận. Một góp ý không phải lúc nào cũng đúng, nhưng lúc nào cũng cho biết người khác đang nhìn thấy điều gì.

Nếu thói quen then chốt của mình là việc làm một mình, như đọc tài liệu hay làm việc sâu, hãy hỏi về kết quả của thói quen đó: "Gần đây anh có thấy bản kế hoạch em gửi rõ ràng hơn không? Có điều gì em có thể bổ sung?"

Tuần này cũng là tuần cuối của mùa họp tổng kết ở nhiều công ty. Một lời xin góp ý nhẹ nhàng trước kỳ nghỉ cuối năm là cách khép năm rất chuyên nghiệp, và cũng là một cách cảm ơn người đã làm việc cùng mình.

**Ngày 5 (15 phút)**

1. Chọn một đồng nghiệp làm việc cùng mình nhiều nhất.
2. Soạn lời xin góp ý theo bốn điểm trên, gửi ngay hôm nay.
3. Khi nhận được trả lời: cảm ơn và ghi lại nguyên văn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-5. Ô góp ý nhận được có thể điền sau, khi đồng nghiệp trả lời.

Chia sẻ hôm nay: "Tôi đã xin góp ý từ .... Góp ý tôi nhận được: ...".


## Bài 6: Ngày 6 (Thứ Bảy 19/12)
@img 6_so-cai-tien
@img2 9_the-thanh-tich
@pdf 10XHub_Kaizen_PhieuNgay6_so-cai-tien.pdf (phiếu thực hành và trang sổ cải tiến năm 2026 để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: SỔ CẢI TIẾN NĂM 2026 CỦA MÌNH

Nếu chỉ được giữ lại một trang ghi chép về năm 2026 trong công việc, các anh chị và các bạn sẽ viết gì trên trang đó?

Hôm nay là ngày viết trang đó. Không phải bản báo cáo thành tích, cũng không phải danh sách những điều chưa làm được. Đó là một sổ cải tiến: những điều mình đã làm tốt hơn, những cải tiến nhỏ đã thử, những góp ý đã nhận, và một bước tiếp theo.

Sổ thực hành đã tự gom những gì viết trong tuần. Trước khi xem, thử trả lời từng câu hỏi dưới đây, mỗi câu một dòng.

**Năm câu hỏi cho sổ cải tiến năm**

Việc nào trong công việc năm nay mình làm tốt hơn hẳn năm ngoái, và điều gì đã giúp mình?

Cải tiến nhỏ nào tuần này có tác dụng, và mình sẽ giữ nó thế nào?

Góc làm việc nào sau buổi 5S giúp mình bắt đầu thói quen dễ hơn?

Góp ý nào từ đồng nghiệp làm mình nhìn thấy một điều trước đây chưa thấy?

Cải tiến nhỏ tiếp theo cho tuần sau là gì?

**Một trang nhật ký năm**

Sau năm câu hỏi, viết thêm một đoạn ngắn, ba đến năm câu, về năm 2026 trong công việc. Viết như một trang nhật ký: mình đã bắt đầu năm thế nào, đã thay đổi ở đâu, và muốn mang điều gì sang năm 2027. Đoạn này chỉ dành cho mình, không cần chia sẻ.

**Bảng hành trình**

Tuần này bảng hành trình nằm ở Ngày 3. Ai chưa bấm các ngày đã làm thói quen từ Thứ Tư đến nay, mở Ngày 3 để bấm bổ sung.

**Sáng nay (15 phút)**

Trả lời năm câu hỏi, xem bảng tự gom trên sổ thực hành.

**Trước khi nghỉ Chủ Nhật (15 phút)**

Viết cải tiến nhỏ tiếp theo cho tuần sau và đoạn nhật ký năm. In trang sổ cải tiến trong phiếu đính kèm, đặt cạnh trang lá chắn và danh sách việc khép năm.

Năm 2026 còn hai tuần. Tuần sau là tuần Giáng sinh, Công thức #0032 về Lòng biết ơn trong công việc sẽ đi chậm và ấm hơn: mỗi ngày một lời cảm ơn cụ thể, gửi đến đồng nghiệp, khách hàng, và cả những người âm thầm hỗ trợ mình suốt năm. Góp ý nhận được hôm qua cũng là một điều đáng để cảm ơn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0031-ngay-6.

Chia sẻ hôm nay: "Sổ cải tiến năm 2026 của tôi có: ...; ...; .... Cải tiến nhỏ tiếp theo cho tuần sau: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Cải tiến liên tục hiện ra, có đường cong tích luỹ, tên mình và cải tiến nhỏ của tuần. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Một tuần tốt hơn một chút đã là một tuần đáng nhớ.
