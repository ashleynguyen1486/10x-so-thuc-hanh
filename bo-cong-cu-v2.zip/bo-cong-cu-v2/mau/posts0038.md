## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 01/02)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0038_Tu Trac An_VN.pdf (tài liệu đầy đủ của Công thức #0038)
@pdf 10XHub_TuTracAn_PhieuNgay1_nhin-lai-nam.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0038.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN GIÁP TẾT: NHÌN LẠI MỘT NĂM, CÔNG BẰNG VỚI CHÍNH MÌNH

Còn năm ngày làm việc nữa là đến tối giao thừa.

Tuần trước, cả nhóm đã đặt ranh giới để bảo vệ những giờ làm việc quan trọng nhất, lập danh sách bàn giao để kỳ nghỉ không bị gọi về giữa chừng, và Thứ Bảy 23 tháng Chạp đã dọn bàn làm việc, tiễn năm cũ. Tuần này còn lại một việc nhẹ mà ít ai dành thời gian: nhìn lại chính mình trong một năm làm việc, bằng con mắt công bằng.

Công thức #0038 của tuần là Tự trắc ẩn trong công việc. Mỗi ngày chỉ 5 đến 15 phút, vì ai cũng đang chạy những việc cuối cùng trước Tết.

**Nếu mới tham gia:** tuần giáp Tết là tuần nhẹ nhất của cả mùa, rất hợp để bắt đầu. Hôm nay chỉ cần viết vào sổ thực hành một câu "Tôi là người ..." và một thói quen nhỏ trong công việc muốn giữ qua năm mới, rồi làm bài Ngày 1 như mọi người. Thứ Năm, sổ sẽ giúp thu nhỏ thói quen đó thành phiên bản Tết, đủ nhẹ để làm cả trong những ngày nghỉ.

**Tự trắc ẩn là gì, và không phải là gì**

Năm 2003, nhà tâm lý học Kristin Neff (Đại học Texas tại Austin) công bố bài viết định nghĩa khái niệm tự trắc ẩn trên tạp chí Self and Identity. Nói gọn bằng ngôn ngữ công việc: khi gặp sai sót hay khó khăn, đối xử với chính mình theo cách mình vẫn đối xử với một đồng nghiệp tốt đang gặp chuyện tương tự.

Neff mô tả ba thành phần, mỗi thành phần đứng đối diện một phản xạ quen thuộc:

1. **Tử tế với bản thân**, thay cho tự phán xét gay gắt. Khi trễ một hạn chót, câu đầu tiên trong đầu là "mình thật vô dụng" hay "lần này mình đã ước lượng sai thời gian"?
2. **Nhân tính chung**, thay cho cảm giác chỉ mình mình như vậy. Ai đi làm cũng có lúc nhầm số liệu, lỡ hẹn, nói chưa khéo trong cuộc họp. Sai sót là một phần của công việc, không phải dấu hiệu mình kém hơn mọi người.
3. **Chánh niệm**, thay cho bị cuốn vào sự việc. Chánh niệm ở đây nghĩa là nhìn sai sót đúng kích thước của nó: ghi nhận, không phóng đại, cũng không lờ đi.

Và ba điều tự trắc ẩn không phải:

- Không phải dễ dãi. Tử tế với mình vẫn đi kèm nhận trách nhiệm và sửa sai. Thứ Tư tuần này có một nghiên cứu về chính điểm này.
- Không phải tự đề cao. Neff phân biệt tự trắc ẩn với lòng tự trọng dựa trên so sánh hơn thua.
- Không phải than thân. Nhìn lại công bằng nghĩa là thấy cả điều làm tốt lẫn điều chưa tốt, rồi đi tiếp.

**Vì sao đặt công thức này vào tuần giáp Tết?**

Cuối năm là lúc nhiều người tự chấm điểm mình. Danh sách việc chưa xong thường hiện ra rõ hơn danh sách việc đã làm được. Có người đã giữ thói quen suốt từ tháng 10 mà vẫn bước vào Tết với cảm giác "năm nay mình làm được ít quá".

Tuần này đặt lại cán cân. Không phải để tự khen, mà để có một bức tranh đúng: tranh đúng thì mới biết năm mới cần giữ gì, cần sửa gì.

Tự trắc ẩn cũng là lớp mới của thói quen then chốt. Kỳ nghỉ Tết rất dễ có ngày lỡ. Cách mình nói với chính mình sau ngày lỡ thường quyết định mình có quay lại hay không. Vì vậy tuần này sổ thực hành lưu thêm hai điều cho cả hành trình: câu tự nhắc tử tế và phiên bản Tết của thói quen.

**Sáu ngày của tuần giáp Tết**

- Thứ Hai, 25 tháng Chạp: ba điều làm tốt, một điều chưa như ý của năm làm việc.
- Thứ Ba: viết một câu tự nhắc tử tế.
- Thứ Tư: một sai sót, một bài học, một cách sửa.
- Thứ Năm, 28 Tết: phiên bản Tết của thói quen.
- Thứ Sáu, 29 Tết, tối giao thừa: ba câu khép năm, 5 phút.
- Thứ Bảy, mùng 1 Tết: một lời chúc cho năm làm việc mới, 5 phút.

Chủ Nhật nghỉ.

**Ngày 1 (10 phút): Nhìn lại một năm như một đồng nghiệp công bằng**

1. Mở sổ thực hành, xem lại thói quen đang giữ.
2. Viết ba điều đã làm tốt trong công việc từ Tết năm ngoái đến nay. Viết cụ thể: việc gì, kết quả ra sao.
3. Chọn một điều trong ba điều để chia sẻ.
4. Viết một điều chưa như ý, bằng giọng của một đồng nghiệp công bằng: nêu sự việc, nêu hoàn cảnh lúc đó, không dùng từ chê bai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-1.

Chia sẻ hôm nay: "Một điều tôi đã làm tốt trong năm làm việc vừa qua: .... Một điều chưa như ý, nhìn lại công bằng: ...".

Điều chưa như ý chỉ cần viết ở mức các anh chị và các bạn thấy thoải mái chia sẻ, phần chi tiết cứ giữ lại trên sổ nha.


## Bài 2: Ngày 2 (Thứ Ba 02/02)
@img 2_cau-tu-nhac
@pdf 10XHub_TuTracAn_PhieuNgay2_cau-tu-nhac.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: VIẾT MỘT CÂU TỰ NHẮC THẬT TỬ TẾ

**Hai giọng nói trong một buổi chiều cuối năm**

Chị Lan là kế toán tổng hợp ở một công ty phân phối, đang chạy những ngày khoá sổ cuối cùng trước Tết. 4 giờ chiều, giám đốc tài chính gọi: một khoản công nợ của khách hàng lớn bị ghi sai kỳ, báo cáo gửi ngân hàng sáng nay phải sửa và gửi lại.

Trong đầu chị vang lên một giọng rất quen: "Làm kế toán bao nhiêu năm mà còn sai lỗi này. Cuối năm rồi còn để sếp phải gọi." Giọng đó nói nhanh, nói to, và không đưa ra cách sửa nào.

Rồi chị thử một cách khác: tự hỏi nếu một đồng nghiệp trong phòng mắc đúng lỗi này, chị sẽ nói gì với bạn ấy. Câu trả lời đến rất nhanh: "Cuối năm chứng từ nhiều gấp đôi, sai một bút toán là chuyện có thể xảy ra với bất kỳ ai. Sửa ngay, rồi xem lại vì sao bước đối chiếu không bắt được."

Hai câu cùng nói về một sai sót. Câu đầu làm chị mất thêm nửa tiếng ngồi bực bội. Câu sau đưa chị đến ngay việc cần làm.

Tình huống trên chỉ là minh hoạ, nhưng gần như ai đi làm cũng từng nghe cả hai giọng nói đó.

**Câu hỏi đồng nghiệp**

Kristin Neff gợi ý một bài tập rất đơn giản: khi gặp khó khăn, hỏi chính mình "nếu một người bạn thân gặp đúng chuyện này, mình sẽ nói gì với họ?". Ở chỗ làm, có thể đổi "người bạn thân" thành "một đồng nghiệp mình quý". Câu trả lời thường có ba phần, trùng đúng ba thành phần của tự trắc ẩn đã nói hôm qua:

- Một lời ghi nhận: chuyện này khó thật.
- Một lời nhắc: ai làm việc này cũng có lúc như vậy.
- Một bước tiếp theo, nhỏ và cụ thể.

**Câu tự nhắc tử tế**

Hôm nay viết một câu ngắn, dùng được nhiều lần trong năm mới: mỗi khi có sai sót, mỗi khi lỡ một ngày thói quen. Vài ví dụ theo vị trí:

- Quản lý: "Mình nhận trách nhiệm, và mình sửa từng bước."
- Kinh doanh: "Mất một hợp đồng không xoá đi những khách hàng mình đã giữ."
- Kế toán: "Sai một số thì sửa một số, rồi xem lại bước đối chiếu."
- Nhân sự: "Mình đã làm hết sức với thông tin có lúc đó."
- Kỹ thuật: "Sự cố là dữ liệu để cải tiến, không phải bản án."
- Chăm sóc khách hàng: "Một cuộc gọi khó không nói lên cả ngày làm việc của mình."

Một câu tự nhắc tốt thường ngắn, nói được thành tiếng mà không thấy ngượng, và kết thúc bằng một hướng đi. Câu nào nghe giống khẩu hiệu treo tường thì viết lại bằng lời mình vẫn nói với đồng nghiệp.

**Ngày 2 (10 phút)**

1. Nhớ lại một lần gần đây mình tự trách trong công việc. Ghi lại câu đầu tiên vang lên trong đầu.
2. Hỏi câu hỏi đồng nghiệp: nếu một đồng nghiệp mình quý gặp đúng chuyện này, mình sẽ nói gì?
3. Viết câu tự nhắc tử tế của mình vào sổ. Sổ lưu câu này cho cả hành trình, các tuần sau sẽ dùng lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-2.

Chia sẻ hôm nay: "Câu tự nhắc tử tế tôi mang vào năm mới: ...".

Câu tự trách ở bước 1 là của riêng mình, không cần chia sẻ nha.


## Bài 3: Ngày 3 (Thứ Tư 03/02)
@img 3_sua-sai
@pdf 10XHub_TuTracAn_PhieuNgay3_sua-sai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: TỬ TẾ VỚI MÌNH CÓ LÀM MÌNH DỄ DÃI KHÔNG?

Sau bài hôm qua, câu hỏi hay gặp nhất là câu trong tiêu đề. Hôm nay trả lời theo dạng hỏi đáp.

**Hỏi: Tử tế với mình có làm mình dễ dãi không?**

Đáp: Đây cũng là câu hỏi mà Juliana Breines và Serena Chen, hai nhà nghiên cứu ở Đại học California, Berkeley, đặt ra trong một loạt bốn thí nghiệm công bố năm 2012 trên tạp chí Personality and Social Psychology Bulletin. Tên bài báo đã nói lên kết luận: tự trắc ẩn làm tăng động lực tự cải thiện.

**Hỏi: Họ thử nghiệm bằng cách nào?**

Đáp: Trong một thí nghiệm, người tham gia làm một bài kiểm tra từ vựng rất khó, gần như ai cũng làm kém. Sau đó họ được chia ngẫu nhiên thành ba nhóm. Nhóm thứ nhất đọc một lời nhắn mang tinh thần tự trắc ẩn: bài khó, nhiều người cũng gặp khó, kết quả kém là điều dễ hiểu. Nhóm thứ hai đọc một lời nhắn đề cao năng lực của chính họ. Nhóm thứ ba không đọc gì. Rồi tất cả được báo sẽ có bài kiểm tra lần hai, và được ngồi ôn bao lâu tuỳ ý.

**Hỏi: Kết quả ra sao?**

Đáp: Nhóm tự trắc ẩn dành nhiều thời gian ôn hơn hai nhóm còn lại. Ở các thí nghiệm khác trong cùng bài báo, khi nhớ lại một lỗi lầm hay một điểm yếu của bản thân, những người được hướng dẫn nhìn bằng con mắt tự trắc ẩn cho biết họ muốn sửa sai và muốn thay đổi nhiều hơn.

**Hỏi: Vì sao lại như vậy?**

Đáp: Một cách giải thích dễ hiểu: tự trách nặng nề làm việc nhìn lại sai sót trở nên khó chịu, nên người ta có xu hướng né. Khi giọng nói bên trong bớt gay gắt, nhìn lại bớt nặng nề, và người ta dễ đi tới bước sửa hơn. Có thể nói gọn: tử tế với người, nghiêm túc với việc.

**Hỏi: Có giới hạn nào cần biết không?**

Đáp: Có. Các thí nghiệm làm với sinh viên đại học ở Mỹ, trong phòng thí nghiệm, đo động lực và thời gian ôn trong ngắn hạn, không đo kết quả công việc lâu dài. Vì vậy cách hiểu đúng mực là: tử tế với mình không làm giảm động lực sửa sai, và có thể giúp tăng động lực đó. Không nên hiểu thành "tử tế với mình thì chắc chắn làm tốt hơn".

**Hỏi: Áp dụng vào một sai sót trong năm như thế nào?**

Đáp: Ba dòng là đủ. Dòng thứ nhất: sự việc, viết như biên bản, không tính từ. Dòng thứ hai: bài học, điều mình hiểu ra. Dòng thứ ba: cách làm khác trong năm mới, đủ cụ thể để làm được. Ví dụ của một trưởng ca sản xuất: "Tháng 9, một lô hàng giao trễ hai ngày vì không kiểm tra lại tồn kho vật tư. Bài học: lịch sản xuất chỉ đúng khi vật tư đã được xác nhận. Năm mới: chiều Thứ Sáu nào cũng đối chiếu vật tư cho tuần sau."

**Ngày 3 (10 phút)**

1. Chọn một sai sót trong năm làm việc vừa qua, loại đã qua đủ lâu để nhìn lại bình tĩnh.
2. Viết ba dòng: sự việc, bài học, cách làm khác.
3. Đọc lại câu tự nhắc viết hôm qua. Nó có giúp mình viết ba dòng này dễ hơn không?

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-3.

Chia sẻ hôm nay: "Một bài học từ sai sót năm qua: .... Năm mới tôi sẽ làm khác bằng cách: ...".


## Bài 4: Ngày 4 (Thứ Năm 04/02)
@img 4_phien-ban-tet
@pdf 10XHub_TuTracAn_PhieuNgay4_phien-ban-tet.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: 28 TẾT, CHỌN PHIÊN BẢN TẾT CỦA THÓI QUEN

Hôm nay đã là 28 Tết. Văn phòng thưa dần, lịch làm việc sắp nhường chỗ cho lịch thăm hỏi, và thói quen then chốt sắp bước vào quãng khó giữ nhất của năm.

Kỳ nghỉ Tết không cần một thói quen trọn vẹn. Nó cần một phiên bản Tết: nhỏ đến mức làm được giữa những ngày nhiều việc nhà, nhiều khách, nhiều chuyến đi. Hôm nay là một bảng chọn. Tìm nhóm gần với thói quen của mình, rồi chọn hoặc tự viết phiên bản Tết.

**Bảng chọn phiên bản Tết**

- **Thói quen đọc, học chuyên môn.** Phiên bản Tết: đọc một trang, hoặc đọc lại một ghi chú cũ và gạch chân một ý.
- **Thói quen lập kế hoạch, viết ba việc quan trọng.** Phiên bản Tết: mỗi sáng viết một việc quan trọng nhất cho ngày đi làm lại đầu tiên. Đến mùng 5, danh sách đã có sẵn.
- **Thói quen làm việc sâu.** Phiên bản Tết: mở tài liệu của dự án quan trọng nhất, đọc lại 5 phút, ghi một ý cho buổi làm việc đầu tiên sau Tết.
- **Thói quen chăm sóc khách hàng, đối tác.** Phiên bản Tết: mỗi ngày một lời chúc Tết cụ thể, gửi đúng tên người nhận, không bàn công việc.
- **Thói quen cải tiến, ghi chép.** Phiên bản Tết: ghi một quan sát nhỏ trong ngày, ví dụ một cách cửa hàng, nhà xe hay quầy dịch vụ ngày Tết đón khách.
- **Thói quen ghi nhận, cảm ơn.** Phiên bản Tết: một lời cảm ơn cụ thể mỗi ngày, gửi một đồng nghiệp hoặc người đã hỗ trợ mình trong năm.

**Ba điều kiện của một phiên bản Tết tốt**

1. Dưới 5 phút. Phiên bản hai phút từ tuần đầu của hành trình vẫn là điểm tựa tốt.
2. Không cần máy tính, làm được ở bất kỳ đâu.
3. Gắn vào một nếp sinh hoạt ngày Tết có sẵn: sau bữa sáng, sau khi pha ấm trà đầu ngày, trước khi đi chúc Tết.

**Khi có ngày lỡ**

Tết có ngày lỡ là chuyện bình thường. Ai cũng có những ngày cả nhà đi từ sáng đến tối. Nguyên tắc từ tuần đầu vẫn giữ: không lỡ hai lần liên tiếp. Và đây là lúc câu tự nhắc tử tế viết hôm Thứ Ba làm đúng việc của nó: thay cho câu "lại hỏng rồi" bằng một câu đưa mình quay lại vào sáng hôm sau.

**Ngày 4 (10 đến 15 phút)**

1. Chọn nhóm gần với thói quen then chốt của mình trên sổ.
2. Viết phiên bản Tết, kiểm tra ba điều kiện.
3. Viết nếp sinh hoạt ngày Tết mà phiên bản Tết sẽ đi ngay sau.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-4.

Chia sẻ hôm nay: "Phiên bản Tết của thói quen: .... Tôi làm ngay sau ...".


## Bài 5: Ngày 5 (Thứ Sáu 05/02)
@img 5_giao-thua
@pdf 10XHub_TuTracAn_PhieuNgay5_giao-thua.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: TỐI GIAO THỪA, BA CÂU KHÉP NĂM BÍNH NGỌ

Gửi các anh chị và các bạn của 10X Excellence Hub,

Hôm nay là 29 Tết. Năm nay tháng Chạp không có ngày 30, nên tối nay đã là giao thừa. Trường viết bài này ngắn hơn mọi ngày, vì biết giờ này nhiều người đang ở trên đường về quê, đang dọn nhà, đang bày mâm cúng tất niên.

Từ tháng 10, cả nhóm đã đi cùng nhau một chặng khá dài. Mỗi người chọn một thói quen then chốt trong công việc, rồi từng tuần thêm cho nó một lớp: một câu bản sắc, bốn quy luật, kế hoạch Nếu... thì..., khung giờ năng lượng cao, khối làm việc sâu, việc quan trọng nhất đầu ngày, luyện tập có chủ đích, giảng lại cho đồng nghiệp, lá chắn cuối năm, nghi thức khép việc, cải tiến nhỏ, lời cảm ơn. Sang năm 2027, thói quen đó được nối với năm mục tiêu, được đặt lên bảng Kanban, được giữ qua những ngày chững lại, được bảo vệ bằng ranh giới.

Trường không biết hết những gì mỗi người đã trải qua trong năm. Nhưng mỗi câu chia sẻ dưới các bài đăng là dấu vết của một thói quen nhỏ được giữ qua nhiều tuần bận rộn, qua những ngày lỡ rồi quay lại. Điều đó đáng được ghi nhận, trước hết bởi chính mình.

Vì vậy việc của tối nay chỉ có ba câu, 5 phút, viết trước hoặc sau bữa cơm tất niên đều được:

1. **Năm Bính Ngọ, tôi tự hào về ...** Một việc cụ thể trong công việc, lớn hay nhỏ đều được.
2. **Bài học tôi mang sang năm Đinh Mùi: ...** Một câu, có thể lấy từ ba dòng viết hôm Thứ Tư.
3. **Cảm ơn chính mình vì ...** Câu này để riêng trên sổ, không cần chia sẻ.

Câu thứ ba có thể nghe lạ với nhiều người. Tháng 12, cả nhóm đã viết rất nhiều lời cảm ơn gửi đồng nghiệp, khách hàng, đối tác. Tối nay, đến lượt người đã đi làm đủ một năm, đã giữ thói quen qua nhiều tuần, đã sửa sai và đi tiếp.

Sau ba câu đó, mời các anh chị và các bạn gập máy tính lại. Ranh giới đặt tuần trước dành cho đúng buổi tối như thế này.

Cảm ơn các anh chị và các bạn đã đi cùng nhau trọn một năm. Chúc cả nhà một đêm giao thừa ấm áp, sum vầy nha.

Trường

**Ngày 5 (5 phút)**

1. Mở sổ thực hành, viết ba câu khép năm.
2. Chọn hai câu đầu để chia sẻ, câu thứ ba giữ lại cho mình.
3. Thói quen hôm nay: làm phiên bản Tết nếu tiện, không thì nghỉ trọn vẹn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-5.

Chia sẻ hôm nay: "Năm Bính Ngọ, tôi tự hào về .... Bài học tôi mang sang năm Đinh Mùi: ...".


## Bài 6: Ngày 6 (Thứ Bảy 06/02)
@img 6_mung-1
@img2 9_the-thanh-tich
@pdf 10XHub_TuTracAn_PhieuNgay6_mung-1.pdf (phiếu thực hành và thiệp năm mới gửi chính mình in được)
@cat Challenges

**Tiêu đề bài trên Skool:** MÙNG 1 TẾT ĐINH MÙI: CHÚC MỪNG NĂM MỚI CẢ NHÀ

Chúc mừng năm mới Đinh Mùi 2027.

Sáng mùng 1, 10X Excellence Hub gửi đến các anh chị và các bạn lời chúc đầu năm: một năm làm việc có nhiều ngày trọn vẹn, việc quan trọng được làm trước, đồng nghiệp tin cậy nhau, và những buổi tối được nghỉ ngơi thật sự bên gia đình.

Bài hôm nay chỉ có một câu hỏi, và chỉ cần 5 phút.

**Mùng 1 Tết năm sau, nhìn lại năm Đinh Mùi, mình muốn thấy điều gì trong công việc?**

Không cần là một con số. Có thể là một cách làm việc: "tôi đã nói không với những việc ngoài năm mục tiêu mà không thấy áy náy". Có thể là một mối quan hệ: "khách hàng lớn nhất gọi cho tôi trước khi gọi cho ai khác". Có thể là một điều về chính thói quen then chốt: "tôi vẫn giữ thói quen này, và quay lại nhanh mỗi lần lỡ".

Viết một câu vào sổ thực hành. Sổ đặt câu đó cạnh câu tự nhắc tử tế viết hôm Thứ Ba, để mỗi lần mở sổ trong năm đều thấy cả hai: điều mình hướng tới, và cách mình nói với chính mình trên đường đi tới đó.

Ai muốn giữ nhịp thì sáng nay làm phiên bản Tết của thói quen, sau ấm trà đầu năm. Ai muốn nghỉ trọn ngày mùng 1 thì cứ nghỉ. Tuần này đã nói rất nhiều về sự công bằng với chính mình, và một ngày nghỉ đầu năm là hoàn toàn công bằng.

**Một tuần giáp Tết đã khép lại**

Sáu ngày qua, cả nhóm đã nhìn lại năm làm việc với ba điều làm tốt và một điều chưa như ý, viết câu tự nhắc tử tế, biến một sai sót thành bài học, chọn phiên bản Tết cho thói quen, và khép năm Bính Ngọ bằng ba câu. Đó là một tuần rất nhẹ về thời gian, nhưng không nhẹ về ý nghĩa.

**Tuần sau: Đừng bao giờ ăn một mình**

Thứ Hai 08.02 là mùng 3 Tết, nhiều nơi còn nghỉ. Công thức #0039 Đừng bao giờ ăn một mình, dựa trên cuốn sách cùng tên của Keith Ferrazzi, mở tuần khai xuân với những việc nhẹ: chúc Tết đối tác, đồng nghiệp, khách hàng bằng lời chúc cụ thể, và chọn những mối quan hệ công việc muốn giữ trong năm mới. Thói quen then chốt có thêm một lớp: mỗi tuần kết nối lại một người.

**Ngày 6 (5 phút)**

1. Mở sổ thực hành, viết một câu cho mùng 1 Tết năm sau.
2. Đọc lại câu tự nhắc tử tế và phiên bản Tết của thói quen.
3. Làm phiên bản Tết nếu muốn, đánh dấu trên sổ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0038-ngay-6.

Chia sẻ hôm nay: "Năm Đinh Mùi, tôi mong mùng 1 năm sau nhìn lại sẽ thấy: .... Câu tự nhắc tôi mang theo: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần giáp Tết hiện ra: một tấm thiệp với dòng chữ "Chúc mừng năm mới", tên mình và câu tự nhắc tử tế mang vào năm Đinh Mùi. Tải thẻ về và đăng vào bình luận dưới bài này, như một lời chúc Tết gửi cả nhóm. Còn thiếu ngày nào thì những ngày Tết vẫn làm bù được.

Chủ Nhật mùng 2 Tết, chúc các anh chị và các bạn những ngày xuân thật an vui bên gia đình nha.
