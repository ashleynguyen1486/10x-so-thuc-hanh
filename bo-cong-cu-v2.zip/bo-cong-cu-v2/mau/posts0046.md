## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 29/03)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0046_Sai Lam Chi Phi Chim_VN.pdf (tài liệu đầy đủ của Công thức #0046)
@pdf 10XHub_ChiPhiChim_PhieuNgay1_dat-len-ban.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0046.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN KHÉP QUÝ 1: NHÌN LẠI ĐỂ ĐI TIẾP NHẸ HƠN

Tuần trước, cả nhóm đã tìm cho mục tiêu số 1 một chỉ số Sao Bắc Đẩu, chọn một con số hành động mỗi tuần, dựng bảng điểm và nối một dòng từ mục tiêu xuống thói quen mỗi sáng. Bảng điểm đó đến đúng lúc: tuần này là tuần cuối của quý 1, và cũng là tuần khép Mùa 2 "Mục tiêu và ưu tiên năm mới". Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Công thức #0046 của tuần là Sai lầm chi phí chìm và nhìn lại quý 1.

**Nếu mới tham gia:** tuần khép quý là lúc rất hợp để bắt đầu, vì ai cũng đang nhìn lại. Hãy viết vào Ngày 1 trên sổ thực hành một mục tiêu công việc quan trọng của năm và một thói quen nhỏ mình muốn giữ. Sáu ngày tuần này giúp xem mục tiêu đó còn đúng không và mang thói quen sang quý 2. Không cần đọc lại các tuần trước.

**Một câu đố trước khi đọc tiếp**

Các anh chị và các bạn thử trả lời câu này trong 30 giây, trước khi đọc phần giải.

Mình đã trả 100 đô la cho một chuyến đi trượt tuyết cuối tuần ở Michigan. Vài tuần sau, mình thấy một chuyến khác ở Wisconsin giá 50 đô la, và tin rằng chuyến Wisconsin sẽ vui hơn. Mình mua luôn. Sau đó mới phát hiện hai chuyến trùng đúng một cuối tuần, và cả hai đều không hoàn tiền, không bán lại được. Mình sẽ đi chuyến nào?

Câu trả lời hợp lý là chuyến Wisconsin: cả 150 đô la đã mất dù chọn chuyến nào, nên chỉ còn câu hỏi chuyến nào vui hơn. Nhưng năm 1985, khi Hal Arkes và Catherine Blumer ở Đại học Ohio đặt đúng câu hỏi này cho sinh viên, hơn một nửa chọn chuyến Michigan, chuyến đắt hơn nhưng kém vui hơn.

**Chi phí chìm là gì?**

Chi phí chìm là thời gian, tiền bạc, công sức đã bỏ ra và không lấy lại được. Sai lầm chi phí chìm là khi phần đã bỏ ra khiến mình tiếp tục một việc, dù nhìn về phía trước thì việc khác tốt hơn. Arkes và Blumer gọi đó là xu hướng tiếp tục một việc khi đã đầu tư vào nó tiền bạc, công sức hoặc thời gian.

Hai nhà nghiên cứu còn làm một thí nghiệm thực tế với vé xem kịch cả mùa của nhà hát trường đại học. Một số người mua được giảm giá ngẫu nhiên. Trong nửa đầu mùa diễn, nhóm trả giá đầy đủ đi xem nhiều buổi hơn nhóm được giảm giá, chỉ vì họ đã trả nhiều hơn.

**Vì sao điều này quan trọng vào tuần khép quý?**

Năm mục tiêu được chọn từ tuần đầu năm. Sau gần ba tháng, mỗi mục tiêu đã nhận một phần thời gian và công sức. Đó chính là lúc câu "đã làm được ba tháng rồi, giờ bỏ thì phí" dễ xuất hiện nhất, kể cả với một mục tiêu không còn đúng vì công việc đã thay đổi.

Tuần này không nhằm bỏ bớt mục tiêu. Phần lớn mục tiêu sẽ được giữ, có mục tiêu chỉ cần sửa lại cho vừa. Điều tuần này nhắm tới là mỗi quyết định giữ, sửa hay dừng đều dựa vào chặng đường phía trước, không dựa vào phần đã bỏ ra phía sau. Và có một điều chắc chắn được giữ: thói quen then chốt.

**Sáu ngày của tuần**

- Thứ Hai: đặt năm mục tiêu lên bàn.
- Thứ Ba: câu hỏi "nếu hôm nay bắt đầu lại".
- Thứ Tư 31.03: khép quý 1.
- Thứ Năm 01.04: mạnh dạn dừng hoặc sửa một mục tiêu.
- Thứ Sáu: giữ thói quen, viết lại năm mục tiêu cho quý 2.
- Thứ Bảy: khép Mùa 2.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Đặt năm mục tiêu lên bàn**

1. Mở sổ thực hành, xem lại thói quen đang giữ, năm mục tiêu và bảng điểm tuần trước.
2. Với từng mục tiêu, chọn một trạng thái: đang đúng hướng; tiến chậm hơn dự kiến; đang đứng yên.
3. Ước lượng phần thời gian mỗi tuần mình đang dành cho mỗi mục tiêu.

Hôm nay chỉ nhìn, chưa quyết định gì.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-1.

Chia sẻ hôm nay: "Sau gần một quý, ... trong 5 mục tiêu của tôi đang đúng hướng. Mục tiêu tôi dành nhiều thời gian nhất: mục tiêu số ...".

Mục tiêu đứng yên không có nghĩa là mình làm chưa tốt, có khi chỉ là công việc đã đổi hướng, các anh chị và các bạn cứ ghi đúng hiện trạng nha.


## Bài 2: Ngày 2 (Thứ Ba 30/03)
@img 2_bat-dau-lai
@pdf 10XHub_ChiPhiChim_PhieuNgay2_bat-dau-lai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: NẾU HÔM NAY BẮT ĐẦU LẠI, CÓ CHỌN LẠI KHÔNG?

Cách gỡ sai lầm chi phí chìm đơn giản nhất là đổi câu hỏi. Thay vì "mình đã bỏ vào mục tiêu này bao nhiêu?", hỏi "nếu hôm nay mới bắt đầu, với những gì đang biết, mình có chọn mục tiêu này không?". Hôm nay là danh sách sáu câu hỏi để đi qua từng mục tiêu.

**Sáu câu hỏi cho mỗi mục tiêu**

1. **Nếu hôm nay mới bắt đầu, mình có chọn mục tiêu này không?** Đây là câu hỏi chính. Năm câu sau giúp trả lời nó cho thật.
2. **Lý do chọn mục tiêu từ tháng 1 còn đúng không?** Có khi vai trò đã đổi, bộ phận có ưu tiên mới, hoặc một dự án đã kết thúc.
3. **Bảng điểm nói gì?** Nếu mục tiêu đã có Sao Bắc Đẩu từ tuần trước, con số cho biết nó đang đi đâu. Nếu chưa có, đó cũng là một thông tin.
4. **Phần lớn kết quả còn nằm trong tầm ảnh hưởng của mình không?** Có mục tiêu ban đầu nằm trong tay mình, sau đó phụ thuộc quyết định của người khác.
5. **Mục tiêu này cần sửa phạm vi, sửa thời hạn hay sửa cách làm?** Nhiều mục tiêu không cần dừng, chỉ cần sửa một phần cho vừa với thực tế.
6. **Nếu dừng mục tiêu này, thời gian dôi ra sẽ dành cho mục tiêu nào?** Câu này giúp thấy rõ giá trị của việc dừng: không phải bớt đi, mà là dồn sức cho điều quan trọng hơn.

**Ba kết luận có thể có**

- **Giữ:** mục tiêu vẫn đúng, đang đi đúng hướng hoặc chỉ chậm vì lý do tạm thời.
- **Sửa:** mục tiêu vẫn đáng theo đuổi nhưng cần đổi phạm vi, thời hạn, cách đo hoặc cách làm.
- **Dừng:** mục tiêu không còn phù hợp. Dừng ở đây có thể là dừng hẳn, hoặc chuyển vào danh sách tránh để xem lại vào cuối năm.

Một lưu ý về mục tiêu do công ty giao: nếu chỉ tiêu của bộ phận vẫn còn, mục tiêu đó không tự dừng được. Khi đó câu hỏi số 5 quan trọng nhất, và nếu thấy cần điều chỉnh, nên trao đổi với cấp trên bằng số liệu từ bảng điểm.

**Ngày 2 (20 phút)**

1. Đi qua sáu câu hỏi với từng mục tiêu, bắt đầu từ mục tiêu số 1.
2. Ghi kết luận cho mỗi mục tiêu: giữ, sửa hay dừng.
3. Ghi tên mục tiêu cần xem lại kỹ hơn vào Thứ Năm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-2.

Chia sẻ hôm nay: "Nếu bắt đầu lại hôm nay, tôi vẫn chọn ... mục tiêu. Mục tiêu cần xem lại: ...".


## Bài 3: Ngày 3 (Thứ Tư 31/03)
@img 3_khep-quy-1
@pdf 10XHub_ChiPhiChim_PhieuNgay3_khep-quy-1.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: HÔM NAY KHÉP LẠI QUÝ 1 NĂM 2027

Hôm nay, Thứ Tư 31.03, là ngày cuối cùng của quý 1. Chín mươi ngày trước, cả nhóm bắt đầu năm 2027 với một câu bản sắc, một thói quen then chốt và năm mục tiêu. Bài hôm nay là năm câu hỏi mở để khép quý. Không có câu trả lời đúng hay sai, chỉ có câu trả lời của mình.

**Câu hỏi 1: Kết quả nào trong quý 1 mình thấy tự hào nhất?**

Không cần là kết quả lớn. Một hợp đồng đầu tiên với khách hàng mới, một quy trình chạy trơn tru hơn, một đồng nghiệp mới đã tự làm được việc, một báo cáo nộp đúng hạn suốt ba tháng. Điều quan trọng là gọi được tên nó.

**Câu hỏi 2: Thói quen then chốt đã đi cùng mình bao nhiêu ngày?**

Bảng hành trình trên sổ thực hành đã đếm sẵn. Con số đó gồm cả những tuần nước rút trước Tết, những ngày giáp Tết, tuần khởi động lại sau kỳ nghỉ. Ngày nào đã làm, ngày đó được ghi lại.

**Câu hỏi 3: Công cụ nào của Mùa 2 mình dùng nhiều nhất?**

Bảng Kanban, ranh giới, phiên bản tối thiểu ngày Tết, lặp lại cách quãng, sổ đầu dòng, hộp thời gian, chọn kiểu đủ tốt, quy tắc mặc định, bảng điểm. Có công cụ trở thành một phần của ngày làm việc, có công cụ chỉ dùng một tuần. Cả hai đều bình thường.

**Câu hỏi 4: Điều gì mình làm khác đi nếu bắt đầu lại quý 1?**

Đây là câu hỏi về bài học, không phải về lỗi. Ví dụ: "đặt ít mục tiêu cho tháng 2 hơn", "dựng bảng điểm ngay từ tháng 1", "nói không sớm hơn với những lời mời ngoài năm mục tiêu".

**Câu hỏi 5: Mình muốn cảm ơn ai về quý 1?**

Một đồng nghiệp đã gánh việc giúp trong tuần mình nghỉ Tết, một người cùng theo dõi thói quen, một khách hàng đã góp ý thẳng thắn. Một tin nhắn ngắn hôm nay là cách khép quý rất đẹp.

**Ngày 3 (20 phút)**

1. Trả lời năm câu hỏi trên sổ thực hành.
2. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen, xem tổng số ngày của cả hành trình.
3. Nếu được, gửi một lời cảm ơn ngắn cho người mình nghĩ tới ở câu hỏi 5.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-3.

Chia sẻ hôm nay: "Quý 1 khép lại. Kết quả tôi tự hào nhất: .... Thói quen đã giữ ... ngày trên cả hành trình".

Tối nay khép máy sớm một chút và ghi nhận chặng đường của mình nha, ba tháng làm việc đều đặn là điều rất đáng trân trọng.


## Bài 4: Ngày 4 (Thứ Năm 01/04)
@img 4_dung-hoac-sua
@pdf 10XHub_ChiPhiChim_PhieuNgay4_dung-hoac-sua.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: MẠNH DẠN DỪNG HOẶC SỬA MỘT MỤC TIÊU

Ngày đầu tiên của quý 2. Hôm nay giải nghĩa một khái niệm đi cùng chi phí chìm, để nhận ra nó khi nó xuất hiện trong chính quyết định của mình.

**Leo thang cam kết là gì?**

Năm 1976, Barry Staw công bố một nghiên cứu với tên gọi rất hình ảnh: "Knee-deep in the big muddy", tạm hiểu là "lún sâu trong bùn". Sinh viên kinh doanh đóng vai lãnh đạo một công ty, quyết định phân bổ ngân sách nghiên cứu cho một trong hai bộ phận. Sau đó họ được biết bộ phận mình chọn đang làm ăn kém, và được giao phân bổ thêm một khoản tiền.

Kết quả: những người tự mình đưa ra quyết định ban đầu dồn thêm nhiều tiền hơn vào chính bộ phận đang kém đó, so với những người tiếp nhận quyết định do người khác đưa ra. Staw gọi đây là leo thang cam kết: càng chịu trách nhiệm cho lựa chọn ban đầu, càng có xu hướng đầu tư thêm để chứng minh lựa chọn đó đúng.

**"Dừng" nghĩa là gì?**

Dừng một mục tiêu không có nghĩa là ba tháng vừa qua bị lãng phí. Những gì đã học được, những mối quan hệ đã xây, những kỹ năng đã luyện vẫn ở lại. Dừng chỉ có nghĩa là thời gian của quý 2 sẽ đi về nơi khác.

**"Sửa" nghĩa là gì?**

Sửa là giữ hướng nhưng đổi cách đi. Bốn kiểu sửa hay gặp: thu hẹp phạm vi ("12 khách hàng doanh nghiệp" thành "6 khách hàng doanh nghiệp ở khu vực phía Nam"); lùi thời hạn có lý do; đổi cách đo (thêm Sao Bắc Đẩu); đổi cách làm (đổi chỉ số hành động).

**Ba câu nói báo hiệu**

Khi bàn về một mục tiêu, nếu nghe chính mình nói một trong ba câu sau, đó là lúc dừng lại và hỏi lại câu hỏi của Thứ Ba:

- "Đã làm đến đây rồi, bỏ thì phí."
- "Thêm một tháng nữa chắc sẽ khác." (trong khi không có điều gì mới thay đổi)
- "Mình đã nói với cả nhóm là sẽ làm được."

Câu thứ ba đặc biệt khó, vì nó gắn với uy tín. Nhưng một kế hoạch được điều chỉnh rõ ràng, có lý do và có số liệu, thường giữ uy tín tốt hơn một mục tiêu được níu giữ mà không còn ai tin.

**Ngày 4 (20 phút)**

1. Chọn một mục tiêu cần dừng hoặc sửa (nếu Thứ Ba tất cả đều là "giữ", chọn mục tiêu cần sửa nhỏ nhất).
2. Đánh dấu những câu báo hiệu mình từng nghĩ tới với mục tiêu này.
3. Chọn cách xử lý: dừng hẳn, chuyển vào danh sách tránh, hay sửa (phạm vi, thời hạn, cách đo, cách làm).
4. Viết một câu lý do dựa vào chặng đường phía trước.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-4.

Chia sẻ hôm nay: "Mục tiêu tôi mạnh dạn dừng hoặc sửa: .... Lý do: ...".


## Bài 5: Ngày 5 (Thứ Sáu 02/04)
@img 5_giu-thoi-quen
@pdf 10XHub_ChiPhiChim_PhieuNgay5_giu-thoi-quen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MỤC TIÊU CÓ THỂ ĐỔI, THÓI QUEN THÌ GIỮ

**Một tình huống minh hoạ**

Anh Tuấn là kỹ sư phụ trách vận hành một dây chuyền đóng gói. Tháng 1, anh chọn năm mục tiêu, trong đó mục tiêu số 3 là "chuẩn hoá tài liệu hướng dẫn cho toàn bộ 14 máy". Thói quen then chốt anh giữ từ Mùa 1 là "đầu mỗi ca, 15 phút đi kiểm tra một máy theo danh sách".

Thứ Ba tuần này, khi hỏi "nếu hôm nay bắt đầu lại, có chọn mục tiêu này không?", anh nhận ra công ty vừa quyết định thay 6 trong 14 máy vào tháng 7. Viết tài liệu cho 6 máy sắp thay là đầu tư vào điều sẽ không còn dùng. Ba tháng qua anh đã viết xong tài liệu cho 5 máy, trong đó có 2 máy sắp thay. Câu "đã viết được 5 máy rồi" xuất hiện ngay.

Thứ Năm, anh sửa mục tiêu số 3: "chuẩn hoá tài liệu cho 8 máy được giữ lại, xong trong quý 2". Hai tài liệu của máy sắp thay được lưu lại làm mẫu cho việc tiếp nhận máy mới. Thời gian dôi ra anh chuyển sang mục tiêu số 1, giảm thời gian dừng máy.

Điều anh không đổi là thói quen. Mười lăm phút đầu ca vẫn ở đó. Chỉ có danh sách máy là được cập nhật, bỏ 6 máy sắp thay, thêm hai điểm kiểm tra mới cho máy hay dừng nhất. Sao Bắc Đẩu và chỉ số hành động anh dựng tuần trước cũng giữ nguyên.

Tình huống trên là minh hoạ. Điều đáng chú ý là thứ tự anh làm: nhìn hiện trạng, hỏi lại từ đầu, sửa mục tiêu, rồi giữ thói quen và cập nhật nó cho vừa với mục tiêu mới.

**Vì sao thói quen là phần nên giữ?**

Mục tiêu trả lời câu hỏi "đi đâu", và câu trả lời có thể thay đổi khi công việc thay đổi. Thói quen trả lời câu hỏi "mình là người làm việc như thế nào", và câu trả lời đó được xây qua nhiều tháng. Đổi mục tiêu là bình thường. Giữ thói quen qua lúc đổi mục tiêu là điều làm nên sự khác biệt của cả một năm.

**Ngày 5 (20 phút)**

1. Viết lại năm mục tiêu cho quý 2 trên sổ thực hành: giữ nguyên, sửa, hoặc thay mục tiêu đã dừng.
2. Viết điều mình giữ sang quý 2: thói quen then chốt và một công cụ của Mùa 2 dùng hiệu quả nhất.
3. Nếu thói quen cần cập nhật cho vừa với mục tiêu mới, sửa phần nội dung, giữ tín hiệu và khung giờ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-5. Điều giữ sang quý 2 được lưu cho cả hành trình.

Chia sẻ hôm nay: "Sang quý 2, tôi giữ: ...".


## Bài 6: Ngày 6 (Thứ Bảy 03/04)
@img 6_khep-mua-2
@img2 9_the-thanh-tich
@pdf 10XHub_ChiPhiChim_PhieuNgay6_khep-mua-2.pdf (phiếu thực hành và trang tổng kết Mùa 2 in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: KHÉP MÙA 2, MỘT CHẶNG ĐƯỜNG ĐÁNG TỰ HÀO

Hôm nay khép Mùa 2 "Mục tiêu và ưu tiên năm mới". Trước khi làm bài, Trường mời các anh chị và các bạn đi lại chặng đường 13 tuần, từng mốc một.

**Dòng thời gian Mùa 2**

- **04.01, Quy tắc 5/25.** Tuần đầu năm 2027, mở Mùa 2. Cả nhóm viết 25 mục tiêu, giữ lại 5, và nối thói quen then chốt với mục tiêu số 1.
- **11.01, Bảng Kanban cá nhân.** Năm mục tiêu thành những bước cụ thể trên một bảng, với giới hạn việc dở.
- **18.01, Gan góc.** Giữa tháng 1, lúc hứng khởi đầu năm chững lại, mục tiêu được nối với lý do dài hạn.
- **25.01, Đặt ranh giới.** Tuần nước rút trước Tết: bảo vệ giờ làm việc sâu, bàn giao gọn gàng, tiễn năm cũ.
- **01.02, Tự trắc ẩn trong công việc.** Tuần giáp Tết, việc rất nhẹ, một phiên bản Tết của thói quen, và lời chúc năm mới Đinh Mùi.
- **08.02, Đừng bao giờ ăn một mình.** Những ngày khai xuân, kết nối lại với đồng nghiệp, đối tác, khách hàng.
- **15.02, Đường cong quên.** Tuần làm việc đầy đủ đầu tiên sau Tết, khởi động lại thói quen và ôn lại các công thức đã học.
- **22.02, Sổ đầu dòng.** Một hệ thống ghi chép để không rơi mất bước nào của năm mục tiêu.
- **01.03, Hộp thời gian.** Mỗi bước có một khung giờ và một hạn chót tự đặt.
- **08.03, Nghịch lý lựa chọn.** Chọn kiểu đủ tốt cho việc nhỏ, dành sức cho mục tiêu lớn.
- **15.03, Luật Hick.** Quy tắc mặc định, để thói quen bắt đầu không cần chọn.
- **22.03, Sao Bắc Đẩu.** Một con số dẫn đường và một con số hành động mỗi tuần.
- **29.03, Chi phí chìm.** Khép quý 1, nhìn lại năm mục tiêu bằng chặng đường phía trước.

Mười ba tuần, có Tết ở giữa, có những tuần công việc dồn dập, có những ngày thói quen chỉ còn phiên bản tối thiểu. Thói quen then chốt vẫn đi qua tất cả những điều đó, và giờ nó đã có thêm năm mục tiêu để phục vụ, một quy tắc mặc định để bắt đầu, một bảng điểm để biết đang tới đâu. Đó là thành quả của chính các anh chị và các bạn, từng buổi sáng một.

**Sáng nay (15 phút)**

1. Đọc lại bảng gom Mùa 2 trên sổ thực hành.
2. Viết điều mình tự hào nhất về Mùa 2, và một điều mang sang mùa tiếp theo.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In trang tổng kết Mùa 2 ở phiếu Ngày 6, điền và kẹp vào sổ kế hoạch, cạnh thẻ 5 mục tiêu từ tuần đầu năm.

**Từ Thứ Hai 05.04: Mùa 3 "Học nhanh, nhớ lâu"**

Mùa 2 giúp đặt đúng mục tiêu và giữ hướng. Mùa 3 chuyển sang một năng lực đi cùng mọi mục tiêu: học điều mới nhanh hơn và nhớ được lâu hơn, từ kỹ năng chuyên môn đến kiến thức về khách hàng, sản phẩm, quy trình. Thói quen then chốt tiếp tục là trục của hành trình, và bảng hành trình tiếp tục đếm ngày.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0046-ngay-6.

Chia sẻ hôm nay: "Mùa 2 của tôi: .... Mang sang Mùa 3: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích khép quý hiện ra: một khung với chữ Q1 lớn, dòng "QUÝ 1 ĐÃ KHÉP", tên mình và điều mình giữ sang quý 2. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Cảm ơn các anh chị và các bạn đã đi cùng nhau suốt Mùa 2. Hẹn gặp lại sáng Thứ Hai, ở mùa mới.
