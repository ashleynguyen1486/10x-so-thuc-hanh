import sys; sys.path.insert(0, '/tmp/f30/b')
import tpl
from tpl import page, cover, disclaimer, build
from vnkeep import keep
tpl.CSS = tpl.CSS.replace('url(lato', 'url(file:///tmp/f30/b/lato')
SP = '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
N = '0034'
P = []
add = lambda inner, **k: P.append(page(len(P) + 1, N, inner, **k))

P.append(cover(N, ['QUY TẮC 5/25'],
  'Viết 25 mục tiêu, giữ lại 5, tránh 20 mục tiêu còn lại.',
  'Phương pháp luận: câu chuyện "hai danh sách" thường được gán cho Warren Buffett, kết hợp nghiên cứu đặt mục tiêu của Edwin Locke và Gary Latham.',
  'Nguồn gốc: câu chuyện được lan truyền qua Scott Dinsmore và James Clear, chưa có xác nhận trực tiếp từ Buffett; Locke và Latham (2002). 10X Excellence Hub biên soạn lại với ví dụ công việc. Người viết: Trường.'))

add('''<h1>PHÉP CHIA CỦA TUẦN ĐẦU NĂM</h1>
<div class="lead">Tuần đầu năm hiếm khi thiếu mục tiêu. Điều thường thiếu là thời gian để theo đuổi tất cả cùng lúc.</div>
<p>Thử một phép tính minh hoạ. Giả sử mỗi tuần, ngoài công việc thường ngày, một người dành được khoảng 5 giờ cho những việc phát triển: học một kỹ năng, mở một mảng khách hàng mới, cải tiến một quy trình. Năm giờ là 300 phút.</p>
<div class="stats"><div><b>25 mục tiêu</b><span>mỗi mục tiêu nhận khoảng 12 phút mỗi tuần</span></div><div><b>5 mục tiêu</b><span>mỗi mục tiêu nhận khoảng 60 phút mỗi tuần</span></div><div><b>Số 1</b><span>mục tiêu số 1 nhận phần lớn sự chú ý của cả quý</span></div></div>
<p>Mười hai phút mỗi tuần hầu như không đủ để bắt đầu một việc có ý nghĩa. Sáu mươi phút mỗi tuần, đều đặn trong một quý, đã là khoảng 13 giờ. Con số chỉ là minh hoạ, nhưng nó cho thấy vì sao danh sách mục tiêu dài thường kết thúc bằng cảm giác "năm nay làm được ít quá".</p>
<h2>Mùa 2 của hành trình bắt đầu từ câu hỏi này</h2>
<p>Mùa 1 của hành trình thói quen (từ tháng 10 đến hết năm 2026) xây một thói quen then chốt qua nhiều tuần. Mùa 2 hỏi tiếp: thói quen đó phục vụ mục tiêu nào? Muốn trả lời, trước hết phải có một danh sách mục tiêu đủ ngắn.</p>
<div class="box"><div class="h">Ý chính của tuần này</div><div class="c">
<p>Viết 25 mục tiêu công việc cho năm 2027, khoanh lấy 5, và biến 20 mục tiêu còn lại thành <b>danh sách tránh</b>. Sau đó <b>nối thói quen then chốt với mục tiêu số 1</b>, đặt ba mốc cho quý 1, và làm một tấm thẻ 5 mục tiêu đặt ngay trên bàn làm việc.</p></div></div>''')

add('''<h1>CÂU CHUYỆN HAI DANH SÁCH, VÀ MỘT DẤU HỎI</h1>
<div class="sub">Một câu chuyện có giá trị thực hành, nhưng nguồn gốc chưa được xác nhận.</div>
<p>Câu chuyện thường được kể như sau. Mike Flint, phi công riêng của Warren Buffett, được Buffett hỏi về mục tiêu nghề nghiệp. Buffett đề nghị Flint viết 25 mục tiêu, rồi khoanh 5 mục tiêu quan trọng nhất. Flint nói sẽ tập trung vào 5 mục tiêu, còn 20 mục tiêu kia làm dần khi rảnh. Theo câu chuyện, Buffett đáp rằng 20 mục tiêu đó là danh sách cần tránh bằng mọi giá, cho đến khi 5 mục tiêu đầu đã xong.</p>
<table class="t"><tr><th style="width:44%">Điều được kể</th><th>Điều đã biết đến nay</th></tr>
<tr><td>Buffett hướng dẫn phi công Mike Flint lập hai danh sách</td><td>Câu chuyện được lan truyền rộng qua blog của Scott Dinsmore, sau đó qua bài viết của James Clear và nhiều trang khác</td></tr>
<tr><td>Buffett dùng cách này cho chính mình</td><td>Chưa có xác nhận trực tiếp nào từ Buffett, trong thư gửi cổ đông hay phỏng vấn chính thức</td></tr>
<tr><td>Buffett biết đến quy tắc này</td><td>Một số bài viết dẫn lời tác giả Alex Banayan rằng khi được hỏi, Buffett nói ông không nhớ từng lập danh sách như vậy; lời kể này cũng chưa được kiểm chứng độc lập</td></tr></table>
<h2>Vì sao 10X Excellence Hub vẫn dùng?</h2>
<p>Giá trị của Quy tắc 5/25 nằm ở cách làm, không nằm ở tên người kể. Cách làm này nhất quán với những gì nghiên cứu về đặt mục tiêu đã cho thấy (trang sau): mục tiêu cụ thể giúp tập trung sự chú ý, và sự chú ý thì có hạn. Tài liệu này gọi đây là "câu chuyện thường được gán cho Buffett", không trình bày như một lời khuyên đã được ông xác nhận.</p>
<p class="note">Khi chia sẻ câu chuyện với đồng nghiệp, các anh chị và các bạn nên nói rõ điểm này, để giữ uy tín của chính mình.</p>''')

add('''<h1>NGHIÊN CỨU: MỤC TIÊU CỤ THỂ, SỰ CHÚ Ý CÓ HẠN</h1>
<div class="sub">Locke và Latham, 2002.</div>
<p>Năm 2002, Edwin Locke và Gary Latham tổng kết khoảng 35 năm nghiên cứu về đặt mục tiêu trong bài báo "Building a Practically Useful Theory of Goal Setting and Task Motivation", tạp chí <i>American Psychologist</i>. Kết luận chính: mục tiêu <b>cụ thể và có độ thách thức</b> thường đi cùng kết quả cao hơn so với mục tiêu mơ hồ kiểu "cố gắng hết sức".</p>
<h2>Bốn cách mục tiêu tác động đến kết quả</h2>
<table class="t"><tr><th style="width:26%">Cơ chế</th><th style="width:38%">Ý nghĩa</th><th>Liên hệ với Quy tắc 5/25</th></tr>
<tr><td class="k">Định hướng</td><td>Hướng sự chú ý vào việc liên quan, ra khỏi việc không liên quan</td><td>Năm mục tiêu dễ định hướng sự chú ý hơn 25 mục tiêu</td></tr>
<tr><td class="k">Tạo năng lượng</td><td>Mục tiêu cao hơn đi cùng nỗ lực lớn hơn</td><td>Chọn mục tiêu có độ thách thức, nhưng ít</td></tr>
<tr><td class="k">Bền bỉ</td><td>Mục tiêu rõ giúp kéo dài nỗ lực</td><td>Mốc tháng và con số tuần giữ nhịp</td></tr>
<tr><td class="k">Chiến lược</td><td>Mục tiêu thúc đẩy tìm cách làm phù hợp</td><td>Nối thói quen then chốt với mục tiêu số 1</td></tr></table>
<h2>Điều kiện để mục tiêu phát huy</h2>
<ul class="b"><li><b>Cam kết:</b> mục tiêu có tác dụng khi người đặt thật sự cam kết với nó. Mục tiêu "của người khác" khó giữ.</li>
<li><b>Phản hồi:</b> cần biết mình đang tiến tới đâu. Đó là vai trò của con số theo dõi mỗi tuần.</li>
<li><b>Độ phức tạp:</b> với việc phức tạp, cần thời gian tìm cách làm. Mục tiêu quá nhiều làm thời gian đó bị chia nhỏ.</li></ul>
<p class="note">Locke và Latham không nghiên cứu riêng con số 5 hay 25. Phần nối từ nghiên cứu sang Quy tắc 5/25 là cách 10X Excellence Hub diễn giải để áp dụng.</p>''')

add('''<h1>NĂM NHÓM MỤC TIÊU CÔNG VIỆC</h1>
<div class="sub">Ngày 1 viết khoảng năm mục tiêu cho mỗi nhóm, chưa lọc.</div>
<table class="t"><tr><th style="width:24%">Nhóm</th><th style="width:30%">Câu hỏi gợi ý</th><th>Ví dụ mục tiêu</th></tr>
<tr><td class="k">Kết quả công việc</td><td>Cuối năm 2027, kết quả nào chứng minh mình đã làm tốt?</td><td>12 khách hàng doanh nghiệp mới; chốt sổ tháng trong 3 ngày; dự án mở rộng kho đúng hạn</td></tr>
<tr><td class="k">Kỹ năng và chuyên môn</td><td>Mình muốn làm giỏi hơn điều gì?</td><td>Thuyết trình với khách hàng nước ngoài không cần người hỗ trợ; tự xây được báo cáo phân tích</td></tr>
<tr><td class="k">Khách hàng và quan hệ</td><td>Mối quan hệ nào cần đầu tư?</td><td>Gặp trực tiếp 20 khách hàng lớn nhất ít nhất một lần; một buổi làm việc mỗi quý với bộ phận sản xuất</td></tr>
<tr><td class="k">Đội nhóm và cách làm việc</td><td>Nhóm mình cần thay đổi điều gì?</td><td>Mỗi thành viên có kế hoạch phát triển riêng; họp giao ban gọn trong 20 phút</td></tr>
<tr><td class="k">Học tập và phát triển</td><td>Mình cần học gì cho năm tới?</td><td>Hoàn thành một chứng chỉ chuyên môn; đọc 12 cuốn sách về quản lý</td></tr></table>
<h2>Vì sao viết đến 25?</h2>
<p>Viết nhiều trước khi lọc giúp đưa hết những mục tiêu đang chiếm chỗ trong đầu ra giấy. Nhiều mục tiêu nghe rất quan trọng khi còn trong đầu, nhưng khi nằm cạnh 24 mục tiêu khác thì tự lộ ra mức độ thật của nó. Không cần đủ đúng 25. Viết được 15 hay 30 đều dùng được.</p>
<p class="note">Danh sách 25 mục tiêu là của riêng mỗi người. Câu chia sẻ Ngày 1 chỉ cần con số và nhóm có nhiều mục tiêu nhất.</p>''')

add('''<h1>BẢY CÂU HỎI ĐỂ KHOANH LẤY 5</h1>
<div class="sub">Ngày 2: từ 25 mục tiêu xuống 8 đến 10, rồi xuống 5.</div>
<table class="t"><tr><th style="width:6%">#</th><th style="width:44%">Câu hỏi</th><th>Vì sao hỏi</th></tr>
<tr><td class="k">1</td><td>Cả năm chỉ đạt được một mục tiêu thì đó là mục tiêu nào?</td><td>Tìm mục tiêu số 1, thường là mục tiêu kéo theo nhiều mục tiêu khác</td></tr>
<tr><td class="k">2</td><td>Mục tiêu có gắn với vai trò chính của mình năm 2027 không?</td><td>Tránh mục tiêu hay nhưng lệch khỏi trách nhiệm chính</td></tr>
<tr><td class="k">3</td><td>Cuối năm có biết đã đạt hay chưa không?</td><td>Mục tiêu cụ thể, đo được hoặc thấy được kết quả</td></tr>
<tr><td class="k">4</td><td>Phần lớn kết quả có nằm trong tầm ảnh hưởng của mình không?</td><td>Tập trung vào điều mình tác động được</td></tr>
<tr><td class="k">5</td><td>Có trùng với mục tiêu khác không?</td><td>Gộp các mục tiêu trùng nhau</td></tr>
<tr><td class="k">6</td><td>Bỏ đi có thấy tiếc thật sự không?</td><td>Loại mục tiêu ở lại chỉ vì nghe hay</td></tr>
<tr><td class="k">7</td><td>Mục tiêu của mình hay của người khác?</td><td>Phân biệt trách nhiệm được giao với mong muốn của người khác</td></tr></table>
<h2>Viết lại cho cụ thể</h2>
<table class="t"><tr><th style="width:46%">Mục tiêu mơ hồ</th><th>Mục tiêu cụ thể</th></tr>
<tr><td>Giỏi tiếng Anh hơn</td><td>Thuyết trình với khách hàng nước ngoài không cần người hỗ trợ trước tháng 9</td></tr>
<tr><td>Phát triển đội nhóm</td><td>Mỗi thành viên có kế hoạch phát triển riêng, xem lại mỗi quý</td></tr>
<tr><td>Tăng khách hàng</td><td>12 khách hàng doanh nghiệp mới ký hợp đồng trong năm</td></tr></table>
<div class="box"><div class="h">Chỉ tiêu do công ty giao</div><div class="c"><p>Nếu bộ phận đã có chỉ tiêu năm, đặt chỉ tiêu đó vào 5 mục tiêu, hoặc chọn một mục tiêu cá nhân đóng góp trực tiếp cho chỉ tiêu. Quy tắc 5/25 dùng để tập trung, không phải để bỏ qua trách nhiệm đã nhận.</p></div></div>''')

add('''<h1>DANH SÁCH TRÁNH</h1>
<div class="sub">Hai mươi mục tiêu tốt, không đầu tư thời gian trong giai đoạn này.</div>
<table class="t"><tr><th style="width:26%">Cách hiểu</th><th style="width:37%">"Làm sau"</th><th>"Tránh"</th></tr>
<tr><td class="k">Trong đầu</td><td>Vẫn chiếm chỗ, mỗi lần rảnh lại hiện ra</td><td>Đã có quyết định từ trước, không phải nghĩ lại</td></tr>
<tr><td class="k">Khi có cơ hội</td><td>Dễ nhận lời, rồi thời gian của 5 mục tiêu bị chia nhỏ</td><td>Có sẵn câu trả lời lịch sự, hẹn lại thời điểm xem xét</td></tr>
<tr><td class="k">Cuối quý</td><td>Nhìn lại thấy làm dở nhiều việc</td><td>Xem lại danh sách, chuyển mục tiêu đã hết hạn tránh sang danh sách chính nếu 5 mục tiêu đầu đã xong</td></tr></table>
<h2>Ba mục tiêu hấp dẫn nhất</h2>
<p>Trong 20 mục tiêu, thường có vài mục tiêu đặc biệt hấp dẫn: dễ làm, vui, được người khác khen, hoặc người khác mong mình làm. Đó là những mục tiêu dễ lấn sang thời gian của 5 mục tiêu chính nhất. Sổ thực hành có ô riêng để ghi tên ba mục tiêu này, như một lời nhắc khi chúng xuất hiện.</p>
<h2>Câu nói không soạn sẵn</h2>
<table class="t"><tr><th style="width:34%">Tình huống</th><th>Câu trả lời mẫu</th></tr>
<tr><td>Cấp trên mời tham gia một nhóm công tác mới</td><td>"Cảm ơn anh đã nghĩ đến em. Quý này em đang tập trung cho mục tiêu mở rộng khách hàng doanh nghiệp. Nếu nhóm cần, em có thể góp ý một buổi, và tham gia nhiều hơn từ tháng 4."</td></tr>
<tr><td>Đồng nghiệp rủ làm một dự án phụ</td><td>"Ý tưởng rất hay. Năm nay em đã chọn năm mục tiêu và dự án này chưa nằm trong đó. Cuối quý em xem lại danh sách, mình nói chuyện tiếp nha."</td></tr>
<tr><td>Lời mời một khoá học chưa cần</td><td>"Cảm ơn chị. Em ghi lại để xem xét vào quý sau, khi mục tiêu chứng chỉ hiện tại đã xong."</td></tr></table>''')

add('''<h1>NỐI THÓI QUEN THEN CHỐT VỚI MỤC TIÊU SỐ 1</h1>
<div class="sub">Thói quen tốt và mục tiêu rõ chưa chắc đã nối với nhau.</div>
<p>Sau Mùa 1, mỗi thành viên có một thói quen then chốt đã được thiết kế kỹ: có tín hiệu, có giờ, có phiên bản hai phút, có kế hoạch cho ngày khó. Ngày 4 của tuần này kiểm tra một điều: mỗi lần làm thói quen, mình có tiến gần hơn tới mục tiêu số 1 không?</p>
<table class="t"><tr><th style="width:22%">Tình trạng</th><th style="width:36%">Dấu hiệu</th><th>Cách làm</th></tr>
<tr><td class="k">Đã nối thẳng</td><td>Mỗi lần làm thói quen đều đóng góp trực tiếp cho mục tiêu số 1</td><td>Giữ nguyên, ghi rõ câu nối trên sổ</td></tr>
<tr><td class="k">Cần điều chỉnh nhỏ</td><td>Thói quen tốt nhưng thường dùng cho việc khác</td><td>Giữ tín hiệu và giờ, thêm một quy định nhỏ để thói quen phục vụ mục tiêu</td></tr>
<tr><td class="k">Cần đổi</td><td>Thói quen không còn liên quan tới mục tiêu số 1</td><td>Theo quy tắc vàng (#0033): giữ tín hiệu và khung giờ, đặt thói quen mới vào</td></tr></table>
<h2>Ba câu hỏi để nối</h2>
<ol class="n"><li>Mỗi lần làm thói quen, mình có tiến gần hơn tới mục tiêu số 1 không?</li>
<li>Nếu chưa, thay đổi nhỏ nào giúp mỗi lần làm thói quen đều đóng góp cho mục tiêu?</li>
<li>Thay đổi đó có giữ được tín hiệu và khung giờ cũ không?</li></ol>
<div class="q"><div class="t">Mỗi ngày [thói quen then chốt], để tiến tới [mục tiêu số 1].</div><div class="s">Câu nối của tuần #0034, sổ thực hành tự ghép ở Ngày 4</div></div>
<p class="note">Bảng hành trình tiếp tục chạy. Từ Mùa 2, mỗi ô đánh dấu trên bảng cũng là một bước tới mục tiêu số 1.</p>''')

add('''<h1>KẾ HOẠCH QUÝ 1 NĂM 2027</h1>
<div class="sub">Ba mốc tháng, một con số tuần.</div>
<table class="t"><tr><th style="width:18%">Tháng</th><th style="width:40%">Đặc điểm</th><th>Gợi ý mốc</th></tr>
<tr><td class="k">Tháng 1</td><td>Khoảng ba tuần làm việc tính từ 04.01. Giai đoạn khởi động</td><td>Chuẩn bị nguồn lực, thử cách làm, ghi con số đầu tiên</td></tr>
<tr><td class="k">Tháng 2</td><td>Có kỳ nghỉ Tết Nguyên Đán, ít ngày làm việc hơn</td><td>Mốc khiêm tốn, có kế hoạch giữ thói quen trong kỳ nghỉ</td></tr>
<tr><td class="k">Tháng 3</td><td>Tháng làm việc trọn vẹn</td><td>Mốc cuối quý của mục tiêu số 1</td></tr></table>
<h2>Mốc là kết quả, con số tuần là việc mình làm</h2>
<table class="t"><tr><th style="width:34%">Loại</th><th>Ví dụ với mục tiêu "12 khách hàng doanh nghiệp mới"</th></tr>
<tr><td class="k">Mốc cuối tháng 1</td><td>Danh sách 40 khách hàng tiềm năng đã sàng lọc</td></tr>
<tr><td class="k">Mốc cuối tháng 2</td><td>10 buổi gặp đã diễn ra</td></tr>
<tr><td class="k">Mốc cuối tháng 3</td><td>2 hợp đồng đầu tiên đã ký</td></tr>
<tr><td class="k">Con số theo dõi mỗi tuần</td><td>Số cuộc gọi chào hàng tới khách hàng mới</td></tr></table>
<p>Con số tuần nên là con số mình kiểm soát được. Số hợp đồng ký phụ thuộc vào khách hàng; số cuộc gọi chào hàng thì phụ thuộc vào mình. Theo dõi con số tuần giúp biết sớm mình đang đi đúng hay lệch, trước khi đến mốc tháng. Đây cũng là phần "phản hồi" mà Locke và Latham nhấn mạnh.</p>
<div class="box"><div class="h">Bốn mục tiêu còn lại</div><div class="c"><p>Mục tiêu số 2 đến số 5 chỉ cần một mốc cuối quý cho mỗi mục tiêu. Sức chú ý lớn nhất trong quý dành cho mục tiêu số 1.</p></div></div>''')

rows = [('Mùa 1','0022','4 quy luật thay đổi hành vi','Bản sắc, thói quen then chốt'),('Mùa 1','0023','Ý định thực hiện','Kế hoạch Nếu... thì...'),
 ('Mùa 1','0024','Quản lý năng lượng','Khung giờ năng lượng cao'),('Mùa 1','0025','Công việc sâu','Khối làm việc sâu'),
 ('Mùa 1','0026','Ăn con ếch','Việc quan trọng nhất đầu ngày'),('Mùa 1','0027','Luyện tập có chủ đích','Một kỹ năng con'),
 ('Mùa 1','0028','Kỹ thuật Feynman','Giảng lại cho đồng nghiệp'),('Mùa 1','0029','Tiên liệu thất bại','Lá chắn cuối năm'),
 ('Mùa 1','0030','Hiệu ứng việc dở dang','Nghi thức kết thúc ngày'),('Mùa 1','0031','Kaizen','Cải tiến nhỏ nhất'),
 ('Mùa 1','0032','Lòng biết ơn','Lời cảm ơn sau thói quen'),('Mùa 1','0033','Sức mạnh thói quen','Giữ, nâng cấp hay đổi cho năm 2027'),
 ('Mùa 2','0034','Quy tắc 5/25','Nối thói quen với mục tiêu số 1'),('Mùa 2','0035','Bảng Kanban cá nhân','Biến mục tiêu thành việc cụ thể')]
add('''<h1>MÙA 2 CỦA HÀNH TRÌNH</h1>
<div class="sub">Mùa 1 xây thói quen. Mùa 2 hướng thói quen vào mục tiêu.</div>
<table class="t" style="font-size:9pt;line-height:12.5pt"><tr><th style="width:12%">Mùa</th><th style="width:11%">Tuần</th><th style="width:33%">Công thức</th><th>Lớp thêm cho thói quen then chốt</th></tr>''' +
 ''.join(f'<tr><td class="k">{m}</td><td>{a}</td><td>{"<b>"+b+"</b>" if a=="0034" else b}</td><td>{"<b>"+c+"</b>" if a=="0034" else c}</td></tr>' for m,a,b,c in rows) + '''</table>
<div class="box"><div class="h">Những gì đi tiếp sang Mùa 2</div><div class="c"><ul class="b">
<li>Thói quen then chốt năm 2027 và mọi lớp đã thêm trong Mùa 1.</li>
<li>Bảng hành trình, tiếp tục đếm ngày và chuỗi.</li>
<li>Mới từ tuần này: năm mục tiêu năm 2027 và danh sách tránh, lưu cho cả hành trình.</li></ul></div></div>''')

add('''<h1>ÁP DỤNG THEO VỊ TRÍ CÔNG VIỆC</h1>
<div class="sub">Mục tiêu số 1, cách nối thói quen, và con số theo dõi mỗi tuần.</div>
<table class="t"><tr><th style="width:15%">Vị trí</th><th style="width:27%">Mục tiêu số 1 mẫu</th><th style="width:33%">Thói quen nối với mục tiêu</th><th>Con số mỗi tuần</th></tr>
<tr><td class="k">Quản lý</td><td>Mỗi thành viên có kế hoạch phát triển riêng</td><td>Ba việc quan trọng mỗi sáng luôn có một việc cho một thành viên</td><td>Số buổi trao đổi một một</td></tr>
<tr><td class="k">Kinh doanh</td><td>12 khách hàng doanh nghiệp mới</td><td>Ba việc quan trọng luôn có một việc hướng tới khách hàng mới</td><td>Số cuộc gọi chào hàng</td></tr>
<tr><td class="k">Kế toán, tài chính</td><td>Chốt sổ tháng trong 3 ngày</td><td>Đối chiếu cuối ngày, ghi một khoản chênh lệch cần xử lý sớm</td><td>Số khoản chênh lệch tồn</td></tr>
<tr><td class="k">Nhân sự</td><td>Giảm tỷ lệ nghỉ việc của nhân viên mới</td><td>Ghi nhận mỗi ngày ưu tiên nhân viên mới vào làm</td><td>Số nhân viên mới được trao đổi</td></tr>
<tr><td class="k">Kỹ thuật, vận hành</td><td>Giảm thời gian dừng máy</td><td>Ghi một điểm cải tiến mỗi ca, tập trung vào nguyên nhân dừng máy</td><td>Số cải tiến đã thử</td></tr>
<tr><td class="k">Chăm sóc khách hàng</td><td>Trả lời khiếu nại trong 24 giờ</td><td>Trả lời thư khó nhất trước 10 giờ, ghi một câu trả lời mẫu</td><td>Số khiếu nại quá 24 giờ</td></tr></table>
<p>Các ví dụ chỉ mang tính gợi ý. Mục tiêu số 1 của mỗi người phụ thuộc vào vai trò, chỉ tiêu bộ phận và giai đoạn phát triển của chính mình.</p>''')

days = [
 ('Thứ Hai 04.01','25 mục tiêu','Viết khoảng 25 mục tiêu công việc theo năm nhóm, chưa lọc','30 phút'),
 ('Thứ Ba 05.01','Khoanh 5','Bảy câu hỏi lọc, chọn và xếp thứ tự 5 mục tiêu','25 phút'),
 ('Thứ Tư 06.01','Danh sách tránh','20 mục tiêu còn lại, ba mục tiêu hấp dẫn nhất, câu nói không','20 phút'),
 ('Thứ Năm 07.01','Nối thói quen','Đặt thói quen cạnh mục tiêu số 1, viết câu nối, bảng hành trình','20 phút'),
 ('Thứ Sáu 08.01','Kế hoạch quý 1','Ba mốc tháng, con số tuần, mốc quý cho 4 mục tiêu còn lại, kế hoạch Tết','25 phút'),
 ('Thứ Bảy 09.01','Thẻ 5 mục tiêu','Gom cả tuần, điền thẻ, đặt cạnh tín hiệu của thói quen','20 phút')]
r = ''.join(f'<tr><td class="k">{a}</td><td><b>{b}</b></td><td>{c}</td><td>{d}</td></tr>' for a,b,c,d in days)
add(f'''<h1>LỘ TRÌNH 6 NGÀY</h1>
<div class="lead">Tuần đầu năm 2027, mở Mùa 2. Chủ Nhật nghỉ, hoặc làm bù một ngày còn thiếu.</div>
<table class="t"><tr><th style="width:19%">Ngày</th><th style="width:18%">Trọng tâm</th><th>Việc chính</th><th style="width:13%">Thời lượng</th></tr>{r}</table>
<div class="box"><div class="h">Cách làm bài mỗi ngày</div><div class="c"><ul class="b">
<li>Mở sổ thực hành tại <b>10xexcellence.co/so-thuc-hanh</b>, chọn tuần 04.01 và đúng ngày.</li>
<li>Điền vào các ô, sổ tự ghép câu chia sẻ ở cuối trang.</li>
<li>Dán câu chia sẻ vào bình luận bài hôm đó, rồi bấm Đánh dấu đã chia sẻ.</li>
<li>Bảng hành trình nằm ở Ngày 4. Mỗi ngày làm thói quen thì bấm vào ô ngày đó.</li>
<li>Đủ 6 ngày, thẻ thành tích hình khung với số 5 hiện ra trên sổ để tải về.</li></ul></div></div>''')

def day(d, tag, tm, title, tagline, body):
    return f'''<div class="dh"><div><div class="d">{d}</div><div class="tag">{tag}</div></div><div class="tm">Thời lượng<b>{tm}</b></div></div>
<div class="dt">{title}</div><div class="di">{tagline}</div>{body}'''
def ci(t): return f'<div class="ci"><b>Câu chia sẻ mẫu:</b> {t}</div>'

add(day('THỨ 2','25 mục tiêu · 04.01','30 phút','Viết 25 mục tiêu công việc năm 2027',
 'Hôm nay chỉ viết, chưa lọc.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Xem lại thói quen đang giữ và câu bản sắc năm 2027 trên sổ thực hành. Người mới viết thói quen then chốt.</li>
<li>Viết khoảng 5 mục tiêu cho mỗi nhóm: kết quả công việc; kỹ năng và chuyên môn; khách hàng và quan hệ; đội nhóm và cách làm việc; học tập và phát triển.</li>
<li>Đếm số mục tiêu đã viết, chọn nhóm có nhiều mục tiêu nhất.</li></ol>
<table class="t"><tr><th style="width:34%">Nhóm</th><th>Ví dụ</th></tr>
<tr><td>Kết quả công việc</td><td>12 khách hàng doanh nghiệp mới</td></tr>
<tr><td>Kỹ năng và chuyên môn</td><td>Thuyết trình với khách hàng nước ngoài không cần người hỗ trợ</td></tr>
<tr><td>Khách hàng và quan hệ</td><td>Gặp trực tiếp 20 khách hàng lớn nhất</td></tr>
<tr><td>Đội nhóm và cách làm việc</td><td>Họp giao ban gọn trong 20 phút</td></tr>
<tr><td>Học tập và phát triển</td><td>Hoàn thành một chứng chỉ chuyên môn</td></tr></table>''' +
 ci('"Tôi đã viết 23 mục tiêu công việc cho năm 2027. Nhóm có nhiều mục tiêu nhất: Kết quả."')))

add(day('THỨ 3','Khoanh 5 · 05.01','25 phút','Khoanh lấy 5 mục tiêu quan trọng nhất',
 'Bảy câu hỏi lọc, rồi xếp thứ tự.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Đi qua bảy câu hỏi lọc với từng mục tiêu.</li>
<li>Chọn 5 mục tiêu, xếp thứ tự, mục tiêu số 1 đứng đầu.</li>
<li>Viết lại cho cụ thể và đo được.</li>
<li>Đánh dấu ba ô kiểm tra trên sổ.</li></ol>
<table class="t"><tr><th style="width:20%">Thứ tự</th><th>Ví dụ của một trưởng nhóm kinh doanh</th></tr>
<tr><td>Số 1</td><td>12 khách hàng doanh nghiệp mới ký hợp đồng trong năm</td></tr>
<tr><td>Số 2</td><td>Mỗi thành viên trong nhóm có kế hoạch phát triển riêng</td></tr>
<tr><td>Số 3</td><td>Thuyết trình với khách hàng nước ngoài không cần người hỗ trợ</td></tr>
<tr><td>Số 4</td><td>Gặp trực tiếp 20 khách hàng lớn nhất ít nhất một lần</td></tr>
<tr><td>Số 5</td><td>Họp giao ban gọn trong 20 phút</td></tr></table>''' +
 ci('"Năm mục tiêu công việc năm 2027 của tôi: 1) 12 khách hàng doanh nghiệp mới; 2) mỗi thành viên có kế hoạch phát triển riêng; 3) thuyết trình với khách nước ngoài không cần người hỗ trợ; 4) gặp 20 khách hàng lớn nhất; 5) họp giao ban gọn trong 20 phút."')))

add(day('THỨ 4','Danh sách tránh · 06.01','20 phút','20 mục tiêu còn lại là danh sách tránh',
 'Tránh không có nghĩa là xoá.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Chép 20 mục tiêu còn lại vào ô danh sách tránh trên sổ.</li>
<li>Ghi tên ba mục tiêu hấp dẫn nhất, chọn lý do vì sao chúng hấp dẫn.</li>
<li>Soạn sẵn một câu từ chối lịch sự cho lời mời ngoài 5 mục tiêu.</li></ol>
<table class="t"><tr><th style="width:34%">Lý do hấp dẫn</th><th>Ví dụ</th></tr>
<tr><td>Dễ và vui</td><td>Thiết kế lại mẫu báo giá cho đẹp hơn</td></tr>
<tr><td>Được người khác khen</td><td>Mở kênh chia sẻ chuyên môn trên mạng xã hội</td></tr>
<tr><td>Người khác muốn mình làm</td><td>Tham gia nhóm tổ chức sự kiện cuối năm</td></tr>
<tr><td>Nghĩ là sẽ làm sau</td><td>Học thêm một phần mềm phân tích dữ liệu</td></tr></table>''' +
 ci('"Danh sách tránh của tôi bắt đầu bằng: mở kênh chia sẻ trên mạng xã hội; học thiết kế; tham gia nhóm sự kiện. Câu tôi dùng để nói không: cảm ơn anh, quý này em tập trung cho mục tiêu khách hàng doanh nghiệp, em xin hẹn lại tháng 4."')))

add(day('THỨ 5','Nối thói quen · 07.01','20 phút','Nối thói quen then chốt với mục tiêu số 1',
 'Mỗi lần làm thói quen là một bước tới mục tiêu quan trọng nhất.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Đặt thói quen then chốt và mục tiêu số 1 cạnh nhau trên sổ.</li>
<li>Chọn: đã nối thẳng, cần điều chỉnh nhỏ, hay cần đổi thói quen.</li>
<li>Viết câu nối: mỗi lần làm thói quen giúp mục tiêu số 1 bằng cách nào.</li>
<li>Đánh dấu trên bảng hành trình những ngày tuần này đã làm.</li></ol>
<table class="t"><tr><th style="width:30%">Phần</th><th>Ví dụ</th></tr>
<tr><td>Thói quen</td><td>Viết ba việc quan trọng nhất trước 8 giờ</td></tr>
<tr><td>Mục tiêu số 1</td><td>12 khách hàng doanh nghiệp mới trong năm</td></tr>
<tr><td>Tình trạng</td><td>Cần điều chỉnh nhỏ</td></tr>
<tr><td>Câu nối</td><td>Trong ba việc quan trọng luôn có một việc hướng tới khách hàng mới</td></tr></table>''' +
 ci('"Thói quen viết ba việc quan trọng nhất trước 8 giờ đưa tôi tới mục tiêu số 1 (12 khách hàng doanh nghiệp mới) bằng cách luôn có một việc hướng tới khách hàng mới."')))

add(day('THỨ 6','Kế hoạch quý 1 · 08.01','25 phút','Kế hoạch quý 1 trên một trang',
 'Ba mốc tháng, một con số tuần, và kế hoạch cho Tết Nguyên Đán.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Viết ba mốc cuối tháng 1, 2, 3 cho mục tiêu số 1. Mỗi mốc là một kết quả thấy được.</li>
<li>Chọn một con số mình kiểm soát được, theo dõi mỗi tuần.</li>
<li>Viết một mốc cuối quý cho mỗi mục tiêu số 2 đến số 5.</li>
<li>Viết phiên bản nhỏ nhất của thói quen cho kỳ nghỉ Tết Nguyên Đán.</li></ol>
<table class="t"><tr><th style="width:30%">Phần</th><th>Ví dụ</th></tr>
<tr><td>Cuối tháng 1</td><td>Danh sách 40 khách hàng tiềm năng đã sàng lọc</td></tr>
<tr><td>Cuối tháng 2</td><td>10 buổi gặp đã diễn ra</td></tr>
<tr><td>Cuối tháng 3</td><td>2 hợp đồng đầu tiên đã ký</td></tr>
<tr><td>Con số mỗi tuần</td><td>Số cuộc gọi chào hàng tới khách hàng mới</td></tr>
<tr><td>Kỳ nghỉ Tết</td><td>Mỗi sáng viết một việc quan trọng nhất cho ngày đi làm lại</td></tr></table>''' +
 ci('"Mốc quý 1 của mục tiêu số 1: 2 hợp đồng đầu tiên đã ký. Tôi theo dõi mỗi tuần bằng: số cuộc gọi chào hàng tới khách hàng mới."')))

add(day('THỨ 7','Thẻ 5 mục tiêu · 09.01','20 phút','Thẻ 5 mục tiêu đặt trên bàn làm việc',
 'Một tấm thẻ nhỏ, đặt đúng chỗ, gắn với một thói quen đã có.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Đọc lại bảng gom cả tuần trên sổ: câu bản sắc năm 2027, năm mục tiêu, danh sách tránh, thói quen, mốc quý 1, con số tuần.</li>
<li>Điền thẻ 5 mục tiêu ở trang công cụ (in hoặc viết tay).</li>
<li>Đặt thẻ cạnh tín hiệu của thói quen then chốt, ghi chỗ đặt vào sổ.</li></ol>
<table class="t"><tr><th style="width:42%">Mục tiêu treo tường</th><th>Thẻ 5 mục tiêu</th></tr>
<tr><td>Ở chỗ ai cũng thấy, ít ai nhìn kỹ</td><td>Ngay trên bàn, cạnh tín hiệu của thói quen</td></tr>
<tr><td>Thường liệt kê nhiều mục tiêu</td><td>Chỉ 5 mục tiêu và một danh sách tránh</td></tr>
<tr><td>Nhắc lại vào cuộc họp tổng kết</td><td>Nhìn mỗi sáng, khi làm thói quen</td></tr>
<tr><td>Chỉ có đích đến</td><td>Có thói quen mỗi ngày, mốc mỗi tháng, con số mỗi tuần</td></tr></table>''' +
 ci('"Năm 2027, tôi tập trung vào 5 mục tiêu. Mục tiêu số 1: 12 khách hàng doanh nghiệp mới. Thẻ của tôi đặt ở: cạnh bàn phím, ngay chỗ đặt sổ kế hoạch buổi sáng."')))

def card():
    rows = ''.join(f'<tr><td class="k" style="width:22%">Số {i}</td><td style="height:21pt"></td></tr>' for i in range(1, 6))
    return f'''<div style="border:1pt dashed #7b1f23;padding:10pt 12pt;background:#fff;margin-bottom:10pt">
<div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-weight:900;font-size:15pt;color:#7b1f23">5 MỤC TIÊU NĂM 2027</div><div style="font-size:8pt;color:#666">10X Excellence Hub · Công thức #0034</div></div>
<table class="t" style="margin:6pt 0 4pt;font-size:9pt">{rows}
<tr><td class="k">Tránh</td><td style="height:21pt"></td></tr><tr><td class="k">Thói quen</td><td style="height:21pt"></td></tr></table></div>'''
add(f'''<h1>CÔNG CỤ IN ĐƯỢC: THẺ 5 MỤC TIÊU</h1>
<div class="sub">In ra, cắt theo đường đứt, đặt cạnh tín hiệu của thói quen then chốt.</div>
{card()}{card()}
<table class="t" style="font-size:8.5pt;margin-top:4pt"><tr><th style="width:24%">Quý 1: con số tuần</th>''' + ''.join(f'<th style="text-align:center;padding:5pt 1pt">T{i}</th>' for i in range(1, 14)) + '''</tr>
<tr><td class="k">Kết quả</td>''' + ''.join('<td style="height:20pt"></td>' for _ in range(13)) + '''</tr></table>''')

add('''<h1>TỪ QUY TẮC 5/25 ĐẾN BẢNG KANBAN CÁ NHÂN</h1>
<div class="sub">Tuần này chọn mục tiêu. Tuần sau biến mục tiêu thành việc làm mỗi ngày.</div>
<table class="t"><tr><th style="width:22%"></th><th style="width:39%">Công thức #0034</th><th>Công thức #0035</th></tr>
<tr><td class="k">Thời điểm</td><td>04.01 đến 09.01.2027, mở Mùa 2</td><td>Từ Thứ Hai 11.01.2027</td></tr>
<tr><td class="k">Câu hỏi</td><td>Năm 2027 tập trung vào năm mục tiêu nào?</td><td>Tuần này làm những việc gì cho các mục tiêu đó?</td></tr>
<tr><td class="k">Công cụ chính</td><td>25 mục tiêu, khoanh 5, danh sách tránh, câu nối, kế hoạch quý 1, thẻ 5 mục tiêu</td><td>Một bảng nhiều cột cho các việc cần làm, đang làm, đã xong</td></tr></table>
<h2>Tuần tới: Công thức #0035</h2>
<p>Bảng Kanban cá nhân giúp nhìn thấy mọi việc đang làm trên một bảng và không ôm quá nhiều việc cùng lúc. Tuần tới, 5 mục tiêu và các mốc quý 1 viết tuần này sẽ được chia thành những việc cụ thể trên bảng. Thói quen then chốt tiếp tục là trục của Mùa 2, và bảng hành trình tiếp tục đếm ngày.</p>
<div class="q"><div class="t">"Năm mục tiêu cụ thể dễ được chú ý hơn hai mươi lăm mục tiêu cụ thể."</div>
<div class="s">Tinh thần của Công thức #0034</div></div>''')

src = ('Các trích dẫn, số liệu và ví dụ được tổng hợp từ các nguồn công khai bao gồm: '
 'Locke, E. A. và Latham, G. P. (2002), "Building a Practically Useful Theory of Goal Setting and Task Motivation: A 35-Year Odyssey", <i>American Psychologist</i>, 57(9), 705 đến 717; '
 'Clear, J., "Warren Buffett\'s 2 List Strategy: How to Maximize Your Focus and Master Your Priorities", jamesclear.com/buffett-focus; Dinsmore, S., bài viết về câu chuyện Mike Flint trên blog Live Your Legend. '
 'Câu chuyện "hai danh sách" thường được gán cho Warren Buffett nhưng chưa có bằng chứng xác nhận trực tiếp từ ông. '
 'Phép tính thời gian ở trang 2 là minh hoạ. Các câu trong ngoặc kép là phần diễn giải hoặc câu mẫu, không phải trích dẫn nguyên văn. Các ví dụ công việc do 10X Excellence Hub biên soạn.')
P.append(disclaimer(len(P) + 1, N, 'Công thức #' + N + ': Quy Tắc 5/25', src))

sys.path.insert(0, '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad/w0034n'); from nbnum import nb
P = [nb(keep(x)) for x in P]
out = f'{SP}/w0034n/formula/10XHub_CongThuc_0034_Quy Tac 5-25_VN.pdf'
over = build(P, f'{SP}/w0034n/formula/0034.html', out)
print('pages', len(P), 'overflow', over)
