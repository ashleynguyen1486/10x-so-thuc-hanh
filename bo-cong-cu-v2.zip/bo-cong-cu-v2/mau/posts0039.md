## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 08/02)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0039_Dung Bao Gio An Mot Minh_VN.pdf (tài liệu đầy đủ của Công thức #0039)
@pdf 10XHub_KetNoi_PhieuNgay1_ban-do-quan-he.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0039.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MÙNG 3 KHAI XUÂN: AI LÀ NGƯỜI MÌNH MUỐN GẶP LẠI NĂM NAY?

Năm vừa qua, ai là người đã giúp công việc của mình nhiều nhất, mà mình chưa liên lạc lại từ lâu?

Câu hỏi đó mở đầu tuần khai xuân. Hôm nay là mùng 3 Tết Đinh Mùi, nhiều nơi còn nghỉ đến giữa tuần, nên mọi việc tuần này đều nhẹ, 10 đến 15 phút mỗi ngày.

Tuần giáp Tết vừa qua, cả nhóm đã nhìn lại một năm làm việc bằng con mắt công bằng, viết một câu tự nhắc tử tế để dùng mỗi khi có sai sót hay ngày lỡ, chọn phiên bản Tết cho thói quen then chốt, và khép năm Bính Ngọ bằng ba câu vào tối giao thừa. Tuần đó hướng vào bên trong. Tuần này hướng ra ngoài: những con người làm nên công việc của mình.

**Nếu mới tham gia:** tuần khai xuân là lúc rất tự nhiên để bắt đầu, vì ai cũng đang gửi lời chúc năm mới. Hôm nay viết vào sổ thực hành một câu "Tôi là người ..." và một thói quen nhỏ trong công việc muốn giữ cả năm, rồi làm bài Ngày 1 như mọi người. Thứ Sáu, sổ sẽ giúp ghép một nhịp kết nối nhỏ vào chính thói quen đó.

**Một cuốn sách và ba ý chính**

Công thức #0039 của tuần là Đừng bao giờ ăn một mình, dựa trên cuốn Never Eat Alone của Keith Ferrazzi, viết cùng Tahl Raz, xuất bản năm 2005. Tên sách nói về một thói quen cụ thể: dùng những bữa ăn, những buổi cà phê để gặp gỡ, thay vì ngồi một mình. Nhưng điều cuốn sách bàn rộng hơn nhiều: cách xây những mối quan hệ công việc bền lâu. Tuần này giữ lại ba ý.

1. **Xây mối quan hệ trước khi cần đến nó.** Một lời hỏi thăm khi không có việc gì cần nhờ khác hẳn một cuộc gọi chỉ đến khi đang gặp khó. Mối quan hệ được vun từ trước thì lúc cần mới có sẵn.
2. **Hào phóng, không đếm điểm.** Ferrazzi nhấn mạnh việc giúp người khác mà không tính toán ngay phần nhận lại: chia sẻ một tài liệu, giới thiệu hai người với nhau, ghi nhận một việc tốt.
3. **Liên lạc đều đặn, dù ngắn.** Một tin nhắn ngắn đúng lúc, lặp lại theo một nhịp, giữ mối quan hệ khỏi nguội đi. Đây là phần gần nhất với thói quen then chốt của hành trình.

**Điều tuần này không làm: bán hàng**

Tuần khai xuân dễ bị biến thành tuần chào hàng: lời chúc Tết kèm bảng giá, tin hỏi thăm kèm lời mời ký hợp đồng. Tuần này đi ngược lại. Mọi lời chúc, mọi lần liên lạc đều không kèm đề nghị mua bán nào. Mối quan hệ đi trước, công việc đến sau, nếu có.

**Sáu ngày của tuần khai xuân**

- Thứ Hai, mùng 3: bản đồ quan hệ công việc năm Đinh Mùi.
- Thứ Ba, mùng 4: ba lời chúc Tết cụ thể.
- Thứ Tư, mùng 5: hai mối quan hệ lâu chưa liên lạc.
- Thứ Năm, mùng 6: cho đi trước một điều hữu ích.
- Thứ Sáu, mùng 7: ghép nhịp kết nối vào thói quen then chốt.
- Thứ Bảy, mùng 8: hẹn một bàn tròn khai xuân.

Chủ Nhật nghỉ.

**Ngày 1 (15 phút): Bản đồ quan hệ công việc**

1. Mở sổ thực hành, xem lại thói quen đang giữ.
2. Điền bốn nhóm: khách hàng; đối tác và nhà cung cấp; đồng nghiệp ở bộ phận khác; người hướng dẫn hoặc người từng làm cùng. Mỗi nhóm vài người.
3. Từ bốn nhóm, chọn 5 đến 10 người muốn giữ liên lạc trong năm nay. Sổ lưu danh sách này cho cả hành trình.
4. Chọn một người đầu tiên muốn kết nối lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-1.

Chia sẻ hôm nay: "Bản đồ quan hệ công việc năm Đinh Mùi của tôi có ... người. Người đầu tiên tôi muốn kết nối lại: ...".

Khi chia sẻ, các anh chị và các bạn chỉ cần ghi vai trò, ví dụ "chị trưởng phòng mua hàng của một khách hàng cũ", không cần ghi tên thật nha.


## Bài 2: Ngày 2 (Thứ Ba 09/02)
@img 2_loi-chuc
@pdf 10XHub_KetNoi_PhieuNgay2_loi-chuc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: MÙNG 4, BA LỜI CHÚC TẾT CÓ TÊN NGƯỜI NHẬN

Mùng 4 Tết, điện thoại của nhiều người đã nhận hàng chục lời chúc giống hệt nhau, chuyển tiếp từ một tấm thiệp có sẵn. Những lời chúc đó lịch sự, nhưng ít khi được nhớ.

Hôm nay gửi ba lời chúc khác: mỗi lời chỉ dành cho một người, và nhắc đến một điều cụ thể của năm vừa qua.

**Năm điều làm nên một lời chúc được nhớ**

1. **Gọi đúng tên, đúng cách xưng hô.** "Chúc mừng năm mới chị Hà" khác hẳn "Chúc mừng năm mới quý khách".
2. **Nhắc một việc cụ thể của năm qua.** "Cảm ơn chị đã cùng em xử lý đợt giao hàng tháng 9." Một chi tiết cho người nhận biết lời chúc này viết riêng cho họ.
3. **Chúc một điều gắn với công việc của họ.** Nếu biết họ đang mở chi nhánh mới, chúc chi nhánh khai trương thuận lợi. Nếu không chắc, một lời chúc sức khoẻ và an vui là đủ.
4. **Ngắn.** Ba đến bốn câu. Người nhận đang nhận rất nhiều tin trong những ngày này.
5. **Không kèm đề nghị nào.** Không bảng giá, không lời mời họp, không "khi nào rảnh anh xem giúp em". Lời chúc chỉ là lời chúc.

**Vài mẫu theo người nhận**

- Gửi khách hàng: "Chúc mừng năm mới anh Minh. Cảm ơn anh đã tin tưởng giao cho nhóm em dự án kho năm qua, nhất là những tuần nước rút tháng 11. Chúc anh và gia đình một năm Đinh Mùi khoẻ mạnh, công việc thuận lợi."
- Gửi đối tác, nhà cung cấp: "Năm mới an khang chị Thuỷ. Nhờ chị linh động lịch giao vật tư hồi tháng 10 mà bên em kịp đơn hàng lớn. Chúc chị một năm mới nhiều niềm vui."
- Gửi đồng nghiệp bộ phận khác: "Chúc mừng năm mới anh Khoa. Báo cáo quý 4 xong đúng hạn có công rất lớn của anh bên phòng dữ liệu. Năm nay mình phối hợp tiếp nha anh."
- Gửi người hướng dẫn cũ: "Em chúc thầy năm mới thật nhiều sức khoẻ. Năm qua em vẫn dùng cách lập kế hoạch thầy chỉ hồi em mới đi làm."

**Chọn kênh nào?**

Không có kênh đúng cho mọi người. Một cuộc gọi ngắn hợp với người thân thiết hoặc người lớn tuổi. Tin nhắn hợp với người bận. Email hợp với đối tác ở nước ngoài hoặc những mối quan hệ trang trọng. Gặp trực tiếp, nếu tiện, luôn là lời chúc ấm nhất.

**Ngày 2 (15 phút)**

1. Từ bản đồ hôm qua, chọn ba người.
2. Viết ba lời chúc, mỗi lời có tên, một việc cụ thể của năm qua, một lời chúc gắn với họ.
3. Kiểm tra lại: không lời nào kèm đề nghị mua bán.
4. Gửi đi, đếm số lời chúc đã gửi.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-2.

Chia sẻ hôm nay: "Hôm nay tôi đã gửi ... lời chúc Tết cụ thể. Một điều cụ thể tôi nhắc trong lời chúc: ...".


## Bài 3: Ngày 3 (Thứ Tư 10/02)
@img 3_quan-he-yeu
@pdf 10XHub_KetNoi_PhieuNgay3_quan-he-yeu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: SỨC MẠNH CỦA NHỮNG MỐI QUAN HỆ LÂU CHƯA GẶP

Khi cần một thông tin mới, một cơ hội mới, người ta thường nghĩ đến những người thân thiết nhất. Năm 1973, nhà xã hội học Mark Granovetter công bố một bài báo cho thấy câu chuyện phức tạp hơn thế. Bài báo có tên "The Strength of Weak Ties", tức "Sức mạnh của mối quan hệ yếu", đăng trên American Journal of Sociology. Hôm nay đặt hai loại quan hệ cạnh nhau.

**Granovetter đã hỏi gì?**

Ông khảo sát những người làm công việc chuyên môn, kỹ thuật và quản lý ở Newton, một thành phố gần Boston, Mỹ, vừa đổi việc. Với những người tìm được việc mới qua một người quen, ông hỏi: trước đó, họ gặp người quen ấy thường xuyên đến đâu? Chỉ khoảng 17% gặp thường xuyên. Khoảng 56% thỉnh thoảng mới gặp. Khoảng 28% hiếm khi gặp, một năm một lần hoặc ít hơn.

Nói cách khác, phần lớn cơ hội đến qua những người không thân lắm.

**Quan hệ mạnh và quan hệ yếu, đặt cạnh nhau**

- Ai: quan hệ mạnh là những người gặp thường xuyên, như đồng nghiệp cùng phòng, bạn thân trong nghề. Quan hệ yếu là những người thỉnh thoảng mới gặp: một đối tác cũ, một bạn học cùng khoá đào tạo, một người từng làm cùng dự án.
- Thông tin: nhóm quan hệ mạnh thường biết những điều mình đã biết, vì cùng đọc, cùng nghe, cùng gặp những người giống nhau. Quan hệ yếu nối mình với những nhóm khác, nên hay mang đến điều mình chưa biết.
- Điều nhận được: quan hệ mạnh cho sự tin cậy, sự hỗ trợ lúc khó. Quan hệ yếu cho thông tin mới, góc nhìn mới, cơ hội mới.
- Rủi ro: quan hệ mạnh dễ giữ vì gặp hằng ngày. Quan hệ yếu dễ mất dần, vì không ai nhắc mình liên lạc.

Hai loại quan hệ không thay thế nhau. Một người làm việc tốt cần cả hai. Nhưng quan hệ yếu là loại dễ bị bỏ quên nhất, nên cần một chút chủ động.

Một lưu ý: nghiên cứu của Granovetter là một khảo sát quy mô nhỏ ở Mỹ vào đầu những năm 1970. Nó cho thấy một xu hướng rất đáng chú ý, không phải một quy luật chắc chắn cho mọi thị trường lao động.

**Ngày 3 (15 phút)**

1. Nhìn lại bản đồ quan hệ, tìm hai người thuộc nhóm quan hệ yếu: lâu chưa liên lạc, nhưng mình quý và tôn trọng.
2. Với mỗi người, viết một dòng: họ biết điều gì, ở lĩnh vực nào mà mình chưa biết.
3. Gửi một tin hỏi thăm ngắn, không nhờ việc gì, nhân dịp năm mới.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-3.

Chia sẻ hôm nay: "Hai mối quan hệ lâu chưa liên lạc tôi đã hỏi thăm lại: ... và .... Điều tôi mong học từ họ: ...".


## Bài 4: Ngày 4 (Thứ Năm 11/02)
@img 4_cho-truoc
@pdf 10XHub_KetNoi_PhieuNgay4_cho-truoc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CHO ĐI TRƯỚC MỘT ĐIỀU HỮU ÍCH

Hôm nay nhiều nơi đã đi làm lại. Ý thứ hai của Ferrazzi, hào phóng và không đếm điểm, thường gây nhiều câu hỏi nhất. Bài hôm nay trả lời từng câu.

**Hỏi: "Cho đi trước" nghĩa là gì trong công việc?**

Đáp: Là làm một điều hữu ích cho người khác trước khi họ nhờ, và không đặt điều kiện nhận lại. Không cần lớn. Một bài viết đúng mối quan tâm của họ, một lời giới thiệu, một lời ghi nhận cụ thể với cấp trên của họ đều là cho đi trước.

**Hỏi: Có những cách cho đi nào phù hợp ở chỗ làm?**

Đáp: Năm cách dễ làm nhất:
- Chia sẻ một tài liệu, một bài viết, một mẫu biểu đúng việc họ đang làm.
- Giới thiệu hai người có thể giúp nhau, sau khi đã hỏi ý cả hai.
- Gửi một lời ghi nhận cụ thể, có thể đồng gửi cấp trên của họ.
- Góp ý chuyên môn khi họ đang gặp một vấn đề mình có kinh nghiệm.
- Chúc mừng một cột mốc: thăng chức, khai trương, hoàn thành dự án.

**Hỏi: Làm vậy có bị xem là lấy lòng không?**

Đáp: Điều phân biệt nằm ở hai chỗ: điều mình cho có thật sự hữu ích với họ không, và mình có kèm theo một yêu cầu nào không. Một tài liệu đúng việc họ cần, gửi kèm một câu "em thấy bài này hợp với dự án chị đang làm", không kèm lời nhờ, hiếm khi bị hiểu lầm.

**Hỏi: Nếu cho mãi mà không nhận lại gì thì sao?**

Đáp: Ferrazzi khuyên không đếm điểm. Ở góc độ công việc, có thể nghĩ thế này: mục tiêu của việc cho đi trước là giữ một mối quan hệ sống, không phải đổi lấy một kết quả cụ thể. Nhiều mối quan hệ chỉ cho thấy giá trị sau nhiều năm. Cũng có mối quan hệ không bao giờ đem lại điều gì cụ thể, và điều đó vẫn ổn.

**Hỏi: Có giới hạn nào không?**

Đáp: Có. Cho đi trong khả năng và trong phạm vi công việc cho phép: không chia sẻ thông tin mật của công ty hay của khách hàng, không hứa điều mình không chắc làm được. Hào phóng không có nghĩa là bỏ ranh giới đã đặt ở tuần #0037.

**Ngày 4 (10 đến 15 phút)**

1. Chọn một người trong danh sách giữ liên lạc.
2. Chọn một cách cho đi phù hợp với người đó.
3. Làm ngay hôm nay, không kèm lời nhờ nào.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-4.

Chia sẻ hôm nay: "Điều tôi cho đi trước hôm nay: ..., gửi tới ...".


## Bài 5: Ngày 5 (Thứ Sáu 12/02)
@img 5_nhip-ket-noi
@pdf 10XHub_KetNoi_PhieuNgay5_nhip-ket-noi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MỖI TUẦN KẾT NỐI LẠI MỘT NGƯỜI

Bốn ngày qua là những việc làm một lần. Hôm nay biến chúng thành một nhịp, ghép vào thói quen then chốt. Để dễ hình dung, dưới đây là nhật ký minh hoạ bốn tuần của anh Tuấn, kỹ sư bảo trì ở một nhà máy chế biến. Anh Tuấn là nhân vật minh hoạ, không phải người thật.

**Nhật ký bốn tuần của anh Tuấn**

Tuần 1. Thói quen then chốt của mình là "chiều Thứ Sáu, viết ba việc quan trọng cho tuần sau". Hôm nay mình thêm một dòng thứ tư: "người kết nối lại tuần này". Mình ghi tên anh Phúc, kỹ sư bên nhà cung cấp máy đóng gói, lâu rồi chưa nói chuyện. Gửi một tin hỏi thăm năm mới. Anh trả lời sau hai tiếng, kể bên anh vừa có bộ cảm biến mới.

Tuần 2. Dòng thứ tư: chị Mai, phòng kế hoạch. Mình không nhắn mà ghé bàn chị năm phút, cảm ơn chị đã sắp lịch dừng máy hợp lý hồi tháng 12. Chị nói đây là lần đầu có người bên bảo trì cảm ơn chuyện đó.

Tuần 3. Tuần bận, sự cố liên tục. Mình chỉ kịp gửi một bài viết về bảo trì dự phòng cho một bạn học cũ cùng khoá đào tạo. Mất hai phút. Vẫn tính.

Tuần 4. Anh Phúc nhắn lại, mời mình đến xem thử bộ cảm biến mới khi nào tiện. Mình không nhờ gì, nhưng giờ có thêm một người để hỏi khi cần.

**Điều rút ra từ nhật ký**

- Nhịp được gắn vào một thói quen đã có, nên không cần nhớ thêm một việc mới.
- Mỗi lần chỉ vài phút. Tuần bận thì làm phiên bản ngắn nhất, giống cách phiên bản Tết đã giữ thói quen qua kỳ nghỉ.
- Không có tuần nào là chào hàng hay nhờ việc.
- Danh sách người giữ liên lạc viết hôm Thứ Hai là nơi lấy tên mỗi tuần.

**Chọn nhịp của mình**

Mỗi tuần một người là nhịp dễ giữ với đa số. Người làm kinh doanh, chăm sóc khách hàng có thể chọn hai người mỗi tuần. Người mới bắt đầu có thể chọn hai tuần một người. Quan trọng hơn con số là chỗ gắn nhịp: ngay sau thói quen then chốt, vào một khung giờ cố định.

**Ngày 5 (15 phút)**

1. Đọc lại thói quen then chốt và danh sách người giữ liên lạc trên sổ.
2. Viết nhịp kết nối của mình: bao lâu một lần, gắn sau việc gì.
3. Ghi tên người kết nối lại của tuần này.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-5.

Chia sẻ hôm nay: "Nhịp kết nối của tôi: .... Tôi gắn nhịp này ngay sau thói quen ...".


## Bài 6: Ngày 6 (Thứ Bảy 13/02)
@img 6_ban-tron
@img2 9_the-thanh-tich
@pdf 10XHub_KetNoi_PhieuNgay6_ban-tron.pdf (phiếu thực hành và vòng tròn quan hệ in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MÙNG 8, HẸN MỘT BÀN TRÒN KHAI XUÂN

Tên cuốn sách của tuần này là một lời khuyên về bữa ăn. Hôm nay làm đúng lời khuyên đó: hẹn một bữa cà phê, một bữa trưa, hoặc một cuộc gọi ngắn với một người trong danh sách, trong tháng 2.

**Một lời mời tốt gồm những gì?**

Một lời mời dễ nhận lời thường có bốn phần: lý do gặp, rõ ràng và không phải bán hàng; thời lượng ngắn, để người kia dễ sắp xếp; hai lựa chọn thời gian; và một lối thoát lịch sự, để người kia không thấy khó xử nếu bận.

Mẫu gửi một đồng nghiệp cũ:

"Chào anh Long, năm mới em chúc anh nhiều sức khoẻ. Lâu rồi anh em mình chưa ngồi với nhau từ hồi xong dự án kho. Em muốn mời anh một ly cà phê khoảng 30 phút, nghe anh kể về mảng vận hành mới anh đang phụ trách. Sáng Thứ Ba 23.02 hoặc Thứ Năm 25.02 anh có tiện không? Nếu tháng này anh bận thì mình hẹn dịp khác nha anh."

Mẫu gửi một khách hàng:

"Chào chị Ngọc, nhân dịp đầu năm, em muốn ghé thăm chị khoảng 20 phút để chúc Tết và nghe chị chia sẻ kế hoạch năm nay của phòng. Em không mang theo đề xuất nào, chỉ muốn hiểu thêm để năm nay hỗ trợ chị tốt hơn. Chị chọn giúp em một buổi trong tuần sau được không chị?"

**Bàn tròn khai xuân không cần lớn**

Một ly cà phê hai người cũng là một bàn tròn. Nếu không gặp được trực tiếp, một cuộc gọi video 20 phút vẫn giữ được tinh thần của buổi gặp. Điều quan trọng là có một cuộc hẹn cụ thể trên lịch, thay cho câu "hôm nào mình cà phê nha" rất quen thuộc mà ít khi thành.

**Một tuần khai xuân đã khép lại**

Sáu ngày qua, cả nhóm đã vẽ bản đồ quan hệ công việc, gửi những lời chúc Tết có tên người nhận, hỏi thăm lại những mối quan hệ lâu chưa gặp, cho đi trước một điều hữu ích, và ghép một nhịp kết nối vào thói quen then chốt. Những người bên kia màn hình có lẽ không biết đó là bài tập của một thử thách. Họ chỉ biết đầu năm có một người nhớ đến họ.

**Tuần sau: Đường cong quên và lặp lại cách quãng**

Thứ Hai 15.02 là tuần làm việc đầy đủ đầu tiên sau Tết. Công thức #0040 giúp khởi động lại thói quen sau kỳ nghỉ và ôn lại những công thức đã học từ tháng 10 theo lịch lặp lại cách quãng, chuẩn bị cho Mùa 3 "Học nhanh, nhớ lâu".

**Ngày 6 (15 phút)**

1. Chọn một người trong danh sách để hẹn.
2. Chọn hình thức và hai lựa chọn thời gian trong tháng 2.
3. Gửi lời mời theo bốn phần.
4. Đếm số người đã liên lạc lại trong tuần khai xuân.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0039-ngay-6.

Chia sẻ hôm nay: "Tuần khai xuân tôi đã kết nối lại với ... người. Cuộc hẹn đầu tiên của năm: ... với ..., ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích tuần khai xuân hiện ra: một vòng tròn với số người đã kết nối lại, tên mình và nhịp kết nối đã chọn. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần sau, công việc trở lại nhịp đầy đủ.
