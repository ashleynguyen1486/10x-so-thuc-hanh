## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 15/02)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0040_Duong Cong Quen_VN.pdf (tài liệu đầy đủ của Công thức #0040)
@pdf 10XHub_LapLaiCachQuang_PhieuNgay1_khoi-dong-lai.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0040.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN ĐẦU SAU TẾT: KHỞI ĐỘNG LẠI THÓI QUEN, ÔN LẠI 19 CÔNG THỨC

Thử ngay trước khi đọc tiếp: không mở lại tài liệu nào, trong hai phút, viết ra tên những công thức thành công của tuần mà mình còn nhớ, từ tháng 10 đến nay.

Được bao nhiêu? Từ #0021 Dòng chảy đến #0039 Đừng bao giờ ăn một mình là 19 công thức. Nếu con số trên giấy ít hơn nhiều, điều đó hoàn toàn bình thường. Đó cũng chính là chủ đề của tuần này.

Tuần khai xuân vừa qua, cả nhóm đã vẽ bản đồ quan hệ công việc, gửi những lời chúc Tết có tên người nhận, hỏi thăm lại những mối quan hệ lâu chưa gặp, cho đi trước một điều hữu ích, và ghép một nhịp kết nối mỗi tuần vào thói quen then chốt. Danh sách giữ liên lạc vẫn nằm trên sổ thực hành, sẵn sàng cho những tuần tới.

Hôm nay là tuần làm việc đầy đủ đầu tiên sau Tết. Công thức #0040 của tuần là Đường cong quên và lặp lại cách quãng. Tuần này làm hai việc song song: khởi động lại thói quen then chốt sau kỳ nghỉ, và ôn lại những công thức đã học theo cách giúp nhớ lâu.

**Nếu mới tham gia:** tuần đầu sau Tết là điểm bắt đầu rất tự nhiên, vì ai cũng đang lấy lại nhịp. Hôm nay viết vào sổ thực hành một câu "Tôi là người ..." và một thói quen nhỏ trong công việc muốn giữ, rồi làm bài Ngày 1 như mọi người. Phần ôn công thức, người mới có thể chọn ôn một công thức vừa đọc trên cộng đồng, cách làm hoàn toàn giống nhau.

**Đường cong quên là gì?**

Năm 1885, nhà tâm lý học người Đức Hermann Ebbinghaus công bố cuốn sách về trí nhớ, kết quả của nhiều năm tự làm thí nghiệm trên chính mình. Ông học thuộc những dãy âm tiết vô nghĩa, rồi đo xem sau 20 phút, một giờ, một ngày, một tháng, mình cần ít công hơn bao nhiêu để học thuộc lại. Kết quả vẽ thành một đường cong: phần lớn lượng quên xảy ra rất sớm, trong vài giờ và vài ngày đầu, rồi chậm dần.

Năm 2015, hai nhà nghiên cứu Jaap Murre và Joeri Dros ở Đại học Amsterdam lặp lại thí nghiệm này và thu được một đường cong rất giống. Thứ Ba sẽ nói kỹ hơn.

**Vì sao điều này quan trọng với hành trình?**

Hành trình thói quen đã đi qua 19 công thức. Nếu mỗi công thức chỉ được đọc một lần, theo đường cong quên, phần lớn sẽ mờ dần. Tin tốt là các nghiên cứu cũng cho thấy cách chống lại đường cong đó: ôn lại vào đúng những thời điểm cách quãng, và ôn bằng cách tự nhớ lại thay vì đọc lại. Tuần này dựng một lịch ôn như vậy, và gắn nó vào thói quen then chốt.

Đây cũng là chiếc cầu sang Mùa 3 "Học nhanh, nhớ lâu", mở từ tháng 4.

**Khởi động lại sau Tết**

Kỳ nghỉ dài làm hầu hết tín hiệu của thói quen thay đổi. Ngày đầu đi làm, có người đã quay lại nhịp ngay, có người lỡ vài ngày, có người dừng hẳn từ 28 Tết. Cả ba đều bình thường. Câu tự nhắc tử tế viết trước Tết là để dùng cho đúng ngày hôm nay. Bước đầu tiên chỉ là làm lại bản đầy đủ của thói quen một lần, càng sớm càng tốt.

**Sáu ngày của tuần đầu sau Tết**

- Thứ Hai: khởi động lại thói quen, thử nhớ lại các công thức.
- Thứ Ba: ba công thức muốn giữ lâu nhất.
- Thứ Tư: học dồn hay học cách quãng, dựng lịch ôn.
- Thứ Năm: làm thẻ ghi nhớ.
- Thứ Sáu: lần ôn đầu tiên, gắn vào thói quen.
- Thứ Bảy, Rằm tháng Giêng: giảng lại một công thức, nhìn sang Mùa 3.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Khởi động lại và thử nhớ lại**

1. Mở sổ thực hành, xem lại thói quen đang giữ và phiên bản Tết.
2. Chọn tình trạng thói quen sau Tết, ghi lần đầu tiên làm bản đầy đủ.
3. Đánh dấu bảng hành trình những ngày đã làm.
4. Không nhìn lại tài liệu, viết tên các công thức còn nhớ, rồi đếm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-1.

Chia sẻ hôm nay: "Sau Tết, tôi khởi động lại thói quen ... từ .... Không nhìn lại, tôi nhớ được ... công thức đã học".

Con số nhớ được không có đúng hay sai, các anh chị và các bạn cứ ghi thật con số của mình nha. Cuối tuần, mình sẽ cùng xem lại con số này.


## Bài 2: Ngày 2 (Thứ Ba 16/02)
@img 2_ebbinghaus
@pdf 10XHub_LapLaiCachQuang_PhieuNgay2_ba-cong-thuc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: HƠN 140 NĂM ĐO TỐC ĐỘ CON NGƯỜI QUÊN

Hôm nay đi qua câu chuyện của đường cong quên theo dòng thời gian, từ một căn phòng ở Berlin cuối thế kỷ 19 đến một thí nghiệm lặp lại ở Amsterdam năm 2015.

**Cuối những năm 1870 đến giữa những năm 1880: một người, hàng nghìn dãy âm tiết**

Hermann Ebbinghaus muốn đo trí nhớ một cách khách quan. Khó khăn đầu tiên: chữ có nghĩa thì gợi liên tưởng, mỗi người nhớ một kiểu. Ông tạo ra những âm tiết vô nghĩa ghép từ phụ âm, nguyên âm, phụ âm, rồi tự học thuộc từng dãy, ghi lại số lần đọc cần thiết. Ông là người làm thí nghiệm và cũng là người được thí nghiệm.

**Phép đo "tiết kiệm"**

Ebbinghaus không hỏi "còn nhớ bao nhiêu chữ". Ông đo xem học thuộc lại một dãy cũ tốn ít công hơn bao nhiêu so với lần đầu. Phần công sức giảm đi gọi là phần tiết kiệm, cho biết trí nhớ còn giữ lại bao nhiêu.

**1885: đường cong được công bố**

Kết quả nổi tiếng nhất trong cuốn sách năm 1885: phần tiết kiệm giảm rất nhanh trong giờ đầu, rồi chậm lại. Theo số liệu thường được trích từ sách, sau khoảng 20 phút còn gần 60%, sau một giờ còn khoảng 44%, sau một ngày còn khoảng một phần ba, và sau một tháng còn khoảng một phần năm. Ebbinghaus cũng ghi nhận rằng ôn lại nhiều lần qua nhiều ngày giúp phần nhớ được giữ lâu hơn.

**2015: lặp lại sau 130 năm**

Jaap Murre và Joeri Dros (Đại học Amsterdam) lặp lại thí nghiệm theo đúng cách của Ebbinghaus, với một người tham gia học thuộc các dãy âm tiết trong khoảng 70 giờ. Kết quả công bố trên tạp chí PLOS ONE: đường cong rất giống bản gốc. Họ còn thấy một điểm đáng chú ý: ở mốc 24 giờ, mức nhớ nhích lên một chút, có thể liên quan đến giấc ngủ.

**Hai điều nên nhớ về đường cong**

- Âm tiết vô nghĩa bị quên nhanh hơn kiến thức có ý nghĩa, gắn với công việc thật. Con số trên không áp thẳng cho mọi điều mình học.
- Hình dạng của đường cong thì rất bền vững: quên nhiều nhất ngay sau khi học. Vì vậy lần ôn đầu tiên nên đến sớm.

**Ngày 2 (20 phút)**

1. Từ danh sách công thức (sổ thực hành có sẵn tên 19 công thức để tra), chọn ba công thức muốn giữ lâu nhất cho công việc của mình.
2. Với mỗi công thức, không nhìn tài liệu, tự chấm mức nhớ: nhớ rõ, nhớ lờ mờ, gần như quên.
3. Chọn công thức nhớ rõ nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-2.

Chia sẻ hôm nay: "Ba công thức tôi muốn giữ lâu nhất: .... Công thức tôi nhớ rõ nhất: ...".


## Bài 3: Ngày 3 (Thứ Tư 17/02)
@img 3_lich-on
@pdf 10XHub_LapLaiCachQuang_PhieuNgay3_lich-on.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: HỌC DỒN MỘT LẦN HAY ÔN CÁCH QUÃNG?

Hai đồng nghiệp cùng chuẩn bị cho một kỳ thi chứng chỉ chuyên môn. Một người học dồn cả cuối tuần trước ngày thi. Một người chia đúng chừng ấy giờ ra nhiều buổi ngắn, cách nhau vài ngày. Ai nhớ lâu hơn? Hôm nay đặt hai cách học cạnh nhau.

**Hai cách học, đặt cạnh nhau**

- Cảm giác khi học: học dồn cho cảm giác rất trôi chảy, vì kiến thức vừa đọc còn nóng. Học cách quãng thường thấy khó hơn, vì mỗi lần ôn phải cố nhớ lại.
- Kết quả ngay sau khi học: hai cách có thể khá giống nhau, đôi khi học dồn còn nhỉnh hơn.
- Kết quả sau vài tuần: học cách quãng thường giữ lại được nhiều hơn rõ rệt.
- Tổng thời gian: có thể bằng nhau. Điều khác là cách chia.
- Hợp với: học dồn hợp khi chỉ cần nhớ trong vài giờ. Học cách quãng hợp với điều cần dùng lâu dài, như những công thức của hành trình.

**Nghiên cứu nói gì?**

Năm 2006, Nicholas Cepeda và các cộng sự tổng hợp 839 phép đo từ 317 thí nghiệm trong 184 bài báo về học cách quãng, đăng trên tạp chí Psychological Bulletin. Kết luận chung: với cùng thời lượng, chia ra nhiều buổi cách quãng giúp nhớ tốt hơn học dồn một lần. Họ cũng thấy khoảng cách giữa các lần ôn nên dài hơn khi mình cần nhớ lâu hơn.

Cảm giác "khó hơn" khi học cách quãng không phải dấu hiệu học kém. Chính nỗ lực nhớ lại đó giúp trí nhớ bền hơn.

**Lịch ôn 1, 3, 7, 14**

Một cách đặt lịch dễ nhớ: ôn lần đầu sau 1 ngày, rồi sau 3 ngày, 7 ngày, 14 ngày kể từ lần học. Khoảng cách giãn dần, đúng tinh thần của nghiên cứu. Cần nói rõ: các con số 1, 3, 7, 14 là một quy ước thực hành phổ biến, không phải công thức chính xác rút ra từ một nghiên cứu cụ thể. Ai thích nhịp khác, ví dụ 2, 7, 21 ngày, hoặc mỗi tuần một lần, đều được, miễn là có cách quãng và có lịch.

**Ngày 3 (20 phút)**

1. Chọn một nhịp ôn: 1, 3, 7, 14 ngày; 2, 7, 21 ngày; hoặc mỗi tuần một lần.
2. Viết lịch ôn cho ba công thức đã chọn hôm qua, với ngày cụ thể.
3. Đặt lời nhắc trong lịch làm việc cho lần ôn đầu tiên.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-3.

Chia sẻ hôm nay: "Lịch ôn của tôi: .... Lần ôn đầu tiên: ...".


## Bài 4: Ngày 4 (Thứ Năm 18/02)
@img 4_the-ghi-nho
@pdf 10XHub_LapLaiCachQuang_PhieuNgay4_the-ghi-nho.pdf (phiếu thực hành và thẻ ghi nhớ in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: SÁU TẤM THẺ GHI NHỚ CHO BA CÔNG THỨC

Đọc lại tài liệu là cách ôn quen thuộc nhất, nhưng không phải cách hiệu quả nhất. Năm 2006, Henry Roediger và Jeffrey Karpicke (Đại học Washington ở St. Louis) cho sinh viên đọc một đoạn văn, rồi hoặc đọc lại thêm, hoặc tự viết ra những gì nhớ được. Một tuần sau, nhóm tự nhớ lại nhớ được nhiều hơn rõ rệt, dù ngay sau khi học, nhóm đọc lại có vẻ nhỉnh hơn. Hiện tượng này thường được gọi là hiệu ứng kiểm tra: tự hỏi mình giúp nhớ lâu hơn đọc lại.

Thẻ ghi nhớ là cách đơn giản nhất để tự hỏi mình. Hôm nay làm sáu thẻ, theo năm bước.

**Bước 1: chọn đúng ý cần nhớ**

Mỗi công thức chọn hai ý dùng được trong công việc. Ví dụ với Ăn con ếch: "con ếch là gì" và "làm con ếch vào lúc nào trong ngày".

**Bước 2: mặt trước là một câu hỏi, không phải một tiêu đề**

"Ăn con ếch" là tiêu đề, nhìn vào chỉ thấy quen mắt. "Con ếch trong ngày làm việc của mình là việc như thế nào?" là câu hỏi, buộc mình phải nhớ lại.

**Bước 3: mặt sau ngắn, bằng lời của mình**

Một đến hai câu. Viết như đang giải thích cho một đồng nghiệp, không chép nguyên văn tài liệu. Đây là tinh thần của Kỹ thuật Feynman ở tuần #0028.

**Bước 4: thêm một ví dụ công việc**

Một dòng ví dụ của chính mình làm thẻ gắn với thực tế. "Con ếch của tôi sáng Thứ Hai là bản kế hoạch quý gửi giám đốc."

**Bước 5: ôn bằng cách che mặt sau**

Đọc câu hỏi, tự trả lời thành tiếng hoặc viết ra, rồi mới lật thẻ. Thẻ trả lời đúng thì để lần ôn sau xa hơn; thẻ trả lời sai thì ôn lại sớm hơn.

**Vài thẻ mẫu**

- Mặt trước: "Kế hoạch Nếu... thì... gồm những phần nào?" Mặt sau: "Nếu tình huống X xảy ra, thì tôi làm hành động Y. Ví dụ: nếu cuộc họp kéo dài quá giờ, thì tôi ghi việc dở vào sổ trước khi rời phòng."
- Mặt trước: "Giới hạn việc dở trên bảng Kanban dùng để làm gì?" Mặt sau: "Để không ôm quá nhiều việc cùng lúc, xong việc này mới kéo việc mới."
- Mặt trước: "Quan hệ yếu khác quan hệ mạnh ở điểm nào?" Mặt sau: "Quan hệ yếu nối mình với nhóm khác, nên hay mang thông tin mới."

Thẻ có thể viết trên giấy (phiếu Ngày 4 có sẵn trang thẻ in được), trong sổ tay, hoặc trong ứng dụng ghi chú. Hình thức không quan trọng bằng việc mặt trước là câu hỏi.

**Ngày 4 (25 phút)**

1. Mỗi công thức trong ba công thức đã chọn: viết hai thẻ.
2. Kiểm tra mặt trước là câu hỏi, mặt sau có một ví dụ công việc.
3. Thử ôn ngay một vòng bằng cách che mặt sau.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-4.

Chia sẻ hôm nay: "Tôi đã làm ... thẻ ghi nhớ. Một câu hỏi trên thẻ của tôi: ...".


## Bài 5: Ngày 5 (Thứ Sáu 19/02)
@img 5_on-sau-thoi-quen
@pdf 10XHub_LapLaiCachQuang_PhieuNgay5_on-sau-thoi-quen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: LẦN ÔN ĐẦU TIÊN, GẮN NGAY SAU THÓI QUEN

Hôm nay là lần ôn đầu tiên, đúng một ngày sau khi làm thẻ. Bài hôm nay trả lời những câu hỏi thường gặp khi bắt đầu ôn cách quãng.

**Hỏi: Ôn vào lúc nào thì dễ giữ nhất?**

Đáp: Ngay sau thói quen then chốt. Thói quen đó đã có tín hiệu, có giờ, có chỗ, đã được giữ qua nhiều tuần. Gắn việc ôn vào sau nó, theo cách xếp chồng thói quen đã dùng từ tuần đầu của hành trình, thì không phải nhớ thêm một tín hiệu mới. Ví dụ: "sau khi viết ba việc quan trọng nhất trước 8 giờ, tôi ôn ba thẻ ghi nhớ".

**Hỏi: Mỗi lần ôn bao lâu?**

Đáp: Năm phút là đủ cho ba đến sáu thẻ. Lịch ôn cách quãng hiệu quả nhờ đều đặn, không nhờ ôn lâu.

**Hỏi: Trả lời sai nhiều thì sao?**

Đáp: Lần ôn đầu sai nhiều là chuyện bình thường, vì đường cong quên dốc nhất ở những ngày đầu. Thẻ sai được ôn lại sớm hơn, thẻ đúng được giãn ra xa hơn. Câu tự nhắc tử tế viết trước Tết dùng được ở đây: trả lời sai là thông tin cho lần ôn sau, không phải điểm kém.

**Hỏi: Có nên đọc lại tài liệu khi quên không?**

Đáp: Có, nhưng sau khi đã cố nhớ. Thứ tự là: đọc câu hỏi, cố trả lời, lật thẻ, nếu vẫn chưa rõ thì mở lại tài liệu của công thức đó. Đọc lại ngay từ đầu sẽ bỏ qua bước tự nhớ lại, bước giúp trí nhớ bền nhất.

**Hỏi: Lịch ôn và bảng hành trình liên quan thế nào?**

Đáp: Ngày nào làm thói quen then chốt và ôn thẻ ngay sau đó, đánh dấu bảng hành trình như mọi ngày. Bảng hành trình tiếp tục đếm thói quen; việc ôn là một lớp mới gắn thêm vào thói quen đó, giống nhịp kết nối của tuần trước.

**Hỏi: Ôn đến bao giờ?**

Đáp: Theo lịch 1, 3, 7, 14 ngày, ba công thức tuần này sẽ có bốn lần ôn trong hai tuần. Sau đó có thể giãn ra mỗi tháng một lần. Mỗi tuần mới của hành trình, thêm hai thẻ cho công thức mới, rồi đưa vào cùng lịch.

**Ngày 5 (15 phút)**

1. Viết câu gắn: sau khi làm thói quen then chốt, tôi ôn thẻ ghi nhớ.
2. Ôn sáu thẻ, đếm số thẻ trả lời đúng.
3. Đánh dấu thẻ cần ôn sớm hơn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-5.

Chia sẻ hôm nay: "Lần ôn đầu tiên: tôi trả lời đúng ... trên ... thẻ. Tôi gắn việc ôn ngay sau ...".


## Bài 6: Ngày 6 (Thứ Bảy 20/02)
@img 6_ram-thang-gieng
@img2 9_the-thanh-tich
@pdf 10XHub_LapLaiCachQuang_PhieuNgay6_ram-thang-gieng.pdf (phiếu thực hành và lịch ôn bốn tuần in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: RẰM THÁNG GIÊNG, GIẢNG LẠI MỘT CÔNG THỨC

Hôm nay là Rằm tháng Giêng, ngày trăng tròn đầu tiên của năm Đinh Mùi. Với nhiều gia đình, đây là dịp sum họp sau Tết. Với hành trình, đây là ngày khép tuần đầu tiên làm việc đầy đủ sau kỳ nghỉ.

**Một tình huống minh hoạ**

Chị Hương là trưởng phòng nhân sự ở một công ty sản xuất. Thứ Hai đầu tuần, chị thử viết tên các công thức đã học và chỉ nhớ được 6 công thức. Chị chọn ba công thức muốn giữ: Ý định thực hiện, Kỹ thuật Feynman và Đặt ranh giới, làm sáu thẻ, ôn lần đầu sáng Thứ Sáu ngay sau thói quen viết ba việc quan trọng.

Sáng Thứ Bảy, chị làm thêm một việc: kể cho một trưởng nhóm mới về kế hoạch Nếu... thì..., trong 5 phút, bằng ví dụ của chính phòng nhân sự. Khi giảng, chị nhận ra mình nhớ cách đặt câu "Nếu... thì..." nhưng quên mất phần chọn tình huống khó nhất. Chị mở lại tài liệu #0023, sửa lại thẻ.

Chị Hương là nhân vật minh hoạ. Điều tình huống muốn nói: giảng lại là một cách ôn rất mạnh, vì nó buộc mình nhớ lại và sắp xếp lại kiến thức, đồng thời lộ ngay chỗ còn hổng. Đây chính là tinh thần của Kỹ thuật Feynman ở tuần #0028, nay trở thành một phần của lịch ôn.

**Việc của hôm nay**

Chọn một công thức trong ba công thức đã chọn, hẹn giảng lại cho một đồng nghiệp trong 5 phút tuần sau, kèm một ví dụ công việc của chính hai người. Rồi lên lịch ôn bốn tuần tới trên sổ thực hành.

Và thử lại bài tập của Thứ Hai: không nhìn tài liệu, viết tên các công thức còn nhớ. Con số hôm nay có khác Thứ Hai không? Dù khác hay không, sổ thực hành đã có một lịch ôn để con số đó tăng dần qua các tuần.

**Tuần sau: Sổ đầu dòng**

Thứ Hai 22.02, Công thức #0041 Sổ đầu dòng, dựa trên phương pháp của Ryder Carroll, dựng một nơi ghi chép duy nhất cho mọi bước của năm mục tiêu: việc trong ngày, lịch trong tháng, và lần chuyển việc đầu tiên cuối tháng 2. Lịch ôn thẻ ghi nhớ có thể đặt ngay trong sổ đó.

**Nhìn xa hơn: Mùa 3 "Học nhanh, nhớ lâu"**

Từ tháng 4, Mùa 3 của hành trình sẽ đi sâu vào cách học: học một kỹ năng mới nhanh hơn, nhớ những gì đã học lâu hơn. Đường cong quên và lặp lại cách quãng tuần này là viên gạch đầu tiên của mùa đó.

**Ngày 6 (20 phút)**

1. Chọn công thức sẽ giảng lại, người nghe và thời điểm.
2. Lên lịch ôn bốn tuần tới trên bảng của sổ thực hành.
3. Viết buổi ôn tiếp theo.
4. Thử lại bài nhớ lại của Thứ Hai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0040-ngay-6.

Chia sẻ hôm nay: "Công thức tôi sẽ giảng lại cho đồng nghiệp: .... Buổi ôn tiếp theo của tôi: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần đầu sau Tết hiện ra: một đường cong đi lên, con số thẻ ghi nhớ đã làm, tên mình và lịch ôn đã chọn. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chúc các anh chị và các bạn một ngày Rằm tháng Giêng thật ấm cúng bên gia đình nha.
