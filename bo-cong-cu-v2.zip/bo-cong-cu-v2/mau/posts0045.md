## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 22/03)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0045_Chi So Sao Bac Dau_VN.pdf (tài liệu đầy đủ của Công thức #0045)
@pdf 10XHub_SaoBacDau_PhieuNgay1_ban-do-5-muc-tieu.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0045.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỘT CON SỐ DẪN ĐƯỜNG CHO MỖI MỤC TIÊU

Tuần trước, cả nhóm đã đo thời gian bắt đầu thói quen vào Thứ Hai, viết quy tắc mặc định, làm lịch mục tiêu theo ngày và đo lại vào Thứ Bảy. Sổ quy tắc mặc định giờ đã nằm cạnh tín hiệu của thói quen, và sáng nay câu hỏi "hôm nay làm cho mục tiêu nào?" đã có câu trả lời sẵn. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Bắt đầu nhanh rồi, câu hỏi tiếp theo là: những bước đó có đang đưa mục tiêu đi đúng hướng không? Công thức #0045 của tuần này là Chỉ số Sao Bắc Đẩu cho mục tiêu.

**Nếu mới tham gia:** tuần này cần một mục tiêu công việc quan trọng nhất của năm, và một thói quen nhỏ phục vụ nó. Viết cả hai vào Ngày 1 trên sổ thực hành, rồi đi cùng cả nhóm tìm con số dẫn đường cho mục tiêu đó. Không cần đọc lại các tuần trước.

**Ba cảnh của một quý**

Đây là một tình huống minh hoạ, ghép từ những điều rất hay gặp khi làm việc với mục tiêu năm.

Cảnh một, đầu tháng 1. Anh Minh, trưởng phòng kinh doanh, viết mục tiêu số 1: "tăng doanh thu từ khách hàng doanh nghiệp". Anh hào hứng, lên kế hoạch, mỗi sáng làm một bước.

Cảnh hai, giữa tháng 2. Có người hỏi: "Mục tiêu của anh đang tới đâu rồi?" Anh trả lời: "Chắc ổn, tuần nào cũng làm." Anh đã làm rất nhiều: gặp khách, viết đề xuất, sửa bảng giá. Nhưng anh không có con số nào để biết những việc đó có cộng dồn thành kết quả hay không. Doanh thu quý thì phải đến tháng 4 mới có.

Cảnh ba, cuối tháng 3. Báo cáo quý về. Kết quả thấp hơn mong muốn. Anh nhìn lại và nhận ra phần lớn thời gian đã dành cho khách hàng nhỏ, dễ gặp, trong khi khách hàng doanh nghiệp lớn chỉ được liên hệ vài lần. Thông tin đó có từ tháng 1, nhưng không ai đếm.

Điều thiếu trong ba cảnh không phải là nỗ lực. Đó là hai con số: một con số cho biết mục tiêu có đang đi đúng hướng, và một con số hành động mỗi tuần mà anh kiểm soát được.

**Hai ý tưởng của tuần này**

Thứ nhất là chỉ số Sao Bắc Đẩu, một khái niệm trong quản trị sản phẩm thường được gắn với Sean Ellis và được công ty phân tích dữ liệu Amplitude hệ thống hoá thành bộ hướng dẫn. Ý chính: chọn một con số phản ánh đúng giá trị mà sản phẩm mang lại cho khách hàng, để cả đội nhìn cùng một hướng. Tuần này áp ý đó vào mục tiêu cá nhân trong công việc.

Thứ hai là cặp chỉ số dẫn trước và chỉ số kết quả, trong cuốn "The 4 Disciplines of Execution" của Chris McChesney, Sean Covey và Jim Huling (2012). Chỉ số kết quả cho biết mình đã đạt hay chưa, nhưng đến khi biết thì thường đã muộn. Chỉ số dẫn trước là việc mình làm mỗi tuần, dự báo được kết quả và nằm trong tầm tác động của mình.

Với anh Minh trong tình huống trên, Sao Bắc Đẩu có thể là "số khách hàng doanh nghiệp đang có đơn hàng mỗi tháng", còn chỉ số hành động mỗi tuần là "số buổi gặp trực tiếp với khách hàng doanh nghiệp".

**Sáu ngày của tuần**

- Thứ Hai: bản đồ năm mục tiêu, mục tiêu nào đã có con số.
- Thứ Ba: viết chỉ số Sao Bắc Đẩu cho mục tiêu số 1.
- Thứ Tư: chọn chỉ số hành động mỗi tuần.
- Thứ Năm: dựng một bảng điểm nhìn năm giây là hiểu.
- Thứ Sáu: nhịp xem bảng điểm 15 phút mỗi tuần.
- Thứ Bảy: nối một dòng từ mục tiêu xuống thói quen mỗi ngày.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Bản đồ năm mục tiêu**

1. Mở sổ thực hành, xem lại thói quen đang giữ và năm mục tiêu.
2. Với từng mục tiêu, chọn một trong ba trạng thái: đã có con số theo dõi đều đặn; có con số nhưng chỉ biết vào cuối kỳ; chưa có con số nào.
3. Đếm số mục tiêu đã có con số theo dõi đều đặn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-1.

Chia sẻ hôm nay: "Trong 5 mục tiêu, ... mục tiêu đã có con số theo dõi đều đặn. Mục tiêu số 1 của tôi: ...".

Mục tiêu nào chưa có con số cũng là chuyện rất bình thường sau một quý, các anh chị và các bạn cứ ghi đúng hiện trạng nha.


## Bài 2: Ngày 2 (Thứ Ba 23/03)
@img 2_sao-bac-dau
@pdf 10XHub_SaoBacDau_PhieuNgay2_sao-bac-dau.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: VIẾT CHỈ SỐ SAO BẮC ĐẨU CHO MỤC TIÊU SỐ 1

Hôm nay giải nghĩa từng chữ trong tên gọi, vì mỗi chữ là một tiêu chí để chọn đúng con số.

**"Sao Bắc Đẩu" nghĩa là gì?**

Trong tiếng Việt, khái niệm North Star Metric thường được gọi là chỉ số Sao Bắc Đẩu. Nói cho chính xác về thiên văn, ngôi sao gần như đứng yên ở phương bắc là sao Bắc Cực, và người đi đường xưa tìm ra nó nhờ hai ngôi sao đầu gáo của chòm Bắc Đẩu. Tên gọi mượn đúng hình ảnh dẫn đường đó: ngôi sao không cho biết mình đã đi được bao xa, nhưng cho biết mình có đang đi đúng hướng. Một chỉ số Sao Bắc Đẩu cũng vậy: nó không thay cho báo cáo kết quả cuối năm, nó cho biết giữa chừng mình có đang lệch hướng hay không.

**"Chỉ số" nghĩa là gì?**

Là một con số đếm hoặc đo được, đều đặn, không cần ý kiến chủ quan. "Khách hàng hài lòng hơn" chưa phải chỉ số. "Tỷ lệ khiếu nại được giải quyết trong 24 giờ" là chỉ số.

**"Một" nghĩa là gì?**

Mỗi mục tiêu chỉ một Sao Bắc Đẩu. Hai, ba con số dẫn đường dễ kéo mình về hai, ba hướng khác nhau. Các con số khác vẫn được theo dõi, nhưng chỉ một con số được dùng để giữ hướng.

**"Giá trị thật" nghĩa là gì?**

Trong quản trị sản phẩm, một chỉ số Sao Bắc Đẩu tốt phản ánh giá trị mà khách hàng thật sự nhận được, không chỉ hoạt động bề mặt. Trong công việc, hãy hỏi: con số này tăng thì người nhận kết quả công việc của mình (khách hàng, đồng nghiệp, cấp trên, bộ phận khác) có thật sự được lợi không?

Ví dụ với người làm kế toán, mục tiêu "chốt sổ tháng nhanh hơn": "số giờ làm thêm trong tuần chốt sổ" là con số của chính mình; "số ngày từ cuối tháng đến khi báo cáo đến tay ban giám đốc" là con số mà người nhận cảm nhận được. Con số thứ hai hợp làm Sao Bắc Đẩu hơn.

**"Không tự làm đẹp được" nghĩa là gì?**

Một con số dễ tăng bằng cách làm nhanh cho có thì không dẫn đường được. "Số email đã gửi cho khách hàng" có thể tăng gấp đôi mà không ai được lợi. Khi chọn, hãy tự hỏi: có cách nào làm con số này đẹp lên mà kết quả thật vẫn đứng yên không?

**Ngày 2 (20 phút)**

1. Viết hai hoặc ba con số ứng viên cho mục tiêu số 1.
2. Kiểm tra từng ứng viên với ba câu hỏi: đo được đều đặn không; người nhận có được lợi khi nó tăng không; có tự làm đẹp được không.
3. Chọn một con số làm Sao Bắc Đẩu, ghi giá trị hiện tại nếu biết.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-2. Chỉ số Sao Bắc Đẩu viết hôm nay được lưu cho cả hành trình.

Chia sẻ hôm nay: "Sao Bắc Đẩu của mục tiêu số 1: ...".


## Bài 3: Ngày 3 (Thứ Tư 24/03)
@img 3_chi-so-hanh-dong
@pdf 10XHub_SaoBacDau_PhieuNgay3_chi-so-hanh-dong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: CHỌN MỘT CON SỐ HÀNH ĐỘNG MỖI TUẦN

Sao Bắc Đẩu cho biết hướng, nhưng thường chỉ thay đổi chậm. Hôm nay chọn con số mình tác động được ngay trong tuần. Dạng bài là một bảng chọn: ba ứng viên, hai tiêu chí, chấm điểm rồi chọn.

**Hai tiêu chí của chỉ số dẫn trước**

Theo "The 4 Disciplines of Execution", một chỉ số dẫn trước tốt có hai đặc điểm:

- Dự báo được: làm nhiều hơn thì kết quả có khả năng tốt hơn.
- Tác động được: phần lớn nằm trong tay mình, không phụ thuộc người khác quyết định.

Thiếu một trong hai là chưa dùng được. "Số hợp đồng ký mỗi tuần" dự báo tốt nhưng phụ thuộc khách hàng. "Số giờ ngồi ở bàn" tác động được nhưng không dự báo được gì.

**Bảng chọn mẫu cho người làm nhân sự**

Mục tiêu số 1: giảm tỷ lệ nghỉ việc của nhân viên mới trong ba tháng đầu. Sao Bắc Đẩu: tỷ lệ nhân viên mới còn làm việc sau 90 ngày.

1. Số buổi trao đổi một một với nhân viên mới mỗi tuần. Dự báo: cao, vì nhiều lý do nghỉ việc sớm được phát hiện qua trao đổi. Tác động: cao. → Chọn được.
2. Số khoá đào tạo hội nhập tổ chức mỗi tháng. Dự báo: trung bình. Tác động: thấp, cần ngân sách và lịch của nhiều bộ phận. → Để sau.
3. Điểm khảo sát hài lòng của nhân viên mới. Dự báo: cao. Tác động: thấp, đây gần với kết quả hơn là hành động. → Không chọn làm chỉ số hành động.

**Bảng chọn mẫu cho người làm kỹ thuật**

Mục tiêu số 1: giảm thời gian dừng máy. Sao Bắc Đẩu: số giờ dừng máy ngoài kế hoạch mỗi tháng.

1. Số lần kiểm tra phòng ngừa đúng lịch mỗi tuần. Dự báo: cao. Tác động: cao. → Chọn được.
2. Số linh kiện dự phòng trong kho. Dự báo: trung bình. Tác động: thấp, cần phê duyệt mua sắm. → Để sau.
3. Số lần máy dừng. Đây chính là kết quả. → Không chọn.

**Viết con số hành động sao cho rõ**

Một con số hành động tốt có động từ, có số, có khung thời gian: "mỗi tuần gặp trực tiếp 3 khách hàng doanh nghiệp", "mỗi tuần 4 buổi kiểm tra phòng ngừa đúng lịch". Con số nên vừa sức: đủ để tạo khác biệt, nhưng vẫn làm được trong tuần bận nhất.

**Ngày 3 (20 phút)**

1. Viết ba ứng viên chỉ số hành động cho Sao Bắc Đẩu của mục tiêu số 1.
2. Chấm mỗi ứng viên theo hai tiêu chí: dự báo được, tác động được.
3. Chọn một, viết thành câu có động từ, con số, khung thời gian.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-3. Chỉ số hành động cũng được lưu cho cả hành trình.

Chia sẻ hôm nay: "Chỉ số hành động mỗi tuần của tôi: ...".


## Bài 4: Ngày 4 (Thứ Năm 25/03)
@img 4_bang-diem
@pdf 10XHub_SaoBacDau_PhieuNgay4_bang-diem.pdf (phiếu thực hành và bảng điểm in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BẢNG ĐIỂM NHÌN NĂM GIÂY LÀ HIỂU

"The 4 Disciplines of Execution" phân biệt hai loại bảng điểm. Hôm nay đặt chúng cạnh nhau.

**Bảng điểm của người quản lý và bảng điểm của người làm**

- Mục đích: bảng của người quản lý dùng để phân tích, có nhiều số liệu, nhiều biểu đồ. Bảng của người làm dùng để biết ngay mình đang thắng hay thua.
- Số lượng con số: bảng của người quản lý có thể có hàng chục. Bảng của người làm chỉ cần hai: Sao Bắc Đẩu và chỉ số hành động.
- Thời gian đọc: bảng của người quản lý cần vài phút, thậm chí cần người giải thích. Bảng của người làm nhìn khoảng năm giây là hiểu.
- Người cập nhật: bảng của người quản lý thường do một bộ phận khác làm. Bảng của người làm do chính mình cập nhật, bằng tay.
- Nơi đặt: bảng của người quản lý nằm trong một tệp báo cáo. Bảng của người làm nằm ở chỗ mình nhìn thấy mỗi ngày.

Không phải bảng của người quản lý là thừa. Nó cần cho việc ra quyết định ở cấp cao hơn. Nhưng để giữ một thói quen hằng tuần, bảng của người làm hiệu quả hơn nhiều, vì nó trả lời đúng một câu: tuần này mình có làm đủ không?

**Một bảng điểm đơn giản trông như thế nào?**

Một tờ giấy khổ nhỏ, hai phần. Phần trên: Sao Bắc Đẩu, giá trị đầu quý và giá trị mong muốn cuối quý. Phần dưới: một hàng ô cho các tuần còn lại của quý 2, mỗi ô ghi số lần đã làm chỉ số hành động trong tuần đó, tô đỏ nếu đạt.

Ví dụ: "Sao Bắc Đẩu: tỷ lệ nhân viên mới còn làm việc sau 90 ngày, từ 70% lên 85% vào cuối tháng 6. Mỗi tuần: 3 buổi trao đổi một một. Tuần 1: 3 ✓. Tuần 2: 2."

Mẫu câu "từ ... lên ... vào ngày ..." cũng là cách viết mục tiêu được dùng trong cuốn sách: có điểm xuất phát, có đích, có thời hạn.

**Ngày 4 (20 phút)**

1. Viết Sao Bắc Đẩu theo mẫu: từ ... lên ... vào ngày ....
2. Dựng bảng điểm hai phần trên giấy (phiếu Ngày 4 có mẫu in được) hoặc trên sổ thực hành.
3. Ghi kết quả tuần này: đã làm chỉ số hành động bao nhiêu lần.
4. Chọn chỗ đặt bảng điểm, gần tín hiệu của thói quen then chốt.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-4.

Chia sẻ hôm nay: "Bảng điểm của tôi đặt ở .... Tuần này tôi đã làm ... lần, mục tiêu tuần là ...".


## Bài 5: Ngày 5 (Thứ Sáu 26/03)
@img 5_nhip-tuan
@pdf 10XHub_SaoBacDau_PhieuNgay5_nhip-tuan.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MƯỜI LĂM PHÚT CHIỀU THỨ SÁU VỚI BẢNG ĐIỂM

Bảng điểm chỉ có ích khi được nhìn đều đặn. Cuốn sách gọi đây là nhịp trách nhiệm: một buổi ngắn, cố định mỗi tuần, chỉ bàn về mục tiêu quan trọng nhất. Với một người, buổi đó có thể là 15 phút chiều Thứ Sáu. Hôm nay là năm câu hỏi mở cho 15 phút ấy. Không cần trả lời hay, chỉ cần trả lời thật.

**Câu hỏi 1: Tuần này mình đã cam kết làm gì, và đã làm được bao nhiêu?**

Nhìn con số hành động trên bảng điểm. Ghi đúng số đã làm, không làm tròn lên.

**Câu hỏi 2: Sao Bắc Đẩu đang đi lên, đứng yên hay đi xuống?**

Chỉ số này thường thay đổi chậm, có khi vài tuần mới thấy. Hai tuần đứng yên chưa nói lên điều gì. Nhưng nếu chỉ số hành động đạt đều mà Sao Bắc Đẩu vẫn đứng yên trong một thời gian dài, đó là tín hiệu nên xem lại chỉ số hành động.

**Câu hỏi 3: Điều gì đã cản mình, và điều đó có lặp lại không?**

Họp đột xuất, khách hàng đổi lịch, một việc gấp chen ngang. Nếu một trở ngại lặp lại hai tuần liền, đó là lúc dùng lại kế hoạch Nếu... thì... hoặc quy tắc mặc định của tuần trước.

**Câu hỏi 4: Tuần tới, mình cam kết làm cụ thể điều gì?**

Một hoặc hai cam kết, có ngày, có việc. "Thứ Ba gặp anh Hoàng bên đối tác phân phối" rõ hơn "gặp thêm khách hàng".

**Câu hỏi 5: Thói quen mỗi ngày có đang phục vụ con số hành động không?**

Đây là chỗ nối với hành trình thói quen. Nếu thói quen then chốt là "20 phút đầu giờ cho mục tiêu số 1", thì 20 phút đó nên là lúc chuẩn bị hoặc làm chính con số hành động: gọi điện hẹn gặp, chuẩn bị buổi trao đổi, kiểm tra phòng ngừa.

**Đặt nhịp vào lịch**

Mười lăm phút này nên có giờ cố định, như mọi cuộc hẹn khác. Chiều Thứ Sáu hợp với nhiều người vì vừa khép tuần, vừa kịp chuẩn bị cho Thứ Hai. Ai có buổi giao ban nhóm đầu tuần thì có thể đặt vào sáng Thứ Hai, trước giờ họp.

**Ngày 5 (15 phút)**

1. Trả lời năm câu hỏi cho tuần này.
2. Viết một cam kết cụ thể cho tuần tới.
3. Đặt giờ cố định cho nhịp hằng tuần vào lịch.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-5.

Chia sẻ hôm nay: "Nhịp xem bảng điểm của tôi: .... Cam kết tuần tới: ...".


## Bài 6: Ngày 6 (Thứ Bảy 27/03)
@img 6_mot-dong
@img2 9_the-thanh-tich
@pdf 10XHub_SaoBacDau_PhieuNgay6_mot-dong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MỘT DÒNG TỪ MỤC TIÊU XUỐNG THÓI QUEN

Hôm nay mở đầu bằng một trang nhật ký minh hoạ của chị Hà, chuyên viên chăm sóc khách hàng, trong tuần đầu dùng bảng điểm. Mục tiêu số 1 của chị: khách hàng được giải quyết khiếu nại nhanh hơn. Sao Bắc Đẩu: tỷ lệ khiếu nại được giải quyết trong 24 giờ. Chỉ số hành động: mỗi tuần viết 3 câu trả lời mẫu cho những tình huống hay gặp.

**Nhật ký minh hoạ**

- Thứ Hai: dán bảng điểm cạnh màn hình. Thói quen 20 phút đầu giờ, viết câu trả lời mẫu đầu tiên cho tình huống giao hàng trễ.
- Thứ Ba: không viết được, cả buổi sáng xử lý một sự cố hệ thống. Tối ghi vào bảng: "Thứ Ba: 0".
- Thứ Tư: viết câu trả lời mẫu thứ hai, về đổi trả hàng. Chiều có hai khách hỏi đúng việc này, trả lời nhanh hơn hẳn.
- Thứ Năm: đồng nghiệp hỏi xin câu trả lời mẫu. Chị đưa vào thư mục chung của nhóm.
- Thứ Sáu: viết câu thứ ba. Mười lăm phút chiều Thứ Sáu: đạt 3 trên 3. Tỷ lệ 24 giờ chưa đổi, còn sớm để biết. Cam kết tuần tới: tình huống sai địa chỉ và thanh toán lỗi.

Chi tiết đáng chú ý nhất không nằm ở con số 3 trên 3, mà ở Thứ Ba. Một ngày bằng 0 được ghi lại rõ ràng, không bị bỏ qua, và tuần vẫn đạt nhờ những ngày còn lại.

**Một dòng nối bốn tầng**

Cuối tuần, chị viết lại mọi điều trên một dòng:

Mục tiêu số 1 → Sao Bắc Đẩu → con số hành động mỗi tuần → thói quen mỗi ngày.

"Khiếu nại được giải quyết nhanh hơn → tỷ lệ giải quyết trong 24 giờ → 3 câu trả lời mẫu mỗi tuần → 20 phút đầu giờ viết hoặc sửa một câu trả lời."

Đọc dòng này từ trái sang phải là thấy vì sao mình làm thói quen mỗi sáng. Đọc từ phải sang trái là thấy mỗi sáng đóng góp vào đâu.

**Sáng nay (15 phút)**

1. Viết một dòng bốn tầng cho mục tiêu số 1.
2. Ghi kết quả cả tuần lên bảng điểm.

**Trước khi nghỉ Chủ Nhật (10 phút)**

Chọn thêm một mục tiêu nữa trong năm mục tiêu để làm dòng bốn tầng vào tuần sau, nếu muốn. Mục tiêu số 1 vẫn là ưu tiên.

**Tuần sau: khép quý 1 và khép Mùa 2**

Công thức #0046, bắt đầu Thứ Hai 29.03, là tuần cuối của quý 1 và của Mùa 2. Cả nhóm sẽ nhìn lại năm mục tiêu sau một quý, và bảng điểm của tuần này sẽ là một nguồn thông tin quan trọng cho lần nhìn lại đó.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0045-ngay-6.

Chia sẻ hôm nay: "Mục tiêu số 1: ... → Sao Bắc Đẩu: ... → mỗi tuần: ... → mỗi ngày: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: một khối đỏ ghi tổng số ngày đã giữ thói quen trên cả hành trình, chuỗi sáu ô của tuần này, tên mình và Sao Bắc Đẩu của mục tiêu số 1. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần sau là tuần khép quý, cả nhóm cùng nhìn lại một chặng đường đã đi.
