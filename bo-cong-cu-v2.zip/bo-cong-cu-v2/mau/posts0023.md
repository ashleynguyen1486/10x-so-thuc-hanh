## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 19/10)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0023_Y Dinh Thuc Hien_VN.pdf (tài liệu đầy đủ của Công thức #0023)
@pdf 10XHub_YDinhThucHien_PhieuNgay1_nhin-lai.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0023.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** NGÀY KHÓ NÀO CŨNG CẦN MỘT KẾ HOẠCH SẴN

Tuần trước, cả nhóm đã viết câu bản sắc, chọn một thói quen then chốt, thiết kế nó qua bốn quy luật và ký hợp đồng thói quen vào Thứ Bảy. Tuần này giữ nguyên thói quen đó, không đổi, và thêm cho nó một lớp bảo vệ cho những ngày không suôn sẻ.

**Nếu mới tham gia:** không cần quay lại tuần trước. Hôm nay mở sổ thực hành Ngày 1, viết một câu bản sắc, một thói quen nhỏ muốn giữ trong công việc và phiên bản tối thiểu của nó, tức là phiên bản làm xong trong hai phút. Phần nhìn lại thì dùng năm ngày làm việc gần nhất của mình. Từ Thứ Ba, các anh chị và các bạn đi cùng nhịp với cả nhóm.

**Một câu hỏi để mở tuần**

Trong sáu ngày vừa qua, thói quen then chốt bị lỡ vào ngày nào?

Câu hỏi này không nhằm chấm điểm. Ngày lỡ là dữ liệu quý nhất của một hành trình thói quen, vì nó chỉ ra đúng chỗ thói quen dễ gãy. Thường thì nguyên nhân không nằm ở quyết tâm. Thói quen được thiết kế cho một ngày bình thường, còn ngày bị lỡ lại là một ngày không bình thường: cuộc họp giao ban kéo dài, chuyến công tác đột xuất, một đồng nghiệp ghé bàn đúng lúc mình định bắt đầu.

Vài câu hỏi tiếp theo đáng dành năm phút:

- Những ngày lỡ có điểm chung nào không? Cùng một ngày trong tuần, cùng một loại cuộc họp, cùng một người cần mình?
- Trở ngại xuất hiện trước hay sau giờ định làm thói quen?
- Lúc đó trong đầu là câu "để chiều làm" hay "hôm nay bỏ qua cũng được"?
- Nếu đúng ngày đó lặp lại vào tuần sau, mình sẽ làm khác đi điều gì?

**Câu trả lời cho câu hỏi cuối cùng có một tên gọi riêng**

Nhà tâm lý học Peter Gollwitzer (Đại học New York) gọi đó là ý định thực hiện dạng "Nếu... thì...". Trong bài tổng quan năm 1999 trên tạp chí American Psychologist, ông mô tả cấu trúc rất ngắn: "Khi tình huống X xuất hiện, tôi sẽ làm Y." Năm 2006, Gollwitzer và Paschal Sheeran tổng hợp 94 thử nghiệm độc lập và ghi nhận kế hoạch dạng này giúp người ta đạt mục tiêu tốt hơn, với mức hiệu ứng từ trung bình đến lớn.

Thứ Ba tuần trước, cả nhóm đã viết câu "Tôi sẽ [việc] vào [giờ] tại [chỗ]". Đó là ý định thực hiện cho ngày bình thường. Tuần này viết phần còn thiếu: ý định thực hiện cho ngày khó. Vế "nếu" là một trở ngại cụ thể. Vế "thì" là phiên bản tối thiểu của thói quen, đủ nhỏ để vẫn làm được ngay trong ngày khó đó.

Khi kế hoạch đã có sẵn, lúc trở ngại xuất hiện, mình không phải cân nhắc lại từ đầu. Theo cách giải thích của Gollwitzer, tình huống đã được gắn trước với hành động, nên chính tình huống trở thành tín hiệu nhắc mình bắt đầu.

**Sáu ngày của tuần này**

Thứ Hai nhìn lại tuần trước. Thứ Ba viết ba kế hoạch Nếu... thì.... Thứ Tư chuẩn bị cho ngày họp dồn và ngày đi công tác. Thứ Năm soạn sẵn câu trả lời khi bị chen ngang. Thứ Sáu dùng thử và ghi lại. Thứ Bảy làm thẻ Nếu... thì... đặt trên bàn và đánh dấu bảng hành trình. Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Đọc lại tuần trước**

1. Mở sổ thực hành, chọn tuần 0022, Ngày 5, xem bảng hành trình. Ghi lại số ngày đã làm và số ngày lỡ.
2. Với mỗi ngày lỡ, viết một dòng: hôm đó chuyện gì đã xảy ra, vào lúc nào.
3. Chọn trở ngại lớn nhất và viết lại thật cụ thể, như đang kể cho một đồng nghiệp nghe.
4. Kiểm tra phiên bản tối thiểu của thói quen. Nếu chưa có, viết ngay hôm nay.

Một dòng viết tốt: "Thứ Tư, họp giao ban kéo dài đến 10 giờ, sau đó hộp thư đầy và tôi bỏ luôn phiên làm việc sâu." Một dòng viết chưa tốt: "Bận quá." Dòng thứ nhất cho thấy ngay chỗ cần đặt kế hoạch. Dòng thứ hai thì chưa.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-1. Thói quen và phiên bản tối thiểu đã viết tuần trước sẽ tự hiện lại.

Chia sẻ hôm nay: "Thói quen tôi đang giữ: .... Tuần trước tôi làm được ... ngày. Trở ngại lớn nhất: ...". Ai chưa lỡ ngày nào thì ghi trở ngại suýt làm mình lỡ, vẫn rất đáng chia sẻ nha.


## Bài 2: Ngày 2 (Thứ Ba 20/10)
@img 2_ba-ke-hoach
@pdf 10XHub_YDinhThucHien_PhieuNgay2_ba-ke-hoach.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: BA CÂU NẾU... THÌ... CHO BA TRỞ NGẠI

Hôm nay là ngày 20 tháng 10, Ngày Phụ nữ Việt Nam. Trường xin gửi lời tri ân đến các chị, các bạn nữ trong cộng đồng 10X Excellence Hub và các đồng nghiệp nữ ở mọi doanh nghiệp: những người vừa giữ nhịp cho đội nhóm, vừa giữ cam kết với khách hàng, và vẫn dành thời gian cho hành trình phát triển của chính mình. Chúc các chị, các bạn một ngày làm việc nhẹ nhàng và được ghi nhận xứng đáng.

Bài hôm nay đi theo dạng giải nghĩa: tách một câu Nếu... thì... thành từng phần, xem mỗi phần cần viết thế nào để dùng được trong một ngày làm việc thật.

**Câu mẫu**

"Nếu họp giao ban kéo dài quá 9 giờ, thì tôi làm 10 phút kế hoạch ngay sau cuộc họp, trước khi mở hộp thư."

**"Nếu": một tình huống nhìn thấy được.** Vế đầu là điều mình nhận ra ngay khi nó xảy ra: cuộc họp kéo dài, cuộc gọi đến, chuyến bay sớm. "Nếu bận" hay "nếu mệt" là cảm giác, rất khó nhận ra đúng lúc. "Nếu đồng hồ chỉ 9 giờ mà cuộc họp chưa kết thúc" thì nhận ra được ngay.

**"Họp giao ban kéo dài": lấy từ chính tuần trước.** Trở ngại đáng viết nhất là trở ngại đã thật sự xảy ra. Đó là lý do hôm qua cả nhóm đọc lại bảng hành trình. Kế hoạch đầu tiên nên giải quyết đúng trở ngại lớn nhất đã ghi ở Ngày 1.

**"Thì": một hành động, không phải một lời hứa.** Vế sau bắt đầu bằng động từ: làm, mở, viết, gọi, gửi. "Thì tôi sẽ cố gắng hơn" chưa phải hành động. "Thì tôi mở tệp kế hoạch" là hành động.

**"10 phút": phiên bản tối thiểu.** Ngày khó không phải ngày để làm bản đầy đủ. Vế "thì" nên là phiên bản tối thiểu đã viết ở tuần trước, hoặc một phiên bản ngắn hơn bình thường. Mục tiêu của ngày khó là giữ được chuỗi.

**"Ngay sau cuộc họp, trước khi mở hộp thư": một mốc rõ ràng.** Hành động cần được gắn vào một mốc. Không có mốc, "làm sau" rất dễ thành "không làm".

Có một thử nghiệm của Gollwitzer và Veronika Brandstätter (1997) hay được nhắc lại. Trước kỳ nghỉ Giáng sinh, sinh viên được giao viết một bản báo cáo về cách mình trải qua đêm Giáng sinh và gửi trong vòng hai ngày sau đó. Ở nhóm viết sẵn khi nào và ở đâu sẽ làm, khoảng 75% gửi đúng hạn. Ở nhóm không viết kế hoạch, con số này khoảng 33%. Chỉ thêm một câu viết sẵn, khác biệt đã khá rõ.

**Ba kế hoạch cho ba trở ngại**

1. Kế hoạch 1: trở ngại lớn nhất tuần trước, lấy từ Ngày 1.
2. Kế hoạch 2: ngày lịch dồn, họp liền nhau hoặc đi công tác. Thứ Tư sẽ sửa kỹ hơn.
3. Kế hoạch 3: khi người khác chen ngang. Thứ Năm sẽ soạn câu trả lời.

**Ngày 2 (25 phút)**

1. Viết ba câu Nếu... thì... cho ba trở ngại trên.
2. Kiểm tra từng câu: vế "nếu" nhận ra được ngay, vế "thì" bắt đầu bằng động từ và làm được trong 10 phút trở xuống.
3. Đọc to ba câu một lần. Đọc thành tiếng giúp phát hiện chỗ còn mơ hồ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-2. Ba kế hoạch được lưu cho cả hành trình.

Chia sẻ hôm nay: "Nếu ... thì tôi .... Nếu ... thì tôi .... Nếu ... thì tôi ...". Ba câu chưa hoàn chỉnh cũng được, hai ngày tới còn sửa tiếp nha.


## Bài 3: Ngày 3 (Thứ Tư 21/10)
@img 3_ngay-kho
@pdf 10XHub_YDinhThucHien_PhieuNgay3_ngay-kho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: LỊCH DỒN VẪN CÒN CHỖ CHO THÓI QUEN

Thử hình dung một Thứ Năm của chị Hạnh, trưởng phòng kinh doanh ở một công ty phân phối thiết bị. Chị Hạnh là nhân vật minh hoạ, nhưng lịch của chị chắc nhiều người thấy quen.

Thói quen then chốt của chị: mỗi sáng dành 30 phút xem lại danh sách khách hàng tiềm năng và chọn ba người cần gọi trong ngày. Phiên bản tối thiểu: mở danh sách, đánh dấu một tên.

Thứ Năm đó, chị bay ra Đà Nẵng lúc 7 giờ 30. Gặp khách lúc 10 giờ. Họp với nhà phân phối lúc 14 giờ. Bay về lúc 18 giờ.

**Phiên bản không có kế hoạch**

Ra sân bay, chị nghĩ "lên máy bay rồi làm". Trên máy bay, chị đọc lại tài liệu cho buổi gặp khách. Buổi trưa có tin nhắn từ văn phòng. Buổi chiều kéo dài hơn dự kiến. Tối về đến nhà, chị tự nhủ "hôm nay đặc biệt, bỏ một ngày cũng được". Thứ Sáu vào văn phòng, hộp thư dồn từ hôm trước, và thói quen lỡ thêm một ngày nữa.

**Phiên bản có kế hoạch**

Thứ Hai đầu tuần, chị nhìn lịch và thấy Thứ Năm là ngày khó. Chị viết: "Nếu tôi có chuyến bay trước 8 giờ, thì trong lúc chờ lên máy bay tôi mở danh sách khách hàng trên điện thoại và chọn ba người cần gọi." Chị tải sẵn danh sách về điện thoại từ tối Thứ Tư.

Sáng Thứ Năm, ngồi ở cửa ra máy bay, chị không phải quyết định gì. Tình huống đã xảy ra, và câu trả lời đã có sẵn. Mười phút, xong. Chuỗi vẫn còn.

Khác biệt giữa hai phiên bản không nằm ở ý chí của chị Hạnh. Khác biệt nằm ở chỗ quyết định đã được đưa ra từ Thứ Hai, khi đầu óc còn thong thả, thay vì phải đưa ra lúc 6 giờ sáng ở sân bay.

**Bốn kiểu ngày khó và chỗ đặt thói quen**

- Họp liền nhau: dùng khoảng trống 10 phút đầu tiên, hoặc làm trước cuộc họp đầu tiên.
- Đi công tác: đặt vào lúc chờ hoặc lúc di chuyển, chuẩn bị tài liệu trên điện thoại từ hôm trước.
- Đào tạo, hội thảo cả ngày: làm ngay khi đến nơi, trước giờ khai mạc.
- Cao điểm cuối tháng: làm đầu ngày, trước khi mở số liệu cần chốt.

**Ngày 3 (20 phút)**

1. Mở lịch hai tuần tới, tìm ngày dày nhất.
2. Chọn chỗ đặt thói quen trong ngày đó.
3. Viết lại Kế hoạch 2 cho đúng ngày đó, và chuẩn bị ngay một việc cần làm trước: tải tài liệu, đặt lời nhắc vào lịch.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-3.

Chia sẻ hôm nay: "Ngày khó sắp tới: .... Kế hoạch của tôi: nếu ... thì tôi ...". Ai đang ở ngay trong một ngày khó thì làm phiên bản tối thiểu trước, viết kế hoạch sau nha.


## Bài 4: Ngày 4 (Thứ Năm 22/10)
@img 4_chen-ngang
@pdf 10XHub_YDinhThucHien_PhieuNgay4_chen-ngang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CÂU TỪ CHỐI LỊCH SỰ VIẾT SẴN TỪ HÔM NAY

Tám giờ mười lăm. Vừa mở tệp kế hoạch thì có tiếng gọi từ bàn bên: "Anh ơi, cho em xin số liệu tháng trước một chút."

Đây là trở ngại khó nhất trong ba trở ngại của tuần, vì nó đến từ một người mình muốn giúp. Từ chối thẳng thì ngại. Giúp ngay thì mất phiên. Phần lớn chúng ta chọn giúp ngay, rồi thói quen lùi sang "lát nữa".

Gollwitzer và các cộng sự đã dùng kế hoạch Nếu... thì... không chỉ để bắt đầu một việc, mà cả để giữ tập trung trước những điều gây xao nhãng. Hôm nay áp dụng đúng điều đó: soạn sẵn câu trả lời, để lúc bị chen ngang chỉ việc nói.

Một nguyên tắc trước khi chọn câu: từ chối ở đây không có nghĩa là không giúp. Nghĩa là giúp vào lúc khác, sau khi mình xong phiên bản tối thiểu.

**Bảng chọn: bốn kiểu câu trả lời**

Chọn một kiểu hợp với mình và với văn hoá nơi làm việc, rồi sửa câu chữ cho tự nhiên.

**1. Hẹn lại giờ.** Hợp khi việc của người kia không gấp trong vài chục phút.
- Kế toán: "Chị cho em 20 phút nha, em đang đối chiếu dở, xong là em gửi số liệu ngay."
- Kỹ thuật: "Anh ghi giúp em lỗi vào phiếu, 10 giờ em qua xem tận nơi."

**2. Chuyển kênh.** Hợp khi yêu cầu cần ghi lại cho rõ.
- Chăm sóc khách hàng: "Bạn nhắn giúp mình mã đơn qua nhóm trao đổi, mình xử lý theo thứ tự trong 15 phút tới."

**3. Hỏi mức gấp.** Hợp khi chưa biết việc kia gấp đến đâu.
- Quản lý: "Việc này em cần trong sáng nay hay trong ngày?" Câu trả lời thường là "trong ngày".

**4. Gợi ý người khác.** Hợp khi có người nắm việc đó rõ hơn mình.
- Nhân sự: "Phần hợp đồng thử việc bạn Minh đang giữ hồ sơ, mình kết nối hai bạn nha."

Có một giới hạn cần nói rõ: câu soạn sẵn không dùng để né việc gấp. Khách hàng đang chờ, cấp trên cần số liệu cho cuộc họp sau 10 phút: làm việc gấp trước. Ngay sau đó, làm phiên bản tối thiểu. Kế hoạch 3 vì vậy có thể có hai nhánh: "Nếu việc không gấp thì tôi hẹn lại giờ. Nếu việc gấp thì tôi làm phiên bản tối thiểu ngay khi xong."

**Ngày 4 (20 phút)**

1. Ghi tình huống chen ngang mình gặp nhiều nhất: ai, lúc nào, cần gì.
2. Chọn một kiểu trong bảng trên và viết câu trả lời của riêng mình.
3. Nói thử câu đó thành tiếng một lần. Câu nói ra lần đầu thường hơi cứng, lần thứ hai sẽ tự nhiên hơn.
4. Sửa Kế hoạch 3 cho khớp với câu vừa soạn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-4.

Chia sẻ hôm nay: "Khi ..., câu tôi soạn sẵn là: ...". Đọc câu của nhau cũng là cách học thêm vài cách nói hay, các anh chị và các bạn xem bình luận của cả nhóm nha.


## Bài 5: Ngày 5 (Thứ Sáu 23/10)
@img 5_dung-thu
@pdf 10XHub_YDinhThucHien_PhieuNgay5_dung-thu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: GHI LẠI LẦN ĐẦU KẾ HOẠCH ĐƯỢC DÙNG

Một kế hoạch chỉ thật sự được kiểm chứng khi tình huống trong vế "nếu" xảy ra. Bài hôm nay là một trang nhật ký mẫu, viết theo lời một chuyên viên nhân sự, để thấy việc ghi lại trông như thế nào trong thực tế. Thói quen của chị: mỗi sáng 20 phút rà hồ sơ ứng viên trước khi mở hộp thư.

**Nhật ký mẫu**

Thứ Ba, 8 giờ 05. "Viết xong ba kế hoạch. Kế hoạch 1: nếu họp giao ban kéo dài quá 9 giờ thì tôi rà một hồ sơ ngay khi về bàn."

Thứ Ba, 9 giờ 20. "Giao ban kéo dài thật. Về bàn, tay đã đặt lên chuột để mở hộp thư thì nhớ ra câu kế hoạch. Rà một hồ sơ, mất 8 phút. Kế hoạch chạy đúng."

Thứ Tư, 8 giờ 10. "Trưởng phòng gọi hỏi lịch phỏng vấn. Tôi nói câu hẹn lại giờ, nhưng nói hơi lúng túng. Sau đó vẫn làm được 15 phút. Kế hoạch chạy một phần."

Thứ Năm, cả ngày đi tuyển dụng ở trường đại học. "Đến tối mới nhớ ra Kế hoạch 2. Vế 'nếu' viết là 'ngày có sự kiện', nhưng sáng hôm đó tôi không nghĩ đó là sự kiện. Kế hoạch chưa chạy."

Thứ Sáu, 7 giờ 50. "Sửa Kế hoạch 2 thành: nếu tôi không ngồi ở bàn làm việc lúc 8 giờ, thì tôi rà một hồ sơ trên điện thoại trước khi bắt đầu việc đầu tiên."

**Đọc nhật ký này thế nào**

Ba dòng kết quả cho ba cách sửa khác nhau:

- Chạy đúng: giữ nguyên câu. Kế hoạch này đã thành một phần của ngày làm việc.
- Chạy một phần: nhớ ra nhưng làm khác hoặc làm muộn. Thường là vế "thì" còn lớn quá, hoặc câu trả lời chưa quen miệng. Thu nhỏ vế "thì", hoặc nói thử câu thêm vài lần.
- Chưa chạy: không nhận ra tình huống lúc nó xảy ra. Vấn đề nằm ở vế "nếu". Viết lại bằng một dấu hiệu dễ thấy hơn, như cách chị chuyên viên đổi "ngày có sự kiện" thành "không ngồi ở bàn lúc 8 giờ".

Kế hoạch chưa chạy không phải là thất bại. Đó chính là thông tin cần để sửa câu cho đúng. Cũng có thể trong tuần, tình huống của một kế hoạch chưa hề xảy ra. Khi đó chỉ cần ghi "chưa gặp" và giữ câu sang tuần sau.

**Ngày 5 (15 phút)**

1. Chấm từng kế hoạch: chưa gặp tình huống, đã gặp nhưng chưa dùng, hay đã dùng.
2. Ghi lại một lần dùng: tình huống đã xảy ra và mình đã làm gì.
3. Sửa một chỗ trong một kế hoạch, dựa trên kết quả.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-5.

Chia sẻ hôm nay: "Tình huống đã gặp: .... Tôi đã .... Điều chỉnh: ...". Ai chưa gặp tình huống nào thì ghi "chưa gặp" và câu dự định giữ sang tuần sau nha.


## Bài 6: Ngày 6 (Thứ Bảy 24/10)
@img 6_the-tren-ban
@img2 9_the-thanh-tich
@pdf 10XHub_YDinhThucHien_PhieuNgay6_the-tren-ban.pdf (phiếu thực hành và thẻ Nếu... thì... để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MỘT TẤM THẺ ĐẶT NGAY TRONG TẦM MẮT

Đặt cạnh nhau hai cách ứng xử với cùng một trở ngại, thấy rõ tuần này đã thêm được gì cho thói quen then chốt.

**Đầu tuần và cuối tuần**

- Đầu tuần: gặp trở ngại thì quyết định tại chỗ, khi đang bận. Cuối tuần: câu trả lời đã viết sẵn từ lúc còn thong thả.
- Đầu tuần: ngày khó thì bỏ cả thói quen. Cuối tuần: ngày khó thì làm phiên bản tối thiểu.
- Đầu tuần: bị chen ngang thì giúp ngay, thói quen lùi lại. Cuối tuần: có một câu hẹn lại giờ lịch sự, đã nói thử thành tiếng.
- Đầu tuần: lỡ rồi mới biết. Cuối tuần: nhìn lịch trước hai tuần và đặt lời nhắc cho ngày dày nhất.
- Đầu tuần: kế hoạch nằm trong đầu. Cuối tuần: kế hoạch nằm trên sổ và trên bàn làm việc.

Điều cuối cùng là việc của hôm nay. Kế hoạch Nếu... thì... phát huy tác dụng khi nó nằm trong tầm mắt đúng lúc cần. Vì vậy, Ngày 6 là một tấm thẻ.

**Sáng nay (15 phút): làm thẻ Nếu... thì...**

1. Đọc lại ba kế hoạch trên sổ, chọn câu mình cần nhất. Thường là câu cho trở ngại lớn nhất tuần trước.
2. In thẻ ở trang cuối phiếu Ngày 6, hoặc gấp đôi một tấm bìa cứng. Mặt trước ghi câu Nếu... thì.... Mặt sau ghi câu bản sắc.
3. Dựng thẻ ở góc bàn, cạnh màn hình, chỗ mắt nhìn thấy mỗi sáng.

Hai câu còn lại vẫn nằm trên sổ thực hành. Tuần sau mở sổ, ba kế hoạch tự hiện lại.

**Trước khi nghỉ Chủ Nhật (10 phút): bảng hành trình**

Mở Ngày 6 trên sổ, bấm vào những ngày tuần này đã làm thói quen then chốt, kể cả những ngày chỉ làm phiên bản tối thiểu. Ngày làm phiên bản tối thiểu vẫn tính là một ngày giữ thói quen, và đó chính là lý do có kế hoạch Nếu... thì....

Tuần sau, Công thức #0024 về Quản lý năng lượng sẽ tìm khung giờ năng lượng cao nhất trong ngày của mỗi người và dời chính thói quen này vào đó, để ngày bình thường cũng nhẹ hơn.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0023-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi giữ thói quen ... ngày. Câu trên thẻ của tôi: ...". Đăng kèm ảnh tấm thẻ trên bàn làm việc nếu tiện nha.

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Ý định thực hiện hiện ra: một vòng tròn ghi số ngày giữ thói quen tuần này, kèm câu Nếu... thì... đầu tiên của mình. Nhập tên, tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Thói quen then chốt cũng được nghỉ, chuỗi không bị tính là lỡ.
