## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 26/04)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0050_Xep Chong Ky Nang_VN.pdf (tài liệu đầy đủ của Công thức #0050)
@pdf 10XHub_XepChongKyNang_PhieuNgay1_kiem-ke.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0050.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** XẾP CHỒNG KỸ NĂNG: LỢI THẾ RIÊNG TRONG CÔNG VIỆC

Tuần trước, mỗi buổi học 20 phút của cả nhóm đã để lại một trang Cornell: cột ghi chép bên phải, cột câu hỏi gợi nhớ bên trái và dải tóm tắt cuối trang. Cột câu hỏi đó đã trở thành công cụ tự kiểm tra: che cột phải, đọc câu hỏi, tự trả lời. Cả nhóm còn thử biên bản họp kiểu Cornell, và Thứ Bảy mỗi người chọn cách dùng trang Cornell sẽ giữ. Những trang Cornell ấy vẫn dùng tiếp trong tuần này. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Công thức #0050 của tuần là Xếp chồng kỹ năng.

**Nếu mới tham gia:** tuần này rất hợp để bắt đầu, vì cả tuần chỉ xoay quanh một câu hỏi về chính mình: mình đang có những kỹ năng nào, và chúng cộng lại thành điều gì. Ở Ngày 1 trên sổ thực hành, hãy viết một thói quen nhỏ mình muốn giữ mỗi ngày và một kỹ năng mình đang muốn học thêm cho công việc. Chừng đó là đủ để đi cùng cả nhóm từ hôm nay.

**Một phần tư nhân một phần tư**

Hôm nay bắt đầu bằng một con số, và giải nghĩa từng phần của nó.

Năm 2007, trên trang blog của mình, Scott Adams, tác giả bộ truyện tranh Dilbert, viết một lời khuyên nghề nghiệp ngắn. Theo ông, muốn có một vị trí đặc biệt trong nghề, có hai con đường. Con đường thứ nhất là trở thành người giỏi nhất ở một việc cụ thể, và con đường này dành cho rất ít người. Con đường thứ hai là trở nên rất khá, thuộc nhóm 25% đứng đầu, ở hai hoặc nhiều việc. Năm 2013, ông viết lại ý tưởng này trong cuốn "How to Fail at Almost Everything and Still Win Big".

Vì sao con đường thứ hai lại hiệu quả? Đây là phần giải nghĩa con số.

- **25%:** thuộc nhóm một phần tư đứng đầu ở một kỹ năng là mức nhiều người đạt được nếu luyện tập đều trong vài năm. Không cần tài năng đặc biệt.
- **25% nhân 25%:** nếu hai kỹ năng không liên quan nhiều với nhau, số người cùng lúc khá ở cả hai chỉ còn khoảng một phần mười sáu.
- **Thêm kỹ năng thứ ba:** khoảng một phần sáu mươi tư. Sự kết hợp trở nên hiếm, dù từng kỹ năng riêng lẻ không hiếm.

Cần nói rõ: phép nhân trên chỉ là cách minh hoạ, không phải phép tính chính xác. Trong thực tế, các kỹ năng thường liên quan đến nhau, và giá trị của một sự kết hợp còn phụ thuộc vào việc công việc có cần đúng sự kết hợp đó hay không. Điều đáng giữ lại là ý chính: lợi thế riêng trong công việc thường đến từ cách các kỹ năng ghép với nhau, không chỉ từ độ sâu của một kỹ năng.

Một ví dụ dễ thấy: một kế toán viên vững nghiệp vụ, biết phân tích dữ liệu bằng bảng tính ở mức khá, và trình bày rõ ràng trước ban lãnh đạo. Từng kỹ năng không hiếm. Nhưng người làm được cả ba thường là người được mời vào phòng họp khi công ty cần hiểu con số.

**Lớp mới cho hành trình**

Ở #0047, mỗi người đã chọn một kỹ năng để học có chủ đích 20 phút mỗi ngày và một dự án học nhỏ cho quý 2. Hai tuần vừa qua đã thêm truy hồi chủ động và trang Cornell vào 20 phút đó. Tuần này không thêm kỹ thuật học mới. Tuần này lùi lại một bước để nhìn toàn bộ bộ kỹ năng, và trả lời câu hỏi: kỹ năng đang học sẽ cộng thêm vào đâu để tạo ra một lợi thế riêng trong công việc của mình.

Đó cũng là một cách nhìn cụ thể về phiên bản 10X của chính mình: không phải một người khác hẳn, mà là chính mình với một bộ kỹ năng được ghép có chủ đích.

**Sáu ngày của tuần**

- Thứ Hai: kiểm kê bộ kỹ năng.
- Thứ Ba: tìm kỹ năng nền và kỹ năng ít gặp.
- Thứ Tư: vẽ chữ T của mình.
- Thứ Năm: ghép thành bộ ba kỹ năng.
- Thứ Sáu 30.4: nghỉ lễ, việc 5 phút.
- Thứ Bảy 1.5: nghỉ lễ, việc 5 phút và thẻ thành tích.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Kiểm kê bộ kỹ năng**

1. Mở sổ thực hành, xem lại thói quen đang giữ, kỹ năng đang học và dự án học đã chọn ở #0047.
2. Viết sáu kỹ năng mình đang dùng trong công việc. Gồm cả kỹ năng chuyên môn (lập dự toán, đọc bản vẽ, tư vấn sản phẩm) và kỹ năng làm việc với người (đàm phán, hướng dẫn người mới, viết email rõ ràng).
3. Chấm mức cho từng kỹ năng, từ 1 (mới làm quen) đến 4 (người khác thường hỏi mình).
4. Đếm số kỹ năng mình dùng ít nhất mỗi tuần một lần.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-1.

Chia sẻ hôm nay: "Bộ kỹ năng của tôi có ... kỹ năng tôi dùng hằng tuần. Kỹ năng đang học: ...".

Nhiều người khi kiểm kê sẽ thấy mình có nhiều kỹ năng hơn mình nghĩ, vì có những việc đã làm quen tay đến mức không còn gọi là kỹ năng nữa. Các anh chị và các bạn cứ ghi cả những việc đó vào nha.


## Bài 2: Ngày 2 (Thứ Ba 27/04)
@img 2_ky-nang-nen
@pdf 10XHub_XepChongKyNang_PhieuNgay2_ky-nang-nen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: KỸ NĂNG NỀN VÀ KỸ NĂNG ÍT GẶP

**Một tình huống minh hoạ**

Chị Ngọc là chuyên viên kế toán công nợ ở một công ty phân phối thiết bị điện. Hôm qua, chị viết ra sáu kỹ năng: hạch toán và đối chiếu công nợ, dùng phần mềm kế toán, lập bảng tính có công thức, gọi điện nhắc thanh toán, tiếng Anh đọc hợp đồng, và hướng dẫn nhân viên mới. Chị chấm mức 4 cho đối chiếu công nợ, mức 3 cho bảng tính và gọi điện, mức 2 cho tiếng Anh.

Hôm nay chị nhìn lại danh sách bằng hai câu hỏi.

Câu hỏi thứ nhất: kỹ năng nào là nền, tức là kỹ năng mình mạnh nhất và công việc dựa vào nhiều nhất? Câu trả lời khá rõ: đối chiếu công nợ. Đây là lý do chị có mặt trong phòng kế toán.

Câu hỏi thứ hai khó hơn: trong bộ phận, kỹ năng nào của mình ít người có? Chị nghĩ một lúc. Cả phòng ai cũng đối chiếu công nợ được. Nhưng chị là người duy nhất thường xuyên gọi điện cho khách hàng và giữ được cuộc trao đổi nhẹ nhàng, kể cả khi khoản nợ đã quá hạn. Phần lớn đồng nghiệp chỉ gửi email nhắc.

Chị ghép hai câu trả lời lại và thấy một điều trước đây chưa gọi tên: chị vừa hiểu từng con số trong công nợ, vừa nói chuyện được với khách hàng về con số đó. Đó là lý do trưởng phòng thường chuyển cho chị những khoản khó thu.

Rồi chị nhìn sang kỹ năng đang học từ #0047: phân tích dữ liệu bằng bảng tính nâng cao. Chị nhận ra kỹ năng này cộng vào rất đúng chỗ. Nếu chị dựng được một bảng theo dõi tuổi nợ theo từng khách hàng, mỗi cuộc gọi sẽ bắt đầu bằng một bức tranh rõ ràng hơn. Ba kỹ năng ghép lại: hiểu công nợ, trao đổi với khách hàng, phân tích dữ liệu.

Tình huống trên là minh hoạ. Điều đáng chú ý không nằm ở nghề kế toán, mà ở thứ tự suy nghĩ: tìm kỹ năng nền, tìm kỹ năng ít gặp ở chỗ mình làm, rồi xem kỹ năng đang học nối hai điều đó với nhau như thế nào.

**Vì sao hỏi "ít gặp ở chỗ mình làm"?**

Một kỹ năng phổ biến ngoài thị trường vẫn có thể hiếm trong một bộ phận cụ thể. Một kỹ sư viết tài liệu rõ ràng, một nhân viên kinh doanh đọc được báo cáo tài chính, một chuyên viên nhân sự biết dựng bảng tính: mỗi kỹ năng không đặc biệt, nhưng đặt vào đúng chỗ thì trở thành điều cả nhóm cần đến. Câu hỏi này giúp nhìn kỹ năng bằng con mắt của nơi mình đang làm việc.

**Ngày 2 (20 phút)**

1. Xem lại sáu kỹ năng và mức chấm từ hôm qua.
2. Chọn kỹ năng nền: mạnh nhất và công việc dựa vào nhiều nhất.
3. Chọn kỹ năng ít gặp: kỹ năng mình có mà ít người trong bộ phận có.
4. Viết một việc mà chỉ khi có cả hai kỹ năng này mình mới làm tốt.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-2.

Chia sẻ hôm nay: "Kỹ năng nền của tôi: .... Kỹ năng ít gặp trong bộ phận: ...".

Nếu chưa nghĩ ra kỹ năng ít gặp, các anh chị và các bạn thử nhớ lại lần gần nhất đồng nghiệp nhờ mình giúp một việc ngoài phần việc chính nha, câu trả lời thường nằm ở đó.


## Bài 3: Ngày 3 (Thứ Tư 28/04)
@img 3_chu-t
@pdf 10XHub_XepChongKyNang_PhieuNgay3_chu-t.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: VẼ CHỮ T CỦA MÌNH

Có một hình ảnh đơn giản giúp nhìn bộ kỹ năng trong một trang: chữ T. Hình ảnh này được dùng trong tuyển dụng từ nhiều thập niên trước, và về sau được Tim Brown, khi là Giám đốc điều hành công ty thiết kế IDEO, nhắc đến nhiều khi nói về những người làm tốt trong nhóm liên ngành. Hôm nay đặt ba kiểu bộ kỹ năng cạnh nhau để thấy chữ T khác gì.

**Ba kiểu bộ kỹ năng**

**Kiểu chữ I: sâu một chiều.** Người rất vững một chuyên môn, nhưng ít kết nối với các phần việc xung quanh. Ví dụ: một kỹ sư thiết kế giỏi, nhưng khó giải thích bản thiết kế cho bộ phận mua hàng hay cho khách hàng.
- Điểm mạnh: độ sâu, độ tin cậy trong chuyên môn.
- Điều dễ gặp: ý tưởng tốt nhưng khó đi qua các bộ phận khác.

**Kiểu gạch ngang: rộng nhưng nông.** Người biết một chút về nhiều việc, nhưng chưa có phần nào thật vững. Ví dụ: một nhân viên mới làm qua nhiều vị trí trong vài tháng.
- Điểm mạnh: hiểu bức tranh chung, dễ kết nối.
- Điều dễ gặp: khó trở thành người được hỏi ý kiến ở một việc cụ thể.

**Kiểu chữ T: một chiều sâu và một chiều rộng.** Thanh dọc là một chuyên môn vững. Thanh ngang là những kỹ năng giúp chuyên môn đó làm việc được với người khác: trao đổi, hiểu khách hàng, hiểu số liệu, hiểu quy trình của bộ phận bên cạnh.
- Điểm mạnh: vừa được tin ở chuyên môn, vừa đưa chuyên môn đi xa hơn.
- Điều cần có: thời gian. Thanh dọc được xây qua nhiều năm, thanh ngang được thêm dần từng kỹ năng.

**Chữ T và xếp chồng kỹ năng nói cùng một ý**

Hôm qua, mỗi người đã chọn một kỹ năng nền và một kỹ năng ít gặp. Kỹ năng nền thường chính là thanh dọc. Kỹ năng ít gặp và những kỹ năng hỗ trợ khác nằm trên thanh ngang. Chữ T là cách vẽ ra bộ kỹ năng xếp chồng để dễ nhìn.

Câu hỏi quan trọng của hôm nay: kỹ năng đang học từ #0047 nằm ở đâu trên chữ T của mình?

- Nếu nó **đào sâu thanh dọc** (ví dụ một kế toán học chuẩn mực báo cáo mới), 20 phút mỗi ngày đang làm chuyên môn vững hơn.
- Nếu nó **kéo dài thanh ngang** (ví dụ một kỹ sư học cách trình bày dự án cho khách hàng), 20 phút mỗi ngày đang mở thêm một cánh cửa cho chuyên môn sẵn có.

Không có lựa chọn nào đúng hơn. Điều quan trọng là biết mình đang xây phần nào, để chọn dự án học và cách đo tiến bộ cho phù hợp.

**Ngày 3 (20 phút)**

1. Viết thanh dọc của chữ T: chuyên môn mình vững nhất.
2. Viết ba kỹ năng trên thanh ngang: những kỹ năng giúp chuyên môn đó làm việc được với người khác.
3. Chọn vị trí của kỹ năng đang học: thanh dọc hay thanh ngang.
4. Viết một câu về điều kỹ năng đang học thêm vào chữ T.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-3.

Chia sẻ hôm nay: "Chữ T của tôi: thanh dọc là .... Kỹ năng đang học nằm ở ...".


## Bài 4: Ngày 4 (Thứ Năm 29/04)
@img 4_bo-ba
@pdf 10XHub_XepChongKyNang_PhieuNgay4_bo-ba.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: GHÉP BA KỸ NĂNG THÀNH MỘT LỢI THẾ

Hôm nay là ngày làm việc cuối cùng trước kỳ nghỉ lễ, và cũng là ngày ghép mọi điều của ba hôm trước vào một câu. Bài hôm nay đi theo dạng hỏi đáp, vì khi viết bộ ba kỹ năng, câu hỏi thường gặp khá giống nhau.

**Hỏi: Bộ ba kỹ năng gồm những gì?**

Đáp: Một kỹ năng nền (thanh dọc của chữ T), một kỹ năng hỗ trợ (từ thanh ngang, thường là kỹ năng ít gặp đã chọn hôm Thứ Ba), và kỹ năng đang học từ #0047. Câu viết theo mẫu: "kỹ năng nền + kỹ năng hỗ trợ + kỹ năng đang học → giá trị cho ai".

**Hỏi: Vì sao cần ghi "giá trị cho ai"?**

Đáp: Một bộ kỹ năng chỉ trở thành lợi thế khi có người cần đúng sự kết hợp đó: khách hàng, cấp trên, một bộ phận khác, hay chính nhóm của mình. Ví dụ: "kỹ thuật bảo trì + hướng dẫn người mới + soạn video ngắn → giúp tổ vận hành rút ngắn thời gian đào tạo công nhân mới". Phần "cho ai" giữ bộ ba gắn với công việc thật.

**Hỏi: Nếu kỹ năng đang học chưa ăn khớp với hai kỹ năng kia thì sao?**

Đáp: Đó là một phát hiện tốt, không phải một lỗi. Có hai cách xử lý. Cách thứ nhất là giữ kỹ năng đang học và chỉnh dự án học cho gần với công việc hơn: thay vì học phân tích dữ liệu chung chung, chọn dự án phân tích đúng dữ liệu của bộ phận mình. Cách thứ hai, nếu thấy rõ một kỹ năng khác cộng vào tốt hơn, là ghi chú để xem lại vào cuối quý. Tuần này không cần đổi kỹ năng.

**Hỏi: Ba kỹ năng có phải đều ở mức cao không?**

Đáp: Không. Ý tưởng của Scott Adams là "khá tốt" ở nhiều việc, không phải xuất sắc ở mọi việc. Kỹ năng đang học thường còn ở mức thấp, và đó chính là lý do có 20 phút mỗi ngày.

**Hỏi: Bộ ba có cố định mãi không?**

Đáp: Không. Bộ kỹ năng thay đổi theo vai trò. Một chuyên viên trở thành trưởng nhóm sẽ thấy kỹ năng hỗ trợ quan trọng nhất đổi từ "làm nhanh" sang "giao việc rõ". Sổ thực hành lưu bộ ba cho cả hành trình, và mỗi cuối quý có thể viết lại.

**Hỏi: Bộ ba thay đổi gì trong 20 phút học mỗi ngày?**

Đáp: Nó giúp chọn nội dung học. Khi đã biết kỹ năng đang học phải ghép với hai kỹ năng nào, mỗi buổi 20 phút có thể ưu tiên phần giao nhau. Ví dụ, chị Ngọc ở bài hôm Thứ Ba sẽ ưu tiên học các hàm bảng tính dùng để theo dõi tuổi nợ, trước những phần nâng cao khác.

**Ngày 4 (20 phút)**

1. Xem lại kỹ năng nền, kỹ năng ít gặp và chữ T của mình.
2. Viết bộ ba kỹ năng theo mẫu, có phần "giá trị cho ai".
3. Chọn mức ăn khớp giữa kỹ năng đang học và hai kỹ năng kia.
4. Viết phần giao nhau sẽ ưu tiên trong 20 phút học tuần tới.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-4. Bộ ba kỹ năng được lưu cho cả hành trình.

Chia sẻ hôm nay: "Bộ kỹ năng xếp chồng của tôi: .... Giá trị cho: ...".

Trước khi tắt máy chiều nay, các anh chị và các bạn nhớ bàn giao gọn những việc đang dở cho kỳ nghỉ nha.


## Bài 5: Ngày 5 (Thứ Sáu 30/04)
@img 5_nghi-le
@pdf 10XHub_XepChongKyNang_PhieuNgay5_nghi-le.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: KỲ NGHỈ LỄ VÀ MỘT VIỆC NĂM PHÚT

Các anh chị và các bạn thân mến,

Hôm nay là ngày đầu của kỳ nghỉ lễ 30.4 và 1.5. Với nhiều người, đây là dịp hiếm hoi trong năm để về quê, đi chơi cùng gia đình, hay đơn giản là ngủ thêm một chút vào buổi sáng. Trường gửi lời chúc các anh chị và các bạn một kỳ nghỉ thật nhẹ nhàng, đi đường bình an, và có những giờ phút trọn vẹn với người thân.

Bốn ngày vừa qua, cả nhóm đã làm một việc không nhỏ: kiểm kê bộ kỹ năng, tìm kỹ năng nền và kỹ năng ít gặp, vẽ chữ T, và ghép thành một bộ ba. Hôm nay không có bài mới. Chỉ có hai việc nhẹ, tổng cộng khoảng 5 phút, làm lúc nào cũng được trong ngày.

**Việc thứ nhất: phiên bản nghỉ lễ của thói quen**

Trong kỳ nghỉ, khung giờ và tín hiệu quen thuộc thường không còn: không có giờ vào ca, không có bàn làm việc, không có ly cà phê đầu giờ ở văn phòng. Cách giữ thói quen qua những ngày này đã quen thuộc từ tuần giáp Tết: một phiên bản rất nhỏ. Với 20 phút học, phiên bản nghỉ lễ có thể là 5 phút đọc lại cột câu hỏi trên một trang Cornell, hoặc 5 phút nghe một đoạn âm thanh liên quan đến kỹ năng đang học. Nếu hôm nay muốn nghỉ hẳn cũng hoàn toàn được: thói quen không mất đi vì một kỳ nghỉ.

**Việc thứ hai: một người để học hỏi**

Trong kỳ nghỉ, khi gặp lại bạn bè, người thân, hay nhớ về những đồng nghiệp cũ, hãy thử để ý một câu hỏi: ai là người mình biết có một bộ kỹ năng xếp chồng đáng học? Có thể là một người bác vừa giỏi nghề mộc vừa biết bán hàng qua mạng, một người bạn là bác sĩ nhưng viết bài phổ biến kiến thức rất dễ hiểu, hay một anh trưởng ca vừa vững kỹ thuật vừa được cả tổ tin. Chỉ cần ghi tên người đó và hai, ba kỹ năng mình thấy ở họ.

Câu hỏi này không nhằm so sánh. Nó giúp nhìn thấy xếp chồng kỹ năng ở ngoài đời thật, rằng phần lớn những người làm tốt công việc của mình đều có nhiều hơn một kỹ năng, và các kỹ năng đó được ghép lại qua nhiều năm.

**Ngày 5 (khoảng 5 phút)**

1. Chọn phiên bản nghỉ lễ của thói quen, hoặc chọn nghỉ hẳn hôm nay.
2. Ghi tên một người có bộ kỹ năng xếp chồng mình muốn học hỏi, và hai, ba kỹ năng của người đó.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-5.

Chia sẻ hôm nay: "Kỳ nghỉ này, phiên bản nhỏ của tôi: .... Người có bộ kỹ năng tôi muốn học hỏi: ...".

Thay mặt nhóm điều hành 10X Excellence Hub, Trường chúc các anh chị và các bạn kỳ nghỉ lễ an vui. Hẹn gặp lại ở bài nhẹ ngày mai nha.

Trường


## Bài 6: Ngày 6 (Thứ Bảy 01/05)
@img 6_khep-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_XepChongKyNang_PhieuNgay6_khep-tuan.pdf (phiếu thực hành và thẻ bộ ba kỹ năng in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: BA CÂU HỎI NHẸ CHO NGÀY 1.5

Hôm nay là Ngày Quốc tế Lao động 1.5, ngày thứ hai của kỳ nghỉ lễ. Một ngày dành cho người lao động là dịp rất hợp để nhìn lại bộ kỹ năng mình đã xây qua bao năm làm việc. Bài hôm nay chỉ có ba câu hỏi mở. Không cần trả lời dài, cũng không có câu trả lời đúng hay sai.

**Câu hỏi 1: Khi viết bộ ba kỹ năng, điều gì làm mình bất ngờ?**

Có người bất ngờ vì kỹ năng ít gặp của mình lại là một việc rất bình thường, như gọi điện cho khách hàng hay viết biên bản họp gọn gàng. Có người bất ngờ vì kỹ năng đang học ăn khớp với công việc hơn mình nghĩ. Có người nhận ra thanh ngang của chữ T còn ngắn. Mỗi phát hiện đều là thông tin cho chặng tiếp theo của Mùa 3.

**Câu hỏi 2: Một năm nữa, mình muốn chữ T của mình khác đi ở đâu?**

Câu hỏi này giúp thấy phiên bản 10X của chính mình bằng hình ảnh cụ thể. Ví dụ: "thanh ngang có thêm kỹ năng trình bày trước khách hàng bằng tiếng Anh", hoặc "thanh dọc đủ vững để hướng dẫn người mới về chuẩn mực kế toán mới". Không cần lớn. Một kỹ năng thêm vào bộ ba trong một năm, cộng với 20 phút mỗi ngày, đã là một thay đổi rõ ràng.

**Câu hỏi 3: Việc nhỏ nào trong tuần tới sẽ dùng đến bộ ba kỹ năng?**

Bộ ba chỉ có ý nghĩa khi được dùng trong một việc thật. Hãy nghĩ tới một việc trong tuần làm việc đầu tiên sau kỳ nghỉ: một cuộc họp, một báo cáo, một khách hàng, một người mới cần hướng dẫn. Việc đó có thể làm tốt hơn một chút nhờ ghép ba kỹ năng không?

**Sáng nay (khoảng 5 phút)**

1. Trả lời ba câu hỏi trên sổ thực hành, mỗi câu một dòng.
2. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen, kể cả phiên bản nghỉ lễ.

Nếu thích, in thẻ bộ ba kỹ năng ở trang 2 của phiếu Ngày 6, điền và kẹp vào sổ kế hoạch, cạnh trang Cornell gần nhất.

**Tuần sau, Thứ Hai 03.05**

Tuần làm việc đầu tiên sau kỳ nghỉ lễ. Mùa 3 quay lại với một kỹ thuật ghi nhớ đã có từ thời Hy Lạp cổ, dùng chính những nơi quen thuộc như văn phòng, đường đi làm để nhớ các ý chính của một bài thuyết trình hay một quy trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0050-ngay-6.

Chia sẻ hôm nay: "Tuần lễ khép lại với ... ngày giữ thói quen. Việc nhỏ tuần tới để dùng bộ ba kỹ năng: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hiện ra: một vòng tròn khép kín với số 3 ở giữa, dòng "KỸ NĂNG XẾP CHỒNG", tên mình và bộ ba kỹ năng của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Ngày nào còn thiếu thì Chủ Nhật vẫn làm bù được, hoặc sau kỳ nghỉ cũng không sao.

Chúc các anh chị và các bạn ngày 1.5 thật vui bên gia đình và bạn bè. Kỳ nghỉ là để nghỉ ngơi trọn vẹn nha. Hẹn gặp lại sáng Thứ Hai.
