## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 09/11)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0026_Ky Thuat An Con Ech_VN.pdf (tài liệu đầy đủ của Công thức #0026)
@pdf 10XHub_AnConEch_PhieuNgay1_abcde.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0026.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** ĂN CON ẾCH: VIỆC QUAN TRỌNG NHẤT LÀM ĐẦU NGÀY

Tuần Công việc sâu vừa khép lại với một kết quả rất cụ thể: thói quen then chốt của mỗi người giờ đã có một khối làm việc sâu riêng, có tên, có giờ và được bảo vệ trong lịch. Khối giờ đó là một khoảng trống quý. Tuần này trả lời câu hỏi tiếp theo: đặt việc gì vào khoảng trống ấy.

**Nếu mới tham gia:** chỉ cần hai việc trong hôm nay. Mở Ngày 1 trên sổ thực hành, viết câu bản sắc và một thói quen then chốt nhỏ trong công việc, ví dụ "dành 20 phút đầu ngày cho việc khó nhất". Sau đó làm phần chấm điểm ABCDE cùng cả nhóm. Không cần đọc lại các tuần trước, công thức tuần này tự đứng được.

**"Con ếch" nghĩa là gì?**

Câu nói "sáng nào cũng ăn một con ếch sống thì cả ngày không còn gì tệ hơn xảy ra" thường được gán cho Mark Twain, nhưng chưa có bằng chứng ông từng nói hay viết câu này. Trang Quote Investigator lần ra một ý gần giống trong ghi chép của nhà văn Pháp Nicolas Chamfort từ khoảng những năm 1790, khi đó là con cóc chứ không phải con ếch. Phiên bản gán cho Twain chỉ xuất hiện nhiều chục năm sau khi ông mất.

Hình ảnh ấy được Brian Tracy biến thành một phương pháp làm việc trong cuốn Eat That Frog! (2001). Theo Tracy, con ếch là việc quan trọng nhất trong ngày, thường cũng là việc mình muốn hoãn nhất. Làm nó trước, phần còn lại của ngày nhẹ đi rõ rệt.

**Vì sao con ếch hay bị để đến chiều?**

Nhà nghiên cứu Piers Steel tổng hợp hàng trăm nghiên cứu về sự trì hoãn (Psychological Bulletin, 2007). Hai yếu tố nổi bật: việc càng khó chịu thì càng dễ bị hoãn, và việc có kết quả càng xa thì càng dễ bị đẩy lùi. Bản báo cáo chiến lược, cuộc gọi khó với khách hàng, bản đề xuất ngân sách đều có cả hai đặc điểm đó. Trong khi đó hộp thư luôn có việc nhỏ, dễ, xong ngay. Không ai chọn bỏ việc quan trọng, nhưng buổi sáng trôi dần sang những việc dễ hơn.

**Phương pháp ABCDE: tìm con ếch trong danh sách**

Tracy đề nghị viết ra mọi việc, rồi gắn cho mỗi việc một chữ cái:

- **A, phải làm:** không làm sẽ có hậu quả rõ ràng. Ví dụ: hồ sơ thầu nộp Thứ Năm, báo cáo thuế đến hạn.
- **B, nên làm:** không làm thì có hậu quả nhẹ. Ví dụ: trả lời một đồng nghiệp hỏi thông tin không gấp.
- **C, làm thì tốt:** không làm cũng không ảnh hưởng gì. Ví dụ: đọc tin tức ngành, sắp xếp lại thư mục.
- **D, giao được:** người khác làm được, giao để mình có thời gian cho việc A.
- **E, bỏ được:** việc không còn đem lại giá trị, dừng hẳn.

Quy tắc đi kèm: không làm việc B khi việc A chưa xong. Nếu có nhiều việc A, đánh số A1, A2, A3. Việc A1 chính là con ếch của ngày.

**Lớp mới cho hành trình thói quen**

Thói quen then chốt của mỗi người vẫn giữ nguyên. Tuần này đặt con ếch ngay cạnh nó, để thói quen trở thành cửa vào cho việc khó nhất trong ngày. Sáu ngày đi theo nhịp sau: Thứ Hai chấm điểm ABCDE. Thứ Ba chuẩn bị con ếch từ chiều hôm trước. Thứ Tư ăn ếch trước 10 giờ. Thứ Năm cắt lát con ếch quá lớn. Thứ Sáu ghép con ếch với thói quen then chốt. Thứ Bảy nhìn lại cả tuần. Chủ Nhật nghỉ.

Một lưu ý: "đầu ngày" ở đây là đầu ngày làm việc của mình. Ai làm ca chiều thì đầu ca chính là buổi sáng của mình.

**Ngày 1 (25 phút): Chấm điểm ABCDE**

1. Mở sổ thực hành, xem lại thói quen đang giữ. Người mới điền câu bản sắc và thói quen then chốt.
2. Viết năm việc lớn nhất cần làm hôm nay hoặc trong tuần.
3. Gắn chữ A, B, C, D hoặc E cho từng việc.
4. Chọn việc A quan trọng nhất làm con ếch hôm nay, viết một câu: nếu không làm việc này thì hậu quả là gì.
5. Bắt đầu con ếch ngay sau khi làm thói quen then chốt, dù chỉ 15 phút.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-1.

Chia sẻ hôm nay: "Thói quen tôi đang giữ: .... Con ếch hôm nay (việc A): ...". Ai mới vào nhóm thì bình luận thêm chữ THAM GIA để cả nhóm biết và cùng đi nha.


## Bài 2: Ngày 2 (Thứ Ba 10/11)
@img 2_chuan-bi
@pdf 10XHub_AnConEch_PhieuNgay2_chuan-bi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CHUẨN BỊ CON ẾCH TỪ CHIỀU HÔM TRƯỚC

Bài hôm nay viết theo dạng nhật ký: hai buổi chiều của cùng một trưởng nhóm kinh doanh giả định, cách nhau một tuần. Nhân vật là hình mẫu để minh hoạ, không phải chuyện của một người cụ thể.

**Chiều Thứ Ba tuần trước, 17 giờ 45**

Gửi xong thư cho khách, tắt máy, về. Trong đầu vẫn còn bản kế hoạch quý I chưa viết dòng nào. Sáng mai làm, chắc chắn.

**Sáng Thứ Tư tuần trước, 8 giờ 10**

Ngồi vào bàn, mở máy. Phải tìm lại tệp số liệu quý trước, rồi nhớ ra cần bảng giá mới từ phòng kế toán. Trong lúc chờ, mở hộp thư xem có gì gấp. 9 giờ 40 có cuộc họp. Bản kế hoạch lại sang chiều, rồi sang ngày hôm sau.

**Chiều Thứ Ba tuần này, 17 giờ 30**

Dành năm phút trước khi về. Viết lên một tờ giấy: "Con ếch ngày mai: phần mục tiêu doanh số của kế hoạch quý I. Bước đầu tiên: điền ba con số doanh thu quý trước vào trang 2." Mở sẵn tệp kế hoạch và tệp số liệu, để cạnh nhau trên màn hình. Nhắn phòng kế toán xin bảng giá ngay chiều nay. Đặt tờ giấy lên bàn phím rồi mới tắt máy.

**Sáng Thứ Tư tuần này, 8 giờ 10**

Mở máy, hai tệp đã nằm sẵn. Tờ giấy nói rõ việc đầu tiên. Đến 9 giờ 30, phần mục tiêu doanh số đã xong bản nháp. Cuộc họp 9 giờ 40 vẫn diễn ra như cũ, nhưng con ếch đã được ăn trước đó.

**Điều gì khác giữa hai buổi sáng?**

Không phải ý chí. Khác biệt nằm ở năm phút chiều hôm trước, khi đầu óc còn nhớ rõ bối cảnh công việc. Tracy khuyên lập kế hoạch cho ngày hôm sau ngay từ tối hôm trước. Ý này cũng gặp lại điều cả nhóm đã luyện ở tuần Ý định thực hiện: khi việc đã có giờ, có chỗ và có bước đầu tiên cụ thể, sáng hôm sau không còn phải quyết định gì nữa, chỉ việc bắt đầu.

Ba yếu tố của một con ếch được chuẩn bị tốt:

- **Tên việc rõ ràng:** không ghi "làm kế hoạch", mà ghi "phần mục tiêu doanh số của kế hoạch quý I".
- **Bước đầu tiên nhỏ và cụ thể:** một hành động làm được trong vài phút, không cần suy nghĩ thêm.
- **Mọi tài liệu cần dùng đã sẵn sàng:** tài liệu mở sẵn, thông tin cần xin đã được hỏi từ chiều.

**Ngày 2 (15 phút, làm vào cuối giờ chiều nay)**

1. Chọn con ếch cho ngày mai từ danh sách ABCDE hôm qua.
2. Viết bước đầu tiên, nhỏ đến mức bắt đầu được trong hai phút.
3. Mở sẵn tài liệu, xin sẵn thông tin còn thiếu, đặt con ếch ở chỗ sáng mai nhìn thấy đầu tiên.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-2.

Chia sẻ hôm nay: "Con ếch ngày mai: .... Bước đầu tiên: ...". Chia sẻ trước khi rời chỗ làm chiều nay là đẹp nhất nha.


## Bài 3: Ngày 3 (Thứ Tư 11/11)
@img 3_truoc-10-gio
@pdf 10XHub_AnConEch_PhieuNgay3_truoc-10-gio.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: ĂN ẾCH TRƯỚC 10 GIỜ SÁNG

Sáng nay là buổi sáng ăn ếch thật. Trước khi bắt đầu, đặt hai buổi sáng điển hình cạnh nhau để thấy rõ khác biệt.

**Buổi sáng mở hộp thư trước**

- 8 giờ: trả lời bốn thư, mỗi thư "chỉ mất hai phút".
- 8 giờ 30: một thư cần tra lại số liệu, mở thêm hai tệp.
- 9 giờ: đồng nghiệp ghé hỏi một việc, nhóm trò chuyện bắt đầu sôi.
- 10 giờ: cảm giác đã bận rộn hai tiếng, nhưng việc quan trọng nhất chưa chạm tới.

**Buổi sáng ăn ếch trước**

- 8 giờ: làm thói quen then chốt, ngay sau đó mở con ếch đã chuẩn bị từ chiều qua.
- 8 giờ 45: con ếch đã đi được một nửa, thông báo vẫn tắt.
- 9 giờ 30: dừng con ếch ở một điểm rõ ràng, mở hộp thư.
- 10 giờ: thư vẫn được trả lời, chỉ muộn hơn một tiếng rưỡi, và không ai bị ảnh hưởng.

Phần lớn thư buổi sáng không mất gì khi được trả lời lúc 9 giờ 30 thay vì 8 giờ. Con ếch thì khác: bỏ lỡ khung giờ đầu ngày, nó dễ bị đẩy sang ngày hôm sau.

**Cảm giác tiến triển cũng là động lực**

Teresa Amabile (Trường Kinh doanh Harvard) và Steven Kramer phân tích gần 12.000 trang nhật ký công việc của 238 nhân viên trong 26 nhóm dự án thuộc bảy công ty. Kết quả được trình bày trong cuốn The Progress Principle (2011): trong những ngày làm việc tốt nhất, sự kiện được nhắc đến nhiều nhất là tạo ra tiến triển trong một công việc có ý nghĩa, kể cả tiến triển nhỏ. Ăn con ếch trước 10 giờ tạo ra đúng loại tiến triển đó, sớm, ngay đầu ngày.

**Vì sao là 10 giờ?**

Mốc 10 giờ không phải con số khoa học. Đó là một ranh giới dễ nhớ để buổi sáng có một khung giờ dành cho việc quan trọng nhất. Ai bắt đầu ngày làm việc lúc 13 giờ thì chọn mốc tương ứng, ví dụ 15 giờ. Ai đã tìm ra giờ năng lượng cao nhất ở tuần Quản lý năng lượng thì ưu tiên đặt con ếch vào đó.

**Ngày 3 (khoảng 20 phút ghi chép, cộng thời gian làm con ếch)**

1. Sáng nay làm thói quen then chốt, ngay sau đó bắt đầu con ếch đã chuẩn bị chiều qua.
2. Bấm đồng hồ trên sổ thực hành, làm liền 25 phút trước khi mở hộp thư.
3. Đến 10 giờ, ghi lại tình trạng con ếch: đã xong, xong một phần, hay chưa bắt đầu.
4. Nếu có việc chen vào trước con ếch, ghi lại đó là việc gì.
5. Đánh dấu thói quen hôm nay trên bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-3.

Chia sẻ hôm nay: "Hôm nay tôi bắt đầu con ếch lúc .... Tình trạng lúc 10 giờ: .... Tuần này tôi đã làm thói quen ... ngày". Chưa bắt đầu được cũng cứ chia sẻ thật, cả nhóm cùng học từ những buổi sáng chưa trọn vẹn nha.


## Bài 4: Ngày 4 (Thứ Năm 12/11)
@img 4_cat-lat
@pdf 10XHub_AnConEch_PhieuNgay4_cat-lat.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: ẾCH QUÁ LỚN THÌ CẮT LÁT

Có những con ếch không ăn hết trong một buổi sáng: viết quy trình mới cho cả phòng, chuẩn bị hồ sơ kiểm toán, xây dựng khung năng lực cho đội. Nhìn vào cả khối việc, đầu óc chỉ thấy một chữ: lớn quá, để mai.

Tracy gọi cách xử lý là cắt lát: chia việc lớn thành những phần nhỏ, mỗi phần làm xong trong một khung giờ ngắn, rồi chỉ tập trung vào lát trước mặt. Ông còn gợi ý một cách thứ hai, tạm gọi là khoét lỗ: cam kết làm việc lớn trong một khoảng thời gian cố định, ví dụ 15 phút, dù chưa biết sẽ xong phần nào.

Dưới đây là danh sách cắt lát theo từng vị trí công việc, để các anh chị và các bạn tìm cách gần nhất với việc của mình.

**1. Quản lý: viết quy trình phê duyệt mới**
- Lát 1: liệt kê các bước hiện tại, mỗi bước một dòng.
- Lát 2: khoanh hai bước hay bị chậm nhất.
- Lát 3: viết lại hai bước đó.
- Lát 4: gửi bản nháp cho một người dùng thử góp ý.

**2. Kinh doanh: chuẩn bị đề xuất cho khách hàng lớn**
- Lát 1: viết ba vấn đề chính của khách bằng lời của khách.
- Lát 2: chọn giải pháp cho từng vấn đề.
- Lát 3: tính giá và các phương án.
- Lát 4: viết trang tóm tắt một trang.

**3. Kế toán: hồ sơ quyết toán cuối năm**
- Lát 1: lập danh mục chứng từ cần có.
- Lát 2: đối chiếu một nhóm tài khoản mỗi buổi sáng.
- Lát 3: ghi riêng các khoản chênh lệch cần hỏi lại.

**4. Nhân sự: khung năng lực cho một vị trí**
- Lát 1: liệt kê năm nhiệm vụ chính của vị trí.
- Lát 2: viết kỹ năng cần cho từng nhiệm vụ.
- Lát 3: mô tả ba mức thành thạo cho một kỹ năng, rồi làm tiếp các kỹ năng khác.

**5. Kỹ thuật và chăm sóc khách hàng: xử lý tồn đọng**
- Lát 1: gom các yêu cầu tồn thành nhóm theo nguyên nhân.
- Lát 2: xử lý nhóm có nhiều yêu cầu nhất.
- Lát 3: viết hướng dẫn ngắn để nhóm đó không lặp lại.

Ba dấu hiệu một lát đã cắt đúng cỡ:

- Bắt đầu được ngay, không cần chờ ai.
- Làm xong trong 15 đến 45 phút.
- Khi xong, nhìn thấy rõ một kết quả cụ thể: một trang, một bảng, một danh sách.

**Ngày 4 (20 phút)**

1. Chọn con ếch lớn nhất của tuần này hoặc tuần sau.
2. Cắt thành ba đến năm lát, mỗi lát một kết quả nhìn thấy được.
3. Chọn lát đầu tiên cho sáng mai và chọn độ dài mỗi lát: 15, 25 hay 45 phút.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-4.

Chia sẻ hôm nay: "Con ếch lớn của tuần: .... Lát đầu tiên tôi làm: ...".


## Bài 5: Ngày 5 (Thứ Sáu 13/11)
@img 5_ghep-thoi-quen
@pdf 10XHub_AnConEch_PhieuNgay5_ghep-thoi-quen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: ĐẶT CON ẾCH NGAY CẠNH THÓI QUEN

Bốn ngày qua, con ếch đã có cách chọn, cách chuẩn bị, cách cắt lát. Hôm nay là lúc nối nó vào hành trình thói quen: viết một quy ước ăn ếch, gắn với thói quen then chốt đang giữ, để từ tuần sau mỗi buổi sáng tự chạy theo quy ước đó mà không cần nghĩ lại.

Bài hôm nay là một bảng chọn. Có ba cách ghép, mỗi cách hợp với một kiểu thói quen. Đọc cả ba rồi chọn một.

**Cách 1: Con ếch ngay sau thói quen**

Hợp với thói quen ngắn, làm đầu ngày: đọc tài liệu chuyên môn 20 phút, viết ba việc quan trọng nhất, xem lại số liệu hôm qua. Thói quen xong là tín hiệu để mở con ếch.

Quy ước mẫu: "Sau 20 phút đọc chuyên môn, tôi làm ngay việc A1, trước khi mở hộp thư."

**Cách 2: Thói quen mở màn cho con ếch**

Hợp với thói quen chuẩn bị: dọn bàn, tắt thông báo, mở khối làm việc sâu trong lịch. Thói quen này dọn đường, con ếch đi vào ngay sau đó, trong cùng một khối giờ.

Quy ước mẫu: "Khi khối làm việc sâu 8 giờ bắt đầu, tôi tắt thông báo rồi mở con ếch đã chuẩn bị từ chiều."

**Cách 3: Thói quen chính là lát đầu tiên của con ếch**

Hợp với thói quen gắn trực tiếp vào việc quan trọng: viết 30 phút mỗi sáng, gọi hai khách hàng mỗi ngày, rà một quy trình mỗi sáng. Khi đó thói quen và con ếch là một. Mỗi ngày chỉ cần chọn đúng nội dung cho thói quen.

Quy ước mẫu: "30 phút viết mỗi sáng của tôi luôn dành cho con ếch của ngày."

**Chọn thế nào?**

- Thói quen dưới 20 phút và không liên quan trực tiếp đến việc chính: chọn cách 1.
- Thói quen là một nghi thức chuẩn bị hay một khối giờ: chọn cách 2.
- Thói quen vốn là một phần của công việc quan trọng: chọn cách 3.

Phân vân giữa hai cách thì chọn cách đơn giản hơn để thử trong một tuần. Quy ước nào cũng sửa lại được.

**Bảo vệ khung giờ buổi sáng**

Quy ước cần thêm một điều nữa: một việc dời hẳn sang sau 10 giờ. Với nhiều người đó là hộp thư. Với người khác là nhóm trò chuyện nội bộ, bảng tin hay họp giao ban ngắn tự phát. Dời một việc thôi, nhưng dời thật.

**Ngày 5 (20 phút)**

1. Đọc ba cách ghép, chọn một cách hợp với thói quen của mình.
2. Viết quy ước ăn ếch trong một câu.
3. Chọn một việc dời sang sau 10 giờ, báo cho đồng nghiệp gần nhất biết nếu cần.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-5. Quy ước hôm nay được lưu cho cả hành trình, các tuần sau sổ sẽ tự hiện lại.

Chia sẻ hôm nay: "Quy ước ăn ếch của tôi: .... Việc tôi dời sau 10 giờ: ...". Cuối tuần thong thả rồi, chúc các anh chị và các bạn một buổi tối Thứ Sáu nhẹ nhàng nha.


## Bài 6: Ngày 6 (Thứ Bảy 14/11)
@img 6_nhin-lai
@img2 9_the-thanh-tich
@pdf 10XHub_AnConEch_PhieuNgay6_nhin-lai.pdf (phiếu thực hành và tấm thẻ quy ước ăn ếch để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: NHÌN LẠI MỘT TUẦN ĂN CON ẾCH

Hôm nay không có kiến thức mới. Chỉ có năm câu hỏi, mỗi câu dành khoảng năm phút. Trả lời thật, kể cả khi câu trả lời chưa đẹp, vì đó là dữ liệu tốt nhất để tuần sau làm tốt hơn.

**Câu hỏi 1: Tuần này có bao nhiêu buổi sáng con ếch được ăn trước 10 giờ?**

Đếm từ Thứ Hai đến Thứ Sáu. Một con ếch xong một phần cũng tính là đã ăn, vì điều quan trọng là nó được bắt đầu trước những việc khác.

**Câu hỏi 2: Mình có chọn đúng con ếch không?**

Nhìn lại các việc đã gắn chữ A. Có việc nào thực ra là B, chỉ vì gấp nên trông giống A? Có việc A thật nào bị bỏ sót vì nó không có hạn chót? Những việc quan trọng mà không gấp, như xây quy trình hay phát triển đội ngũ, rất hay bị bỏ sót theo cách này.

**Câu hỏi 3: Việc gì hay chen vào trước con ếch nhất?**

Có thể là một cuộc họp lặp lại, một nhóm trò chuyện, một thói quen kiểm tra số liệu. Gọi được tên nó là đã xử lý được một nửa. Nửa còn lại là quyết định: dời, giới hạn, hay chuẩn bị sẵn câu trả lời.

**Câu hỏi 4: Buổi chiều chuẩn bị con ếch có giúp gì không?**

So sánh những buổi sáng có chuẩn bị từ chiều hôm trước và những buổi không có. Nếu khác biệt rõ, năm phút cuối ngày đáng giữ thành một phần của thói quen.

**Câu hỏi 5: Con ếch đầu tiên của Thứ Hai tới là gì?**

Viết ra ngay hôm nay. Chiều Thứ Sáu tuần sau, chỉ cần lặp lại câu hỏi này.

**Tấm thẻ quy ước ăn ếch**

Phiếu đính kèm có một tấm thẻ in được, gom lại quy ước ăn ếch, thói quen then chốt và việc dời sau 10 giờ. In ra, cắt theo đường viền và đặt cạnh màn hình.

**Ngày 6 (25 phút)**

1. Đánh dấu trên sổ những buổi sáng đã ăn ếch trước 10 giờ và những ngày đã làm thói quen.
2. Chấm điểm năm câu hỏi theo thang 1 đến 5, viết một điều học được về buổi sáng của mình.
3. Viết con ếch đầu tiên của Thứ Hai tới.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0026-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi ăn ếch trước 10 giờ ... buổi sáng. Con ếch đầu tiên của tuần tới: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Ăn con ếch hiện ra, có hình mặt trời mọc, ghi tên mình, số buổi sáng đã ăn ếch và quy ước ăn ếch của riêng mình. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

**Tuần sau**

Con ếch giúp việc quan trọng được làm trước. Tuần sau, Công thức #0027 về Luyện tập có chủ đích đặt câu hỏi tiếp theo: làm sao để chính thói quen then chốt được làm ngày càng giỏi hơn, chứ không chỉ làm đều.

Chủ Nhật nghỉ trọn vẹn nha. Thói quen then chốt cũng được nghỉ, chuỗi ngày không bị tính là lỡ.
