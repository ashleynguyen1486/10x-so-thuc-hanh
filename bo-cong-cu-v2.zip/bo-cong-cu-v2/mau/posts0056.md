## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 07/06)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0056_Phuong Phap PARA_VN.pdf (tài liệu đầy đủ của Công thức #0056)
@pdf 10XHub_PARA_PhieuNgay1_kiem-ke-tai-lieu.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0056.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TÀI LIỆU HỌC CÓ NẰM ĐÚNG CHỖ KHI MÌNH CẦN?

Tuần trước, cả nhóm đã khép mỗi buổi học 20 phút bằng một thẻ ghi chú viết bằng lời của chính mình, rồi nối thẻ mới với một thẻ cũ. Cả nhóm cũng đã gom ghi chú tạm để giữ lại ý đáng giữ, viết lại một đoạn chép nguyên văn bằng lời của mình, đánh số thẻ theo kiểu Luhmann (1, 1a, 1a1) và viết một thẻ mục lục. Sau sáu ngày, mỗi người đã có những thẻ đầu tiên của một hộp thẻ riêng và một quy ước hộp thẻ cho cả hành trình. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Thẻ ghi chú giữ ý tưởng. Nhưng quanh mỗi buổi học còn nhiều tài liệu khác: tệp bài giảng, đường dẫn bài đọc, bảng tính luyện tập, bản nháp của dự án học. Công thức #0056 của tuần này là Phương pháp PARA, một cách sắp xếp để những tài liệu đó nằm đúng chỗ khi cần dùng.

**Nếu mới tham gia:** hãy chọn một kỹ năng muốn học trong quý 2 và một sản phẩm nhỏ chứng minh mình đã học được, ví dụ một bảng phân tích mẫu. Viết cả hai, cùng một thói quen nhỏ mỗi ngày, vào Ngày 1 trên sổ thực hành. Đến Thứ Năm, mình sẽ có một thư mục gọn gàng cho chính dự án học đó. Không cần đọc lại các tuần trước.

**Ba ngộ nhận về việc sắp xếp tài liệu**

**Ngộ nhận 1: "Sắp xếp theo chủ đề là hợp lý nhất."**

Thư mục "Bán hàng", "Tài chính", "Kỹ năng mềm" nhìn rất ngăn nắp, nhưng khi chuẩn bị một buổi đào tạo nội bộ, tài liệu lại nằm rải ở ba bốn thư mục. Tiago Forte, tác giả cuốn "Building a Second Brain" (2022), đề xuất một nguyên tắc khác: sắp xếp theo mức độ sẵn sàng hành động. Tài liệu của việc đang làm nằm gần nhất, tài liệu tham khảo xa hơn, việc đã xong thì cất đi.

**Ngộ nhận 2: "Muốn gọn thì phải có nhiều tầng thư mục."**

Càng nhiều tầng, cất một tệp càng phải nghĩ lâu, tìm lại càng phải mở nhiều lớp. PARA chỉ có bốn ngăn ở tầng trên cùng, bên dưới giữ càng ít tầng càng tốt.

**Ngộ nhận 3: "Phải dọn sạch toàn bộ rồi mới bắt đầu."**

Tuần này đi theo hướng ngược lại: bắt đầu từ việc đang chạy, mà việc đầu tiên là dự án học của quý 2. Tài liệu cũ có thể gom cả khối vào ngăn lưu trữ, khi nào cần dùng mới sắp xếp.

**Bốn ngăn của PARA**

- **Dự án:** việc ngắn hạn, có một kết quả cụ thể và một hạn chót. Ví dụ: dự án học của quý 2, buổi đào tạo ngày 25.06.
- **Lĩnh vực:** phần trách nhiệm cần giữ chuẩn liên tục, không có ngày kết thúc. Ví dụ: chăm sóc nhóm khách hàng phía Nam, an toàn lao động của xưởng.
- **Tài nguyên:** chủ đề mình quan tâm và tài liệu tham khảo cho sau này. Ví dụ: các mẫu thuyết trình hay, bài viết về kỹ năng đang học.
- **Lưu trữ:** mọi điều không còn hoạt động từ ba ngăn trên, cất lại để tham khảo.

Tên PARA ghép từ chữ cái đầu tên tiếng Anh của bốn ngăn.

**PARA nằm ở đâu trong hành trình Mùa 3?**

Từ đầu Mùa 3, mỗi người thêm 20 phút học có chủ đích ngay sau thói quen then chốt, phục vụ một kỹ năng và một dự án học đã chọn. Cả nhóm đã có sổ đầu dòng (#0041) để ghi việc mỗi ngày, trang Cornell (#0049) để ghi trong buổi học, hộp thẻ (#0055) để giữ ý tưởng. PARA không thay công cụ nào. PARA là nơi chứa tài liệu, để buổi học 20 phút bắt đầu ngay ở phút đầu tiên thay vì mất năm phút đi tìm tệp.

Phiên bản 10X của chính mình không đến từ một buổi dọn dẹp lớn, mà từ những việc nhỏ lặp lại: hôm nay mở đúng thư mục trong vài giây, tuần sau thêm một thẻ ghi chú, cuối quý có một sản phẩm học thật để trình bày.

**Sáu ngày của tuần**

- Thứ Hai: tài liệu đang nằm ở đâu.
- Thứ Ba: ngăn Dự án.
- Thứ Tư: ngăn Lĩnh vực và ngăn Tài nguyên.
- Thứ Năm: dọn thư mục dự án học, mở ngăn Lưu trữ.
- Thứ Sáu: mỗi công cụ một vai trò.
- Thứ Bảy: đo lại và đặt nhịp dọn hằng tuần.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Tài liệu đang nằm ở đâu?**

1. Ngay sau thói quen then chốt, mở sổ thực hành, xem lại kỹ năng và dự án học đã chọn từ đầu Mùa 3.
2. Chọn một tài liệu đã dùng trong buổi học tuần trước. Bấm giờ xem mất bao nhiêu phút để mở lại được nó.
3. Đánh dấu mọi nơi tài liệu học và công việc đang nằm: hộp thư email, ổ máy tính, thư mục chung, ứng dụng ghi chú, sổ tay giấy, điện thoại.

Hôm nay chưa dọn gì cả, chỉ ghi lại hiện trạng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-1.

Chia sẻ hôm nay: "Tôi mất ... phút để tìm lại .... Tài liệu học và công việc của tôi đang nằm ở ... nơi khác nhau".

Con số phút hôm nay chỉ là điểm xuất phát của riêng mình, các anh chị và các bạn cứ ghi đúng hiện trạng nha.


## Bài 2: Ngày 2 (Thứ Ba 08/06)
@img 2_ngan-du-an
@pdf 10XHub_PARA_PhieuNgay2_ngan-du-an.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: VIỆC NÀO MỚI THẬT SỰ LÀ MỘT DỰ ÁN?

Ngăn đầu tiên của PARA là ngăn Dự án, và cũng là ngăn dễ đặt sai nhất. Forte định nghĩa dự án là một chuỗi việc ngắn hạn hướng tới một kết quả cụ thể. Có hai câu hỏi để kiểm tra rất nhanh:

1. Khi xong, có một kết quả nhìn thấy được không?
2. Có ngày kết thúc không?

Hai câu đều "có" thì đó là dự án. Chỉ cần một câu "không" thì đó là điều khác: một lĩnh vực cần giữ chuẩn, hoặc một chủ đề để tham khảo.

**Bài tập phân loại: tám mục, tự trả lời trước**

Các anh chị và các bạn thử xếp tám mục dưới đây vào bốn ngăn Dự án, Lĩnh vực, Tài nguyên, Lưu trữ, rồi mới đọc đáp án.

1. Chuẩn bị bài trình bày kết quả quý 2 cho ban giám đốc, ngày 30.06.
2. Tiếng Anh.
3. Chăm sóc khách hàng doanh nghiệp khu vực miền Trung.
4. Hoàn thành khoá học Excel nâng cao và nộp một bảng phân tích mẫu trước 30.06.
5. Quy trình nhập kho.
6. Tuyển hai nhân viên kinh doanh trước 15.07.
7. Các bài viết hay về kỹ năng đàm phán.
8. Báo cáo tháng 5 đã nộp.

**Đáp án và lý do**

1. **Dự án.** Có kết quả (bài trình bày) và có ngày.
2. **Chưa phải dự án.** "Tiếng Anh" là một chủ đề, thường nằm ở Tài nguyên. Muốn thành dự án, cần viết lại thành kết quả có hạn chót, ví dụ "thuyết trình 5 phút bằng tiếng Anh về sản phẩm mới cho đối tác vào 25.06".
3. **Lĩnh vực.** Đây là trách nhiệm liên tục, không có ngày xong.
4. **Dự án.** Một dự án học đúng nghĩa: có sản phẩm (bảng phân tích) và có ngày nộp.
5. **Tuỳ cách viết.** Nếu là việc giữ quy trình chạy đúng mỗi ngày, đó là Lĩnh vực. Nếu là "viết lại quy trình nhập kho cho kho mới trước 30.06", đó là Dự án.
6. **Dự án.** Có kết quả (hai người được tuyển) và có ngày.
7. **Tài nguyên.** Tham khảo cho sau này, chưa gắn với việc cụ thể.
8. **Lưu trữ.** Việc đã xong, cất lại để tham khảo.

**Kỹ năng và dự án học khác nhau ở đâu?**

Mục 2 và mục 4 cho thấy một điểm quan trọng của Mùa 3. Kỹ năng đang học là một chủ đề, nó đi cùng mình lâu dài. Dự án học mới là một dự án: một sản phẩm cụ thể, một ngày hoàn thành trong quý 2. Khi đầu Mùa 3 cả nhóm chọn cả hai, kỹ năng cho biết mình học gì, còn dự án học cho biết đến cuối quý mình làm ra được gì. Nếu dự án học của mình chưa có hạn chót, hôm nay là lúc thêm vào.

**Ngày 2 (20 phút)**

1. Liệt kê các dự án đang chạy, cả công việc và dự án học. Thường là 3 đến 8 mục.
2. Áp hai câu hỏi cho từng mục. Mục nào chưa có kết quả hoặc chưa có ngày, viết lại câu chữ cho rõ, hoặc chuyển sang ngăn khác.
3. Chọn dự án gần hạn nhất. Đây sẽ là thư mục đầu tiên được mở mỗi sáng tuần này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-2.

Chia sẻ hôm nay: "Tôi có ... dự án đang chạy, kể cả dự án học: .... Dự án gần hạn nhất: ...".

Danh sách dài hơn mình nghĩ cũng là chuyện rất bình thường. Thấy rõ được bao nhiêu việc đang chạy đã là một bước tiến rồi nha.


## Bài 3: Ngày 3 (Thứ Tư 09/06)
@img 3_linh-vuc-tai-nguyen
@pdf 10XHub_PARA_PhieuNgay3_linh-vuc-tai-nguyen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: LĨNH VỰC CẦN GIỮ CHUẨN, TÀI NGUYÊN ĐỂ DÙNG SAU

Hai ngăn giữa của PARA là nơi nhiều người phân vân nhất. Hôm nay là một cuộc trao đổi minh hoạ giữa hai đồng nghiệp, ghép từ những câu hỏi rất hay gặp.

**Một buổi trao đổi cuối giờ**

Khoa là chuyên viên tuyển dụng mới vào được ba tháng. Chị Hạnh là trưởng nhóm nhân sự. Khoa đang dọn thư mục theo PARA và mang máy tính sang hỏi.

Khoa: "Chị ơi, thư mục 'Chính sách lương thưởng' em để vào Dự án hay Tài nguyên ạ?"

Chị Hạnh: "Em hỏi thế này: nếu ba tháng em không đụng tới nó, có ai bị ảnh hưởng không?"

Khoa: "Có chứ chị, cuối tháng là có người hỏi ngay."

Chị Hạnh: "Vậy đó là Lĩnh vực. Không có ngày xong, nhưng có một mức chuẩn em phải giữ. Lĩnh vực của em là tuyển dụng, hồ sơ nhân sự, chính sách lương thưởng."

Khoa: "Còn mấy bài về phỏng vấn theo năng lực em lưu từ hồi học, chưa dùng tới?"

Chị Hạnh: "Ba tháng không mở cũng không ai bị ảnh hưởng, nhưng em muốn đọc lại. Đó là Tài nguyên."

Khoa: "Nhưng kỹ năng em đang học trong quý này là phỏng vấn theo năng lực mà chị."

Chị Hạnh: "Vậy thì tài liệu nào phục vụ dự án học của em, ví dụ bộ câu hỏi phỏng vấn em phải nộp cuối tháng 6, chuyển vào thư mục dự án học trong ngăn Dự án. Phần còn lại vẫn ở Tài nguyên. Khi nào cần, kéo sang."

Khoa: "Em hiểu rồi. Tài liệu đi theo việc đang làm, không đi theo chủ đề."

Tình huống trên là minh hoạ, tên nhân vật là tên giả định.

**Hai câu hỏi phân biệt**

- **Bỏ quên ba tháng, có ai bị ảnh hưởng không, kể cả mình?** Có thì đó là Lĩnh vực.
- **Không ai bị ảnh hưởng, nhưng mình muốn dùng lại?** Đó là Tài nguyên.

Theo Forte, lĩnh vực gắn với một chuẩn mực cần duy trì, còn tài nguyên là chủ đề mình quan tâm. Một tài liệu có thể đổi ngăn theo thời gian: hôm nay ở Tài nguyên, tuần sau phục vụ một dự án thì chuyển sang Dự án, xong việc thì vào Lưu trữ.

**Một gợi ý cho kỹ năng đang học**

Mỗi người nên có một thư mục trong ngăn Tài nguyên mang tên kỹ năng đang học. Đây là nơi gom bài đọc, đường dẫn, ví dụ hay gặp trong công việc. Mỗi buổi học 20 phút có thể bắt đầu bằng việc lấy một tài liệu từ đây, và kết thúc bằng một thẻ ghi chú như tuần trước.

**Ngày 3 (20 phút)**

1. Viết ra ba lĩnh vực mình chịu trách nhiệm trong công việc.
2. Viết ra ba chủ đề tài nguyên, trong đó có một chủ đề là kỹ năng đang học.
3. Tạo hai thư mục tương ứng trên máy tính hoặc trong sổ, chưa cần chuyển tệp.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-3.

Chia sẻ hôm nay: "Lĩnh vực tôi cần giữ chuẩn: .... Tài nguyên tôi đang gom cho kỹ năng ...: ...".

Ai làm việc với tài liệu của khách hàng hoặc tài liệu nội bộ, các anh chị và các bạn giữ đúng nơi lưu theo quy định của công ty nha, PARA chỉ áp dụng cho phần tài liệu mình được phép tự sắp xếp.


## Bài 4: Ngày 4 (Thứ Năm 10/06)
@img 4_don-thu-muc
@pdf 10XHub_PARA_PhieuNgay4_don-thu-muc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: HAI MƯƠI PHÚT DỌN THƯ MỤC DỰ ÁN HỌC

Hôm nay là ngày làm thật. Để dễ hình dung, Trường kể lại hai mươi phút của một người theo từng mốc thời gian. Đây là tình huống minh hoạ.

**Nhật ký hai mươi phút của anh Phúc**

Anh Phúc là kế toán tổng hợp. Kỹ năng anh chọn cho Mùa 3 là phân tích số liệu bằng Excel, dự án học là "bảng phân tích chi phí theo bộ phận, trình bày với trưởng phòng ngày 30.06".

**Phút 0 đến 3.** Ngay sau thói quen then chốt, anh tạo bốn thư mục ở tầng trên cùng: "1 Dự án", "2 Lĩnh vực", "3 Tài nguyên", "4 Lưu trữ". Đánh số để bốn ngăn luôn đứng đúng trình tự.

**Phút 3 đến 8.** Trong "1 Dự án", anh tạo thư mục "Phân tích chi phí, 30.06". Anh tìm và chuyển vào đây các tệp liên quan đang nằm rải rác: hai bài giảng trong hộp thư email, một bảng tính luyện tập trong thư mục tải về, bản nháp đầu tiên trên màn hình chính.

**Phút 8 đến 13.** Bên trong thư mục dự án học, anh chỉ giữ ba thư mục con: "Bài tập", "Ghi chú", "Sản phẩm". Không thêm tầng nào nữa.

**Phút 13 đến 17.** Anh nhìn lại ngăn Dự án. Thư mục "Quyết toán quý 1" đã xong từ tháng 4. Anh kéo nó sang "4 Lưu trữ". Không xoá gì cả, chỉ chuyển chỗ.

**Phút 17 đến 20.** Anh ghi lại cấu trúc thư mục dự án học vào sổ thực hành và đánh dấu bảng hành trình những ngày tuần này đã giữ thói quen.

**Ba điều đáng chú ý trong hai mươi phút đó**

- **Chỉ dọn một dự án.** Anh Phúc không đụng tới hàng trăm tệp cũ. Dự án học được dọn trước vì đó là thư mục anh mở mỗi ngày trong Mùa 3.
- **Lưu trữ không phải thùng rác.** Chuyển sang Lưu trữ nghĩa là việc đó đã ngừng hoạt động, nhưng vẫn tìm lại được khi cần, ví dụ khi làm quyết toán quý 2.
- **Cấu trúc được viết ra.** Một dòng mô tả cấu trúc giúp lần sau tạo thư mục cho dự án mới nhanh hơn, và giúp đồng nghiệp tìm được khi mình vắng mặt, nếu đó là thư mục dùng chung.

**Ngày 4 (20 phút)**

1. Tạo bốn thư mục đánh số ở tầng trên cùng (trên máy tính, ổ lưu trữ trực tuyến hoặc một ứng dụng ghi chú mình đang dùng).
2. Tạo thư mục dự án học trong ngăn Dự án, đặt tên kèm hạn chót, gom tệp liên quan vào.
3. Đưa ít nhất một dự án đã xong sang Lưu trữ.
4. Ghi lại cấu trúc thư mục dự án học trên sổ thực hành, đánh dấu bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-4. Cấu trúc thư mục dự án học được lưu cho cả hành trình.

Chia sẻ hôm nay: "Thư mục dự án học đã vào nếp: .... Tôi chuyển ... mục đã xong sang Lưu trữ".

Ai dùng sổ tay giấy cũng làm được: bốn trang đầu sổ là bốn ngăn, mỗi dự án một trang mục lục. Hai mươi phút là đủ, phần còn lại dọn dần vào những tuần sau nha.


## Bài 5: Ngày 5 (Thứ Sáu 11/06)
@img 5_moi-cong-cu
@pdf 10XHub_PARA_PhieuNgay5_moi-cong-cu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: SỔ ĐẦU DÒNG, HỘP THẺ, PARA: MỖI CÔNG CỤ MỘT VAI

Đến tuần này, nhiều người đang dùng cùng lúc ba công cụ: sổ đầu dòng từ Mùa 2, hộp thẻ từ tuần trước, và bốn ngăn PARA từ hôm qua. Ba công cụ mà không phân vai thì rất dễ rối: một ý hay nằm trong sổ việc, một việc cần làm nằm trong thư mục tài nguyên. Hôm nay là một bảng chọn sáu tình huống. Các anh chị và các bạn thử tự chọn công cụ trước khi đọc gợi ý.

**Sáu tình huống, chọn công cụ nào?**

1. **Trong cuộc họp, trưởng phòng giao thêm một việc cần xong trước Thứ Năm.**
Gợi ý: sổ đầu dòng. Một dòng việc, có ngày, có ký hiệu, để không rơi mất.

2. **Sau buổi học 20 phút, mình hiểu ra một ý mới về cách đọc báo cáo dòng tiền.**
Gợi ý: hộp thẻ. Một thẻ viết bằng lời của mình, nối với một thẻ cũ có liên quan.

3. **Nhận được tệp bài giảng và bài tập tuần này của khoá học.**
Gợi ý: PARA, ngăn Dự án, thư mục dự án học.

4. **Thấy một bài viết hay về kỹ năng thuyết trình, chưa cần dùng ngay.**
Gợi ý: PARA, ngăn Tài nguyên.

5. **Đọc bài viết đó, một ý khiến mình nghĩ lại cách mở đầu bài trình bày của chính mình.**
Gợi ý: hộp thẻ. Tài liệu ở lại ngăn Tài nguyên, còn ý tưởng của mình thì vào thẻ.

6. **Dự án học đã xong, sản phẩm đã nộp.**
Gợi ý: PARA, chuyển thư mục sang Lưu trữ. Thêm một dòng ghi nhận trong sổ đầu dòng, vì đó là một mốc đáng nhớ.

**Một câu dễ nhớ**

Sổ đầu dòng giữ việc. Hộp thẻ giữ ý. PARA giữ tài liệu.

Ba công cụ nối với nhau rất tự nhiên. Một dòng việc trong sổ đầu dòng có thể ghi "học bài 4, thư mục dự án học". Một thẻ ghi chú có thể ghi nguồn "tài liệu ở ngăn Tài nguyên, thư mục thuyết trình". Không cần phần mềm đặc biệt, chỉ cần mỗi điều có một chỗ quen thuộc.

**Khi nào không cần cả ba?**

Không phải ai cũng cần dùng đủ ba công cụ. Người làm việc chủ yếu trên giấy có thể dùng sổ đầu dòng với một trang mục lục bốn ngăn. Người làm việc chủ yếu trên máy tính có thể để thẻ ghi chú thành một thư mục con trong ngăn Tài nguyên. Điều quan trọng là quy tắc rõ ràng, và mình giữ đúng quy tắc đó trong ít nhất vài tuần.

**Ngày 5 (20 phút)**

1. Đọc sáu tình huống, ghi lại tình huống nào mình từng đặt sai chỗ.
2. Viết quy tắc của riêng mình cho từng công cụ: sổ đầu dòng dùng cho điều gì, hộp thẻ dùng cho điều gì, PARA dùng cho điều gì.
3. Áp quy tắc vào buổi học 20 phút hôm nay: tài liệu lấy từ thư mục dự án học, ý mới viết vào thẻ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-5.

Chia sẻ hôm nay: "Mỗi công cụ một vai trò: sổ đầu dòng cho ..., hộp thẻ cho ..., PARA cho ...".

Cuối tuần rồi, buổi học hôm nay có thể ngắn hơn một chút, miễn là vẫn diễn ra ngay sau thói quen then chốt nha.


## Bài 6: Ngày 6 (Thứ Bảy 12/06)
@img 6_nhip-don-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_PARA_PhieuNgay6_nhip-don-tuan.pdf (phiếu thực hành và trang bốn ngăn in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MƯỜI LĂM PHÚT MỖI TUẦN GIỮ BỐN NGĂN GỌN

Hôm nay Trường viết bài khép tuần theo dạng một lá thư gửi các anh chị và các bạn.

**Thư gửi những người vừa dọn xong bốn ngăn**

Các anh chị và các bạn thân mến,

Tuần này mình không học thêm một kỹ thuật ghi nhớ nào. Mình làm một việc ít ai để ý: chuẩn bị chỗ cho việc học. Thứ Hai, mỗi người bấm giờ xem mất bao lâu để tìm lại một tài liệu. Thứ Ba, danh sách dự án được viết lại cho rõ kết quả và hạn chót. Thứ Tư, lĩnh vực và tài nguyên được tách ra. Thứ Năm, thư mục dự án học có hình hài rõ ràng, và ít nhất một việc đã xong được cất vào Lưu trữ. Thứ Sáu, ba công cụ được phân vai.

Tiago Forte mô tả cách làm việc với kiến thức qua bốn bước, ông viết tắt là CODE: Thu thập điều đáng giữ, Sắp xếp theo việc đang làm, Chắt lọc phần cốt lõi, và Thể hiện thành một sản phẩm. Nhìn lại Mùa 3, cả nhóm đã đi qua gần đủ bốn bước. Những buổi học 20 phút là lúc thu thập. Tuần này là sắp xếp. Thẻ ghi chú tuần trước và trang Cornell là chắt lọc. Còn thể hiện chính là sản phẩm của dự án học, điều mỗi người sẽ trình bày vào cuối quý 2.

Một hệ thống chỉ có ích nếu được giữ. Vì vậy sáng nay chỉ có hai việc nhỏ: đo lại, và đặt một nhịp dọn hằng tuần.

Hẹn gặp các anh chị và các bạn ở dòng chia sẻ cuối tuần.

Trường

**Sáng nay (15 phút)**

1. Bấm giờ tìm lại một tài liệu của buổi học tuần này, giống như Thứ Hai.
2. Đặt nhịp dọn hằng tuần: chọn một khung 15 phút cố định, ví dụ cuối giờ chiều Thứ Sáu.

**Mười lăm phút dọn tuần gồm những gì?**

- Gom tệp trong thư mục tải về và màn hình chính vào đúng ngăn.
- Dự án nào đã xong thì chuyển sang Lưu trữ.
- Dự án học còn bao nhiêu ngày đến hạn, bước tiếp theo là gì.
- Một tài liệu nào ở Tài nguyên cần kéo sang dự án tuần tới.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In trang bốn ngăn ở phiếu Ngày 6, viết tên các dự án, lĩnh vực, tài nguyên chính và dán gần bàn làm việc trong vài tuần đầu.

**Tuần sau: Hiệu ứng Dunning-Kruger và tự đánh giá**

Tài liệu đã nằm đúng chỗ. Câu hỏi tiếp theo của Mùa 3: sau gần mười tuần học, mình đã thạo kỹ năng đang học tới đâu, và làm sao biết điều đó bằng bằng chứng thay vì cảm giác?

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0056-ngay-6.

Chia sẻ hôm nay: "Thứ Hai tôi mất ... phút để tìm lại một tài liệu học, hôm nay là ... phút. Nhịp dọn bốn ngăn của tôi: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: một dấu ngoặc kép lớn, câu mô tả thư mục dự án học của chính mình, chữ PARA và dòng "BỐN NGĂN ĐÃ VÀO NẾP". Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Hẹn gặp lại các anh chị và các bạn sáng Thứ Hai.
