## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 16/11)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0027_Luyen Tap Co Chu Dich_VN.pdf (tài liệu đầy đủ của Công thức #0027)
@pdf 10XHub_LuyenTap_PhieuNgay1_ky-nang-con.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0027.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TỪ LÀM ĐỀU ĐẾN LÀM GIỎI HƠN MỖI TUẦN

Sáu buổi sáng của tuần trước đã có một trật tự mới: thói quen then chốt mở đầu, con ếch đi ngay sau, hộp thư chờ đến sau 10 giờ. Mỗi người khép tuần bằng một quy ước ăn ếch của riêng mình, và quy ước đó vẫn nằm trên sổ thực hành, tuần này mở ra là thấy.

**Nếu mới tham gia:** tuần này bắt đầu rất dễ. Viết câu bản sắc và một thói quen mình làm hằng ngày trong công việc, ví dụ "viết báo cáo cuối ngày" hay "gọi lại khách hàng mỗi sáng". Sau đó chọn một kỹ năng nhỏ trong thói quen đó để luyện cùng cả nhóm. Không cần đọc lại các tuần trước.

**Một nghiên cứu ở Berlin và một con số bị hiểu nhầm**

Năm 1993, nhà tâm lý học Anders Ericsson cùng Ralf Krampe và Clemens Tesch-Römer nghiên cứu các sinh viên vĩ cầm tại một học viện âm nhạc ở Berlin. Các giáo sư chia sinh viên thành nhóm xuất sắc và nhóm giỏi, thêm một nhóm sinh viên ngành sư phạm âm nhạc. Các nhà nghiên cứu phỏng vấn, đề nghị sinh viên ghi nhật ký thời gian và ước tính số giờ đã luyện từ nhỏ.

Khác biệt rõ nhất giữa các nhóm không nằm ở năng khiếu được kể lại, mà ở lượng thời gian luyện tập một mình, có mục tiêu rõ ràng, nhắm vào đúng chỗ còn yếu. Các tác giả gọi kiểu luyện tập đó là luyện tập có chủ đích (Psychological Review, 1993).

Mười lăm năm sau, cuốn Outliers của Malcolm Gladwell (2008) làm nổi tiếng "quy tắc 10.000 giờ". Chính Ericsson và cộng sự Robert Pool về sau phản biện cách hiểu này trong cuốn Peak (2016):

- 10.000 giờ là mức trung bình của nhóm xuất sắc khi 20 tuổi, và khoảng một nửa số người trong nhóm đó chưa đạt mức ấy.
- Con số không có gì đặc biệt. Nếu lấy mốc 18 tuổi thì là khoảng 7.400 giờ.
- Điều quan trọng nhất bị bỏ qua: không phải giờ nào cũng như nhau. Lặp lại việc mình đã làm quen thì gần như không làm mình giỏi lên.

**Vì sao điều này liên quan đến công việc?**

Nhiều người viết báo cáo, gọi điện cho khách hay chạy cuộc họp hằng tuần suốt nhiều năm. Làm đều là một nền móng tốt, cả nhóm đã xây nền móng đó qua năm tuần hành trình. Nhưng làm đều chưa chắc đã làm giỏi hơn. Bước tiếp theo là chọn một phần nhỏ của thói quen và luyện nó một cách có chủ đích.

**Lớp mới cho hành trình thói quen**

Thói quen then chốt giữ nguyên. Tuần này tách ra một kỹ năng con bên trong nó: với thói quen viết báo cáo, kỹ năng con có thể là viết đoạn tóm tắt mở đầu; với thói quen gọi lại khách hàng, có thể là đặt câu hỏi tìm nhu cầu. Sáu ngày đi theo nhịp sau: Thứ Hai chọn kỹ năng con. Thứ Ba đặt mục tiêu nhỏ, đo được. Thứ Tư luyện một buổi tập trung. Thứ Năm dựng vòng phản hồi. Thứ Sáu 20.11, Ngày Nhà giáo Việt Nam, xin góp ý từ người hướng dẫn và gửi lời cảm ơn người đã dẫn dắt mình trong nghề. Thứ Bảy lập bậc thang luyện tập cho bốn tuần tới. Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Chọn kỹ năng con**

1. Mở sổ thực hành, xem lại thói quen đang giữ. Người mới điền câu bản sắc và thói quen.
2. Viết ba kỹ năng nhỏ nằm bên trong thói quen đó.
3. Chọn một kỹ năng mà nếu giỏi hơn, kết quả công việc sẽ khác rõ nhất.
4. Tự đánh giá mức hiện tại và viết một câu: vì sao kỹ năng này đáng luyện.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-1. Kỹ năng chọn hôm nay được lưu cho cả hành trình.

Chia sẻ hôm nay: "Thói quen của tôi: .... Kỹ năng con tôi chọn luyện: ...". Người mới thêm chữ THAM GIA ở đầu bình luận để cả nhóm biết và chào đón nha.


## Bài 2: Ngày 2 (Thứ Ba 17/11)
@img 2_muc-tieu
@pdf 10XHub_LuyenTap_PhieuNgay2_muc-tieu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: MỤC TIÊU NHỎ, ĐO ĐƯỢC NGAY

Trong cuốn Peak, Ericsson và Pool mô tả bốn đặc điểm của một buổi luyện tập có mục đích. Bài hôm nay giải nghĩa từng đặc điểm bằng ví dụ công việc, vì hiểu đúng bốn điều này thì đặt mục tiêu cho kỹ năng con sẽ rất nhanh.

**1. Mục tiêu cụ thể**

Nghĩa là: biết rõ buổi luyện hôm nay nhắm vào điều gì, nhỏ đến mức đạt được trong vài buổi.

Ví dụ: không phải "thuyết trình tốt hơn", mà là "mở đầu bài trình bày bằng một câu nêu kết luận, không quá 20 giây".

**2. Tập trung trọn vẹn**

Nghĩa là: trong khoảng thời gian luyện, toàn bộ sự chú ý dành cho kỹ năng đó. Ericsson nhấn mạnh rằng luyện tập kiểu này tốn sức, nên một buổi ngắn mà tập trung có giá trị hơn một buổi dài mà phân tán.

Ví dụ: 20 phút viết lại đoạn tóm tắt báo cáo, điện thoại để ngoài tầm tay.

**3. Có phản hồi**

Nghĩa là: biết ngay mình làm đúng hay sai, đúng đến mức nào. Không có phản hồi thì dễ lặp lại cùng một lỗi mà không biết.

Ví dụ: so đoạn tóm tắt của mình với một bản tóm tắt mẫu được cấp trên đánh giá cao.

**4. Ra khỏi vùng quen**

Nghĩa là: mục tiêu cao hơn mức hiện tại một chút. Quá dễ thì không học thêm được gì, quá khó thì dễ nản và bỏ.

Ví dụ: đang tóm tắt một báo cáo trong 10 câu, thử rút còn 5 câu mà vẫn đủ ý.

**Đo bằng gì?**

Mục tiêu tốt luôn đi kèm một cách đo đơn giản. Vài cách đo dùng được ngay trong công việc:

- Đếm: số câu hỏi mở trong một cuộc gọi, số lỗi trong một bảng số liệu.
- Bấm giờ: thời gian hoàn thành một bảng đối chiếu, độ dài phần mở đầu bài trình bày.
- So chuẩn: bao nhiêu mục trong danh sách kiểm tra đã đạt.
- Phản hồi của người nhận: khách hàng có nhắc lại đúng ý chính không.

Một lưu ý quan trọng: con số đo là để mình thấy tiến bộ, không phải để tự chấm điểm bản thân. Mức hiện tại thấp chỉ có nghĩa là còn nhiều chỗ để luyện.

**Ngày 2 (20 phút)**

1. Viết một mục tiêu cụ thể cho kỹ năng con, đạt được trong khoảng bốn tuần.
2. Chọn cách đo và ghi mức hiện tại bằng một con số.
3. Kiểm tra độ khó: quá dễ, vừa ngoài vùng quen, hay quá khó. Điều chỉnh cho đến khi đúng mức thứ hai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-2.

Chia sẻ hôm nay: "Mục tiêu luyện tuần này: .... Tôi đo bằng: ...".


## Bài 3: Ngày 3 (Thứ Tư 18/11)
@img 3_buoi-luyen
@pdf 10XHub_LuyenTap_PhieuNgay3_buoi-luyen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: HAI MƯƠI PHÚT NGOÀI VÙNG QUEN

Hôm nay là buổi luyện đầu tiên. Thay vì giải thích thêm, bài viết là một kịch bản theo từng phút cho một buổi luyện 20 phút. Ví dụ đi theo một nhân viên chăm sóc khách hàng giả định đang luyện kỹ năng con "xác nhận lại vấn đề của khách bằng một câu trước khi giải thích". Mỗi người thay bằng kỹ năng của mình.

**Phút 0 đến 2: Nhắc lại mục tiêu**

Đọc to mục tiêu đã viết hôm qua: "Mở đầu mỗi câu trả lời bằng một câu xác nhận vấn đề, không quá 15 chữ." Đặt điện thoại úp xuống, đóng hộp thư, bấm đồng hồ trên sổ thực hành.

**Phút 2 đến 6: Làm một lần, ghi lại**

Lấy ba phản ánh cũ của khách. Viết câu xác nhận cho từng phản ánh, đúng như khi làm thật. Chưa sửa gì cả.

**Phút 6 đến 10: Tìm chỗ khó nhất**

Đọc lại ba câu. Câu nào dài quá 15 chữ? Câu nào nhắc lại lời khách mà chưa nêu đúng vấn đề? Khoanh chỗ yếu nhất. Đây là chỗ cần luyện, không phải những câu đã ổn.

**Phút 10 đến 16: Luyện đúng chỗ khó**

Viết lại riêng phần yếu đó ba đến năm lần, mỗi lần một cách khác. Đây là phần khó chịu nhất của buổi luyện, và cũng là phần có giá trị nhất. Ericsson mô tả luyện tập có chủ đích thường không dễ chịu, chính vì nó luôn nhắm vào chỗ mình còn làm chưa tốt.

**Phút 16 đến 19: Làm lại từ đầu**

Lấy hai phản ánh mới, viết câu xác nhận một lần nữa. So với lần đầu: ngắn hơn chưa, đúng vấn đề hơn chưa?

**Phút 19 đến 20: Ghi một dòng**

Ghi số phút đã luyện, chỗ khó đã luyện lại và một lỗi còn lặp. Ngày mai sẽ dùng dòng này để dựng vòng phản hồi.

**Ba điều giữ cho buổi luyện có chủ đích**

- Luyện đúng chỗ khó, không luyện lại chỗ đã giỏi cho dễ chịu.
- Ngắn mà tập trung tốt hơn dài mà phân tán. 15 đến 30 phút là đủ cho một buổi.
- Buổi luyện nằm ngay trong thói quen then chốt, không phải một việc thêm vào ngày đã kín lịch.

**Ngày 3 (khoảng 20 phút)**

1. Bấm đồng hồ trên sổ thực hành, chọn 15, 20 hoặc 30 phút.
2. Đi theo năm chặng: nhắc mục tiêu, làm một lần, tìm chỗ khó, luyện chỗ khó, làm lại.
3. Ghi chỗ khó đã luyện lại và lỗi còn lặp nhiều nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-3.

Chia sẻ hôm nay: "Hôm nay tôi luyện ... phút. Chỗ khó tôi luyện lại: ...". Buổi đầu thấy vụng là dấu hiệu đang luyện đúng chỗ, cứ chia sẻ thật nha.


## Bài 4: Ngày 4 (Thứ Năm 19/11)
@img 4_phan-hoi
@pdf 10XHub_LuyenTap_PhieuNgay4_phan-hoi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: MỖI LẦN LUYỆN, MỘT LẦN SO CHUẨN

Phản hồi là phần hay bị thiếu nhất khi luyện một kỹ năng trong công việc. Hôm nay đi theo dạng hỏi đáp, với những câu hỏi thường gặp khi bắt đầu dựng vòng phản hồi cho chính mình.

**Hỏi: Không có ai kèm cặp thì lấy phản hồi ở đâu?**

Đáp: Có ít nhất bốn nguồn không cần người khác:

- **Mẫu chuẩn:** một bản báo cáo, một bài trình bày, một email mẫu được đánh giá tốt. Đặt bản của mình cạnh bản mẫu và tìm khác biệt.
- **Con số:** thời gian hoàn thành, số lỗi, tỷ lệ khách hàng đồng ý hẹn gặp lại.
- **Ghi lại chính mình:** ghi âm cuộc gọi luyện tập, quay màn hình lúc thuyết trình thử, rồi xem lại.
- **Danh sách kiểm tra:** năm tiêu chí của một bản làm tốt, tự đánh dấu sau mỗi lần.

**Hỏi: So với mẫu chuẩn thì nhìn vào đâu?**

Đáp: Chỉ tìm khác biệt rõ nhất, một điều thôi. Ví dụ: bản mẫu mở đầu bằng kết luận, bản của mình mở đầu bằng bối cảnh. Một khác biệt được sửa triệt để có giá trị hơn mười khác biệt được ghi lại rồi để đó.

**Hỏi: Vì sao làm lâu năm mà vẫn không giỏi lên?**

Đáp: Ericsson cho rằng khi đã làm được ở mức chấp nhận được, phần lớn chúng ta chuyển sang chế độ tự động. Làm thêm nhiều năm theo cách cũ gần như không cải thiện thêm, vì không còn mục tiêu mới và không còn phản hồi. Vòng phản hồi chính là cách thoát khỏi chế độ tự động đó.

**Hỏi: Một vòng phản hồi gồm những bước nào?**

Đáp: Bốn bước, lặp lại sau mỗi buổi luyện:

1. Làm.
2. So với chuẩn.
3. Chọn một điều chỉnh.
4. Làm lại với điều chỉnh đó.

**Hỏi: Nghiên cứu có hứa rằng luyện như vậy sẽ giỏi lên không?**

Đáp: Không. Một tổng hợp 88 nghiên cứu của Brooke Macnamara và cộng sự (Psychological Science, 2014) cho thấy lượng luyện tập có chủ đích giải thích khoảng 26% khác biệt về thành tích trong trò chơi trí tuệ, 21% trong âm nhạc, 18% trong thể thao, 4% trong giáo dục và dưới 1% trong các nghề nghiệp. Ericsson phản biện cách các nghiên cứu đó đo "luyện tập". Điều rút ra cho tuần này rất thực tế: luyện tập có chủ đích là một công cụ hữu ích, không phải lời hứa về kết quả.

**Ngày 4 (20 phút)**

1. Chọn một nguồn phản hồi cho kỹ năng con.
2. Đặt kết quả buổi luyện hôm qua cạnh chuẩn, viết khác biệt rõ nhất.
3. Chọn một điều chỉnh cho buổi luyện tiếp theo.
4. Đánh dấu thói quen trên bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-4.

Chia sẻ hôm nay: "Khác biệt rõ nhất giữa bản của tôi và chuẩn: .... Lần sau tôi chỉnh: ...".


## Bài 5: Ngày 5 (Thứ Sáu 20/11, Ngày Nhà giáo Việt Nam)
@img 5_cam-on
@pdf 10XHub_LuyenTap_PhieuNgay5_cam-on.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: CẢM ƠN NGƯỜI DẪN DẮT TRONG NGHỀ

Hôm nay là Ngày Nhà giáo Việt Nam. Trường xin gửi lời tri ân đến các thầy cô, và đến những người thầy không đứng trên bục giảng: trưởng phòng đầu tiên kiên nhẫn sửa từng bản báo cáo, đồng nghiệp đi trước chỉ cho mình cách nói chuyện với khách hàng khó, người hướng dẫn đã chịu khó góp ý thẳng thắn đúng lúc mình cần. Ai đi làm cũng có ít nhất một người như vậy.

Bài hôm nay viết theo dạng thư, với hai lá thư ngắn. Một lá xin góp ý, một lá cảm ơn.

**Lá thư thứ nhất: xin góp ý về kỹ năng con**

Ba ngày qua, phản hồi đến từ mẫu chuẩn và con số. Hôm nay thêm một nguồn quý nhất: một người giỏi hơn mình ở kỹ năng đó. Lời xin góp ý tốt thường ngắn và hỏi đúng một điều. Mẫu thư:

"Chào anh/chị ..., em đang luyện kỹ năng ... trong công việc. Em gửi kèm một bản em vừa làm. Nếu chỉ sửa một điều để bản này tốt hơn rõ rệt, anh/chị sẽ sửa điều gì? Em cảm ơn anh/chị đã dành thời gian."

Vì sao hỏi "một điều"? Người được hỏi trả lời được trong vài phút, và mình nhận về đúng một điều chỉnh để đưa vào buổi luyện tiếp theo. Câu hỏi chung chung như "anh chị thấy thế nào?" thường chỉ nhận lại lời khen lịch sự.

**Lá thư thứ hai: cảm ơn người đã dẫn dắt mình**

Lời cảm ơn có giá trị nhất khi nói rõ người đó đã dạy mình điều gì và điều đó còn ở lại với mình ra sao. Mẫu thư:

"Chào anh/chị ..., nhân Ngày Nhà giáo, em muốn cảm ơn anh/chị vì đã dạy em .... Đến giờ em vẫn dùng điều đó mỗi khi .... Em rất biết ơn những góp ý của anh/chị ngày ấy."

Người nhận có thể là thầy cô ngày đi học, cấp trên cũ, một đồng nghiệp, hay một chuyên gia mình theo học qua sách. Gửi bằng tin nhắn, email hay một tấm thiệp tay đều được. Điều quan trọng là gửi ngay hôm nay.

**Một lưu ý khi chia sẻ**

Khi chia sẻ trong cộng đồng, có thể ghi vai trò thay cho tên người thật, ví dụ "trưởng phòng đầu tiên của tôi", để tôn trọng sự riêng tư của người được nhắc đến.

**Ngày 5 (25 phút)**

1. Ghi tên hoặc vai trò người có thể góp ý cho kỹ năng con, viết câu hỏi xin góp ý và gửi đi.
2. Ghi người thầy, người dẫn dắt mình muốn cảm ơn và điều người đó đã dạy mình.
3. Viết lời cảm ơn và gửi ngay hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-5.

Chia sẻ hôm nay: "Hôm nay tôi gửi lời cảm ơn đến ..., người đã dạy tôi .... Người tôi xin góp ý về ...: ...". Chúc các thầy cô và những người dẫn dắt trong cộng đồng mình một ngày 20.11 thật ấm áp nha.


## Bài 6: Ngày 6 (Thứ Bảy 21/11)
@img 6_bac-thang
@img2 9_the-thanh-tich
@pdf 10XHub_LuyenTap_PhieuNgay6_bac-thang.pdf (phiếu thực hành và bậc thang luyện tập 4 tuần để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: BỐN BẬC LUYỆN CHO BỐN TUẦN TỚI

Một tuần đủ để bắt đầu luyện một kỹ năng con, chưa đủ để giỏi lên. Hôm nay lập một bậc thang luyện tập cho bốn tuần tới, để kỹ năng con đi tiếp cùng thói quen then chốt khi cả nhóm sang công thức mới.

Bài viết đưa ra một bản mẫu hoàn chỉnh trước, rồi mới đến phần tự làm.

**Bản mẫu: trưởng nhóm kế toán luyện kỹ năng "trình bày số liệu trong một trang"**

Thói quen then chốt: rà báo cáo tài chính 20 phút mỗi sáng. Kỹ năng con: tóm tắt tình hình tài chính tháng trong một trang cho ban giám đốc. Mục tiêu sau bốn tuần: một trang, ba con số chính, đọc trong hai phút.

- **Bậc 1 (tuần 1):** chọn ba con số chính của tháng và viết mỗi con số kèm một câu giải thích. Phản hồi: so với bản tóm tắt mẫu.
- **Bậc 2 (tuần 2):** thêm một biểu đồ duy nhất cho xu hướng quan trọng nhất. Phản hồi: hỏi một đồng nghiệp không làm kế toán xem có hiểu ngay không.
- **Bậc 3 (tuần 3):** viết phần đề xuất hai dòng ở cuối trang. Phản hồi: nhờ kế toán trưởng góp ý một điều.
- **Bậc 4 (tuần 4):** làm trọn một trang trong 30 phút, gửi ban giám đốc. Phản hồi: ghi lại câu hỏi ban giám đốc đặt ra.

Mỗi bậc chỉ cao hơn bậc trước một chút. Mỗi bậc đều có một nguồn phản hồi rõ ràng. Và buổi luyện nằm ngay trong 20 phút thói quen buổi sáng, không cần thêm giờ.

**Nhịp luyện**

Ba buổi một tuần thường dễ giữ hơn mỗi ngày, vì còn chỗ cho ngày bận. Ai có thói quen then chốt gắn trực tiếp với kỹ năng con thì có thể luyện mỗi ngày làm việc. Ai lịch quá kín thì hai buổi một tuần vẫn tốt hơn không buổi nào.

**Bậc thang luyện tập in được**

Phiếu đính kèm có một trang bậc thang bốn tuần, mỗi bậc có ô mục tiêu, nguồn phản hồi và ô tích các buổi đã luyện. In ra và đặt cạnh tấm thẻ quy ước ăn ếch của tuần trước.

**Ngày 6 (25 phút)**

1. Đếm số buổi đã luyện trong tuần này.
2. Viết bốn bậc cho bốn tuần tới, mỗi bậc cao hơn bậc trước một chút.
3. Chọn nhịp luyện và ghi nguồn phản hồi cho từng bậc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0027-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi luyện ... buổi. Bậc tiếp theo: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Luyện tập có chủ đích hiện ra, hình bậc thang, ghi tên mình, số buổi đã luyện và kỹ năng con đang luyện. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

**Tuần sau**

Luyện một kỹ năng giúp mình giỏi hơn. Giảng lại điều mình đã học cho người khác giúp mình hiểu sâu hơn nữa. Tuần sau, Công thức #0028 về Kỹ thuật Feynman mời cả nhóm chọn một điều đã học trong hành trình và giải thích nó bằng lời đơn giản cho một đồng nghiệp mới vào nghề.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Thói quen then chốt cũng được nghỉ, chuỗi ngày không bị tính là lỡ.
