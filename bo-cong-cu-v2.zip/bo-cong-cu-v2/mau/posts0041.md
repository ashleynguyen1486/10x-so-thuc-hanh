## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 22/02)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0041_So Dau Dong_VN.pdf (tài liệu đầy đủ của Công thức #0041)
@pdf 10XHub_SoDauDong_PhieuNgay1_dung-so.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0041.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỞ TUẦN #0041: MỘT CUỐN SỔ ĐỂ KHÔNG RƠI MẤT VIỆC

Tuần trước, cả nhóm đã khởi động lại thói quen then chốt sau kỳ nghỉ Tết, lập lịch ôn cách quãng cho những công thức đã học từ đầu hành trình, và khép tuần đúng dịp Rằm tháng Giêng. Từ tuần này, các bước nhỏ của năm mục tiêu bắt đầu nhiều lên, xen giữa họp hành và việc phát sinh, nên cũng dễ rơi mất nhất.

Công thức #0041 của tuần này là Sổ đầu dòng, tên gốc là Bullet Journal, phương pháp ghi chép do Ryder Carroll xây dựng.

**Nếu mới tham gia:** tuần này rất dễ bắt đầu, vì việc đầu tiên chỉ là chọn một nơi ghi chép. Hôm nay mở sổ thực hành, viết một thói quen then chốt trong công việc mà mình muốn giữ (ví dụ: mỗi sáng ghi nhanh các việc trong ngày trước khi mở hộp thư), rồi làm bài Ngày 1 cùng mọi người. Chưa có năm mục tiêu cũng không sao: đến Ngày 3, chỉ cần một mục tiêu quan trọng nhất của quý này là đủ.

**Đọc thử một trang sổ**

Trước khi nói về phương pháp, hãy đọc một trang sổ minh hoạ. Người ghi là một trưởng nhóm mua hàng, trong buổi sáng Thứ Hai:

*Trang 14. Thứ Hai 22.02*

**X** Viết ba việc quan trọng nhất trước 8 giờ

**○** 9:00 họp giao ban đầu tuần

**•** Gửi bảng so sánh ba nhà cung cấp cho trưởng phòng

**✱ •** Chốt số lượng đặt hàng quý 2 (mục tiêu số 1)

**-** Nhà cung cấp B báo giá tăng từ tháng 4

**>** Soạn quy trình nhận hàng mới

Dòng đầu có chữ **X**: thói quen then chốt đã làm xong. Vòng tròn **○** là một sự kiện gắn với ngày giờ. Dấu chấm **•** là một việc cần làm. Dấu sao **✱** đặt trước dấu chấm đánh dấu việc ưu tiên, ở đây là một bước của mục tiêu số 1. Gạch ngắn **-** là ghi chú: thông tin cần nhớ, chưa phải là việc. Dấu **>** là việc đã được chuyển sang ngày khác.

Mỗi dòng là một ý, viết trong vài giây, không trang trí. Đến cuối ngày, trang này cho biết việc nào đã xong, việc nào còn treo, và thông tin gì mới cần nhớ.

**Phương pháp này từ đâu ra?**

Ryder Carroll là một nhà thiết kế sản phẩm số. Theo lời kể của chính ông, ông tự xây dựng cách ghi chép này từ những năm đại học để quản lý sự chú ý của mình, rồi chia sẻ công khai vào năm 2013. Năm 2018, ông viết lại toàn bộ phương pháp trong cuốn "The Bullet Journal Method", với lời đề sách có thể tạm dịch là: ghi lại quá khứ, sắp xếp hiện tại, thiết kế tương lai.

Phương pháp gồm bốn phần chính: trang chỉ mục, trang tương lai, nhật ký tháng và nhật ký ngày, cùng một bước đặc trưng là "chuyển việc" vào cuối mỗi tháng.

Một điểm cần nói rõ: Sổ đầu dòng là một phương pháp thực hành, chưa có nghiên cứu khoa học nào đánh giá riêng phương pháp này. Phần nền khoa học gần nhất là các nghiên cứu về việc ghi ra kế hoạch cho những mục tiêu còn dang dở, được trình bày trong tài liệu PDF của tuần.

**Vì sao tuần này cần một cuốn sổ?**

Năm mục tiêu đã có từ tuần Quy tắc 5/25, và tuần Bảng Kanban cá nhân đã chia các mục tiêu thành từng bước nhỏ. Nhưng trong một ngày làm việc thật, các bước ấy cạnh tranh với rất nhiều điều khác. Sổ đầu dòng giữ tất cả ở một chỗ, để cuối tháng nhìn lại được mọi bước đã đi và chưa đi. Sổ không phụ thuộc vào giấy hay ứng dụng.

**Sáu ngày của tuần**

- Thứ Hai: dựng sổ, chọn nơi ghi, trang chỉ mục, bảng ký hiệu.
- Thứ Ba: ghi nhanh cả ngày bằng ba ký hiệu.
- Thứ Tư: nhật ký tháng 3 trên hai trang.
- Thứ Năm: trang tương lai cho các tháng còn lại của năm.
- Thứ Sáu: một trang riêng cho mục tiêu số 1.
- Thứ Bảy: lần chuyển việc đầu tiên, đúng dịp cuối tháng 2.

Chủ Nhật nghỉ.

**Ngày 1 (25 phút): Dựng sổ**

1. Chọn một nơi ghi duy nhất cho công việc: sổ giấy, ứng dụng ghi chú hay tệp trên máy tính. Ghi lựa chọn vào sổ thực hành.
2. Nếu dùng sổ giấy, đánh số trang và để trống hai trang đầu làm trang chỉ mục. Nếu dùng ứng dụng, tạo một ghi chú tên là "Chỉ mục".
3. Chép bảng ký hiệu (có sẵn trên phiếu Ngày 1) vào trang trong bìa hoặc đầu tệp.
4. Mở trang đầu tiên, ghi ngày hôm nay. Dòng đầu là thói quen then chốt. Từ giờ đến hết ngày, ghi nhanh mọi việc, sự kiện, ghi chú phát sinh. Cuối ngày chọn dòng quan trọng nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-1.

Chia sẻ hôm nay: "Tôi ghi sổ đầu dòng ở .... Dòng quan trọng nhất hôm nay: ...".

Không cần một cuốn sổ đẹp, các anh chị và các bạn cứ bắt đầu với cuốn sổ hoặc ứng dụng đang có sẵn nha.


## Bài 2: Ngày 2 (Thứ Ba 23/02)
@img 2_ghi-nhanh
@pdf 10XHub_SoDauDong_PhieuNgay2_ghi-nhanh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: GHI NHANH, BA KÝ HIỆU LÀ ĐỦ

Phần lõi của Sổ đầu dòng là ghi nhanh: mỗi dòng một ý, đầu dòng là một ký hiệu cho biết đó là việc, sự kiện hay ghi chú. Nghe thì đơn giản, nhưng khi bắt tay vào làm, rất nhiều người vấp phải cùng một vài hiểu lầm. Hôm nay đi qua năm hiểu lầm thường gặp nhất, mỗi hiểu lầm kèm cách hiểu đúng.

**Hiểu lầm 1: ghi sổ là phải viết đầy đủ, rõ câu**

Cách hiểu đúng: ghi nhanh cần ngắn. "Gọi chị Hoa, xác nhận lịch giao hàng 05.03" là đủ, không cần viết thành một đoạn văn. Carroll nhấn mạnh rằng mục đích là giữ ý, không phải viết đẹp. Câu càng ngắn, mình càng dễ ghi ngay khi việc phát sinh, kể cả giữa một cuộc họp.

**Hiểu lầm 2: phải có cuốn sổ đẹp và biết trang trí**

Cách hiểu đúng: trên mạng có rất nhiều hình ảnh sổ đầu dòng được vẽ màu, dán hình công phu. Đó là lựa chọn của người thích trang trí, không phải yêu cầu của phương pháp. Phương pháp gốc chỉ cần một cuốn sổ có số trang, một cây bút, hoặc một tệp ghi chú. Với người đi làm, một trang ghi gọn gàng thường hữu ích hơn một trang được trang trí kỹ.

**Hiểu lầm 3: ghi mọi điều vào thì sổ sẽ rối**

Cách hiểu đúng: sổ rối khi mọi dòng trông giống nhau. Ba ký hiệu giải quyết chuyện này. Dấu chấm (•) là việc cần làm. Vòng tròn (○) là sự kiện có ngày giờ: cuộc họp, buổi gặp khách hàng, hạn nộp báo cáo. Gạch ngắn (-) là ghi chú: thông tin cần nhớ, ý tưởng, điều khách hàng vừa nói. Khi đọc lại, mắt chỉ cần tìm ký hiệu là lọc được loại dòng cần xem.

**Hiểu lầm 4: ghi xong là xong**

Cách hiểu đúng: giá trị của trang sổ đến khi đọc lại. Cuối ngày, dành năm phút đi qua từng dấu chấm và đổi trạng thái: việc đã xong thì đánh **X** đè lên dấu chấm; việc chuyển sang ngày khác thì đổi thành **>**; việc đã lên lịch cho một tháng sau thì đổi thành **<** và ghi vào trang tương lai (sẽ làm ở Ngày 4); việc không còn cần làm nữa thì gạch ngang cả dòng. Năm phút này giúp mình biết chính xác ngày làm việc đã đi đến đâu.

**Hiểu lầm 5: sổ là một thói quen mới, tách khỏi thói quen then chốt**

Cách hiểu đúng: sổ là nơi giữ thói quen then chốt. Dòng đầu tiên của mỗi trang ngày là thói quen đang giữ. Khi làm xong, đánh X. Nhờ vậy, sau một tháng, chỉ cần lật lại các trang là thấy ngay chuỗi ngày đã giữ, bên cạnh bảng hành trình trên sổ thực hành.

**Ngày 2 (20 phút, chia thành nhiều lần trong ngày)**

1. Sáng: mở trang mới, ghi ngày, dòng đầu là thói quen then chốt.
2. Trong ngày: mỗi khi có việc, sự kiện hay ghi chú phát sinh, ghi ngay một dòng với đúng ký hiệu.
3. Cuối ngày: đổi trạng thái cho từng dấu chấm, rồi đếm số việc, sự kiện, ghi chú và số việc đã xong, nhập vào sổ thực hành.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-2.

Chia sẻ hôm nay: "Hôm nay tôi ghi nhanh ... việc, ... sự kiện và ... ghi chú; ... việc đã đánh dấu X.".

Ngày đầu ghi nhanh, nhiều người thấy mình quên ghi vào buổi chiều. Điều đó rất bình thường, sáng mai chỉ cần ghi tiếp nha.


## Bài 3: Ngày 3 (Thứ Tư 24/02)
@img 3_nhat-ky-thang
@pdf 10XHub_SoDauDong_PhieuNgay3_nhat-ky-thang.pdf (phiếu thực hành và trang nhật ký tháng 3 in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NHẬT KÝ THÁNG 3 TRÊN HAI TRANG

Tháng 2 chỉ còn bốn ngày. Thay vì dựng nhật ký cho tháng sắp hết, hôm nay dựng luôn cho tháng 3, tháng khép lại quý 1 của năm 2027. Bài hôm nay đi theo dạng một buổi làm việc 30 phút, chia theo từng mốc phút. Các anh chị và các bạn có thể đặt đồng hồ và làm theo.

**Phút 0 đến 3: mở hai trang trống**

Trang bên trái là lịch tháng. Trang bên phải là danh sách việc của tháng. Nếu dùng ứng dụng, tạo một ghi chú tên "Tháng 3 năm 2027" và chia thành hai phần với hai tiêu đề.

**Phút 3 đến 10: trang lịch**

Viết dọc xuống mép trái các ngày từ 1 đến 31, bên cạnh mỗi ngày ghi gọn ngày trong tuần: T2, T3, T4, T5, T6, T7, CN. Tháng 3 năm 2027 bắt đầu vào Thứ Hai, nên rất dễ viết. Sau đó ghi các sự kiện đã biết vào đúng dòng: cuộc họp định kỳ, hạn nộp báo cáo tháng, buổi gặp khách hàng đã hẹn. Hai mốc nên có: Thứ Hai 08.03 là Ngày Quốc tế Phụ nữ, và Thứ Tư 31.03 là ngày khép quý 1.

Trang lịch chỉ ghi những điều đã chắc chắn có ngày. Đừng biến nó thành danh sách việc.

**Phút 10 đến 20: trang việc**

Đây là phần quan trọng nhất. Sổ thực hành hiện lại năm mục tiêu đã chọn ở tuần Quy tắc 5/25. Với mỗi mục tiêu, viết ít nhất một việc cần làm trong tháng 3, bắt đầu bằng dấu chấm. Ví dụ với mục tiêu "chốt sổ tháng trong 3 ngày làm việc" của một kế toán tổng hợp: "• Chuẩn hoá mẫu đối chiếu công nợ với 5 khách hàng lớn". Sau đó thêm các việc khác của tháng đã biết: báo cáo, dự án đang chạy, việc cấp trên giao.

**Phút 20 đến 25: chọn việc quan trọng nhất của tháng**

Trong các việc của mục tiêu số 1, chọn một việc mà nếu hết tháng 3 chỉ làm được một việc, mình vẫn thấy tháng này đã đi đúng hướng. Đánh dấu sao (✱) trước dòng đó. Đây cũng là việc sẽ xuất hiện trong câu chia sẻ hôm nay.

**Phút 25 đến 30: ghi chỉ mục và bảng hành trình**

Mở trang chỉ mục, ghi một dòng: "Tháng 3: trang ...". Sau đó vào sổ thực hành, đánh dấu những ngày tuần này đã làm thói quen then chốt trên bảng hành trình. Bảng hành trình tuần này nằm ở Ngày 3.

**Một lưu ý về số lượng việc**

Trang việc của tháng thường dài hơn khả năng thực tế của một tháng. Không sao cả: nhật ký tháng không phải lời hứa sẽ làm hết. Nó là bản đồ để mỗi sáng chọn việc cho trang ngày. Cuối tháng, bước chuyển việc sẽ giúp lọc lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-3.

Chia sẻ hôm nay: "Nhật ký tháng 3 của tôi đã sẵn sàng. Việc quan trọng nhất của tháng cho mục tiêu số 1: ...".

Phiếu Ngày 3 có sẵn một trang nhật ký tháng 3 để in, ai thích viết tay thì dùng luôn nha.


## Bài 4: Ngày 4 (Thứ Năm 25/02)
@img 4_trang-tuong-lai
@pdf 10XHub_SoDauDong_PhieuNgay4_trang-tuong-lai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: TRANG TƯƠNG LAI CHO CÁC THÁNG CÒN LẠI

**Một tình huống minh hoạ**

Chị Ngọc là kế toán tổng hợp ở một công ty phân phối. Mục tiêu số 2 của chị năm nay là "hoàn thành một chứng chỉ chuyên môn về kế toán quản trị". Đầu tháng 1, chị đã tìm hiểu kỹ: kỳ thi tổ chức vào tháng 10, cần đăng ký trước tháng 8, và nên học xong phần lý thuyết trước tháng 6.

Tất cả những thông tin này nằm trong một tin nhắn chị tự gửi cho mình. Đến giữa tháng 2, tin nhắn đó đã trôi xuống dưới hàng trăm tin nhắn khác. Chị nhớ là có hạn đăng ký, nhưng không nhớ chính xác là tháng nào.

Chị Ngọc không quên mục tiêu. Chị chỉ không có một chỗ để đặt những điều thuộc về các tháng sau.

Trong Sổ đầu dòng, chỗ đó là trang tương lai. Đây là hai trang chia thành các ô theo tháng, dành cho những sự kiện và việc chưa thuộc về tháng này. Nếu có trang tương lai, chị Ngọc chỉ cần ghi ba dòng: tháng 6 "• Học xong phần lý thuyết"; tháng 8 "○ Hạn đăng ký thi"; tháng 10 "○ Ngày thi chứng chỉ".

Tình huống trên là minh hoạ, nhưng chuyện thông tin quan trọng trôi mất trong hộp thư hay tin nhắn thì gần như ai cũng từng gặp.

**Ba điều rút ra từ tình huống của chị Ngọc**

1. **Mục tiêu năm cần có chỗ đứng trong từng tháng.** Năm mục tiêu nằm trên thẻ mục tiêu. Nhưng các mốc của chúng rải ra suốt năm. Trang tương lai là nơi các mốc ấy được nhìn thấy cùng nhau.
2. **Trang tương lai nối với nhật ký tháng.** Đầu mỗi tháng, khi dựng nhật ký tháng mới, mở trang tương lai, chép những dòng của tháng đó sang. Nhờ vậy, việc đăng ký thi tháng 8 sẽ tự xuất hiện trong nhật ký tháng 8, đúng lúc cần làm.
3. **Dấu < có nơi để đến.** Hôm Thứ Ba, việc nào lên lịch cho tháng sau thì đổi dấu chấm thành dấu <. Hôm nay, mọi dòng mang dấu < đều được chép vào đúng ô tháng trên trang tương lai.

**Cách dựng trang tương lai cho năm 2027**

Chia hai trang thành chín ô cho tháng 4 đến tháng 12. Quý 1 đã có nhật ký tháng 3 nên không cần ô riêng. Với mỗi mục tiêu trong năm mục tiêu, tự hỏi: mốc tiếp theo của mục tiêu này rơi vào tháng nào? Ghi mốc đó vào ô tháng tương ứng. Thêm các sự kiện cả năm đã biết: kỳ đánh giá giữa năm, mùa cao điểm của ngành, kỳ nghỉ dài.

**Ngày 4 (25 phút)**

1. Dựng chín ô tháng 4 đến tháng 12 trên hai trang, hoặc chín tiêu đề trong tệp ghi chú.
2. Ghi ít nhất một mốc cho mỗi mục tiêu vào đúng tháng.
3. Chép các dòng mang dấu < của Thứ Ba và Thứ Tư sang.
4. Ghi trang tương lai vào trang chỉ mục.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-4.

Chia sẻ hôm nay: "Trang tương lai của tôi đã có mốc cho cả năm mục tiêu. Mốc xa nhất: ...".


## Bài 5: Ngày 5 (Thứ Sáu 26/02)
@img 5_trang-muc-tieu
@pdf 10XHub_SoDauDong_PhieuNgay5_trang-muc-tieu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MỤC TIÊU SỐ 1 CÓ MỘT TRANG RIÊNG

Ngoài bốn phần chính, Sổ đầu dòng còn có các trang riêng cho một chủ đề, Carroll gọi là bộ sưu tập. Một dự án, một danh sách sách cần đọc, một danh sách câu hỏi cho buổi đánh giá với cấp trên đều có thể là một bộ sưu tập. Hôm nay mỗi người dành một trang riêng cho mục tiêu số 1.

Bài hôm nay là một danh sách kiểm. Một trang mục tiêu dùng tốt thường có đủ bảy điều dưới đây. Đọc từng điều, làm xong thì đánh dấu.

**Bảy điều một trang mục tiêu nên có**

1. **Tên mục tiêu viết đầy đủ ở đầu trang.** Chép đúng câu đã viết ở tuần Quy tắc 5/25, kể cả con số và thời hạn. Mỗi lần mở trang là một lần đọc lại mục tiêu.

2. **Một dòng "vì sao".** Một câu ngắn cho biết mục tiêu này quan trọng với công việc của mình ở điểm nào. Ví dụ của một trưởng nhóm chăm sóc khách hàng: "Trả lời khiếu nại trong 24 giờ, vì nhóm đang mất dần khách hàng cũ do phản hồi chậm."

3. **Các mốc của quý.** Chép các mốc tháng đã đặt cho mục tiêu số 1. Mốc nào đã qua thì đánh X hoặc ghi kết quả thật bên cạnh.

4. **Danh sách các bước tiếp theo.** Ba đến năm bước cụ thể, mỗi bước một dấu chấm. Khi bước nào được đưa vào trang ngày để làm, đánh dấu > bên cạnh để biết nó đã có chỗ.

5. **Một chỗ cho ghi chú.** Những điều học được, câu hỏi chưa có lời giải, ý kiến của đồng nghiệp. Dùng gạch ngắn, giống như trong trang ngày.

6. **Số trang trong chỉ mục.** Ghi "Mục tiêu số 1: trang ..." vào trang chỉ mục. Không có dòng này, trang mục tiêu rất dễ bị lạc giữa các trang ngày.

7. **Một mốc xem lại.** Ghi ngày sẽ mở lại trang này để cập nhật. Gợi ý: cùng ngày chuyển việc cuối tháng sẽ đặt vào ngày mai.

**Chọn kiểu trang phù hợp**

Không phải mục tiêu nào cũng hợp với cùng một kiểu trang. Sổ thực hành có ba lựa chọn:

- **Danh sách bước:** hợp với mục tiêu có trình tự rõ, như hoàn thành một chứng chỉ, triển khai một quy trình mới.
- **Nhật ký tiến độ:** hợp với mục tiêu đo bằng con số theo tuần, như số khách hàng mới, thời gian xử lý khiếu nại. Mỗi tuần ghi một dòng con số và một dòng nhận xét.
- **Danh sách câu hỏi:** hợp với mục tiêu còn mơ hồ ở cách làm, như cải thiện phối hợp giữa hai bộ phận. Mỗi câu hỏi tìm được lời giải sẽ trở thành một bước.

Nếu dùng ứng dụng, trang mục tiêu là một ghi chú riêng, đặt tên bắt đầu bằng "Mục tiêu số 1" để dễ tìm.

**Ngày 5 (20 phút)**

1. Chọn kiểu trang trên sổ thực hành.
2. Dựng trang mục tiêu số 1 theo bảy điều trên.
3. Ghi số trang vào chỉ mục.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-5.

Chia sẻ hôm nay: "Mục tiêu số 1 của tôi đã có trang riêng kiểu ..., ghi ở trang ... trong chỉ mục.".


## Bài 6: Ngày 6 (Thứ Bảy 27/02)
@img 6_chuyen-viec
@img2 9_the-thanh-tich
@pdf 10XHub_SoDauDong_PhieuNgay6_chuyen-viec.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: LẦN CHUYỂN VIỆC ĐẦU TIÊN CUỐI THÁNG 2

Hôm nay là Thứ Bảy cuối cùng của tháng 2. Đây là thời điểm rất đúng để làm bước đặc trưng nhất của Sổ đầu dòng: chuyển việc.

Cách làm rất đơn giản. Lật lại các trang của tuần, tìm mọi dấu chấm chưa có X. Với từng việc, chọn một trong ba hướng. Bài hôm nay viết theo dạng một bảng chọn, để đọc xong là làm được ngay.

**Hướng 1: chuyển sang tháng 3 (dấu >)**

Chọn hướng này khi: việc vẫn còn cần làm, và nên làm trong tháng tới.

Cách làm: đổi dấu chấm thành dấu >, rồi chép lại việc vào trang việc của nhật ký tháng 3.

Ví dụ: "Soạn quy trình nhận hàng mới" của trưởng nhóm mua hàng ở bài Thứ Hai. Việc này gắn với mục tiêu quý 1, phải xong trước 31.03.

**Hướng 2: lên lịch cho tháng sau nữa (dấu <)**

Chọn hướng này khi: việc vẫn cần, nhưng thời điểm phù hợp là từ tháng 4 trở đi.

Cách làm: đổi dấu chấm thành dấu <, chép việc vào đúng ô tháng trên trang tương lai.

Ví dụ: "Tìm hiểu khoá học phân tích dữ liệu", để sang quý 2, khi mục tiêu quý 1 đã xong.

**Hướng 3: gạch bỏ**

Chọn hướng này khi: việc không còn cần làm nữa, hoặc thật ra không đáng làm.

Cách làm: gạch ngang cả dòng. Không cần chép đi đâu cả.

Ví dụ: "Thiết kế lại mẫu báo cáo tuần cho đẹp hơn", một việc đã nằm đó ba tuần mà không ai hỏi đến.

**Vì sao phải chép tay lại?**

Đây là câu hỏi hay gặp nhất. Chuyển một việc sang trang mới bằng cách viết lại tốn công hơn một cú bấm trên ứng dụng. Theo Carroll, chính sự tốn công đó là điểm mấu chốt: nếu một việc không đáng để mất vài giây viết lại, có lẽ nó cũng không đáng để mất vài giờ làm. Dùng ứng dụng thì vẫn giữ tinh thần này được: đừng kéo thả hàng loạt, hãy đọc từng dòng và tự hỏi việc này còn đáng làm không.

Lần chuyển việc đầu tiên thường cho thấy một điều thú vị: có không ít việc đã nằm trong danh sách rất lâu chỉ vì chưa ai quyết định bỏ nó đi.

**Ngày chuyển việc mỗi tháng**

Bước chuyển việc chỉ phát huy khi thành nhịp đều đặn. Hôm nay chọn ngày chuyển việc cố định hằng tháng và ghi vào sổ thực hành. Gợi ý: Thứ Bảy cuối cùng của tháng, hoặc ngày làm việc cuối cùng của tháng. Ngày này được lưu cho cả hành trình.

**Tuần sau: Quy luật Parkinson và hộp thời gian**

Tuần này, các bước của năm mục tiêu đã có chỗ đứng trong sổ. Tuần sau, Công thức #0042 Quy luật Parkinson và hộp thời gian, bắt đầu Thứ Hai 01.03, đặt cho mỗi bước một khoảng thời gian cụ thể trên lịch, để việc không kéo dài ra chiếm hết thời gian có được.

**Ngày 6 (30 phút)**

1. Lật lại các trang của tuần, tìm mọi việc chưa xong.
2. Với từng việc: chuyển (>), lên lịch (<) hay gạch bỏ.
3. Đếm số việc theo ba hướng, nhập vào sổ thực hành.
4. Chọn ngày chuyển việc hằng tháng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0041-ngay-6.

Chia sẻ hôm nay: "Lần chuyển việc đầu tiên của tôi: ... việc chuyển sang tháng 3, ... việc lên lịch, ... việc gạch bỏ. Ngày chuyển việc hằng tháng: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần Sổ đầu dòng hiện ra: con số 6/6, sáu cột của các ngày đã làm thói quen trong tuần, tên mình, nơi ghi sổ và ngày chuyển việc hằng tháng. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tháng 2 khép lại với một cuốn sổ đã có đủ chỗ cho năm mục tiêu.
