## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 03/05)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0051_Cung Dien Tri Nho_VN.pdf (tài liệu đầy đủ của Công thức #0051)
@pdf 10XHub_CungDienTriNho_PhieuNgay1_chon-cung-dien.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0051.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** CUNG ĐIỆN TRÍ NHỚ: NHỚ Ý CHÍNH BẰNG NƠI QUEN THUỘC

Kỳ nghỉ lễ đã khép lại, và sáng nay cả nhóm quay về nhịp làm việc quen thuộc. Tuần trước, giữa những ngày nghỉ, cả nhóm đã kiểm kê bộ kỹ năng, tìm kỹ năng nền và kỹ năng ít gặp, vẽ chữ T của mình và viết một bộ ba kỹ năng: kỹ năng nền, kỹ năng hỗ trợ và kỹ năng đang học, kèm câu trả lời "giá trị cho ai". Bộ ba đó đã được lưu trên sổ thực hành, và tuần này nó sẽ giúp chọn điều cần nhớ.

Công thức #0051 của tuần là Cung điện trí nhớ.

**Nếu mới tham gia:** tuần này bắt đầu rất dễ, vì công cụ chính là một nơi mình đã thuộc lòng, như văn phòng hay đường từ cổng công ty vào bàn làm việc. Ở Ngày 1 trên sổ thực hành, hãy viết một thói quen nhỏ mình muốn giữ mỗi ngày, một kỹ năng muốn học thêm cho công việc, rồi làm theo các bước bên dưới. Không cần đọc lại các tuần trước.

**Một câu chuyện từ hơn hai nghìn năm trước**

Trong cuốn "De Oratore" (Bàn về nhà hùng biện), viết năm 55 trước Công nguyên, Cicero kể lại một câu chuyện về nhà thơ Hy Lạp Simonides xứ Ceos.

Simonides được mời đến đọc thơ tại một bữa tiệc lớn do một nhà quý tộc tên Scopas tổ chức. Giữa tiệc, ông được báo có hai người đang chờ gặp ở ngoài cửa. Ông bước ra, không thấy ai. Đúng lúc đó, mái của phòng tiệc đổ sập. Mọi người bên trong đều thiệt mạng, và thi thể không còn nhận ra được.

Khi người thân đến tìm, Simonides giúp họ theo một cách không ai ngờ. Ông nhớ lại từng chỗ ngồi quanh bàn tiệc, người nào ngồi ở đâu, và từ vị trí đó chỉ ra từng người. Theo lời Cicero, chính trải nghiệm này giúp Simonides nhận ra một điều: trí nhớ bám rất chắc vào vị trí. Nếu đặt những điều cần nhớ vào các vị trí theo một thứ tự cố định, chỉ cần đi lại các vị trí đó trong đầu là lấy lại được nội dung theo đúng thứ tự.

Câu chuyện mang màu sắc truyền thuyết, và chi tiết có thể đã được kể lại nhiều lần. Nhưng phương pháp đi kèm thì có thật và được ghi chép rõ: các nhà hùng biện La Mã dùng nó để nhớ những bài nói dài mà không cần giấy. Ngày nay nó được gọi là phương pháp định vị, hay quen thuộc hơn là cung điện trí nhớ.

**Vì sao cần nó trong công việc?**

Ngày làm việc đầy những điều cần nhớ theo thứ tự: năm ý chính của một bài trình bày, bảy bước của một quy trình, bốn con số cần nói trong cuộc họp giao ban. Ghi chú vẫn cần, nhưng có những lúc không tiện nhìn: khi đang đứng trước khách hàng, khi trả lời câu hỏi của cấp trên ngay trong cuộc họp, khi hướng dẫn đồng nghiệp tại hiện trường.

Hai tuần #0048 và #0049 đã đưa truy hồi chủ động và trang Cornell vào 20 phút học. Tuần này thêm một lớp nữa: một cách sắp xếp để nhớ các ý chính theo thứ tự, và mỗi lần đi lại cung điện trong đầu cũng chính là một lần tự kiểm tra.

**Sáu ngày của tuần**

- Thứ Hai: chọn cung điện và các điểm dừng.
- Thứ Ba: chọn điều cần nhớ cho công việc.
- Thứ Tư: biến ý thành hình ảnh, đặt vào ba điểm đầu.
- Thứ Năm: đặt đủ các ý, đi một vòng.
- Thứ Sáu: dùng cung điện trong một việc thật.
- Thứ Bảy: đi lại sau vài ngày, khép tuần.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Chọn cung điện và các điểm dừng**

Sáng nay, ngày đầu quay lại sau kỳ nghỉ, việc đầu tiên vẫn là thói quen then chốt ở đúng khung giờ cũ. Sau đó:

1. Chọn một nơi mình biết rất rõ, đi lại hằng ngày: văn phòng, đường từ bãi gửi xe vào bàn làm việc, hay chính căn hộ của mình.
2. Nhắm mắt, đi một vòng trong đầu theo một hướng cố định, như cách mình vẫn đi thật.
3. Chọn bảy điểm dừng dễ nhận ra trên đường đi, ví dụ cổng bảo vệ, quầy lễ tân, thang máy, máy in, cửa phòng họp, bàn trưởng phòng, bàn làm việc của mình.
4. Viết bảy điểm dừng theo đúng thứ tự.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-1.

Chia sẻ hôm nay: "Cung điện trí nhớ đầu tiên của tôi: ..., ... điểm dừng.".

Chọn nơi càng quen thì càng dễ, các anh chị và các bạn đừng chọn một nơi mới đến lần đầu nha. Và nếu sáng nay thói quen chưa vào nhịp sau kỳ nghỉ, chỉ cần làm phiên bản nhỏ, ngày mai sẽ trơn tru hơn.


## Bài 2: Ngày 2 (Thứ Ba 04/05)
@img 2_dieu-can-nho
@pdf 10XHub_CungDienTriNho_PhieuNgay2_dieu-can-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CHỌN ĐIỀU CẦN NHỚ CHO CÔNG VIỆC

Cung điện đã có. Hôm nay chọn điều sẽ đặt vào đó. Bài hôm nay là một bảng chọn: bốn loại nội dung hay gặp trong công việc, mỗi loại có dấu hiệu nhận biết và một ví dụ. Mỗi người chỉ chọn một loại cho tuần này.

**Lựa chọn A: Ý chính của một bài trình bày**

- Hợp khi: tuần này hoặc tuần sau có một buổi trình bày, báo cáo, hay một cuộc gọi quan trọng với khách hàng.
- Dấu hiệu: có từ 4 đến 7 ý, nói theo một thứ tự, và mình muốn nói mà không phải nhìn trang chiếu liên tục.
- Ví dụ: một trưởng nhóm kinh doanh có 5 ý cho buổi báo cáo quý: kết quả, ba khách hàng lớn, vướng mắc giao hàng, kế hoạch tháng 6, đề xuất.

**Lựa chọn B: Các bước của một quy trình**

- Hợp khi: đang học một quy trình mới, hoặc sắp hướng dẫn quy trình cho người khác.
- Dấu hiệu: thứ tự các bước quan trọng, bỏ sót một bước là có lỗi.
- Ví dụ: một chuyên viên nhân sự nhớ 7 bước tiếp nhận nhân viên mới, từ chuẩn bị chỗ ngồi đến buổi trao đổi cuối tuần đầu tiên.

**Lựa chọn C: Một nhóm số liệu cần dùng thường xuyên**

- Hợp khi: hay bị hỏi số liệu bất ngờ trong cuộc họp hoặc khi làm việc với khách hàng.
- Dấu hiệu: có vài con số then chốt, cần nói đúng, không nhiều hơn 7.
- Ví dụ: một kỹ sư chất lượng nhớ tỷ lệ lỗi của 5 dây chuyền trong tháng.

**Lựa chọn D: Kiến thức của kỹ năng đang học**

- Hợp khi: kỹ năng đang học từ #0047 có một danh sách cần thuộc: các nguyên tắc, các hàm, các thuật ngữ.
- Dấu hiệu: đã có trang Cornell cho phần này, nhưng vẫn hay quên thứ tự hoặc quên mất một mục.
- Ví dụ: một kế toán học phân tích dữ liệu nhớ 6 hàm bảng tính hay dùng nhất cho dữ liệu công nợ.

**Cách chọn nhanh**

Nếu tuần này có một việc thật sắp diễn ra (buổi trình bày, cuộc họp, buổi hướng dẫn), hãy chọn nội dung cho việc đó. Một cung điện được dùng ngay trong việc thật sẽ cho cảm nhận rõ hơn nhiều so với một bài tập. Nếu chưa có việc nào sắp tới, chọn D để gắn với 20 phút học và bộ ba kỹ năng của tuần trước.

Một lưu ý: nội dung chọn hôm nay nên là các ý đã hiểu. Cung điện trí nhớ giúp nhớ thứ tự và không bỏ sót, không thay cho việc hiểu nội dung.

**Ngày 2 (20 phút)**

1. Chọn một loại nội dung: A, B, C hoặc D.
2. Viết tên nội dung cụ thể, ví dụ "báo cáo quý cho ban giám đốc ngày 07.05".
3. Viết các ý cần nhớ theo đúng thứ tự, mỗi ý vài chữ, tối đa bằng số điểm dừng.
4. Đánh dấu bảng hành trình những ngày đã làm thói quen từ đầu tuần.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-2.

Chia sẻ hôm nay: "Điều tôi sẽ đặt vào cung điện trí nhớ: ... (...).".

Nếu là số liệu nội bộ hay thông tin khách hàng, các anh chị và các bạn chỉ chia sẻ tên loại nội dung thôi nha, không cần nêu con số cụ thể.


## Bài 3: Ngày 3 (Thứ Tư 05/05)
@img 3_nguoi-nho-gioi
@pdf 10XHub_CungDienTriNho_PhieuNgay3_hinh-anh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NGƯỜI NHỚ GIỎI LÀM KHÁC Ở ĐÂU?

Hôm nay giải nghĩa một nghiên cứu, theo từng cụm từ, vì nó trả lời một câu hỏi nhiều người hay đặt ra: người nhớ giỏi có bộ não khác người không?

**"Người nhớ giỏi"**

Năm 2003, Eleanor Maguire và các cộng sự ở Đại học College London công bố trên tạp chí Nature Neuroscience một nghiên cứu về 10 người có thành tích trí nhớ rất cao, phần lớn từng tham gia các giải thi đấu trí nhớ. Họ được so sánh với một nhóm người bình thường có cùng độ tuổi và điều kiện.

**"Không khác về cấu trúc"**

Khi chụp cộng hưởng từ, nhóm nghiên cứu không tìm thấy khác biệt có ý nghĩa về cấu trúc não giữa người nhớ giỏi và nhóm đối chứng. Nói cách khác, họ không có một vùng não to hơn hay đặc biệt hơn.

**"Khác ở cách dùng"**

Khác biệt xuất hiện khi họ đang ghi nhớ. Ở người nhớ giỏi, các vùng não liên quan đến trí nhớ không gian và định hướng, trong đó có vùng hồi hải mã, hoạt động mạnh hơn. Đó là những vùng giúp mình nhớ đường đi và vị trí của đồ vật quanh mình.

**"Chín trên mười"**

Khi được hỏi họ làm thế nào, 9 trong 10 người nhớ giỏi cho biết đã dùng phương pháp định vị cho một phần hoặc toàn bộ bài kiểm tra. Họ đặt từng con số, từng khuôn mặt vào những vị trí trên một lộ trình quen thuộc.

**Điều nghiên cứu này nói, và chưa nói**

Nghiên cứu cho thấy thành tích trí nhớ cao gắn với một chiến lược, không gắn với một bộ não khác thường. Đó là tin tốt: chiến lược thì học được. Nhưng nghiên cứu có quy mô nhỏ, đo những bài kiểm tra trong phòng thí nghiệm như nhớ dãy số hay khuôn mặt, và không đo việc nhớ trong công việc. Hôm Thứ Bảy, một nghiên cứu khác năm 2017 sẽ trả lời câu hỏi "người bình thường luyện thì sao".

**Bí quyết của hình ảnh**

Điều người nhớ giỏi làm tại mỗi điểm dừng là đặt vào đó một hình ảnh cụ thể, sinh động, có chút bất thường, thay vì một chữ khô khan. Ví dụ, ý "ba khách hàng lớn" đặt ở quầy lễ tân có thể thành hình ảnh ba chiếc xe tải mang logo của ba khách hàng đang xếp hàng trước quầy. Hình ảnh càng có chuyển động, màu sắc, kích thước khác thường, càng dễ nhớ.

**Ngày 3 (20 phút)**

1. Xem lại bảy điểm dừng và các ý đã viết hôm qua.
2. Với ý 1, 2 và 3, nghĩ một hình ảnh cụ thể, có chuyển động hoặc chi tiết khác thường.
3. Đặt từng hình ảnh vào điểm dừng 1, 2 và 3, viết lại một dòng cho mỗi điểm.
4. Nhắm mắt, đi qua ba điểm đầu và gọi lại ba ý.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-3.

Chia sẻ hôm nay: "Điểm dừng đầu tiên, ..., giữ hình ảnh: ...".


## Bài 4: Ngày 4 (Thứ Năm 06/05)
@img 4_nam-diem-dung
@pdf 10XHub_CungDienTriNho_PhieuNgay4_di-mot-vong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: NĂM Ý TRÌNH BÀY, NĂM ĐIỂM DỪNG

Hôm nay mở đầu bằng một trang nhật ký minh hoạ. Anh Khoa là trưởng nhóm kinh doanh khu vực, có buổi báo cáo quý trước ban giám đốc vào sáng Thứ Sáu. Đây là ghi chép ba ngày của anh khi thử cung điện trí nhớ.

**Thứ Ba, 21 giờ**

Chọn cung điện là đường từ bãi gửi xe vào phòng họp lớn tầng 5, vì sáng Thứ Sáu mình sẽ đi đúng đường này trước khi trình bày. Năm điểm dừng: cổng bảo vệ, quầy lễ tân, thang máy, cửa kính tầng 5, bục trình bày. Năm ý: kết quả quý, ba khách hàng lớn, vướng mắc giao hàng, kế hoạch tháng 6, đề xuất thêm một nhân sự.

**Thứ Tư, 12 giờ 30**

Làm hình ảnh cho ba ý đầu. Cổng bảo vệ: anh bảo vệ cầm một tấm biển lớn ghi con số doanh thu quý, giơ lên chào mình. Quầy lễ tân: ba chiếc xe tải nhỏ mang logo ba khách hàng xếp hàng chờ ký sổ. Thang máy: cửa thang máy kẹt lại giữa chừng, đúng như những lô hàng giao chậm tháng trước. Đi thử trong đầu hai lần, nhớ đủ ba ý. Hình ảnh thang máy kẹt làm mình bật cười, chắc sẽ khó quên.

**Thứ Năm, 7 giờ 45**

Hai điểm còn lại. Cửa kính tầng 5: một tờ lịch tháng 6 dán to trên cửa, có năm ngày khoanh đỏ. Bục trình bày: một chiếc ghế trống đặt cạnh bục, chờ người mới. Nhắm mắt đi từ bãi xe vào, lần đầu quên mất ý thứ tư, lần thứ hai thì đủ năm. Thử nói thành lời theo đúng thứ tự trong 3 phút, không nhìn trang chiếu.

**Thứ Năm, 17 giờ**

Đi lại một lần nữa trên đường ra bãi xe, lần này là đi thật. Đến mỗi điểm, ý tự hiện ra. Ngày mai vẫn mang theo trang chiếu, nhưng nếu máy chiếu trục trặc thì mình vẫn nói được trọn vẹn.

Trang nhật ký trên là minh hoạ. Điều đáng chú ý là ba chi tiết anh Khoa làm: chọn cung điện gần với nơi sẽ dùng, làm hình ảnh có chút buồn cười hoặc bất thường, và đi lại nhiều lần ở những thời điểm khác nhau. Lần đầu quên một ý là chuyện bình thường; chính lần quên đó cho biết điểm dừng nào cần hình ảnh mạnh hơn.

**Ngày 4 (20 phút)**

1. Làm hình ảnh cho các ý còn lại, đặt vào các điểm dừng tiếp theo.
2. Nhắm mắt, đi một vòng từ điểm đầu đến điểm cuối, gọi lại từng ý.
3. Đếm số ý nhớ được ở lần đi đầu tiên.
4. Với ý bị quên, làm lại hình ảnh cho rõ hơn, rồi đi thêm một vòng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-4.

Chia sẻ hôm nay: "Đi một vòng cung điện, tôi nhớ được ... trên ... ý ngay lần đầu.".


## Bài 5: Ngày 5 (Thứ Sáu 07/05)
@img 5_hoi-dap
@pdf 10XHub_CungDienTriNho_PhieuNgay5_viec-that.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: DÙNG CUNG ĐIỆN TRONG MỘT VIỆC THẬT

Sau bốn ngày, câu hỏi về cung điện trí nhớ thường rất giống nhau. Hôm nay đi theo dạng hỏi đáp, trước khi đưa cung điện vào một việc thật.

**Hỏi: Đi lại cung điện có phải là một cách ôn bài không?**

Đáp: Có, và là một cách ôn tốt. Mỗi lần đi qua các điểm dừng và gọi lại ý, mình đang tự kiểm tra, đúng tinh thần truy hồi chủ động của #0048. Khác ở chỗ cung điện cho sẵn một trật tự để truy hồi theo, nên khó bỏ sót.

**Hỏi: Có cần vẫn ghi chép không?**

Đáp: Có. Trang Cornell của #0049 vẫn là nơi lưu nội dung đầy đủ. Cung điện giữ khung các ý chính theo thứ tự. Hai công cụ bổ sung cho nhau: trang Cornell để hiểu và lưu lại, cung điện để mang theo trong đầu.

**Hỏi: Một cung điện dùng được cho bao nhiêu nội dung?**

Đáp: Người mới nên dùng một cung điện cho một nội dung trong một thời gian, để hình ảnh cũ không lẫn với hình ảnh mới. Khi nội dung cũ đã thuộc, có thể dùng lại cung điện đó. Nếu cần nhớ song song hai nội dung, chọn thêm một cung điện thứ hai: ví dụ văn phòng cho bài trình bày, đường đi làm cho quy trình.

**Hỏi: Mình không giỏi tưởng tượng hình ảnh thì sao?**

Đáp: Hình ảnh không cần đẹp hay chi tiết. Chỉ cần đủ cụ thể để gắn với điểm dừng: một đồ vật, một hành động, một âm thanh. Nhiều người thấy hình ảnh có chút buồn cười hoặc phóng đại sẽ dễ nhớ hơn. Kỹ năng này cũng tiến bộ sau vài lần làm.

**Hỏi: Phương pháp này có hợp với mọi loại nội dung không?**

Đáp: Không. Nó hợp nhất với một danh sách các ý rời, cần nhớ theo thứ tự. Với kiến thức cần hiểu sâu, như lý do đằng sau một chuẩn mực kế toán hay nguyên lý của một hệ thống máy, cách giảng lại kiểu Feynman (#0028) và trang Cornell phù hợp hơn.

**Hỏi: Hôm nay "dùng trong việc thật" là thế nào?**

Đáp: Là đưa cung điện vào một việc có người khác: trình bày ý chính trong cuộc họp, hướng dẫn quy trình cho đồng nghiệp, trả lời câu hỏi về số liệu, hoặc ít nhất là nói thành lời trọn vẹn cho một người nghe. Nếu hôm nay chưa có dịp, có thể tự nói thành lời và tự bấm giờ.

**Ngày 5 (20 phút)**

1. Đi một vòng cung điện trước khi bắt đầu việc.
2. Dùng cung điện trong một việc thật, hoặc nói thành lời trọn vẹn cho một người nghe.
3. Ghi lại việc đã làm và chọn kết quả: đã dùng trong việc thật, đã nói thành lời, hay chưa có dịp.
4. Viết một điều sẽ điều chỉnh ở lần dùng sau.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-5.

Chia sẻ hôm nay: "Tôi đã dùng cung điện trí nhớ cho: .... Kết quả: ...".

Cuối tuần đầu tiên sau kỳ nghỉ thường khá dồn việc, các anh chị và các bạn nhớ khép lại những việc dở trước khi tắt máy chiều nay nha.


## Bài 6: Ngày 6 (Thứ Bảy 08/05)
@img 6_sau-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_CungDienTriNho_PhieuNgay6_di-lai.pdf (phiếu thực hành và bản đồ cung điện in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: SÁU TUẦN TRONG NGHIÊN CỨU, MỘT TUẦN CỦA MÌNH

Hôm nay đặt hai chặng đường cạnh nhau: sáu tuần của những người tham gia một nghiên cứu năm 2017, và một tuần của chính mình.

**Bên trái: sáu tuần trong nghiên cứu**

Năm 2017, Martin Dresler và các cộng sự công bố trên tạp chí Neuron một nghiên cứu hai phần. Phần đầu so sánh 23 vận động viên trí nhớ hàng đầu thế giới với 23 người bình thường. Phần sau mời 51 người chưa từng luyện trí nhớ, chia thành ba nhóm.

- **Nhóm luyện phương pháp định vị:** 30 phút mỗi ngày, trong 40 ngày.
- **Nhóm luyện một bài tập trí nhớ ngắn hạn khác:** cùng thời lượng.
- **Nhóm không luyện tập.**

Trước khi luyện, mỗi người nhớ được trung bình khoảng 26 đến 30 từ trong một danh sách 72 từ. Sau 40 ngày, nhóm luyện phương pháp định vị nhớ thêm trung bình khoảng 35 từ, tức khoảng 62 từ. Hai nhóm kia chỉ tăng ít hơn nhiều. Bốn tháng sau, nhóm luyện phương pháp định vị vẫn nhớ nhiều hơn mức ban đầu khoảng 22 từ. Hình ảnh chụp não cũng cho thấy cách các vùng não kết nối với nhau ở nhóm này thay đổi theo hướng giống với các vận động viên trí nhớ.

**Bên phải: một tuần của mình**

Một cung điện, khoảng bảy điểm dừng, một nội dung công việc thật. Mỗi ngày khoảng 20 phút, phần lớn nằm ngay trong 20 phút học có chủ đích. Một lần đi vòng đầu có thể quên một hai ý, và vài lần đi lại sau đó thì đủ.

**Đặt cạnh nhau để thấy điều gì?**

- Nghiên cứu đo việc nhớ danh sách từ trong phòng thí nghiệm, không đo việc nhớ trong công việc. Mình dùng cùng phương pháp cho một mục đích khác, nên không nên kỳ vọng đúng những con số đó.
- Điều giống nhau là cách làm: luyện ngắn, đều đặn mỗi ngày, trên một chiến lược rõ ràng. Đó cũng chính là cách thói quen then chốt đã được xây từ Mùa 1.
- Kết quả bốn tháng sau gợi ý rằng điều đã luyện có thể giữ được khá lâu. Với mình, cách giữ là tiếp tục dùng cung điện cho nội dung mới.

Mỗi lần mình dùng cung điện trí nhớ để nói trọn vẹn một bài trình bày, hay hướng dẫn đúng đủ các bước của một quy trình, đó là một bước nhỏ, cụ thể về phía phiên bản 10X của chính mình trong công việc.

**Sáng nay (20 phút)**

1. Không nhìn ghi chú, đi lại cung điện của tuần này và đếm số ý còn nhớ sau vài ngày.
2. Ghi lại cung điện mình sẽ giữ cho cả hành trình.
3. Chọn nội dung tiếp theo sẽ đặt vào cung điện, ưu tiên phần giao nhau của bộ ba kỹ năng.

Nếu thích, in bản đồ cung điện ở trang 2 của phiếu Ngày 6, vẽ lộ trình và các điểm dừng, rồi kẹp vào sổ kế hoạch cạnh thẻ bộ ba kỹ năng của tuần trước.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0051-ngay-6.

Chia sẻ hôm nay: "Sau vài ngày, tôi vẫn nhớ ... ý trong cung điện trí nhớ. Nội dung tiếp theo tôi đặt vào cung điện: ...".

**Tuần sau, Thứ Hai 10.05**

Tuần sau Mùa 3 quay lại với cách sắp xếp chính 20 phút học: trộn nhiều dạng bài thay vì học dồn một dạng, và hiểu vì sao cảm giác khó hơn khi học có thể lại là một dấu hiệu tốt.

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hình con dấu tròn hiện ra: số điểm dừng của cung điện mình ở giữa, dòng "ĐIỂM DỪNG", tên mình và cung điện trí nhớ của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Ngày nào còn thiếu thì Chủ Nhật vẫn làm bù được.

Chúc các anh chị và các bạn một Chủ Nhật nghỉ ngơi trọn vẹn nha. Và nếu ngày mai là dịp gửi lời cảm ơn đến mẹ, mong các anh chị và các bạn có những giờ phút ấm áp bên gia đình.
