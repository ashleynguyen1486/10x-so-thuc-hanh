## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 12/04)
@img 1_doc-lai-hay-tu-hoi
@pdf 10XHub_CongThuc_0048_Truy Hoi Chu Dong_VN.pdf (tài liệu đầy đủ của Công thức #0048)
@pdf 10XHub_TruyHoi_PhieuNgay1_doc-lai-hay-tu-hoi.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0048.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** ĐỌC LẠI BỐN LẦN HAY TỰ KIỂM TRA BA LẦN?

Tuần đầu của Mùa 3, cả nhóm đã đặt 20 phút học ngay sau thói quen then chốt, chọn một kỹ năng cho quý 2 bằng bảng chọn, vẽ bản đồ khái niệm, dữ kiện, quy trình, đặt tên dự án học, làm buổi học có chủ đích đầu tiên và viết thư gửi mình ngày 30.06. Kỹ năng và dự án học đó là nơi thử mọi công thức của tuần này.

Công thức #0048 của tuần là Truy hồi chủ động.

**Nếu mới tham gia:** tuần này chỉ cần hai điều để bắt đầu. Trên sổ thực hành Ngày 1, viết thói quen then chốt và một kỹ năng mình đang muốn học trong công việc, ví dụ chính sách sản phẩm mới hay cách đọc một loại báo cáo. Sau đó làm ngay "trang giấy trắng" bên dưới với kỹ năng đó. Không cần đọc lại tuần trước.

**Hai đồng nghiệp, một buổi đào tạo**

Đây là một tình huống minh hoạ, dựng theo thiết kế của một nghiên cứu sẽ kể ngay bên dưới.

Lan và Minh cùng làm kinh doanh, cùng dự buổi đào tạo về một dòng sản phẩm mới. Cuối buổi, mỗi người có 20 phút để ôn tài liệu năm trang.

Lan đọc lại tài liệu bốn lần. Lần thứ tư, mọi câu đều quen, Lan thấy rất yên tâm.

Minh đọc một lần, rồi gập tài liệu, tự viết ra giấy mọi điều nhớ được. Mở ra đối chiếu, thấy sót khá nhiều. Minh gập lại, viết lần nữa, rồi lần nữa. Cuối 20 phút, Minh thấy không chắc lắm.

Nếu kiểm tra ngay sau buổi ôn, nhiều khả năng Lan làm tốt hơn. Nhưng một tuần sau, khi khách hàng đầu tiên hỏi về sản phẩm, người nhớ được nhiều hơn có thể lại là Minh.

**Nghiên cứu nói gì?**

Năm 2006, Henry Roediger và Jeffrey Karpicke (Đại học Washington ở St. Louis) công bố trên tạp chí Psychological Science một thí nghiệm có thiết kế gần giống tình huống trên. Sinh viên học một bài đọc ngắn theo bốn khoảng thời gian bằng nhau. Một nhóm dùng cả bốn khoảng để đọc. Một nhóm đọc một lần rồi dùng ba khoảng còn lại để tự viết ra những gì nhớ được, không xem lại bài.

Năm phút sau khi học, nhóm đọc bốn lần nhớ được khoảng 83% ý, nhóm tự viết ba lần khoảng 71%. Một tuần sau, kết quả đảo chiều: nhóm đọc bốn lần còn khoảng 40%, nhóm tự viết ba lần còn khoảng 61%.

Điều đáng chú ý hơn: chính nhóm đọc bốn lần lại tin rằng mình sẽ nhớ bài tốt hơn. Cảm giác quen mắt khi đọc lại dễ bị nhầm thành đã nhớ.

**Truy hồi chủ động là gì?**

Truy hồi là lấy lại một điều từ trí nhớ, không nhìn tài liệu. Truy hồi chủ động là cố ý làm việc đó trong lúc học: đóng tài liệu, tự viết ra, tự đặt câu hỏi rồi tự trả lời, tự giải thích lại cho người khác. Tuần #0040 đã gặp hiệu ứng này qua thẻ ghi nhớ. Tuần này đặt nó vào trung tâm của 20 phút học mỗi ngày.

**Lớp của tuần này**

Trong 20 phút học sau thói quen then chốt, bớt phần đọc lại, thêm phần tự kiểm tra. Không phải bỏ hẳn việc đọc: vẫn cần đọc hoặc nghe một lần để hiểu. Điều thay đổi là những lần sau, thay vì đọc lại, mình tự hỏi mình.

**Sáu ngày của tuần**

- Thứ Hai: trang giấy trắng đầu tiên.
- Thứ Ba: viết câu hỏi buộc mình phải nhớ lại.
- Thứ Tư: một thí nghiệm nhỏ trên chính mình.
- Thứ Năm: mười cách học, xếp theo bằng chứng.
- Thứ Sáu 16.04, Giỗ Tổ Hùng Vương: bài nhẹ, nhớ người đã dạy mình nghề.
- Thứ Bảy: đối chiếu kết quả thí nghiệm, chọn cách tự kiểm tra sẽ giữ.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Trang giấy trắng**

1. Chọn một phần nhỏ của kỹ năng đang học (một mục trong bản đồ tuần trước).
2. Đọc hoặc xem phần đó khoảng 8 phút.
3. Gập tài liệu lại. Trong 7 phút, viết ra giấy trắng mọi điều nhớ được.
4. Mở tài liệu ra đối chiếu trong 5 phút, đánh dấu ý đã nhớ và ý bị sót.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-1.

Chia sẻ hôm nay: "Trang giấy trắng đầu tiên: tôi tự viết lại được ... ý về ..., sót ... ý".

Sót nhiều ý ở lần đầu là chuyện rất bình thường, đó chính là lúc trí nhớ đang được luyện, các anh chị và các bạn cứ ghi đúng con số của mình nha.


## Bài 2: Ngày 2 (Thứ Ba 13/04)
@img 2_cau-hoi-tot
@pdf 10XHub_TruyHoi_PhieuNgay2_cau-hoi-tot.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CÂU HỎI BUỘC MÌNH PHẢI NHỚ LẠI

Tự kiểm tra chỉ hiệu quả khi câu hỏi buộc mình phải lấy điều gì đó ra từ trí nhớ. Có những câu hỏi nhìn vào là thấy quen, trả lời được mà không cần nhớ gì. Hôm nay đặt năm cặp câu hỏi cạnh nhau, mỗi cặp một câu chưa tốt và một câu tốt hơn.

**Cặp 1: tiêu đề và câu hỏi**

Chưa tốt: "Chính sách đổi trả."
Tốt hơn: "Khách hàng mua được 10 ngày muốn đổi sản phẩm, những điều kiện nào phải kiểm tra?"

Một tiêu đề chỉ gợi cảm giác quen. Một câu hỏi buộc mình nói ra nội dung.

**Cặp 2: có hoặc không, và giải thích**

Chưa tốt: "Dòng tiền khác lợi nhuận phải không?"
Tốt hơn: "Vì sao một tháng có lãi mà công ty vẫn thiếu tiền trả nhà cung cấp?"

Câu hỏi có hoặc không đoán đúng một nửa. Câu hỏi "vì sao" cần hiểu thật mới trả lời được.

**Cặp 3: định nghĩa và tình huống**

Chưa tốt: "Câu hỏi phỏng vấn theo hành vi là gì?"
Tốt hơn: "Ứng viên trả lời chung chung 'tôi luôn làm việc nhóm tốt', câu hỏi tiếp theo nên là gì?"

Kỹ năng được dùng trong tình huống, nên câu hỏi tốt nhất đặt mình vào tình huống.

**Cặp 4: gợi sẵn đáp án và để trống**

Chưa tốt: "Bốn bước xử lý khiếu nại là nghe, xác nhận, đề xuất và gì?"
Tốt hơn: "Bốn bước xử lý khiếu nại theo đúng trình tự là gì?"

Câu hỏi càng gợi nhiều, trí nhớ càng ít phải làm việc.

**Cặp 5: một câu hỏi lớn và một câu hỏi một ý**

Chưa tốt: "Trình bày mọi điều về đàm phán giá."
Tốt hơn: "Khi khách hàng đề nghị giảm 10%, điều đầu tiên mình hỏi lại là gì?"

Câu hỏi một ý dễ biết mình đúng hay sai. Câu hỏi quá lớn thường chỉ nhận được câu trả lời mơ hồ.

**Ba lưu ý khi viết câu hỏi**

- Viết câu hỏi ngay sau buổi học, khi còn nhớ phần nào quan trọng.
- Viết đáp án ngắn ở mặt sau hoặc ở một tờ riêng, để đối chiếu sau khi trả lời.
- Với kỹ năng thiên về quy trình, câu hỏi có thể là một yêu cầu: "Không nhìn hướng dẫn, làm lại bước đối chiếu sổ phụ ngân hàng."

**Ngày 2 (20 phút)**

1. Viết năm câu hỏi cho kỹ năng đang học, theo năm cặp trên.
2. Đặt tài liệu sang một bên, trả lời cả năm câu.
3. Đối chiếu, đánh dấu câu trả lời đúng, chọn câu khó nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-2.

Chia sẻ hôm nay: "Tôi viết 5 câu hỏi cho kỹ năng .... Câu khó nhất: ...".


## Bài 3: Ngày 3 (Thứ Tư 14/04)
@img 3_thi-nghiem-nho
@pdf 10XHub_TruyHoi_PhieuNgay3_thi-nghiem-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: MỘT THÍ NGHIỆM NHỎ TRÊN CHÍNH MÌNH

Đọc về nghiên cứu là một chuyện, tự thấy trên chính mình là chuyện khác. Hôm nay là bản đề cương cho một thí nghiệm nhỏ, chạy từ hôm nay đến Thứ Bảy, ngay trong 20 phút học.

**Cảm hứng: một nghiên cứu năm 2008**

Năm 2008, Jeffrey Karpicke và Henry Roediger công bố trên tạp chí Science một thí nghiệm với 40 cặp từ tiếng Swahili và tiếng Anh. Sinh viên học rồi tự kiểm tra qua nhiều vòng. Ở một số nhóm, cặp từ nào đã nhớ được thì bị bỏ ra khỏi các vòng kiểm tra sau; có nhóm vẫn được đọc lại các cặp đó, có nhóm thì không.

Một tuần sau, các nhóm vẫn tiếp tục tự kiểm tra cả những cặp từ đã nhớ đạt khoảng 80%. Các nhóm thôi kiểm tra những cặp đó chỉ nhớ được khoảng 33 đến 36%, kể cả nhóm vẫn tiếp tục đọc lại chúng. Sinh viên ở các nhóm dự đoán mức nhớ của mình gần như giống nhau, không khớp với kết quả thật.

Bài học cho người đi làm: điều đã nhớ hôm nay vẫn cần được tự hỏi lại ở những lần sau.

**Đề cương thí nghiệm**

**Câu hỏi:** Với kỹ năng mình đang học, tự kiểm tra có giúp mình nhớ hơn đọc lại không?

**Vật liệu:** mười ý của kỹ năng đang học. Với kỹ năng thiên về dữ kiện, đó là mười điều cần nhớ. Với kỹ năng thiên về quy trình, đó là mười bước. Với khái niệm, đó là mười câu giải thích ngắn.

**Cách chia:** nhóm A gồm năm ý sẽ chỉ đọc lại. Nhóm B gồm năm ý sẽ tự kiểm tra. Chia sao cho hai nhóm khó như nhau.

**Cách làm:** hôm nay, Thứ Năm và Thứ Sáu, mỗi ngày dành khoảng 5 phút trong 20 phút học: đọc lại năm ý nhóm A một lượt; với năm ý nhóm B, che đáp án, tự trả lời, rồi mới mở ra.

**Cách đo:** sáng Thứ Bảy, không nhìn tài liệu, viết ra cả mười ý. Đếm số ý nhớ được của từng nhóm.

**Ghi trước dự đoán:** hôm nay ghi dự đoán của mình. Thứ Bảy so lại.

**Một lưu ý trung thực**

Mười ý và ba ngày là một thí nghiệm rất nhỏ, kết quả có thể khác nghiên cứu, và không chứng minh được gì. Mục đích là tự quan sát cách trí nhớ của mình làm việc, không phải để có một con số đẹp. Kết quả nào cũng có giá trị.

**Ngày 3 (20 phút)**

1. Chọn mười ý của kỹ năng đang học, chia thành nhóm A và nhóm B.
2. Ghi dự đoán: nhóm nào sẽ nhớ hơn vào Thứ Bảy.
3. Làm vòng đầu: đọc lại nhóm A, tự kiểm tra nhóm B.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-3.

Chia sẻ hôm nay: "Thí nghiệm nhỏ của tôi: 5 ý đọc lại, 5 ý tự kiểm tra. Dự đoán của tôi: ...".


## Bài 4: Ngày 4 (Thứ Năm 15/04)
@img 4_muoi-cach-hoc
@pdf 10XHub_TruyHoi_PhieuNgay4_muoi-cach-hoc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: MƯỜI CÁCH HỌC, XẾP THEO BẰNG CHỨNG

Năm 2013, nhóm của John Dunlosky (Đại học Kent State) cùng Katherine Rawson, Elizabeth Marsh, Mitchell Nathan và Daniel Willingham công bố một bài tổng quan dài trên tạp chí Psychological Science in the Public Interest. Họ xem xét mười cách học phổ biến và xếp mỗi cách vào một trong ba mức hữu ích: cao, vừa, thấp. Hôm nay là bảng xếp hạng đó, kèm cách dùng trong 20 phút học của người đi làm.

**Mức hữu ích cao**

1. **Tự kiểm tra:** tự hỏi, làm đề, làm thẻ câu hỏi. Đây là truy hồi chủ động của tuần này.
2. **Học cách quãng:** chia thời gian ôn ra nhiều lần, cách nhau vài ngày. Đây là lịch ôn của tuần #0040.

**Mức hữu ích vừa**

3. **Tự hỏi vì sao:** với mỗi ý, tự hỏi "vì sao điều này đúng?".
4. **Tự giải thích:** giải thích cho chính mình từng bước đã làm, đã đọc.
5. **Học xen kẽ:** trộn các dạng bài, dạng tình huống trong một buổi. Một tuần sau của Mùa 3 sẽ nói kỹ.

**Mức hữu ích thấp**

6. **Tóm tắt:** viết lại ý chính thành đoạn ngắn.
7. **Tô đậm, gạch chân:** đánh dấu trong tài liệu khi đọc.
8. **Mẹo từ khoá:** gắn từ cần nhớ với một từ quen nghe giống.
9. **Hình dung bằng hình ảnh:** tự vẽ trong đầu hình ảnh cho nội dung bài đọc.
10. **Đọc lại:** đọc lại tài liệu nhiều lần.

**Đọc bảng này cho đúng**

- "Thấp" không có nghĩa là vô ích. Các tác giả xếp mức thấp khi bằng chứng còn hạn chế, hiệu quả phụ thuộc nhiều vào người học hoặc tài liệu, hoặc chỉ có lợi trong một số điều kiện. Ví dụ tóm tắt có ích hơn với người đã được hướng dẫn cách tóm tắt.
- Phần lớn nghiên cứu được làm với học sinh, sinh viên học từ tài liệu. Người đi làm áp dụng theo tinh thần chung, không coi đó là đảm bảo kết quả.
- Hai cách ở mức cao lại bổ sung cho nhau: tự kiểm tra theo lịch cách quãng.

**Kiểm kê 20 phút của mình**

Nhìn lại vài buổi học vừa qua, đánh dấu những cách mình đang dùng nhiều nhất. Nếu phần lớn thời gian đang nằm ở nhóm thấp, không cần bỏ hết. Chỉ cần đổi một cách: ví dụ bớt năm phút tô đậm, thêm năm phút gập tài liệu tự viết ra.

**Ngày 4 (20 phút)**

1. Đánh dấu những cách mình đang dùng trong 20 phút học.
2. Chọn một cách sẽ bớt và một cách sẽ thêm.
3. Làm vòng hai của thí nghiệm nhỏ (khoảng 5 phút).
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-4.

Chia sẻ hôm nay: "Trong 20 phút học, tôi bớt ..., thêm ...".


## Bài 5: Ngày 5 (Thứ Sáu 16/04)
@img 5_nho-nguon
@pdf 10XHub_TruyHoi_PhieuNgay5_nho-nguon.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: GIỖ TỔ, NHỚ NGƯỜI ĐÃ DẠY MÌNH NGHỀ

Hôm nay, Thứ Sáu 16.04, là ngày Giỗ Tổ Hùng Vương, mùng 10 tháng 3 âm lịch, ngày nhiều người được nghỉ để cùng gia đình hướng về cội nguồn. Bài hôm nay nhẹ, khoảng 10 phút, và mượn tinh thần "uống nước nhớ nguồn" cho một câu hỏi về công việc.

**Kỹ năng của mình bắt nguồn từ đâu?**

Gần như ai cũng có một người đã dạy mình nghề, theo cách này hay cách khác. Một trưởng nhóm đầu tiên kiên nhẫn sửa từng email. Một anh kỹ sư lâu năm chỉ cách nghe tiếng máy. Một chị kế toán chỉ cho mình đối chiếu sổ sách đến từng dòng. Một khách hàng khó tính dạy mình chuẩn bị kỹ trước mỗi cuộc gặp.

Những điều họ dạy giờ đã thành một phần cách mình làm việc, đến mức có khi mình quên mất nó bắt đầu từ đâu.

**Một bài tự kiểm tra rất đặc biệt**

Hôm nay, truy hồi chủ động được dùng theo một cách khác. Không nhìn tài liệu nào, hãy nhớ lại và viết ra:

- Người đã dạy mình nhiều nhất về nghề là ai?
- Ba điều cụ thể người đó dạy mình, mà đến giờ mình vẫn dùng.
- Một lần mình thấy rõ điều đó có ích trong công việc.

Có thể sẽ thấy, có những điều được dạy từ nhiều năm trước vẫn nhớ rất rõ. Thường đó là những điều mình đã dùng đi dùng lại, tức là đã được truy hồi rất nhiều lần trong công việc.

**Nếu được, gửi một lời cảm ơn**

Một tin nhắn ngắn: "Hôm nay em nhớ lại điều anh dạy về...". Với người nhận, đó có thể là một tin nhắn đáng nhớ trong ngày nghỉ.

**Ngày 5 (khoảng 10 phút)**

1. Viết tên người đã dạy mình nghề nhiều nhất và ba điều người đó dạy, từ trí nhớ.
2. Nếu được, gửi người đó một lời cảm ơn ngắn.
3. Nếu còn thời gian, tự trả lời lại năm câu hỏi của Thứ Ba (3 phút), đó cũng là vòng ba của thí nghiệm nhỏ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-5.

Chia sẻ hôm nay: "Ngày Giỗ Tổ, tôi nhớ đến ..., người đã dạy tôi: ...".

Chúc các anh chị và các bạn một ngày nghỉ lễ ấm áp bên gia đình nha.


## Bài 6: Ngày 6 (Thứ Bảy 17/04)
@img 6_ket-qua-thi-nghiem
@img2 9_the-thanh-tich
@pdf 10XHub_TruyHoi_PhieuNgay6_ket-qua-thi-nghiem.pdf (phiếu thực hành và bộ thẻ câu hỏi gập đôi in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: KẾT QUẢ THÍ NGHIỆM CỦA CHÍNH MÌNH

Sáng nay là lúc đo thí nghiệm nhỏ bắt đầu từ Thứ Tư. Không nhìn tài liệu, viết ra cả mười ý, rồi đếm. Dưới đây là những câu hỏi thường gặp khi nhìn kết quả.

**Hỏi: Nhóm tự kiểm tra nhớ hơn. Vậy là xong?**

Đó là kết quả nhiều nghiên cứu đã thấy, và giờ mình thấy trên chính kỹ năng của mình. Điều còn lại là giữ nó thành một phần của 20 phút học, không chỉ trong tuần này.

**Hỏi: Hai nhóm như nhau, hoặc nhóm đọc lại nhớ hơn thì sao?**

Hoàn toàn có thể. Mười ý và ba ngày là mẫu rất nhỏ. Có thể nhóm A dễ hơn, có thể ba ngày chưa đủ để thấy khác biệt. Trong nghiên cứu năm 2006, khác biệt rõ nhất xuất hiện sau một tuần. Có thể kiểm tra lại cả mười ý vào Thứ Bảy tuần sau.

**Hỏi: Tự kiểm tra mà sai nhiều thì có hại không?**

Sai khi tự kiểm tra là thông tin, không phải thất bại. Điều quan trọng là mở tài liệu đối chiếu ngay sau khi trả lời, để sửa lại câu sai trước khi nó thành nếp.

**Hỏi: Có nên bỏ hẳn việc đọc lại?**

Không. Lần đầu tiếp xúc, cần đọc hoặc nghe để hiểu. Khi thấy một ý còn mơ hồ, đọc lại để hiểu cũng cần thiết. Điều tuần này đổi là: đọc lại không còn là cách ôn chính.

**Hỏi: Kỹ năng thiên về quy trình thì tự kiểm tra thế nào?**

Làm lại không nhìn hướng dẫn. Ví dụ dựng lại bảng đối chiếu từ đầu, hay tự đóng vai một cuộc gọi khiếu nại mà không nhìn kịch bản, rồi so với chuẩn.

**Hỏi: Lịch ôn của tuần #0040 thay đổi gì?**

Lịch ôn 1, 3, 7, 14 ngày giữ nguyên. Chỉ thay cách ôn: mỗi lần ôn là một lần tự kiểm tra. Học cách quãng và tự kiểm tra là hai cách học được xếp ở mức hữu ích cao, dùng cùng nhau càng hợp.

**Sáng nay (15 phút)**

1. Không nhìn tài liệu, viết ra mười ý của thí nghiệm nhỏ. Đếm số ý nhớ được của nhóm A và nhóm B.
2. So với dự đoán hôm Thứ Tư.
3. Viết một câu: cách tự kiểm tra mình sẽ giữ trong 20 phút học.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In bộ thẻ câu hỏi gập đôi ở phiếu Ngày 6, chép năm câu hỏi của Thứ Ba vào, kẹp cạnh bản đồ dự án học.

**Tuần sau: Ghi chép Cornell**

Từ Thứ Hai 19.04, mỗi buổi học có một trang ghi chép chia ba vùng, trong đó cột bên trái chính là chỗ đặt câu hỏi tự kiểm tra của tuần này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0048-ngay-6.

Chia sẻ hôm nay: "Thí nghiệm nhỏ: đọc lại nhớ .../5 ý, tự kiểm tra nhớ .../5 ý. Cách tự kiểm tra tôi giữ: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích tự kiểm tra hiện ra: vòng tròn đỏ với dấu tích lớn, dòng "ĐỦ 6/6 NGÀY", tên mình và cách tự kiểm tra mình chọn giữ. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Cảm ơn các anh chị và các bạn đã dám thử nghiệm trên chính cách học của mình. Hẹn gặp lại sáng Thứ Hai.
