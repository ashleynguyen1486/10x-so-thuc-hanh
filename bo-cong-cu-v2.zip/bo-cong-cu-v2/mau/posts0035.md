## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 11/01)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0035_Bang Kanban Ca Nhan_VN.pdf (tài liệu đầy đủ của Công thức #0035)
@pdf 10XHub_Kanban_PhieuNgay1_dung-bang.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0035.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN ĐẦU TIÊN TRỌN VẸN: ĐƯA 5 MỤC TIÊU LÊN BẢNG

Ngay lúc này, có bao nhiêu việc đang dở dang trong đầu các anh chị và các bạn? Một bản báo giá viết được một nửa, một email đang chờ trả lời, một báo cáo mới mở tệp, một cuộc gọi hẹn "chiều nay gọi lại". Phần lớn chúng ta không trả lời được ngay. Tuần này bắt đầu từ chính câu hỏi đó.

Tuần trước, cả nhóm đã viết 25 mục tiêu công việc cho năm 2027, khoanh lấy 5, biến 20 mục tiêu còn lại thành danh sách tránh, nối thói quen then chốt với mục tiêu số 1 và đặt ba mốc cho quý 1. Nhiều tấm thẻ 5 mục tiêu đã nằm cạnh bàn phím, cạnh màn hình, trong sổ kế hoạch. Năm mục tiêu đã rõ. Câu hỏi tiếp theo là: sáng Thứ Hai này, việc cụ thể nào đưa mình lại gần chúng?

Đây là tuần làm việc trọn vẹn đầu tiên của năm 2027, không có ngày nghỉ lễ chen giữa. Công thức #0035 của tuần là Bảng Kanban cá nhân.

**Nếu mới tham gia:** tuần này không đòi hỏi biết trước điều gì. Hôm nay chỉ cần một tờ giấy chia ba cột, hoặc một trang trống trên máy tính, và viết ra mọi việc đang có trong đầu. Trên sổ thực hành, Ngày 1 có sẵn hai ô cho người mới: một thói quen then chốt muốn giữ, và một câu "Tôi là người ...". Thứ Ba, sổ có thêm ô để ghi mục tiêu quan trọng nhất của năm, rồi cả tuần đi tiếp cùng mọi người.

**Một tấm thẻ trong nhà máy Toyota**

"Kanban" là tiếng Nhật, nghĩa gốc là tấm biển, tấm thẻ. Đầu những năm 1950, trong xưởng của Toyota, Taiichi Ohno và các đồng nghiệp bắt đầu thử một cách điều phối rất khác thời đó. Thay vì công đoạn trước sản xuất thật nhiều rồi đẩy sang công đoạn sau, công đoạn sau chủ động đến lấy đúng loại linh kiện, đúng số lượng mình cần, vào đúng lúc cần. Tấm thẻ kanban đi kèm linh kiện cho biết đã lấy gì, cần làm bù bao nhiêu. Không có thẻ thì không sản xuất, không vận chuyển.

Theo chính Ohno kể lại, ý tưởng này được gợi ra từ cách các siêu thị ở Mỹ bổ sung hàng lên kệ: khách lấy món nào, cửa hàng bổ sung đúng món đó. Lịch sử chính thức của Toyota ghi rằng hệ thống kanban được áp dụng ở tất cả các nhà máy vào năm 1963, và từ năm 1965 được mở rộng sang các nhà cung cấp.

Có hai điều từ nhà máy rất đáng mang về bàn làm việc. Một là, mọi việc đều nhìn thấy được trên thẻ. Hai là, số thẻ đang lưu hành có giới hạn. Ohno viết rằng giảm bớt số thẻ giúp hệ thống nhạy hơn: hàng dở dang ít đi thì vấn đề lộ ra sớm hơn.

**Từ nhà máy đến bàn làm việc**

Năm 2010, David J. Anderson xuất bản cuốn "Kanban", tổng kết cách áp dụng nguyên lý này cho các nhóm phát triển phần mềm. Năm 2011, Jim Benson và Tonianne DeMaria Barry viết "Personal Kanban", đưa nó về quy mô một người, với đúng hai quy tắc: nhìn thấy việc của mình, và giới hạn số việc đang làm dở.

Bảng Kanban cá nhân của tuần này có ba cột: Cần làm, Đang làm, Xong. Mỗi việc là một tấm thẻ. Thẻ chỉ đi từ trái sang phải, và chỉ được kéo vào cột Đang làm khi cột đó còn chỗ.

**Trong Mùa 2, tấm bảng làm gì cho thói quen then chốt?**

Thói quen then chốt vẫn là trục. Tuần này nó có thêm một lớp: năm phút nhìn bảng mỗi sáng, gắn ngay trước hoặc sau thói quen đang giữ. Năm mục tiêu nằm ở cột Cần làm dưới dạng những bước nhỏ, và mỗi ngày làm thói quen là một ngày ít nhất một bước được kéo sang phải.

Lộ trình tuần này đi từ dựng bảng (Thứ Hai), tách mục tiêu số 1 thành thẻ việc (Thứ Ba), đặt giới hạn việc dở (Thứ Tư), năm phút nhìn bảng buổi sáng (Thứ Năm), gỡ việc tắc (Thứ Sáu), đến nhìn lại luồng việc cả tuần (Thứ Bảy). Chủ Nhật nghỉ.

**Ngày 1 (30 phút): Dựng bảng ba cột**

1. Chọn nơi đặt bảng: một tấm bảng trắng, một tờ giấy khổ lớn dán cạnh bàn, một trang sổ, hoặc một ứng dụng trên máy tính. Điều quan trọng là nhìn thấy được mỗi ngày.
2. Kẻ ba cột: Cần làm, Đang làm, Xong.
3. Viết mỗi việc đang có trong đầu ra một thẻ, kể cả việc nhỏ. Thẻ nào đang dở thì đặt ngay vào cột Đang làm, đừng sắp xếp lại vội.
4. Đếm số thẻ ở hai cột đầu, ghi vào sổ thực hành.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-1.

Chia sẻ hôm nay: "Bảng Kanban của tôi đặt ở: .... Cột Cần làm có ... thẻ, cột Đang làm đang có ... việc dở.".

Con số ở cột Đang làm hôm nay thường lớn hơn mình nghĩ. Đó là điểm xuất phát rất bình thường, các anh chị và các bạn cứ ghi đúng con số thật nha.


## Bài 2: Ngày 2 (Thứ Ba 12/01)
@img 2_tach-buoc
@pdf 10XHub_Kanban_PhieuNgay2_tach-buoc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: TÁCH MỤC TIÊU SỐ 1 THÀNH THẺ VIỆC

Một mục tiêu năm không đặt được lên bảng. "Có 12 khách hàng doanh nghiệp mới trong năm" nằm ở cột Cần làm cả năm thì cũng không ai biết sáng nay phải làm gì với nó. Thẻ trên bảng Kanban cần là một việc làm được, có điểm bắt đầu và điểm kết thúc rõ ràng.

Hôm nay là một danh sách mẫu: cùng một cách tách, áp vào sáu vị trí công việc khác nhau. Các ví dụ chỉ mang tính minh hoạ.

**Cách tách: mục tiêu → mốc gần nhất → thẻ việc**

Không cần tách cả năm. Lấy mốc gần nhất của mục tiêu số 1 (mốc cuối tháng 1 đã viết tuần trước), rồi hỏi: để đạt mốc đó, những việc cụ thể nào phải xong? Mỗi việc thành một thẻ.

**Sáu ví dụ theo vị trí**

- **Kinh doanh.** Mốc cuối tháng 1: danh sách 40 khách hàng tiềm năng đã sàng lọc. Thẻ việc: lọc khách hàng cũ từ hệ thống theo ngành; xin danh sách hội viên của hiệp hội ngành; viết tiêu chí sàng lọc một trang; gọi thử 5 khách hàng đầu để kiểm tra tiêu chí.
- **Kế toán.** Mốc: quy trình chốt sổ tháng 1 rút từ 5 xuống 4 ngày. Thẻ việc: ghi lại các bước chốt sổ tháng 12 kèm thời gian; khoanh hai bước chờ lâu nhất; hẹn bộ phận mua hàng chốt hạn gửi hoá đơn.
- **Nhân sự.** Mốc: chương trình hội nhập mới cho nhân viên vào làm tháng 2. Thẻ việc: phỏng vấn ngắn 3 nhân viên mới vào năm 2026; viết lịch tuần đầu tiên; chuẩn bị bộ tài liệu chào mừng.
- **Kỹ thuật.** Mốc: danh sách 3 nguyên nhân dừng máy hàng đầu của dây chuyền A. Thẻ việc: xuất số liệu dừng máy quý 4; phân loại theo nguyên nhân; trao đổi 15 phút với tổ trưởng ca đêm.
- **Chăm sóc khách hàng.** Mốc: bộ câu trả lời mẫu cho 10 khiếu nại thường gặp. Thẻ việc: lọc khiếu nại tháng 12 theo nhóm; viết 3 câu trả lời đầu tiên; gửi trưởng nhóm góp ý.
- **Quản lý.** Mốc: mỗi thành viên có bản nháp kế hoạch phát triển. Thẻ việc: gửi mẫu kế hoạch cho cả nhóm; đặt lịch trao đổi riêng với từng người; chuẩn bị ba câu hỏi cho buổi trao đổi.

**Ba dấu hiệu của một thẻ việc tốt**

1. Bắt đầu bằng một động từ: gọi, viết, gửi, lọc, hẹn. "Báo cáo quý" là một chủ đề, "Viết phần tóm tắt báo cáo quý" là một thẻ việc.
2. Làm xong trong một lần ngồi, thường dưới 90 phút. Việc lớn hơn thì tách tiếp.
3. Khi xong, ai nhìn vào cũng biết là đã xong. Có tệp đã gửi, có cuộc hẹn đã đặt, có danh sách đã lọc.

Thẻ nào chưa đạt ba dấu hiệu, viết lại ngay trên bảng. Sau đó chọn một thẻ làm được ngay trong tuần này để kéo sang cột Đang làm.

**Ngày 2 (25 phút)**

1. Viết mốc gần nhất của mục tiêu số 1 lên đầu bảng.
2. Tách mốc đó thành 3 đến 6 thẻ việc, mỗi thẻ đạt ba dấu hiệu.
3. Đặt các thẻ vào cột Cần làm, chọn thẻ đầu tiên kéo sang Đang làm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-2.

Chia sẻ hôm nay: "Mục tiêu số 1 của tôi đã thành ... thẻ việc. Thẻ đầu tiên tôi kéo sang Đang làm: ...".


## Bài 3: Ngày 3 (Thứ Tư 13/01)
@img 3_gioi-han
@pdf 10XHub_Kanban_PhieuNgay3_gioi-han.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: GIỚI HẠN VIỆC DỞ, MỘT CON SỐ NHỎ

Quy tắc số hai của Bảng Kanban cá nhân thường bị bỏ qua nhất, và cũng là quy tắc tạo ra khác biệt lớn nhất: giới hạn số việc đang làm dở. Hôm nay giải nghĩa từng cụm từ trong quy tắc này.

**"Việc dở" là gì?**

Việc dở là việc đã bắt đầu nhưng chưa xong: đã mở tệp, đã hứa, đã làm một phần. Trong nhà máy, đó là hàng dở dang nằm giữa các công đoạn: chiếm chỗ, chiếm vốn, và che đi những lỗi chưa ai thấy. Ở bàn làm việc, việc dở chiếm một phần sự chú ý. Nhà nghiên cứu Sophie Leroy (2009) gọi hiện tượng này là "phần sót lại của sự chú ý": khi chuyển sang việc mới mà việc cũ chưa xong, một phần tâm trí vẫn ở lại với việc cũ, và việc mới được làm kém hơn.

**"Giới hạn" nghĩa là gì?**

Là một con số tối đa cho cột Đang làm, ví dụ 3. Khi cột đã có 3 thẻ, muốn kéo thêm một thẻ nữa vào thì phải làm xong một thẻ, hoặc trả một thẻ về Cần làm. Giới hạn không phải là mục tiêu làm ít đi. Nó là quy tắc để làm xong nhiều hơn.

**Vì sao ít việc dở lại xong nhanh hơn?**

Năm 1961, John Little chứng minh một công thức trong lý thuyết hàng đợi, sau này gọi là Định luật Little. Áp vào bàn làm việc, có thể hiểu gần đúng thế này: thời gian trung bình một việc nằm trên bảng bằng số việc dở chia cho số việc làm xong mỗi tuần. Nếu đang có 12 việc dở và mỗi tuần xong khoảng 4 việc, mỗi việc trung bình mất khoảng 3 tuần từ lúc bắt đầu đến lúc xong. Giữ còn 4 việc dở, với cùng tốc độ, con số đó còn khoảng 1 tuần. Định luật nói về giá trị trung bình trong một hệ thống ổn định, nên đây là phép tính minh hoạ, không phải lời hứa.

**"Đầy cột" thì làm gì?**

Đây là lúc cần một quy tắc viết sẵn. Ví dụ: "Khi cột Đang làm đã đầy, tôi làm xong thẻ gần xong nhất trước khi nhận việc mới." Hoặc: "Tôi trả một thẻ ít gấp nhất về Cần làm và ghi lý do." Có quy tắc từ trước, mình không phải đắn đo mỗi lần có việc mới đến.

**"Việc gấp" thì sao?**

Việc gấp vẫn đến, nhất là với người làm chăm sóc khách hàng hay vận hành. Nhiều nhóm dành một làn riêng phía trên bảng cho việc gấp, giới hạn một thẻ. Việc gấp vào làn đó, việc khác tạm dừng, và cả bảng thấy rõ việc gì đã bị tạm dừng vì nó.

**Chọn con số nào?**

Với phần lớn công việc văn phòng, 2 đến 4 là con số khởi đầu hợp lý. Bắt đầu nhỏ hơn mình nghĩ một chút, Thứ Bảy sẽ điều chỉnh.

**Ngày 3 (20 phút)**

1. Đếm số việc dở hiện tại và ước lượng số việc mình làm xong mỗi tuần.
2. Chọn giới hạn việc dở, viết con số lên đầu cột Đang làm.
3. Viết quy tắc khi cột đã đầy.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-3.

Chia sẻ hôm nay: "Giới hạn việc dở của tôi: ... việc. Khi cột Đang làm đã đầy, tôi ...".


## Bài 4: Ngày 4 (Thứ Năm 14/01)
@img 4_nhin-bang
@pdf 10XHub_Kanban_PhieuNgay4_nhin-bang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: NĂM PHÚT NHÌN BẢNG MỖI SÁNG

Hôm nay là một trang nhật ký minh hoạ: năm phút đầu ngày của một trưởng nhóm chăm sóc khách hàng, ghi theo từng phút. Nhân vật không có thật, nhưng năm phút này thì ai cũng làm được.

**7 giờ 55.** Chị Ngân đến bàn, pha trà như mọi ngày. Thói quen then chốt của chị trong Mùa 2 là viết ba việc quan trọng nhất trước khi mở hộp thư. Từ tuần này, chị gắn thêm một bước ngay trước đó: nhìn bảng.

**7 giờ 56.** Chị đọc bảng từ phải sang trái, bắt đầu ở cột Xong. Hôm qua có hai thẻ sang cột này: bộ câu trả lời mẫu cho nhóm khiếu nại giao hàng chậm, và lịch trao đổi riêng với một nhân viên mới. Chị dừng lại vài giây ở đây. Thấy được việc đã xong là một phần của buổi sáng.

**7 giờ 57.** Cột Đang làm có ba thẻ, đúng bằng giới hạn. Một thẻ đã nằm đó từ Thứ Hai: "Viết quy trình xử lý hoàn tiền". Chị tự hỏi: thẻ này đang chờ gì? Câu trả lời là chờ phòng kế toán xác nhận hạn mức. Chị dán một chấm đỏ lên thẻ và ghi "chờ kế toán, nhắn trước 10 giờ".

**7 giờ 58.** Hôm nay việc nào gần xong nhất? Thẻ "Gửi bộ câu trả lời mẫu cho trưởng phòng góp ý" chỉ cần thêm 20 phút. Chị quyết định làm nó đầu tiên. Cột Đang làm chưa có chỗ trống, nên chị không kéo thẻ mới vào.

**7 giờ 59.** Chị nhìn cột Cần làm một lượt, tìm thẻ nào thuộc mục tiêu số 1 của năm: giảm thời gian phản hồi khiếu nại xuống dưới 24 giờ. Thẻ "Lọc 20 khiếu nại quá hạn tháng 12" sẽ được kéo vào ngay khi có chỗ.

**8 giờ.** Chị mở sổ, viết ba việc quan trọng nhất. Cả ba lấy thẳng từ bảng. Năm phút đã xong.

**Ba câu hỏi cho năm phút**

Trang nhật ký trên thực chất xoay quanh ba câu hỏi, đọc bảng từ phải sang trái:

1. Hôm qua việc gì đã sang cột Xong?
2. Việc nào trong cột Đang làm đang tắc, đang chờ gì?
3. Hôm nay việc nào gần xong nhất, và có chỗ cho thẻ mới không?

Đọc từ phải sang trái là một thói quen của các nhóm làm Kanban: ưu tiên làm xong việc đang dở trước khi bắt đầu việc mới.

**Gắn vào thói quen then chốt**

Năm phút nhìn bảng dễ giữ nhất khi đặt ngay cạnh một thói quen đã vững. Có người đặt ngay trước thói quen then chốt, có người đặt ngay sau, có người đặt vào lúc mở máy tính. Chọn một chỗ và giữ nguyên cả tuần.

**Ngày 4 (10 phút)**

1. Bấm đồng hồ 5 phút trên sổ thực hành, đọc bảng theo ba câu hỏi.
2. Chọn việc kéo sang Đang làm hôm nay (nếu cột còn chỗ).
3. Chọn thời điểm nhìn bảng mỗi sáng, gắn với thói quen then chốt.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-4.

Chia sẻ hôm nay: "Năm phút nhìn bảng sáng nay, tôi chọn làm trước: .... Thời điểm tôi nhìn bảng mỗi sáng: ...".


## Bài 5: Ngày 5 (Thứ Sáu 15/01)
@img 5_viec-tac
@pdf 10XHub_Kanban_PhieuNgay5_viec-tac.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: THẺ NÀO ĐANG TẮC, TẮC VÌ ĐÂU?

Đến Thứ Sáu, gần như bảng nào cũng có một thẻ nằm yên ở cột Đang làm nhiều ngày. Trong cách làm Kanban, đó không phải lỗi của người làm. Đó là thông tin. Một thẻ đứng yên cho biết luồng việc đang vướng ở đâu.

Hôm nay là một bảng chọn. Chọn một thẻ đang tắc, tìm lý do của nó trong năm nhóm dưới đây, rồi làm đúng bước gỡ tắc của nhóm đó.

**1. Chờ người khác**

Dấu hiệu: thẻ cần một xác nhận, một số liệu, một chữ ký từ người khác. Bước gỡ tắc: gửi một lời nhắn ngắn có hạn rõ ràng ("Anh xác nhận giúp em hạn mức trước 15 giờ Thứ Hai nha"). Ghi tên người đang giữ việc lên thẻ, dán chấm đỏ, và nếu cột Đang làm cần chỗ thì chuyển thẻ sang một làn "Đang chờ" riêng.

**2. Thiếu thông tin**

Dấu hiệu: bắt đầu làm thì mới thấy chưa đủ dữ liệu, chưa rõ yêu cầu. Bước gỡ tắc: viết ra đúng một câu hỏi cần trả lời, rồi dành 15 phút tìm câu trả lời hoặc hỏi người biết.

**3. Việc quá lớn**

Dấu hiệu: thẻ ghi một chủ đề, không phải một việc ("Hệ thống báo cáo bán hàng"). Mỗi lần nhìn thấy lại không biết làm từ đâu. Bước gỡ tắc: tách thẻ theo ba dấu hiệu của Ngày 2, giữ lại thẻ nhỏ nhất ở cột Đang làm, trả phần còn lại về Cần làm.

**4. Chưa rõ bước tiếp theo**

Dấu hiệu: đã làm một phần, nhưng dừng lại ở chỗ "rồi sao nữa". Bước gỡ tắc: viết ngay lên thẻ bước tiếp theo bằng một động từ, càng cụ thể càng tốt ("Gọi chị Lan hỏi mẫu hợp đồng năm ngoái").

**5. Ngại bắt đầu**

Dấu hiệu: không thiếu gì cả, chỉ là việc khó hoặc không thích. Bước gỡ tắc: đặt đồng hồ 15 phút và làm phần dễ nhất của thẻ. Mùa 1 đã luyện cách này với con ếch và phiên bản hai phút. Nhiều khi chỉ cần bắt đầu là luồng việc chạy lại.

**Một lưu ý từ sản xuất tinh gọn**

Trong nhà máy, khi một công đoạn dừng, người ta không chỉ sửa cho nó chạy lại mà còn hỏi vì sao nó dừng, để lần sau không dừng nữa. Áp vào bảng cá nhân: nếu tuần nào cũng có thẻ tắc vì "chờ người khác", có lẽ cần hẹn trước với người đó ngay khi thẻ vào cột Đang làm, chứ không đợi đến lúc cần.

**Ngày 5 (20 phút)**

1. Tìm thẻ nằm ở cột Đang làm lâu nhất.
2. Chọn lý do tắc trong năm nhóm trên.
3. Làm bước gỡ tắc trong 15 phút, dán dấu tắc lên thẻ nếu vẫn phải chờ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-5.

Chia sẻ hôm nay: "Việc tắc trên bảng của tôi: .... Lý do: .... Bước gỡ tắc hôm nay: ...".

Thẻ nào gỡ được ngay hôm nay thì các anh chị và các bạn kể thêm trong bình luận nha, cả nhóm sẽ học được nhiều từ những cách gỡ tắc rất đời thường.


## Bài 6: Ngày 6 (Thứ Bảy 16/01)
@img 6_luong-viec
@img2 9_the-thanh-tich
@pdf 10XHub_Kanban_PhieuNgay6_luong-viec.pdf (phiếu thực hành và tấm bảng Kanban khổ A4 in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: NHÌN LẠI LUỒNG VIỆC CỦA TUẦN

Một tuần trước, năm mục tiêu còn nằm trên một tấm thẻ. Hôm nay, chúng đã thành những thẻ việc di chuyển trên một tấm bảng. Ngày cuối tuần dành cho một buổi nhìn lại ngắn, theo dạng câu hỏi mở. Không có câu trả lời đúng hay sai, chỉ có điều mình nhận ra.

**Cột Xong nói gì?**

Đếm số thẻ đã sang cột Xong trong tuần. Có bao nhiêu thẻ thuộc mục tiêu số 1? Nếu phần lớn thẻ xong là việc phát sinh, đó là một thông tin quan trọng cho tuần sau, không phải lý do để tự trách.

**Thẻ nào nằm lâu nhất?**

Thẻ đứng yên lâu nhất trong tuần là thẻ nào? Nó tắc vì lý do gì trong năm nhóm của hôm qua? Lý do đó có lặp lại ở các thẻ khác không?

**Giới hạn việc dở có vừa không?**

Cả tuần, cột Đang làm có thường xuyên đầy không? Nếu luôn đầy và thẻ đứng yên nhiều, có lẽ nên giảm giới hạn đi một. Nếu luôn còn chỗ mà việc vẫn chảy đều, có thể giữ nguyên hoặc tăng thêm một. Giới hạn là con số để thử nghiệm, Thứ Bảy nào cũng có thể điều chỉnh.

**Năm phút buổi sáng có giữ được không?**

Có bao nhiêu buổi sáng mình nhìn bảng? Gắn ở vị trí nào trong ngày thì giữ dễ nhất? Thói quen then chốt có được tấm bảng giúp thêm điều gì không?

**Điều gì đáng giữ cho tuần sau?**

Chọn một điều nhỏ để giữ hoặc đổi: vị trí đặt bảng, giới hạn việc dở, làn việc gấp, giờ nhìn bảng. Một điều là đủ.

**Tấm bảng in được**

Phiếu Ngày 6 có thêm một trang bảng Kanban khổ A4 với ba cột và ô ghi giới hạn việc dở, dùng được cho cả những tuần sau.

**Tuần sau: Gan góc**

Giữa tháng 1 thường là lúc hứng khởi đầu năm bắt đầu chững lại. Công thức #0036 Gan góc, bắt đầu Thứ Hai 18.01, dựa trên nghiên cứu của Angela Duckworth, bàn về cách giữ thói quen và mục tiêu khi cảm hứng không còn như tuần đầu, bằng cách nối chúng với một lý do dài hạn. Tấm bảng của tuần này sẽ tiếp tục được dùng.

**Ngày 6 (20 phút)**

1. Đếm số thẻ đã sang cột Xong, số thẻ thuộc mục tiêu số 1.
2. Trả lời các câu hỏi mở trên sổ, viết một điều nhận ra về luồng việc.
3. Quyết định giữ, giảm hay tăng giới hạn việc dở cho tuần sau.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0035-ngay-6.

Chia sẻ hôm nay: "Tuần này ... thẻ đã sang cột Xong. Điều tôi nhận ra về luồng việc: ...".

**Thẻ thành tích**

Ai đánh dấu đã chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: một mảng đỏ cắt chéo với con số lớn là số thẻ đã sang cột Xong, chữ "việc đã xong", tên mình, giới hạn việc dở và nơi đặt bảng. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tấm bảng cứ để nguyên đó, sáng Thứ Hai năm phút nhìn bảng sẽ đón các anh chị và các bạn quay lại.
