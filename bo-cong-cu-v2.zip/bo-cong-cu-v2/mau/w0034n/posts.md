## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 04/01)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0034_Quy Tac 5-25_VN.pdf (tài liệu đầy đủ của Công thức #0034)
@pdf 10XHub_QuyTac525_PhieuNgay1_25-muc-tieu.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0034.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỞ MÙA 2: 25 MỤC TIÊU, CHỈ GIỮ LẠI 5

Tuần chuyển năm vừa qua, cả nhóm đã đọc lại năm 2026 trên bảng hành trình, vẽ vòng lặp thói quen của mình và quyết định cho năm 2027: giữ, nâng cấp hay đổi thói quen then chốt. Nhiều người đã viết một lá thư gửi chính mình vào ngày 31.12 và một câu bản sắc mới vào sáng 01.01. Những điều đó đều còn trên sổ thực hành.

Hôm nay là ngày làm việc đầu tiên trọn vẹn của năm 2027, và cũng là ngày mở Mùa 2 của hành trình. Mùa 1 xây một thói quen then chốt qua nhiều tuần. Mùa 2 bắt đầu bằng câu hỏi: thói quen đó phục vụ mục tiêu nào? Công thức #0034 của tuần này là Quy tắc 5/25.

**Nếu mới tham gia:** tuần đầu năm là điểm bắt đầu rất tự nhiên. Không cần biết gì về Mùa 1. Hôm nay viết vào sổ thực hành một thói quen then chốt trong công việc mà mình muốn giữ cả năm, rồi làm bài Ngày 1 như mọi người. Thứ Năm, sổ sẽ giúp nối thói quen đó với mục tiêu quan trọng nhất của mình.

**Một câu chuyện được kể rất nhiều, và một dấu hỏi**

Câu chuyện thường được kể thế này. Mike Flint, phi công riêng của Warren Buffett trong nhiều năm, một hôm được Buffett hỏi về mục tiêu nghề nghiệp. Buffett đề nghị Flint viết ra 25 mục tiêu, rồi khoanh lấy 5 mục tiêu quan trọng nhất. Flint nói sẽ tập trung vào 5 mục tiêu đó, còn 20 mục tiêu kia thì làm dần khi có thời gian. Theo câu chuyện, Buffett trả lời rằng 20 mục tiêu còn lại chính là danh sách cần tránh bằng mọi giá, cho đến khi 5 mục tiêu đầu đã xong.

Câu chuyện này được lan truyền rộng qua blog của Scott Dinsmore, rồi qua bài viết của James Clear và rất nhiều trang khác. Điều cần nói rõ: đến nay chưa có xác nhận trực tiếp nào từ Buffett. Một số bài viết còn dẫn lời tác giả Alex Banayan rằng khi được hỏi, Buffett nói ông không nhớ mình từng lập danh sách như vậy; lời kể này cũng chưa được kiểm chứng độc lập.

Vậy vì sao vẫn dùng? Vì giá trị của Quy tắc 5/25 không nằm ở tên người kể. Nó nằm ở một nhận xét rất thực tế: kế hoạch đầu năm hiếm khi hỏng vì thiếu mục tiêu. Nó hỏng vì có quá nhiều mục tiêu tốt cùng giành một quỹ thời gian có hạn.

**Nghiên cứu nền về đặt mục tiêu**

Năm 2002, Edwin Locke và Gary Latham tổng kết khoảng 35 năm nghiên cứu về đặt mục tiêu trên tạp chí American Psychologist: mục tiêu cụ thể và có độ thách thức thường đi cùng kết quả cao hơn so với lời dặn chung "cố gắng hết sức". Mục tiêu cụ thể giúp người ta tập trung sự chú ý và nỗ lực vào đúng việc. Nhưng sự chú ý có hạn. Năm mục tiêu cụ thể dễ được chú ý hơn hai mươi lăm mục tiêu cụ thể.

**Sáu ngày của tuần mở Mùa 2**

- Thứ Hai: viết 25 mục tiêu công việc cho năm 2027.
- Thứ Ba: khoanh lấy 5.
- Thứ Tư: 20 mục tiêu còn lại thành danh sách tránh.
- Thứ Năm: nối thói quen then chốt với mục tiêu số 1.
- Thứ Sáu: kế hoạch quý 1.
- Thứ Bảy: thẻ 5 mục tiêu đặt trên bàn làm việc.

Chủ Nhật nghỉ.

**Ngày 1 (30 phút): Viết 25 mục tiêu công việc năm 2027**

1. Mở sổ thực hành, xem lại thói quen đang giữ và câu bản sắc năm 2027.
2. Viết càng gần 25 mục tiêu càng tốt, chia theo năm nhóm có sẵn trên sổ: kết quả công việc; kỹ năng và chuyên môn; khách hàng và quan hệ; đội nhóm và cách làm việc; học tập và phát triển.
3. Đừng lọc vội. Hôm nay chỉ viết. Mục tiêu nhỏ, mục tiêu lớn, mục tiêu đã ấp ủ lâu đều ghi vào.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-1.

Chia sẻ hôm nay: "Tôi đã viết ... mục tiêu công việc cho năm 2027. Nhóm có nhiều mục tiêu nhất: ...".

Danh sách 25 mục tiêu là của riêng mình, các anh chị và các bạn chỉ cần chia sẻ con số và nhóm nhiều nhất thôi nha.


## Bài 2: Ngày 2 (Thứ Ba 05/01)
@img 2_khoanh-5
@pdf 10XHub_QuyTac525_PhieuNgay2_khoanh-5.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: KHOANH LẤY 5 MỤC TIÊU QUAN TRỌNG NHẤT

Viết 25 mục tiêu là phần dễ. Khoanh lấy 5 mới là phần khó, vì mục tiêu nào trong danh sách cũng có lý do để ở lại. Hôm nay là một danh sách câu hỏi lọc. Đọc từng mục tiêu, đi qua các câu dưới đây.

**Bảy câu hỏi để lọc**

1. **Nếu cả năm chỉ đạt được một mục tiêu, đó là mục tiêu nào?** Mục tiêu đó là số 1. Thường đó là mục tiêu mà khi đạt được, nhiều mục tiêu khác cũng dễ đi theo.
2. **Mục tiêu này có gắn với vai trò chính của mình năm 2027 không?** Một trưởng nhóm kinh doanh mới lên chức có thể có rất nhiều mục tiêu cá nhân hay, nhưng mục tiêu về đội nhóm thường quan trọng hơn trong năm đầu.
3. **Cuối năm, mình có biết đã đạt hay chưa không?** Mục tiêu cần đo được hoặc thấy được kết quả. "Giỏi tiếng Anh hơn" khó biết. "Thuyết trình được với khách hàng nước ngoài không cần người hỗ trợ" thì biết được.
4. **Phần lớn kết quả có nằm trong tầm ảnh hưởng của mình không?** Doanh số của cả công ty không nằm trong tay một người. Số khách hàng mình gặp mỗi tuần thì có.
5. **Mục tiêu này có trùng với mục tiêu khác không?** Gộp những mục tiêu trùng nhau thành một.
6. **Nếu bỏ mục tiêu này, mình có thấy tiếc thật sự không?** Có những mục tiêu ở trong danh sách chỉ vì nghe hay.
7. **Mục tiêu này của mình hay của người khác?** Có mục tiêu do cấp trên giao, cần làm. Có mục tiêu chỉ vì người khác mong mình làm. Phân biệt hai loại này trước khi chọn.

Đi hết bảy câu, danh sách thường rút từ 25 xuống còn 8 đến 10. Từ đó chọn 5, xếp theo thứ tự, mục tiêu số 1 đứng đầu.

Một lưu ý về mục tiêu do công ty giao: nếu chỉ tiêu năm của bộ phận đã có, nên đặt nó vào 5 mục tiêu, hoặc chọn một mục tiêu cá nhân đóng góp trực tiếp cho chỉ tiêu đó. Quy tắc 5/25 dùng để tập trung, không phải để bỏ qua trách nhiệm đã nhận.

**Ngày 2 (25 phút)**

1. Đọc lại 25 mục tiêu viết hôm qua, đi qua bảy câu hỏi lọc.
2. Chọn 5 mục tiêu, xếp thứ tự, viết lại cho cụ thể và đo được.
3. Đánh dấu ba ô kiểm tra trên sổ cho cả 5 mục tiêu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-2.

Chia sẻ hôm nay: "Năm mục tiêu công việc năm 2027 của tôi: 1) ...; 2) ...; 3) ...; 4) ...; 5) ...".


## Bài 3: Ngày 3 (Thứ Tư 06/01)
@img 3_danh-sach-tranh
@pdf 10XHub_QuyTac525_PhieuNgay3_danh-sach-tranh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: 20 MỤC TIÊU CÒN LẠI LÀ DANH SÁCH TRÁNH

Phần đáng nhớ nhất của Quy tắc 5/25 không nằm ở 5 mục tiêu được chọn. Nó nằm ở cách đối xử với 20 mục tiêu còn lại. Hôm nay giải nghĩa từng chữ trong ý tưởng đó.

**"Còn lại" nghĩa là gì?**

Hai mươi mục tiêu còn lại không phải mục tiêu xấu. Phần lớn là mục tiêu tốt, thậm chí rất tốt. Chính vì tốt nên chúng nguy hiểm: chúng có đủ lý do để lấy đi một buổi chiều, một cuối tuần, một phần sự chú ý của 5 mục tiêu chính.

**"Tránh" nghĩa là gì?**

Trong câu chuyện, Flint định làm dần 20 mục tiêu kia "khi có thời gian". Câu trả lời được gán cho Buffett là: không, tránh chúng cho đến khi 5 mục tiêu đầu đã xong. Tránh ở đây không có nghĩa là xoá. Nó có nghĩa là không đầu tư thời gian và sức lực vào chúng trong giai đoạn này. Danh sách vẫn được giữ lại, để xem lại vào cuối quý.

**"Làm sau" khác "tránh" ở chỗ nào?**

"Làm sau" vẫn chiếm một chỗ trong đầu. Mỗi lần có chút thời gian rảnh, mục tiêu đó lại hiện ra và đòi được làm. "Tránh" là một quyết định đã đưa ra từ trước, nên khi cơ hội đến, mình không phải quyết định lại.

**"Nói không" trong công việc nghĩa là gì?**

Danh sách tránh còn giúp trả lời những lời mời hấp dẫn: một dự án phụ thú vị, một khoá học hay nhưng chưa cần, một nhóm công tác mới. Nói không ở chỗ làm cần lịch sự và có lý do. Một câu soạn sẵn giúp việc đó dễ hơn nhiều: "Cảm ơn anh đã nghĩ đến em. Quý này em đang tập trung cho mục tiêu mở rộng nhóm khách hàng doanh nghiệp, nên em xin hẹn lại vào tháng 4."

**"Ba mục tiêu hấp dẫn nhất" nghĩa là gì?**

Trong 20 mục tiêu, thường có vài mục tiêu đặc biệt hấp dẫn: dễ làm, vui, hoặc được người khác khen. Đó là những mục tiêu dễ lấn sang thời gian của 5 mục tiêu chính nhất. Ghi tên ba mục tiêu này ra, để nhận ra chúng khi chúng xuất hiện.

**Ngày 3 (20 phút)**

1. Chép 20 mục tiêu còn lại vào ô danh sách tránh trên sổ.
2. Khoanh ba mục tiêu hấp dẫn nhất, ghi lý do vì sao chúng hấp dẫn.
3. Soạn sẵn một câu từ chối lịch sự cho những lời mời ngoài 5 mục tiêu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-3.

Chia sẻ hôm nay: "Danh sách tránh của tôi bắt đầu bằng: .... Câu tôi dùng để nói không: ...".


## Bài 4: Ngày 4 (Thứ Năm 07/01)
@img 4_noi-thoi-quen
@pdf 10XHub_QuyTac525_PhieuNgay4_noi-thoi-quen.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: NỐI THÓI QUEN THEN CHỐT VỚI MỤC TIÊU SỐ 1

**Một tình huống minh hoạ**

Anh Khoa là trưởng nhóm kinh doanh khách hàng doanh nghiệp. Thói quen then chốt anh giữ suốt Mùa 1 là "viết ba việc quan trọng nhất trước 8 giờ". Anh giữ khá đều, và anh thấy ngày làm việc có trật tự hơn.

Thứ Ba, anh chọn mục tiêu số 1 của năm 2027: "có 12 khách hàng doanh nghiệp mới ký hợp đồng trong năm". Thứ Năm, khi đặt thói quen và mục tiêu cạnh nhau, anh nhận ra một điều: ba việc quan trọng mỗi sáng của anh thường là xử lý đơn hàng, họp nội bộ, trả lời khách cũ. Rất ít khi có việc nào đưa anh lại gần một khách hàng mới.

Thói quen tốt, mục tiêu rõ, nhưng hai điều đó chưa nối với nhau.

Anh có ba cách. Giữ nguyên thói quen nhưng thêm một quy định nhỏ: trong ba việc quan trọng mỗi sáng, luôn có ít nhất một việc hướng tới khách hàng mới. Nâng cấp thói quen thành "viết ba việc quan trọng nhất và gửi một lời chào hàng tới một khách hàng tiềm năng trước 9 giờ". Hoặc đổi hẳn thói quen, nếu thói quen cũ không còn liên quan. Anh chọn cách đầu tiên, vì nó giữ được tín hiệu và nhịp mà anh đã mất ba tháng để xây.

**Ba câu hỏi để nối**

Tình huống trên chỉ là minh hoạ, nhưng ba câu hỏi anh Khoa tự hỏi dùng được cho mọi vị trí:

1. Mỗi lần làm thói quen, mình có tiến gần hơn tới mục tiêu số 1 không?
2. Nếu chưa, có thể thay đổi nhỏ nào để mỗi lần làm thói quen đều đóng góp cho mục tiêu?
3. Thay đổi đó có giữ được tín hiệu và khung giờ cũ không?

Vài ví dụ nối khác:

- Kế toán, mục tiêu số 1 là chốt sổ tháng trong 3 ngày: thói quen đối chiếu số liệu cuối ngày giữ nguyên, thêm ghi lại một khoản chênh lệch cần xử lý sớm.
- Nhân sự, mục tiêu số 1 là giảm tỷ lệ nghỉ việc của nhân viên mới: thói quen ghi nhận một đồng nghiệp mỗi ngày ưu tiên nhân viên mới vào làm.
- Kỹ thuật, mục tiêu số 1 là giảm thời gian dừng máy: thói quen ghi một điểm cải tiến mỗi ca tập trung vào nguyên nhân dừng máy.

**Ngày 4 (20 phút)**

1. Đặt thói quen then chốt và mục tiêu số 1 cạnh nhau trên sổ.
2. Chọn: đã nối thẳng, cần nâng cấp, hay cần đổi.
3. Viết một câu: mỗi lần làm thói quen giúp mục tiêu số 1 bằng cách nào.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-4.

Chia sẻ hôm nay: "Thói quen ... đưa tôi tới mục tiêu số 1 (...) bằng cách ...".


## Bài 5: Ngày 5 (Thứ Sáu 08/01)
@img 5_quy-1
@pdf 10XHub_QuyTac525_PhieuNgay5_quy-1.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: KẾ HOẠCH QUÝ 1 TRÊN MỘT TRANG

Một năm là một khoảng thời gian dài. Quý 1 thì đủ gần để thấy rõ, đủ dài để làm được việc có ý nghĩa. Hôm nay đặt mục tiêu số 1 vào ba tháng đầu năm, theo dạng một bảng mốc.

**Quý 1 năm 2027 trông như thế nào?**

- Tháng 1: từ hôm nay đến cuối tháng còn khoảng ba tuần làm việc. Đây là giai đoạn khởi động: chuẩn bị nguồn lực, thử cách làm, ghi lại con số đầu tiên.
- Tháng 2: tháng có kỳ nghỉ Tết Nguyên Đán, nên số ngày làm việc ít hơn hẳn. Mốc của tháng 2 nên khiêm tốn, và nên có sẵn kế hoạch giữ thói quen trong những ngày nghỉ.
- Tháng 3: tháng làm việc trọn vẹn. Mốc cuối quý thường đặt ở đây.

**Ba mốc, một con số theo dõi**

Với mục tiêu số 1, viết ba mốc: cuối tháng 1, cuối tháng 2, cuối tháng 3. Mỗi mốc là một kết quả thấy được, không phải một việc làm. Ví dụ với mục tiêu "12 khách hàng doanh nghiệp mới trong năm":

- Cuối tháng 1: danh sách 40 khách hàng tiềm năng đã được sàng lọc.
- Cuối tháng 2: 10 buổi gặp đã diễn ra.
- Cuối tháng 3: 2 hợp đồng đầu tiên đã ký.

Sau đó chọn một con số theo dõi mỗi tuần, con số mình kiểm soát được: số cuộc gọi chào hàng, số buổi gặp, số bản đề xuất đã gửi. Con số tuần cho biết sớm mình đang đi đúng hay lệch, trước khi đến mốc tháng.

**Còn bốn mục tiêu kia?**

Mục tiêu số 2 đến số 5 cũng cần mốc quý 1, nhưng có thể đơn giản hơn: một mốc cuối quý cho mỗi mục tiêu là đủ. Sức chú ý lớn nhất trong quý dành cho mục tiêu số 1.

**Kế hoạch cho Tết Nguyên Đán**

Mùa 1 đã có kế hoạch Nếu... thì... và lá chắn cuối năm. Tết Nguyên Đán là lúc dùng lại: viết sẵn phiên bản nhỏ nhất của thói quen cho những ngày nghỉ, và ngày đi làm lại đầu tiên sau Tết.

**Ngày 5 (25 phút)**

1. Viết ba mốc tháng cho mục tiêu số 1.
2. Chọn một con số theo dõi mỗi tuần.
3. Viết một mốc cuối quý cho mỗi mục tiêu số 2 đến số 5.
4. Viết kế hoạch giữ thói quen trong kỳ nghỉ Tết Nguyên Đán.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-5.

Chia sẻ hôm nay: "Mốc quý 1 của mục tiêu số 1: .... Tôi theo dõi mỗi tuần bằng: ...".


## Bài 6: Ngày 6 (Thứ Bảy 09/01)
@img 6_the-5-muc-tieu
@img2 9_the-thanh-tich
@pdf 10XHub_QuyTac525_PhieuNgay6_the-5-muc-tieu.pdf (phiếu thực hành và thẻ 5 mục tiêu in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: THẺ 5 MỤC TIÊU ĐẶT TRÊN BÀN LÀM VIỆC

Đầu năm, nhiều văn phòng có những bảng mục tiêu được treo rất đẹp. Đến tháng 3, phần lớn đã thành một phần của bức tường. Hôm nay đặt hai cách làm cạnh nhau.

**Mục tiêu treo tường và mục tiêu có thói quen đi kèm**

- Nơi ở: mục tiêu treo tường nằm ở chỗ mọi người đều thấy, nhưng ít ai nhìn kỹ. Thẻ 5 mục tiêu nằm ngay trên bàn, cạnh tín hiệu của thói quen then chốt.
- Số lượng: bảng treo tường thường liệt kê nhiều mục tiêu. Thẻ chỉ có 5, và một danh sách tránh.
- Nhịp nhìn lại: mục tiêu treo tường được nhắc lại vào cuộc họp tổng kết. Thẻ được nhìn mỗi sáng, khi làm thói quen.
- Đường đi tới mục tiêu: mục tiêu treo tường chỉ có đích. Thẻ có thêm thói quen mỗi ngày, mốc mỗi tháng và con số mỗi tuần.

Không phải bảng treo tường vô ích. Nó cho cả nhóm thấy hướng đi chung. Nhưng với mỗi người, một tấm thẻ nhỏ đặt đúng chỗ, gắn với một thói quen đã có, thường được nhìn thấy nhiều hơn.

**Thẻ 5 mục tiêu**

Phiếu Ngày 6 có sẵn thẻ 5 mục tiêu khổ nhỏ để in. Sổ thực hành cũng gom sẵn mọi điều đã viết trong tuần: năm mục tiêu, danh sách tránh, thói quen then chốt, câu bản sắc năm 2027. Điền thẻ, đặt ngay cạnh tín hiệu của thói quen: trên bàn phím, cạnh màn hình, trong sổ kế hoạch.

**Tuần sau: Bảng Kanban cá nhân**

Tuần này chọn mục tiêu. Tuần sau, Công thức #0035 Bảng Kanban cá nhân, bắt đầu Thứ Hai 11.01, biến 5 mục tiêu và kế hoạch quý 1 thành những việc cụ thể trên một bảng nhiều cột, để nhìn thấy mọi việc đang làm và không ôm quá nhiều việc cùng lúc. Thói quen then chốt tiếp tục là trục của cả Mùa 2.

**Ngày 6 (20 phút)**

1. Mở sổ thực hành, đọc lại bảng gom cả tuần.
2. Điền thẻ 5 mục tiêu (in từ phiếu Ngày 6 hoặc viết tay).
3. Đặt thẻ cạnh tín hiệu của thói quen then chốt, ghi chỗ đặt vào sổ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0034-ngay-6.

Chia sẻ hôm nay: "Năm 2027, tôi tập trung vào 5 mục tiêu. Mục tiêu số 1: .... Thẻ của tôi đặt ở: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích tuần đầu Mùa 2 hiện ra: một khung với số 5 lớn, chữ "mục tiêu năm 2027", tên mình và mục tiêu số 1. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần đầu tiên của năm 2027 đã khép lại với 5 mục tiêu rõ ràng.
