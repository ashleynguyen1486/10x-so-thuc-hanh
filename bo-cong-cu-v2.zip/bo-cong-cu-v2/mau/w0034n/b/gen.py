import sys, os, random
sys.path.insert(0, '/tmp/f30/b')
from bkit import page, render
D = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(D)); from nbnum import nb
LC = '<img class="abs" src="img/logo_c_crop.png" style="{}">'
LW = '<img class="abs" src="img/logo_w_crop.png" style="{}">'
R = '#862222'; R2 = '#7b1f23'; CR = '#FBF5F4'; PINK = '#F2DEDB'
B = {}
random.seed(3)

# 1 Mở tuần: 25 giấy ghi chú, gạch còn 5
keep5 = {2, 8, 11, 17, 23}
notes = ''.join(f'''<div style="width:150px;height:150px;background:{R if i in keep5 else "#fff"};transform:rotate({random.uniform(-4,4):.1f}deg);box-shadow:0 8px 16px rgba(35,31,32,.10);position:relative;display:flex;align-items:center;justify-content:center;font-size:40px;font-weight:900;color:{"#fff" if i in keep5 else "#D8C3C0"}">{i+1}
{"" if i in keep5 else '<div style="position:absolute;left:18px;right:18px;top:50%;height:6px;background:#C9A9A6;transform:rotate(-18deg)"></div>'}</div>''' for i in range(25))
B['1_mo-tuan'] = f'''<div class="abs" style="left:120px;top:170px;width:780px">
<div class="k" style="color:{R};white-space:nowrap">Công thức #0034 · Mở Mùa 2</div>
<div class="fit" data-max="92" data-min="64" style="width:830px;margin-top:34px">Mở Mùa 2: 25 mục tiêu, <span style="color:{R}">giữ lại 5</span></div>
<div style="font-size:34px;line-height:1.5;color:#4a3a3a;margin-top:40px">Hai mươi mục tiêu còn lại không phải để làm sau. Đó là danh sách tránh, cho đến khi năm mục tiêu đầu đã xong.</div></div>
{LC.format("left:120px;bottom:70px;height:100px")}
<div class="abs" style="left:1000px;top:110px;display:grid;grid-template-columns:repeat(5,150px);gap:22px">{notes}</div>'''

# 2 Khoanh 5: phễu lọc
dots_in = ''.join(f'<circle cx="{560+ (i%9)*58 + (29 if (i//9)%2 else 0)}" cy="{150+(i//9)*55}" r="18" fill="{R if i in {3,10,13,19,22} else "#E2CDCA"}"/>' for i in range(25))
B['2_khoanh-5'] = f'''<svg class="abs" style="left:700px;top:0" width="1220" height="1080">
{dots_in}
<path d="M 470 330 L 1130 330 L 880 700 L 880 860 L 720 860 L 720 700 Z" fill="#fff" stroke="{R}" stroke-width="8" stroke-linejoin="round"/>
{''.join(f'<line x1="{560+i*90}" y1="390" x2="{560+i*90}" y2="{410+ (i%2)*20}" stroke="#E2CDCA" stroke-width="6"/>' for i in range(7))}
<text x="800" y="520" text-anchor="middle" font-family="Be Vietnam Pro" font-weight="800" font-size="36" fill="{R}" letter-spacing="4">7 CÂU HỎI</text>
<text x="800" y="570" text-anchor="middle" font-family="Be Vietnam Pro" font-weight="600" font-size="26" fill="#8a7373">LỌC</text>
{''.join(f'<circle cx="{680+i*60}" cy="950" r="24" fill="{R}"/><text x="{680+i*60}" y="959" text-anchor="middle" font-family="Be Vietnam Pro" font-weight="900" font-size="24" fill="#fff">{i+1}</text>' for i in range(5))}
</svg>
<div class="abs" style="left:120px;top:200px;width:820px">
<div class="k" style="color:{R}">Ngày 2 / 6 · Khoanh 5</div>
<div class="fit" data-max="88" data-min="64" style="width:760px;margin-top:30px">Bảy câu hỏi để <span style="color:{R}">khoanh lấy 5</span></div>
<div style="font-size:32px;line-height:1.5;color:#4a3a3a;margin-top:40px;max-width:640px">Cả năm chỉ đạt một mục tiêu thì đó là mục tiêu nào? Câu trả lời là mục tiêu số 1.</div></div>
{LC.format("left:120px;bottom:70px;height:100px")}'''

# 3 Danh sách tránh: hai cột
five = ['12 khách hàng doanh nghiệp mới', 'Kế hoạch phát triển cho từng thành viên', 'Thuyết trình không cần người hỗ trợ', 'Gặp 20 khách hàng lớn nhất', 'Họp giao ban gọn 20 phút']
avoid = ['Mở kênh chia sẻ trên mạng xã hội', 'Học thiết kế đồ hoạ', 'Viết sách chuyên môn', 'Nhóm tổ chức sự kiện', 'Thiết kế lại mẫu báo giá', 'Học thêm phần mềm phân tích']
B['3_danh-sach-tranh'] = f'''<div class="abs" style="left:0;top:0;width:1920px;height:300px;background:{R}"></div>
<div class="abs" style="left:120px;top:80px;color:#fff"><div class="k" style="color:#F2C9C9">Ngày 3 / 6 · Danh sách tránh</div>
<div class="fit" data-max="92" data-min="64" style="width:1460px;margin-top:24px">Danh sách tránh: không phải làm sau</div></div>
{LW.format("right:120px;top:100px;height:100px")}
<div class="abs" style="left:120px;top:370px;width:780px"><div style="font-size:28px;font-weight:900;letter-spacing:.16em;color:{R};border-bottom:5px solid {R};padding-bottom:16px">5 MỤC TIÊU</div>
{''.join(f'<div style="display:flex;gap:24px;align-items:center;padding:18px 0;border-bottom:2px solid #EADBD8"><div style="width:52px;height:52px;border-radius:50%;background:{R};color:#fff;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:900;flex:none">{i+1}</div><div style="font-size:32px;font-weight:700">{t}</div></div>' for i,t in enumerate(five))}</div>
<div class="abs" style="left:1010px;top:370px;width:790px"><div style="font-size:28px;font-weight:900;letter-spacing:.16em;color:#a07c7c;border-bottom:5px solid #D8C3C0;padding-bottom:16px">DANH SÁCH TRÁNH · 20 MỤC TIÊU</div>
{''.join(f'<div style="padding:18px 0;border-bottom:2px solid #EADBD8;font-size:30px;color:#a59090;text-decoration:line-through;text-decoration-thickness:3px">{t}</div>' for t in avoid)}
<div style="font-size:26px;color:#a07c7c;margin-top:16px">... và 14 mục tiêu khác, xem lại cuối quý</div></div>'''

# 4 Nối thói quen: cầu nối hai khối
B['4_noi-thoi-quen'] = f'''<div class="abs" style="left:0;top:0;width:1920px;height:640px;background:{R}"></div>
<div class="abs" style="left:150px;top:180px;width:600px;height:300px;background:#fff;border-radius:30px;padding:50px;box-shadow:0 30px 50px rgba(0,0,0,.18)">
<div style="font-size:24px;font-weight:800;letter-spacing:.18em;color:#a07c7c">THÓI QUEN THEN CHỐT</div>
<div class="serif" style="font-size:40px;font-style:italic;margin-top:24px;line-height:1.3">Viết ba việc quan trọng nhất trước 8 giờ</div></div>
<div class="abs" style="left:1170px;top:180px;width:600px;height:300px;background:#fff;border-radius:30px;padding:50px;box-shadow:0 30px 50px rgba(0,0,0,.18)">
<div style="font-size:24px;font-weight:800;letter-spacing:.18em;color:{R}">MỤC TIÊU SỐ 1</div>
<div class="serif" style="font-size:40px;font-style:italic;margin-top:24px;line-height:1.3">12 khách hàng doanh nghiệp mới trong năm 2027</div></div>
<svg class="abs" style="left:750px;top:250px" width="420" height="160">
<rect x="0" y="66" width="420" height="28" fill="#fff"/>
<rect x="120" y="30" width="110" height="100" rx="50" fill="none" stroke="#fff" stroke-width="22"/>
<rect x="190" y="30" width="110" height="100" rx="50" fill="none" stroke="#F2C9C9" stroke-width="22"/></svg>
<div class="abs" style="left:0;top:540px;width:1920px;text-align:center;color:#F2C9C9;font-size:30px;font-weight:700;letter-spacing:.06em">Câu nối: trong ba việc quan trọng, luôn có một việc hướng tới khách hàng mới</div>
<div class="abs" style="left:120px;top:720px"><div class="k" style="color:{R}">Ngày 4 / 6 · Thứ Năm 07.01</div>
<div class="fit" data-max="100" data-min="64" style="width:1400px;margin-top:24px">Nối thói quen với <span style="color:{R}">mục tiêu số 1</span></div>
<div style="font-size:32px;color:#4a3a3a;margin-top:26px">Giữ tín hiệu và khung giờ cũ, để mỗi lần làm thói quen là một bước tới mục tiêu.</div></div>
{LC.format("right:120px;bottom:70px;height:100px")}'''

# 5 Quý 1: dòng thời gian 13 tuần
weeks = ''.join(f'<div style="width:112px;height:{90 if i not in (5,6) else 50}px;background:{PINK if i in (5,6) else ("#E7D3D0" if i%4 else "#DCC4C0")};border-radius:8px 8px 0 0;align-self:flex-end"></div>' for i in range(13))
flags = [(2, 'CUỐI THÁNG 1', '40 khách hàng tiềm năng'), (7, 'CUỐI THÁNG 2', '10 buổi gặp'), (12, 'CUỐI THÁNG 3', '2 hợp đồng đầu tiên')]
fl = ''.join(f'''<div class="abs" style="left:{120+i*124+40}px;top:480px;width:6px;height:330px;background:{R}"></div>
<div class="abs" style="left:{120+i*124+46 - (300 if i==12 else 0)}px;top:480px;width:300px;background:{R};color:#fff;padding:18px 22px"><div style="font-size:22px;font-weight:800;letter-spacing:.14em;opacity:.85">{a}</div><div style="font-size:30px;font-weight:800;margin-top:6px">{b}</div></div>''' for i, a, b in flags)
B['5_quy-1'] = f'''<div class="abs" style="left:120px;top:110px"><div class="k" style="color:{R}">Ngày 5 / 6 · Thứ Sáu 08.01</div>
<div class="fit" data-max="100" data-min="64" style="width:1300px;margin-top:24px">Kế hoạch quý 1 <span style="color:{R}">trên một trang</span></div>
<div style="font-size:32px;color:#4a3a3a;margin-top:26px">Ba mốc tháng là kết quả. Một con số mỗi tuần là việc mình làm.</div></div>
{LC.format("right:120px;top:110px;height:100px")}
{fl}
<div class="abs" style="left:120px;top:720px;width:1680px;display:flex;gap:12px;height:90px">{weeks}</div>
<div class="abs" style="left:120px;top:810px;width:1680px;border-top:6px solid #231F20"></div>
<div class="abs" style="left:120px;top:830px;width:1680px;display:flex;gap:12px">{''.join(f'<div style="width:112px;text-align:center;font-size:22px;font-weight:700;color:{"#c08a86" if i in (5,6) else "#8a7373"}">T{i+1}</div>' for i in range(13))}</div>
<div class="abs" style="left:{120+5*124}px;top:890px;width:236px;text-align:center;font-size:24px;font-weight:700;color:{R}">Tết Nguyên Đán</div>
<div class="abs" style="left:120px;top:960px;font-size:24px;color:#8a7373">Ví dụ minh hoạ với mục tiêu 12 khách hàng doanh nghiệp mới trong năm</div>'''

# 6 Thẻ 5 mục tiêu trên bàn: bàn phím và tấm thẻ nhìn từ trên xuống
keys = ''.join(f'<div style="height:44px;background:#fff;border-radius:6px;box-shadow:0 3px 0 #D8C3C0"></div>' for _ in range(42))
B['6_the-5-muc-tieu'] = f'''<div class="abs" style="left:0;top:0;width:960px;height:1080px;background:{R}"></div>
<div class="abs" style="left:110px;top:170px;width:780px;color:#fff">
<div class="k" style="color:#F2C9C9">Ngày 6 / 6 · Thứ Bảy 09.01</div>
<div class="fit" data-max="84" data-min="64" style="width:770px;margin-top:30px">Thẻ 5 mục tiêu trên bàn làm việc</div>
<div style="font-size:32px;line-height:1.5;margin-top:40px;opacity:.95">Đặt ngay cạnh tín hiệu của thói quen then chốt, nhìn thấy mỗi sáng.</div></div>
{LW.format("left:110px;bottom:70px;height:100px")}
<div class="abs" style="left:1060px;top:650px;width:740px;height:320px;background:#EFE4E2;border-radius:22px;padding:30px;display:grid;grid-template-columns:repeat(14,1fr);gap:9px">{keys}</div>
<div class="abs" style="left:1150px;top:100px;width:570px;height:520px;background:#fff;transform:rotate(-3deg);box-shadow:0 26px 50px rgba(35,31,32,.18);padding:44px 50px;border-top:12px solid {R}">
<div style="font-size:30px;font-weight:900;color:{R};letter-spacing:.06em">5 MỤC TIÊU NĂM 2027</div>
{''.join(f'<div style="display:flex;gap:20px;align-items:center;border-bottom:3px solid #EFE2E0;padding:13px 0"><div style="font-size:28px;font-weight:900;color:{R if i==0 else "#c9a9a6"};width:30px">{i+1}</div><div style="height:12px;width:{w}px;background:{"#E7D3D0"};border-radius:6px"></div></div>' for i,w in enumerate([400,340,380,300,360]))}
<div style="display:flex;gap:20px;align-items:center;padding:13px 0"><div style="font-size:22px;font-weight:800;color:#a07c7c;letter-spacing:.1em">TRÁNH</div><div style="height:12px;width:300px;background:#EFE2E0;border-radius:6px"></div></div></div>'''

# 9 Thẻ thành tích: năm ô xếp hạng
sq = ''.join(f'<div style="width:{300 if i==0 else 190}px;height:{300 if i==0 else 190}px;{"background:"+R+";color:#fff" if i==0 else "border:6px solid "+R+";color:"+R};display:flex;flex-direction:column;align-items:center;justify-content:center;align-self:flex-end"><div style="font-size:{150 if i==0 else 96}px;font-weight:900;line-height:1">{i+1}</div>{"<div style=\'font-size:24px;font-weight:800;letter-spacing:.16em;margin-top:10px\'>SỐ 1</div>" if i==0 else ""}</div>' for i in range(5))
B['9_the-thanh-tich'] = f'''<div class="abs" style="left:60px;top:60px;right:60px;bottom:60px;border:3px solid #E2CFCC"></div>
<div class="abs" style="left:0;top:120px;width:1920px;text-align:center"><div class="k" style="color:{R}">Thẻ thành tích · Công thức #0034 · Mùa 2</div></div>
<div class="abs fit" data-max="92" data-min="64" style="left:210px;top:180px;width:1500px;text-align:center">Thẻ thành tích: <span style="color:{R}">5 mục tiêu 2027</span></div>
<div class="abs" style="left:0;top:400px;width:1920px;display:flex;justify-content:center;gap:40px">{sq}</div>
<div class="abs" style="left:0;top:760px;width:1920px;text-align:center;font-size:32px;color:#4a3a3a">Dành cho thành viên đã chia sẻ đủ 6 ngày của tuần đầu Mùa 2</div>
{LC.format("left:910px;top:850px;height:100px")}'''

for k, v in B.items():
    open(f'{D}/{k}.html', 'w').write(page(nb(v)))
render(D, '10XHub_QuyTac525_')
