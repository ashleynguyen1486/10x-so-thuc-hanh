import sys,asyncio,os;sys.path.insert(0,'/tmp/f30/b');from vnkeep import keep
D=os.path.dirname(os.path.abspath(__file__));os.chdir(D);sys.path.insert(0,os.path.dirname(D));from nbnum import nb
H=open('head.html').read()
def ft(n):return f'<div class="ft"><span>10X Excellence Hub · Hướng dẫn sổ thực hành tuần Quy tắc 5/25</span><span>{n}</span></div>'
def bar(r):return f'<div class="bar"><span>CÔNG THỨC #0034 · QUY TẮC 5/25 · MÙA 2</span><span>{r}</span></div>'
def st(n,h,ps,img,style=''):return f'<div class="step"><div><div class="st"><span class="num">{n}</span><h2>{h}</h2></div>{"".join("<p>"+p+"</p>" for p in ps)}</div><img class="shot" src="{img}" style="{style}"></div>'
P=[]
P.append(f'''<div class="page"><div class="hd"><div><div class="k">10X EXCELLENCE HUB · TUẦN 04.01 ĐẾN 09.01.2027</div><h1>Sổ thực hành<br>tuần mở Mùa 2</h1></div><img src="logo_w_crop.png"></div><div class="ct">
<p class="lead">Tuần đầu năm 2027, sổ thực hành có thêm <b>năm ô mục tiêu</b> và <b>một ô danh sách tránh</b>, được lưu cho cả hành trình như thói quen then chốt. Các tuần sau của Mùa 2 sẽ dùng lại năm mục tiêu này. Tài liệu này đi theo đúng thứ tự các ngày.</p>
<div class="box"><b class="t">Đường dẫn</b><span class="link">10xexcellence.co/so-thuc-hanh#0034-ngay-1</span><br>Đổi số cuối thành 2 đến 6 để mở thẳng ngày khác. Bài đăng mỗi ngày đều có sẵn đường dẫn đúng ngày.</div>
{st(1,'Mở đúng tuần',['Trên hàng tuần dưới logo, chọn thẻ <b>Từ ngày 04.01 - 09.01.2027</b>. Sáu ô Ngày 1 đến Ngày 6 là Thứ Hai đến Thứ Bảy.','Thói quen then chốt và câu bản sắc năm 2027 từ tuần trước tự hiện lại ở đầu Ngày 1. Người mới viết vào hai ô bên dưới.'],'s0.png','height:105mm;object-fit:cover;object-position:top')}
<div class="box"><b class="t">Sáu ngày trên sổ</b><ul style="padding-left:5mm">
<li><b>Ngày 1:</b> năm ô lớn cho năm nhóm mục tiêu, ô đếm và nút chọn nhóm nhiều nhất.</li>
<li><b>Ngày 2:</b> bảy câu hỏi lọc, năm ô mục tiêu lưu cho cả hành trình, ba ô kiểm tra.</li>
<li><b>Ngày 3:</b> ô danh sách tránh, ba mục tiêu hấp dẫn nhất, câu nói không.</li>
<li><b>Ngày 4:</b> thói quen và mục tiêu số 1 đặt cạnh nhau, câu nối tự ghép, bảng hành trình.</li>
<li><b>Ngày 5:</b> ba mốc tháng, con số tuần, mốc quý cho bốn mục tiêu còn lại, kế hoạch Tết.</li>
<li><b>Ngày 6:</b> bảng gom cả tuần, chỗ đặt thẻ, thẻ thành tích.</li></ul></div>
</div>{ft(1)}</div>''')
P.append(f'''<div class="page">{bar('NGÀY 1 VÀ NGÀY 2')}<div class="ct">
{st(2,'Viết theo năm nhóm',['Mỗi nhóm là một ô lớn, <b>mỗi dòng một mục tiêu</b> (bấm xuống dòng trong ô). Hôm nay chỉ viết, chưa lọc.','Viết xong, nhập con số vào ô <b>Tôi đã viết được bao nhiêu mục tiêu?</b> và bấm nhóm có nhiều mục tiêu nhất. Câu chia sẻ chỉ hiện con số và nhóm, danh sách là của riêng mình.'],'s1.png','max-height:150mm;object-fit:cover;object-position:bottom')}
{st(3,'Năm ô mục tiêu',['Ngày 2: điền năm mục tiêu đã chọn, mục tiêu số 1 ở ô đầu tiên. Năm ô này <b>được lưu cho cả hành trình</b>, các tuần sau và thẻ thành tích tự dùng lại.'],'s2.png')}
</div>{ft(2)}</div>''')
P.append(f'''<div class="page">{bar('CÔNG CỤ RIÊNG CỦA TUẦN')}<div class="ct">
{st(4,'Danh sách tránh',['Ngày 3: chép 20 mục tiêu còn lại vào ô lớn. Ghi ba mục tiêu hấp dẫn nhất vào ô riêng, rồi bấm lý do vì sao chúng hấp dẫn, mỗi lý do có giải thích.','Ô câu nói không giúp trả lời lịch sự những lời mời ngoài năm mục tiêu.'],'s3.png')}
{st(5,'Câu nối tự ghép',['Ngày 4: sổ đặt thói quen then chốt cạnh mục tiêu số 1. Bấm tình trạng (đã nối thẳng, cần điều chỉnh nhỏ, cần đổi), viết cách nối. Sổ tự ghép câu <b>Mỗi ngày ..., để tiến tới ...</b> trong khung đỏ.','Bảng hành trình tuần này nằm ở cuối Ngày 4.'],'s4.png')}
{st(6,'Ba mốc quý 1',['Ngày 5: ba ô mốc cuối tháng 1, 2, 3 và một ô con số theo dõi mỗi tuần. Bên dưới có bảng tự hiện mục tiêu số 2 đến số 5 để viết mốc cuối quý.'],'s5.png','max-height:90mm;object-fit:cover;object-position:top')}
</div>{ft(3)}</div>''')
P.append(f'''<div class="page">{bar('NGÀY 6 VÀ THẺ THÀNH TÍCH')}<div class="ct">
{st(7,'Bảng gom cả tuần',['Ngày 6 gom câu bản sắc năm 2027, năm mục tiêu, danh sách tránh, thói quen, mốc quý 1, con số tuần. Đây là nội dung để chép sang thẻ 5 mục tiêu in ở phiếu Ngày 6.','Ô hiện dấu ba chấm là ngày đó chưa điền.'],'s6.png','max-height:95mm;object-fit:cover;object-position:top')}
{st(8,'Thẻ thành tích số 5',['Đủ 6 ngày đã chia sẻ, thẻ hiện ra với khung số 5, chữ "mục tiêu năm 2027", tên mình và mục tiêu số 1. Bấm <b>Tải thẻ thành tích</b> và đăng vào bình luận bài Thứ Bảy.'],'s7.png')}
<div class="box qa"><b class="t">Hỏi nhanh</b>
<p><b>Chưa viết đủ 25 mục tiêu?</b> Không sao. Viết được 15 hay 30 đều dùng được, miễn là viết hết trước khi lọc.</p>
<p><b>Có cần chia sẻ cả năm mục tiêu không?</b> Câu chia sẻ Ngày 2 ghép đủ năm mục tiêu. Nếu có mục tiêu cần giữ kín, viết gọn lại theo cách chung chung hơn trước khi dán.</p>
<p><b>Đổi mục tiêu giữa năm được không?</b> Được. Sửa trong năm ô mục tiêu ở Ngày 2, các nơi dùng lại sẽ tự cập nhật.</p></div>
</div>{ft(4)}</div>''')
open('guide.html','w').write(H+nb(keep(''.join(P)))+'</body></html>')
from playwright.async_api import async_playwright
async def m():
  async with async_playwright() as p:
    b=await p.chromium.launch();pg=await b.new_page();await pg.goto('file://'+os.path.abspath('guide.html'));await pg.wait_for_load_state('networkidle');await pg.evaluate('document.fonts.ready');await pg.wait_for_timeout(500)
    await pg.pdf(path='10XHub_HuongDan_SoThucHanh_0034.pdf',format='A4',print_background=True);await b.close()
asyncio.run(m())
