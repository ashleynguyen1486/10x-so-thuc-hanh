import asyncio,datetime,sys,subprocess,socket
from playwright.async_api import async_playwright
SP='/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
s=socket.socket();s.bind(('',0));port=s.getsockname()[1];s.close()
srv=subprocess.Popen([sys.executable,'-m','http.server',str(port)],cwd=f'{SP}/site_0034',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
U=f'http://localhost:{port}/'
BOX="el=>{el.style.outline=(el.closest('.ci')?'4px solid #ffffff':'4px solid #862222');el.style.outlineOffset='4px'}"
UNBOX="()=>document.querySelectorAll('[style*=outline]').forEach(e=>{e.style.outline='';})"
async def clip(pg,top,bot,path,pad=14,maxh=None):
    await pg.evaluate('document.activeElement && document.activeElement.blur();window.scrollTo(0,0)');await pg.wait_for_timeout(150)
    a=await pg.locator(top).first.bounding_box();b=await pg.locator(bot).first.bounding_box()
    y0=max(0,a['y']-pad);y1=b['y']+b['height']+pad
    if maxh:y1=min(y1,y0+maxh)
    await pg.screenshot(path=path,full_page=True,clip={'x':0,'y':y0,'width':390,'height':y1-y0})
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();ctx=await b.new_context(viewport={'width':390,'height':844},device_scale_factor=3)
    pg=await ctx.new_page();await pg.clock.install(time=datetime.datetime(2027,1,9,9,0))
    await pg.goto(U+'#0034-ngay-1',wait_until='networkidle');await pg.wait_for_timeout(1500)
    await pg.evaluate("()=>{localStorage.clear();localStorage.setItem('sth-journey',JSON.stringify({j_identity:'làm việc quan trọng trước khi mở hộp thư',j_habit:'viết ba việc quan trọng nhất trước 8 giờ',j_identity_2027:'giữ lời hẹn với khách hàng, dù là hẹn gọi lại',j_marks:{}}))}")
    await pg.reload(wait_until='networkidle');await pg.wait_for_timeout(1500)
    async def go(d): await pg.click(f'[data-day="{d}"]');await pg.wait_for_timeout(400)
    await pg.evaluate("document.querySelector('#weeks').scrollLeft=9999");await pg.wait_for_timeout(200)
    a=await pg.locator('header.top').bounding_box();await pg.screenshot(path='s0.png',clip={'x':0,'y':a['y']-10,'width':390,'height':700})
    await pg.fill('[data-k="d1g1"]','12 khách hàng doanh nghiệp mới\nchốt hợp đồng khung với 3 đối tác');await pg.fill('[data-k="d1g2"]','thuyết trình với khách nước ngoài không cần người hỗ trợ')
    await pg.fill('[data-k="d1count"]','23');await pg.click('[data-seg="d1most"] button >> nth=0');await pg.wait_for_timeout(300)
    await pg.locator('.card >> nth=2').evaluate(BOX);await clip(pg,'.card >> nth=1','.card >> nth=2','s1.png',pad=10,maxh=1300);await pg.evaluate(UNBOX);await pg.click('[data-done]')
    await go(2)
    for i,t in enumerate(['12 khách hàng doanh nghiệp mới','mỗi thành viên có kế hoạch phát triển riêng','thuyết trình không cần người hỗ trợ','gặp 20 khách hàng lớn nhất','họp giao ban gọn 20 phút']): await pg.fill(f'[data-k="j_goal{i+1}"]',t)
    await pg.wait_for_timeout(300);await pg.locator('input[data-k="j_goal1"]').evaluate(BOX);await clip(pg,'.card >> nth=1','.card >> nth=1','s2.png',pad=10);await pg.evaluate(UNBOX);await pg.click('[data-done]')
    await go(3);await pg.fill('[data-k="j_avoid"]','mở kênh chia sẻ trên mạng xã hội; học thiết kế; nhóm sự kiện');await pg.click('[data-seg="d3why"] button >> nth=1');await pg.fill('[data-k="d3no"]','cảm ơn anh, quý này em tập trung cho khách hàng doanh nghiệp, em xin hẹn lại tháng 4');await pg.wait_for_timeout(300)
    await pg.locator('[data-seg="d3why"]').evaluate(BOX);await clip(pg,'.card >> nth=1','.card >> nth=1','s3.png',pad=10);await pg.evaluate(UNBOX);await pg.click('[data-done]')
    await go(4);await pg.click('[data-seg="d4fit"] button >> nth=1');await pg.fill('[data-k="d4link"]','luôn có một việc hướng tới khách hàng mới trong ba việc quan trọng')
    for k in ['2027-01-04','2027-01-05','2027-01-06','2027-01-07','2027-01-08']: await pg.click(f'[data-jm="{k}"]')
    await pg.wait_for_timeout(300);await pg.locator('.card >> nth=0 >> [data-show] >> nth=2').evaluate(BOX);await clip(pg,'.card','.card','s4.png',pad=10);await pg.evaluate(UNBOX);await pg.click('[data-done]')
    await go(5);await pg.fill('[data-k="d5m1"]','danh sách 40 khách hàng tiềm năng đã sàng lọc');await pg.fill('[data-k="d5m2"]','10 buổi gặp đã diễn ra');await pg.fill('[data-k="d5m3"]','2 hợp đồng đầu tiên đã ký');await pg.fill('[data-k="d5measure"]','số cuộc gọi chào hàng tới khách hàng mới');await pg.wait_for_timeout(300)
    await pg.locator('input[data-k="d5m3"]').evaluate(BOX);await clip(pg,'.card','.card >> nth=1','s5.png',pad=10);await pg.evaluate(UNBOX);await pg.click('[data-done]')
    await go(6);await pg.fill('[data-k="d6place"]','cạnh bàn phím, chỗ đặt sổ kế hoạch buổi sáng');await pg.wait_for_timeout(300)
    await pg.locator('.card >> nth=0 >> table').evaluate(BOX);await clip(pg,'.card','.card','s6.png',pad=10);await pg.evaluate(UNBOX)
    await pg.click('[data-done]');await pg.wait_for_timeout(300);await pg.fill('[data-k="badgeName"]','Nguyễn Minh An');await pg.wait_for_timeout(1500)
    await clip(pg,'.card:has(#bcv)','.card:has(#bcv)','s7.png',pad=10)
    await b.close()
try: asyncio.run(main())
finally: srv.terminate()
