import asyncio, os, sys
sys.path.insert(0, '/tmp/f30/b')
from vnkeep import keep
sys.path.insert(0, '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad/w0034n'); from nbnum import nb
from playwright.async_api import async_playwright
D = os.path.dirname(os.path.abspath(__file__))
PFX = '10XHub_QuyTac525_'
K = '#862222'; CR = '#FBF5F4'; LN = '#D9C3C0'; INK = '#231F20'
CSS = f"""<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800;900&family=Noto+Serif:ital,wght@0,500;0,700;1,500&display=swap" rel="stylesheet">
<style>@page{{size:A4;margin:0}}*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Be Vietnam Pro',sans-serif;color:{INK};font-size:10.2pt}}
.page{{width:210mm;height:297mm;padding:14mm 30mm 0 15mm;page-break-after:always;overflow:hidden;position:relative;display:flex;flex-direction:column;
 background-color:#fff;background-image:radial-gradient(circle,#E6D3D0 .55pt,transparent .7pt);background-size:5mm 5mm;background-position:2.5mm 2.5mm}}
.tab{{position:absolute;right:0;top:22mm;width:18mm;background:{K};color:#fff;border-radius:3mm 0 0 3mm;padding:5mm 0 6mm;text-align:center}}
.tab .n{{font-size:34pt;font-weight:900;line-height:1}}.tab .of{{font-size:8pt;letter-spacing:.15em;opacity:.85}}
.tab .w{{writing-mode:vertical-rl;font-size:9pt;font-weight:800;letter-spacing:.2em;margin:6mm auto 0}}
.tab2{{position:absolute;right:0;top:150mm;width:18mm;height:60mm;border:1.2pt solid {K};border-right:0;border-radius:3mm 0 0 3mm;background:#fff;display:flex;align-items:center;justify-content:center}}
.tab2 span{{writing-mode:vertical-rl;font-size:8pt;font-weight:800;letter-spacing:.22em;color:{K}}}
.logo{{position:absolute;right:3.5mm;bottom:34mm;height:11mm}}
.kk{{font-size:8pt;font-weight:700;letter-spacing:.18em;color:{K};white-space:nowrap}}
h1{{font-size:24pt;font-weight:900;text-transform:uppercase;line-height:1.12;margin-top:2mm;text-wrap:balance}}
.lead{{background:#fff;border:1pt solid {LN};padding:3mm 4mm;font-size:10pt;line-height:1.55;color:#4a3a3a;margin-top:4mm}}
.body{{flex:1;display:flex;flex-direction:column;gap:4mm;padding:5mm 0;justify-content:space-evenly}}
.card{{background:#fff;border:1pt solid {LN};border-top:2.4pt solid {K};padding:3mm 4mm}}
.card .h{{font-size:8.5pt;font-weight:800;letter-spacing:.12em;color:{K};text-transform:uppercase;margin-bottom:1.5mm}}
.card .h span{{color:#9a7c7c;font-weight:600;letter-spacing:.03em;text-transform:none}}
.ln{{border-bottom:.8pt solid {LN};height:8.6mm}}
.fl{{font-family:'Noto Serif',serif;font-size:11.5pt;line-height:2.25}}.fl u{{text-decoration:none;display:inline-block;border-bottom:.8pt solid {K};min-width:40mm}}
.chk{{display:flex;gap:2.5mm;align-items:center;margin:1.2mm 0;font-size:9.5pt}}.cb{{width:4mm;height:4mm;border:1.1pt solid {K};flex:none}}
.opts{{display:grid;grid-template-columns:1fr 1fr;gap:.5mm 5mm}}
table{{width:100%;border-collapse:collapse;font-size:9.2pt}}th{{text-align:left;font-size:8pt;letter-spacing:.08em;color:{K};padding:1.5mm;border-bottom:1.2pt solid {K}}}td{{border-bottom:.8pt solid {LN};padding:1.6mm 1.5mm;height:9mm;vertical-align:bottom}}td.k{{font-weight:700;color:{K};width:34mm}}
.ex{{font-size:9pt;line-height:1.5;color:#5a4646;border-left:2pt solid {K};padding-left:3mm;background:#fff}}.ex b{{color:{K}}}
.ci{{background:{K};color:#fff;margin:0 -30mm 0 -15mm;padding:4mm 30mm 3mm 15mm}}.ci b{{font-size:7.8pt;letter-spacing:.18em}}.ci div{{font-family:'Noto Serif',serif;font-size:11pt;margin-top:1.2mm;line-height:1.5}}
.ci small{{display:flex;justify-content:space-between;font-size:7.2pt;opacity:.85;margin-top:2mm}}
</style>"""
def L(n): return '<div class="ln"></div>' * n
def C(t): return f'<div class="chk"><div class="cb"></div><div>{t}</div></div>'
def CARD(h, body, hint=''): return f'<div class="card"><div class="h">{h}{" <span>· "+hint+"</span>" if hint else ""}</div>{body}</div>'
WD = ['THỨ HAI 04.01', 'THỨ BA 05.01', 'THỨ TƯ 06.01', 'THỨ NĂM 07.01', 'THỨ SÁU 08.01', 'THỨ BẢY 09.01']
def page(d, title, time, lead, body, ci):
    return f"""<div class="page"><div class="tab"><div class="n">{d}</div><div class="of">/ 6</div><div class="w">{WD[d-1]}</div></div>
<div class="tab2"><span>MÙA 2 · NĂM 2027</span></div><img class="logo" src="img/logo_c_crop.png">
<div class="kk">QUY TẮC 5/25 · CÔNG THỨC #0034 · {time}</div><h1>{title}</h1><div class="lead">{lead}</div>
<div class="body">{body}</div>
<div class="ci"><b>CÂU CHIA SẺ TRÊN 10X EXCELLENCE HUB</b><div>{ci}</div>
<small><span>Sổ thực hành: 10xexcellence.co/so-thuc-hanh#0034-ngay-{d}</span><span>Họ tên: ........................ Ngày: ..../..../....</span></small></div></div>"""
GROUPS = ['Kết quả công việc', 'Kỹ năng và chuyên môn', 'Khách hàng và quan hệ', 'Đội nhóm và cách làm việc', 'Học tập và phát triển']
P = {}
P[1] = ('25-muc-tieu', [page(1, 'Viết 25 mục tiêu công việc năm 2027', 'KHOẢNG 30 PHÚT',
 'Hôm nay chỉ viết, chưa lọc. Khoảng năm mục tiêu cho mỗi nhóm. Mục tiêu nhỏ, mục tiêu lớn, mục tiêu ấp ủ lâu đều ghi vào.',
 ''.join(CARD(g, '<div style="display:grid;grid-template-columns:1fr 1fr;column-gap:5mm">' + L(4) + '</div>') for g in GROUPS) +
 CARD('Đếm lại', '<div class="fl">Tôi đã viết <u style="min-width:18mm"></u> mục tiêu. Nhóm nhiều nhất: <u style="min-width:45mm"></u></div>'),
 '"Tôi đã viết ... mục tiêu công việc cho năm 2027. Nhóm có nhiều mục tiêu nhất: ...."')])
P[2] = ('khoanh-5', [page(2, 'Khoanh lấy 5 mục tiêu quan trọng nhất', 'KHOẢNG 25 PHÚT',
 'Đi qua bảy câu hỏi lọc với từng mục tiêu, rút danh sách xuống 8 đến 10, rồi chọn 5 và xếp thứ tự.',
 CARD('Bảy câu hỏi lọc', '<div style="font-size:9pt;line-height:1.6;color:#4a3a3a">1. Cả năm chỉ đạt một mục tiêu thì đó là mục tiêu nào? 2. Có gắn với vai trò chính năm 2027? 3. Cuối năm biết đã đạt hay chưa? 4. Phần lớn kết quả trong tầm ảnh hưởng của mình? 5. Có trùng mục tiêu khác? 6. Bỏ đi có tiếc thật sự? 7. Mục tiêu của mình hay của người khác?</div>') +
 CARD('Năm mục tiêu năm 2027', '<table>' + ''.join(f'<tr><td class="k" style="width:22mm">Số {i}</td><td></td></tr>' for i in range(1, 6)) + '</table>', 'viết cụ thể, đo được') +
 CARD('Kiểm tra cả 5 mục tiêu', C('Đo được hoặc thấy được kết quả vào cuối năm') + C('Phần lớn kết quả nằm trong tầm ảnh hưởng của tôi') + C('Chỉ tiêu công ty giao (nếu có) đã nằm trong 5 mục tiêu hoặc có mục tiêu đóng góp trực tiếp')) +
 '<div class="ex"><b>Viết lại cho cụ thể.</b> "Giỏi tiếng Anh hơn" thành "thuyết trình với khách hàng nước ngoài không cần người hỗ trợ trước tháng 9".</div>',
 '"Năm mục tiêu công việc năm 2027 của tôi: 1) ...; 2) ...; 3) ...; 4) ...; 5) ...."')])
P[3] = ('danh-sach-tranh', [page(3, '20 mục tiêu còn lại là danh sách tránh', 'KHOẢNG 20 PHÚT',
 'Tránh không có nghĩa là xoá. Đây là những mục tiêu tốt, không đầu tư thời gian trong giai đoạn này. Cuối quý xem lại.',
 CARD('Danh sách tránh', '<div style="display:grid;grid-template-columns:1fr 1fr;column-gap:5mm">' + L(10) + '</div>') +
 CARD('Ba mục tiêu hấp dẫn nhất', L(3) + '<div class="opts" style="margin-top:2mm">' + C('Dễ và vui') + C('Được người khác khen') + C('Người khác muốn tôi làm') + C('Nghĩ là sẽ làm sau') + '</div>', 'vì sao hấp dẫn') +
 CARD('Câu nói không soạn sẵn', L(2)) +
 '<div class="ex"><b>Ví dụ.</b> "Cảm ơn anh đã nghĩ đến em. Quý này em đang tập trung cho mục tiêu mở rộng nhóm khách hàng doanh nghiệp, nên em xin hẹn lại vào tháng 4."</div>',
 '"Danh sách tránh của tôi bắt đầu bằng: .... Câu tôi dùng để nói không: ...."')])
P[4] = ('noi-thoi-quen', [page(4, 'Nối thói quen then chốt với mục tiêu số 1', 'KHOẢNG 20 PHÚT',
 'Thói quen tốt và mục tiêu rõ chưa chắc đã nối với nhau. Hôm nay đặt hai điều cạnh nhau và viết một câu nối.',
 CARD('Đặt cạnh nhau', '<table><tr><td class="k">Thói quen then chốt</td><td></td></tr><tr><td class="k">Mục tiêu số 1</td><td></td></tr></table>') +
 CARD('Tình trạng', C('<b>Đã nối thẳng</b>: mỗi lần làm thói quen đều đóng góp cho mục tiêu') + C('<b>Cần điều chỉnh nhỏ</b>: giữ tín hiệu và giờ, thêm một quy định nhỏ') + C('<b>Cần đổi</b>: giữ tín hiệu và khung giờ, đặt thói quen mới vào')) +
 CARD('Câu nối', '<div class="fl">Mỗi ngày <u style="min-width:60mm"></u>,<br>để tiến tới <u style="min-width:85mm"></u>.</div><div class="fl">Bằng cách: <u style="min-width:110mm"></u></div>') +
 CARD('Bảng hành trình tuần này', '<div style="display:flex;gap:3mm">' + ''.join(f'<div style="text-align:center;font-size:8pt;font-weight:700;color:{K}"><div style="width:14mm;height:11mm;border:1.2pt solid {K};margin-bottom:1mm;background:#fff"></div>{t}</div>' for t in ['T2 04', 'T3 05', 'T4 06', 'T5 07', 'T6 08', 'T7 09']) + '</div>'),
 '"Thói quen ... đưa tôi tới mục tiêu số 1 (...) bằng cách ...."')])
P[5] = ('quy-1', [page(5, 'Kế hoạch quý 1 trên một trang', 'KHOẢNG 25 PHÚT',
 'Mỗi mốc là một kết quả thấy được, không phải một việc làm. Tháng 2 có kỳ nghỉ Tết Nguyên Đán, mốc nên khiêm tốn hơn.',
 CARD('Ba mốc cho mục tiêu số 1', '<table><tr><td class="k">Cuối tháng 1</td><td></td></tr><tr><td class="k">Cuối tháng 2</td><td></td></tr><tr><td class="k">Cuối tháng 3</td><td></td></tr></table>') +
 CARD('Con số theo dõi mỗi tuần', L(1) + '<div style="display:grid;grid-template-columns:repeat(13,1fr);gap:1mm;margin-top:2.5mm">' + ''.join(f'<div style="border:1pt solid {K};height:10mm;font-size:6.5pt;font-weight:700;color:{K};padding:.5mm;background:#fff">T{i}</div>' for i in range(1, 14)) + '</div>', 'con số mình kiểm soát được') +
 CARD('Mốc cuối quý cho mục tiêu số 2 đến số 5', '<table>' + ''.join(f'<tr><td class="k" style="width:22mm">Số {i}</td><td></td></tr>' for i in range(2, 6)) + '</table>') +
 CARD('Thói quen trong kỳ nghỉ Tết Nguyên Đán', L(1), 'phiên bản nhỏ nhất'),
 '"Mốc quý 1 của mục tiêu số 1: .... Tôi theo dõi mỗi tuần bằng: ...."')])
def tcard():
    return f'''<div style="border:1.2pt dashed {K};background:#fff;padding:5mm 6mm;flex:1;display:flex;flex-direction:column">
<div style="display:flex;justify-content:space-between;align-items:center"><div style="font-size:15pt;font-weight:900;color:{K}">5 MỤC TIÊU NĂM 2027</div><img src="img/logo_c_crop.png" style="height:9mm"></div>
<table style="margin-top:2mm">{''.join(f'<tr><td class="k" style="width:22mm">Số {i}</td><td></td></tr>' for i in range(1, 6))}<tr><td class="k">Tránh</td><td></td></tr><tr><td class="k">Thói quen</td><td></td></tr></table></div>'''
cards = f'''<div class="page" style="padding:14mm 15mm;background-image:none;gap:6mm"><div class="kk">QUY TẮC 5/25 · CÔNG THỨC #0034</div><h1 style="margin-top:-3mm">Thẻ 5 mục tiêu in được</h1>
<div style="font-size:10pt;color:#5a4646;margin-top:-3mm">Cắt theo đường đứt, đặt một thẻ cạnh tín hiệu của thói quen then chốt, một thẻ trong sổ kế hoạch.</div>{tcard()}{tcard()}</div>'''
P[6] = ('the-5-muc-tieu', [page(6, 'Thẻ 5 mục tiêu đặt trên bàn làm việc', 'KHOẢNG 20 PHÚT',
 'Một tấm thẻ nhỏ, đặt đúng chỗ, gắn với một thói quen đã có, thường được nhìn thấy nhiều hơn một bảng treo tường.',
 CARD('Gom cả tuần', '<table><tr><td class="k">Câu bản sắc năm 2027</td><td></td></tr><tr><td class="k">Mục tiêu số 1</td><td></td></tr><tr><td class="k">Danh sách tránh</td><td></td></tr><tr><td class="k">Thói quen then chốt</td><td></td></tr><tr><td class="k">Mốc cuối quý 1</td><td></td></tr><tr><td class="k">Con số mỗi tuần</td><td></td></tr></table>') +
 CARD('Đặt thẻ đúng chỗ', C('Đã điền thẻ 5 mục tiêu (trang sau)') + '<div class="fl">Thẻ của tôi đặt ở: <u style="min-width:95mm"></u></div>') +
 '<div class="ex"><b>Tuần sau.</b> Công thức #0035 Bảng Kanban cá nhân, từ Thứ Hai 11.01, biến 5 mục tiêu và kế hoạch quý 1 thành những việc cụ thể trên một bảng.</div>',
 '"Năm 2027, tôi tập trung vào 5 mục tiêu. Mục tiêu số 1: .... Thẻ của tôi đặt ở: ...."'), cards])
async def main():
    os.makedirs(D + '/pdf', exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page()
        for d, (slug, pages) in P.items():
            f = f'{D}/sheet_{d}.html'
            open(f, 'w').write(f'<!doctype html><html><head><meta charset="utf-8">{CSS}</head><body>{nb(keep("".join(pages)))}</body></html>')
            await pg.goto('file://' + f); await pg.wait_for_load_state('networkidle'); await pg.evaluate('document.fonts.ready'); await pg.wait_for_timeout(400)
            await pg.pdf(path=f'{D}/pdf/{PFX}PhieuNgay{d}_{slug}.pdf', format='A4', print_background=True)
        await b.close()
asyncio.run(main())
