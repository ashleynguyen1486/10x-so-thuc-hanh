import re
_RX=re.compile(r'(?<=[A-Za-zÀ-ỹ]) (?=\d)')
def nb(html):
    """Nối chữ với số đứng ngay sau (số 1, quý 1, Mùa 2, năm 2027) bằng khoảng trắng không ngắt, chỉ trong phần chữ."""
    parts=re.split(r'(<[^>]+>)',html)
    return ''.join(p if p.startswith('<') else _RX.sub('\xa0',p) for p in parts)
