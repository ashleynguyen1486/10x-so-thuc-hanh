import json, sys
sys.path.insert(0, '/tmp/f30/b')
from vnkeep import keep
sys.path.insert(0, '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad/w0034n'); from nbnum import nb
SP = '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
H = 'Dán vào bình luận của bài Ngày {}.'
def tx(k, q, ph=''): return {"f": "tx", "k": k, "q": q, "ph": ph}
def ta(k, q, ph=''): return {"f": "ta", "k": k, "q": q, "ph": ph}
def note(t): return {"f": "note", "text": t}
def show(t, need): return {"f": "show", "text": t, "need": need}
def cb(k, l): return {"f": "cb", "k": k, "label": l}
def ci(*parts): return [{"tpl": t, "need": n} for t, n in parts]
GROUPS = ["Kết quả công việc", "Kỹ năng và chuyên môn", "Khách hàng và quan hệ", "Đội nhóm và cách làm việc", "Học tập và phát triển"]
GEX = ["Ví dụ: 12 khách hàng doanh nghiệp mới; chốt sổ tháng trong 3 ngày", "Ví dụ: thuyết trình với khách hàng nước ngoài không cần người hỗ trợ",
       "Ví dụ: gặp trực tiếp 20 khách hàng lớn nhất ít nhất một lần", "Ví dụ: mỗi thành viên trong nhóm có kế hoạch phát triển riêng", "Ví dụ: hoàn thành một chứng chỉ chuyên môn"]
days = [
{"label": "Thứ Hai", "kick": "25 mục tiêu", "title": "Viết 25 mục tiêu công việc năm 2027", "time": "Khoảng 30 phút", "cards": [
 {"h": "Thói quen đang giữ", "items": [
  show("Thói quen đang giữ: {j_habit}", ["j_habit"]),
  show("Câu bản sắc năm 2027: Năm 2027, tôi là người {j_identity_2027}.", ["j_identity_2027"]),
  note("Người mới tham gia: viết câu bản sắc và thói quen then chốt muốn giữ cả năm ở hai ô dưới đây."),
  tx("j_identity", "Tôi là người ...", "Ví dụ: làm việc quan trọng trước khi mở hộp thư"),
  tx("j_habit", "Thói quen then chốt của tôi", "Ví dụ: viết ba việc quan trọng nhất trước 8 giờ")]},
 {"h": "25 mục tiêu theo năm nhóm", "items": [
  note("Hôm nay chỉ viết, chưa lọc. Mỗi nhóm khoảng 5 mục tiêu, mỗi dòng một mục tiêu. Nhóm nào nghĩ ra nhiều hơn cứ viết thêm.")] +
  [ta(f"d1g{i+1}", g, GEX[i]) for i, g in enumerate(GROUPS)]},
 {"h": "Đếm lại", "items": [
  {"f": "nums", "items": [{"k": "d1count", "q": "Tôi đã viết được bao nhiêu mục tiêu?"}]},
  {"f": "seg", "k": "d1most", "q": "Nhóm có nhiều mục tiêu nhất", "opts": ["Kết quả", "Kỹ năng", "Khách hàng", "Đội nhóm", "Học tập"],
   "hints": ["Kết quả công việc: doanh số, chỉ tiêu, dự án, thời hạn.", "Kỹ năng và chuyên môn: điều mình muốn làm giỏi hơn.",
             "Khách hàng và quan hệ: khách hàng, đối tác, đồng nghiệp bộ phận khác.", "Đội nhóm và cách làm việc: quy trình, phối hợp, phát triển người khác.",
             "Học tập và phát triển: khoá học, chứng chỉ, sách chuyên môn."]}]}],
 "checkin": ci(("Tôi đã viết {d1count} mục tiêu công việc cho năm 2027.", ["d1count"]),
               (" Nhóm có nhiều mục tiêu nhất: {d1most}.", ["d1most"])),
 "hint": H.format(1)},
{"label": "Thứ Ba", "kick": "Khoanh 5", "title": "Khoanh lấy 5 mục tiêu quan trọng nhất", "time": "Khoảng 25 phút", "cards": [
 {"h": "Bảy câu hỏi lọc", "items": [
  note("1. Cả năm chỉ đạt một mục tiêu thì đó là mục tiêu nào? 2. Có gắn với vai trò chính năm 2027 không? 3. Cuối năm có biết đã đạt hay chưa không? 4. Phần lớn kết quả có trong tầm ảnh hưởng của mình không? 5. Có trùng mục tiêu khác không? 6. Bỏ đi có tiếc thật sự không? 7. Mục tiêu của mình hay của người khác?")]},
 {"h": "Năm mục tiêu năm 2027", "items": [
  tx("j_goal1", "Mục tiêu số 1 (quan trọng nhất)", "Ví dụ: 12 khách hàng doanh nghiệp mới ký hợp đồng trong năm"),
  tx("j_goal2", "Mục tiêu số 2", "Ví dụ: chốt sổ tháng trong 3 ngày làm việc"),
  tx("j_goal3", "Mục tiêu số 3", "Ví dụ: thuyết trình với khách hàng nước ngoài không cần người hỗ trợ"),
  tx("j_goal4", "Mục tiêu số 4", "Ví dụ: mỗi thành viên trong nhóm có kế hoạch phát triển riêng"),
  tx("j_goal5", "Mục tiêu số 5", "Ví dụ: hoàn thành một chứng chỉ chuyên môn")]},
 {"h": "Kiểm tra cả 5 mục tiêu", "items": [
  cb("d2c1", "Mỗi mục tiêu đo được hoặc thấy được kết quả vào cuối năm"),
  cb("d2c2", "Phần lớn kết quả nằm trong tầm ảnh hưởng của tôi"),
  cb("d2c3", "Chỉ tiêu do công ty giao (nếu có) đã nằm trong 5 mục tiêu hoặc có mục tiêu đóng góp trực tiếp")]}],
 "checkin": ci(("Năm mục tiêu công việc năm 2027 của tôi: 1) {j_goal1}; 2) {j_goal2}; 3) {j_goal3}; 4) {j_goal4}; 5) {j_goal5}.", ["j_goal1", "j_goal2", "j_goal3", "j_goal4", "j_goal5"]),),
 "hint": H.format(2)},
{"label": "Thứ Tư", "kick": "Danh sách tránh", "title": "20 mục tiêu còn lại là danh sách tránh", "time": "Khoảng 20 phút", "cards": [
 {"h": "Danh sách tránh", "items": [
  note("Tránh không có nghĩa là xoá. Đây là những mục tiêu tốt nhưng không đầu tư thời gian trong giai đoạn này. Cuối quý xem lại."),
  ta("d3rest", "20 mục tiêu còn lại", "Chép từ Ngày 1 những mục tiêu không nằm trong 5 mục tiêu đã chọn")]},
 {"h": "Ba mục tiêu hấp dẫn nhất", "items": [
  tx("j_avoid", "Ba mục tiêu dễ lấn sang thời gian của 5 mục tiêu chính nhất", "Ví dụ: mở kênh bán hàng trên mạng xã hội; học thiết kế; viết sách"),
  {"f": "seg", "k": "d3why", "q": "Vì sao chúng hấp dẫn?", "opts": ["Dễ và vui", "Được người khác khen", "Người khác muốn tôi làm", "Nghĩ là sẽ làm sau"],
   "hints": ["Việc dễ, cho cảm giác xong việc nhanh, nhưng không đưa mình tới 5 mục tiêu.",
             "Việc được ghi nhận ngay, dễ làm mình quên mục tiêu dài hạn.",
             "Việc người khác mong mình làm, chưa chắc là mục tiêu của mình.",
             "Việc để dành khi có thời gian, nhưng mỗi lần rảnh lại đòi được làm."]}]},
 {"h": "Câu nói không soạn sẵn", "items": [
  tx("d3no", "Câu từ chối lịch sự cho lời mời ngoài 5 mục tiêu", "Ví dụ: cảm ơn anh, quý này em tập trung cho mục tiêu khách hàng doanh nghiệp, em xin hẹn lại tháng 4")]}],
 "checkin": ci(("Danh sách tránh của tôi bắt đầu bằng: {j_avoid}.", ["j_avoid"]),
               (" Câu tôi dùng để nói không: {d3no}.", ["d3no"])),
 "hint": H.format(3)},
{"label": "Thứ Năm", "kick": "Nối thói quen", "title": "Nối thói quen then chốt với mục tiêu số 1", "time": "Khoảng 20 phút", "cards": [
 {"h": "Đặt cạnh nhau", "items": [
  show("Thói quen then chốt: {j_habit}", ["j_habit"]),
  show("Mục tiêu số 1: {j_goal1}", ["j_goal1"]),
  {"f": "seg", "k": "d4fit", "q": "Hai điều này đã nối với nhau chưa?", "opts": ["Đã nối thẳng", "Cần điều chỉnh nhỏ", "Cần đổi thói quen"],
   "hints": ["Mỗi lần làm thói quen đều đưa mình gần mục tiêu số 1. Giữ nguyên.",
             "Giữ tín hiệu và giờ, thêm một quy định nhỏ để thói quen đóng góp cho mục tiêu. Ví dụ: trong ba việc quan trọng luôn có một việc cho khách hàng mới.",
             "Thói quen không còn liên quan. Theo quy tắc vàng: giữ tín hiệu và khung giờ, đặt thói quen mới vào."]},
  tx("d4link", "Mỗi lần làm thói quen giúp mục tiêu số 1 bằng cách ...", "Ví dụ: luôn có một việc hướng tới khách hàng mới trong ba việc quan trọng"),
  show("Mỗi ngày {j_habit}, để tiến tới {j_goal1}.", ["j_habit", "j_goal1"])]},
 {"h": "Bảng hành trình thói quen", "items": [
  {"f": "track", "note": "Bấm vào những ngày tuần này đã làm thói quen. Từ Mùa 2, mỗi ô cũng là một bước tới mục tiêu số 1."}]}],
 "checkin": ci(("Thói quen {j_habit} đưa tôi tới mục tiêu số 1 ({j_goal1}) bằng cách {d4link}.", ["j_habit", "j_goal1", "d4link"]),),
 "hint": H.format(4)},
{"label": "Thứ Sáu", "kick": "Kế hoạch quý 1", "title": "Kế hoạch quý 1 trên một trang", "time": "Khoảng 25 phút", "cards": [
 {"h": "Ba mốc cho mục tiêu số 1", "items": [
  show("Mục tiêu số 1: {j_goal1}", ["j_goal1"]),
  note("Mỗi mốc là một kết quả thấy được, không phải một việc làm. Tháng 2 có kỳ nghỉ Tết Nguyên Đán, mốc nên khiêm tốn hơn."),
  tx("d5m1", "Cuối tháng 1", "Ví dụ: danh sách 40 khách hàng tiềm năng đã sàng lọc"),
  tx("d5m2", "Cuối tháng 2", "Ví dụ: 10 buổi gặp đã diễn ra"),
  tx("d5m3", "Cuối tháng 3", "Ví dụ: 2 hợp đồng đầu tiên đã ký")]},
 {"h": "Con số theo dõi mỗi tuần", "items": [
  tx("d5measure", "Con số tôi kiểm soát được, theo dõi mỗi tuần", "Ví dụ: số cuộc gọi chào hàng tới khách hàng mới")]},
 {"h": "Mốc cuối quý cho mục tiêu số 2 đến số 5", "items": [
  {"f": "compare", "cols": ["Mục tiêu"], "rows": [{"label": "Số 2", "keys": ["j_goal2"]}, {"label": "Số 3", "keys": ["j_goal3"]}, {"label": "Số 4", "keys": ["j_goal4"]}, {"label": "Số 5", "keys": ["j_goal5"]}]},
  ta("d5others", "Mỗi mục tiêu một mốc cuối quý", "Ví dụ: số 2: chốt sổ tháng 3 trong 4 ngày; số 3: một buổi thuyết trình thử với đồng nghiệp")]},
 {"h": "Thói quen trong kỳ nghỉ Tết Nguyên Đán", "items": [
  tx("d5tet", "Phiên bản nhỏ nhất cho những ngày nghỉ", "Ví dụ: mỗi sáng viết một việc quan trọng nhất cho ngày đi làm lại")]}],
 "checkin": ci(("Mốc quý 1 của mục tiêu số 1: {d5m3}.", ["d5m3"]),
               (" Tôi theo dõi mỗi tuần bằng: {d5measure}.", ["d5measure"])),
 "hint": H.format(5)},
{"label": "Thứ Bảy", "kick": "Thẻ 5 mục tiêu", "title": "Thẻ 5 mục tiêu đặt trên bàn làm việc", "time": "Khoảng 20 phút", "cards": [
 {"h": "Thẻ 5 mục tiêu năm 2027", "items": [
  note("Mọi điều đã viết trong tuần tự gom lại ở đây. Ô nào còn trống thì quay lại ngày đó để điền."),
  {"f": "compare", "cols": ["Nội dung"], "rows": [
   {"label": "Câu bản sắc năm 2027", "keys": ["j_identity_2027"]}, {"label": "Mục tiêu số 1", "keys": ["j_goal1"]},
   {"label": "Mục tiêu số 2", "keys": ["j_goal2"]}, {"label": "Mục tiêu số 3", "keys": ["j_goal3"]},
   {"label": "Mục tiêu số 4", "keys": ["j_goal4"]}, {"label": "Mục tiêu số 5", "keys": ["j_goal5"]},
   {"label": "Danh sách tránh", "keys": ["j_avoid"]}, {"label": "Thói quen then chốt", "keys": ["j_habit"]},
   {"label": "Mốc cuối quý 1", "keys": ["d5m3"]}, {"label": "Con số mỗi tuần", "keys": ["d5measure"]}]}]},
 {"h": "Đặt thẻ đúng chỗ", "items": [
  cb("d6print", "Tôi đã điền thẻ 5 mục tiêu (in từ phiếu Ngày 6 hoặc viết tay)"),
  tx("d6place", "Thẻ của tôi đặt ở", "Ví dụ: cạnh bàn phím, ngay chỗ đặt sổ kế hoạch buổi sáng"),
  note("Tuần sau, Công thức #0035 Bảng Kanban cá nhân biến 5 mục tiêu và kế hoạch quý 1 thành những việc cụ thể trên một bảng.")]}],
 "checkin": ci(("Năm 2027, tôi tập trung vào 5 mục tiêu. Mục tiêu số 1: {j_goal1}.", ["j_goal1"]),
               (" Thẻ của tôi đặt ở: {d6place}.", ["d6place"])),
 "hint": H.format(6) + " Đủ 6 ngày, thẻ thành tích sẽ hiện ra bên dưới."},
]
W = {"id": "0034", "name": "Quy tắc 5/25", "storeKey": "sth-0034-6n", "kicker": "Công thức #0034",
     "title": "Quy tắc 5/25: năm mục tiêu cho năm 2027",
     "sub": "Tuần đầu năm 2027, mở Mùa 2 của hành trình. Viết 25 mục tiêu công việc, khoanh lấy 5, biến 20 mục tiêu còn lại thành danh sách tránh, rồi nối thói quen then chốt với mục tiêu số 1. Từ Thứ Hai đến Thứ Bảy, Chủ Nhật nghỉ. Điền ngay trên trang, sao chép câu chia sẻ và dán vào bình luận bài hôm đó.",
     "badge": {"style": "frame", "big": "5", "unit": "MỤC TIÊU", "sub": "năm 2027",
               "line": "Mục tiêu số 1: {j_goal1|đã được chọn}"},
     "days": days}
def K(o, key=None):
    if isinstance(o, dict): return {k: (v if k in ('tpl','k','kp','dk','f','id','storeKey','style','line','need','keys','big') else K(v, k)) for k, v in o.items()}
    if isinstance(o, list): return [K(x, key) for x in o]
    if isinstance(o, str): return nb(keep(o))
    return o
json.dump(K(W), open(f'{SP}/gh_all/0034.json', 'w'), ensure_ascii=False, indent=1)
print('ok')
