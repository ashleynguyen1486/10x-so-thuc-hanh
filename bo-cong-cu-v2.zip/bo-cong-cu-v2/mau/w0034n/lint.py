import re,sys,glob,html
N=sys.argv[1];SP='/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
files=['posts.md',f'doc{N}.txt',f'{SP}/gh_all/{N}.json']+glob.glob('formula/*.html')+glob.glob('sheet_*.html')+glob.glob('b/*.html')+glob.glob('guide/guide.html')+glob.glob(f'rev{N}.txt')
EN=r'\b(email|e-mail|file|check|check-in|tab|flow|deadline|team|ok|kpi|ceo|feedback|online|offline|sale|sales|meeting|list|to-do|goal|target|habit|plan|report|update|coach|mentor|workshop)\b'
for f in files:
    t=open(f).read()
    if f.endswith('.html'): t=re.sub(r'<style.*?</style>|<script.*?</script>','',t,flags=re.S);t=html.unescape(re.sub(r'<[^>]+>',' ',t))
    t=t.replace('\xa0',' ')
    for name,rx in [('nhé',r'nhé'),('dash',r'[—–]'),('tôi',r'\btôi\b'),('thứ',r'(?<![A-ZÀ-Ỹ])\bthứ\b'),('EN',EN)]:
        for m in re.finditer(rx,t,flags=re.I if name=='EN' else 0):
            s=t[max(0,m.start()-50):m.end()+40].replace('\n',' ')
            if name=='tôi' and '"' in t[max(0,m.start()-200):m.start()] : 
                # print only if not inside quotes: count quotes on the line
                line=t[t.rfind('\n',0,m.start())+1:m.start()]
                if line.count('"')%2==1 or line.count('“')>line.count('”'): continue
            print(f'{f.split("/")[-1]}|{name}| ...{s}...')
