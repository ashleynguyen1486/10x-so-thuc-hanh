## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 18/01)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0036_Gan Goc_VN.pdf (tài liệu đầy đủ của Công thức #0036)
@pdf 10XHub_GanGoc_PhieuNgay1_tu-cham.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0036.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** GIỮA THÁNG 1: KHI HỨNG KHỞI GIẢM, GAN GÓC Ở LẠI

Tuần trước, năm mục tiêu của cả nhóm đã xuống tới mặt bàn. Mỗi người dựng một tấm bảng ba cột, tách mục tiêu số 1 thành những thẻ việc bắt đầu bằng động từ, đặt giới hạn việc dở và tập nhìn bảng năm phút mỗi sáng. Thứ Sáu, nhiều thẻ tắc đã được gọi đúng tên và gỡ ra. Thứ Bảy, cột Xong cho thấy một tuần làm việc nhìn thấy được.

Tuần này là tuần thứ ba của năm 2027. Thử nhìn lại ba tuần đầu năm như một dòng thời gian, theo trải nghiệm chung của rất nhiều người đi làm.

**Tuần đầu tiên.** Mọi điều đều mới: sổ mới, kế hoạch mới, mục tiêu mới. Quyết tâm cao, việc gì cũng muốn bắt đầu ngay.

**Tuần thứ hai.** Công việc thường ngày quay lại đầy đủ. Một vài buổi sáng thói quen bị đẩy lùi vì cuộc họp, vì khách hàng gọi sớm. Kế hoạch vẫn còn, nhưng không còn cảm giác hào hứng của tuần đầu.

**Tuần thứ ba.** Đây là lúc nhiều người bắt đầu tự hỏi: mình có thật sự cần mục tiêu này không? Không có biến cố gì lớn. Chỉ là cảm hứng đầu năm đã dùng gần hết.

Các nghiên cứu của nhà tâm lý học John Norcross về quyết tâm năm mới (năm 1989 và năm 2002) ghi nhận khoảng 40 đến 46% người đặt quyết tâm cho biết vẫn giữ được sau sáu tháng. Những nghiên cứu này chủ yếu về các thay đổi cá nhân như sức khoẻ, không riêng công việc, nhưng nó gợi ra một điều quen thuộc: phần lớn quyết tâm không dừng lại vì một thất bại lớn. Chúng dừng lại dần dần, khi hứng khởi giảm xuống.

Công thức #0036 của tuần này là Gan góc.

**Nếu mới tham gia:** tuần này rất hợp để bắt đầu, vì ai cũng từng có một mục tiêu đầu năm đang chững lại. Hôm nay chỉ cần viết vào sổ thực hành một thói quen nhỏ trong công việc muốn giữ suốt năm, một câu "Tôi là người ...", và tự chấm sáu câu hỏi ngắn. Thứ Tư, sổ có ô cho mục tiêu quan trọng nhất của năm.

**Gan góc là gì?**

Angela Duckworth, giáo sư tâm lý học tại Đại học Pennsylvania, định nghĩa gan góc là sự kết hợp giữa đam mê và kiên trì dành cho những mục tiêu dài hạn. Năm 2007, bà và các cộng sự công bố trên tạp chí Journal of Personality and Social Psychology sáu nghiên cứu, từ người trưởng thành, sinh viên đại học, học viên Học viện Quân sự West Point đến các thí sinh vòng chung kết cuộc thi đánh vần quốc gia của Mỹ. Ở West Point, điểm gan góc dự báo việc học viên hoàn thành khoá huấn luyện mùa hè đầu tiên tốt hơn điểm tổng hợp mà hội đồng tuyển sinh dùng. Năm 2016, bà viết cuốn sách "Grit" cho đông đảo người đọc.

Có một điều quan trọng cần nói cùng lúc. Trong chính nghiên cứu năm 2007, gan góc chỉ giải thích khoảng 4% khác biệt về thành tích. Năm 2017, một phân tích tổng hợp của Marcus Credé và cộng sự cho thấy gan góc trùng nhiều với tính tận tâm, và phần "kiên trì nỗ lực" có giá trị dự báo rõ hơn phần "đam mê". Vì vậy, tuần này không xem gan góc là một nhãn dán cho người giỏi và người kém. Tuần này xem nó như một cách làm việc có thể rèn được: giữ một hướng đi đủ lâu, và tiếp tục làm khi không còn hứng.

**Ba chặng của tuần**

Chặng một, nhìn lại mình (Thứ Hai, Thứ Ba): tự chấm, rồi tách đam mê và kiên trì ra để thấy phần nào đang chững. Chặng hai, nối với lý do (Thứ Tư, Thứ Năm): đặt mục tiêu số 1 vào ba tầng, chọn một việc khó để luyện. Chặng ba, chuẩn bị cho ngày nản (Thứ Sáu, Thứ Bảy): phiên bản tối thiểu của thói quen, và một lá thư cho chính mình. Chủ Nhật nghỉ.

Thói quen then chốt và tấm bảng Kanban vẫn đi tiếp. Lớp thêm của tuần này là một lý do dài hạn, để những buổi sáng không còn hứng vẫn có điều để nhớ.

**Ngày 1 (20 phút): Tự chấm sáu câu**

1. Mở sổ thực hành, đọc lại thói quen đang giữ và mục tiêu số 1. Người mới viết thói quen và câu bản sắc.
2. Chấm sáu câu về cách mình làm việc trong ba tháng gần đây, mỗi câu từ 1 đến 5. Ba câu đầu về kiên trì, ba câu sau về sự nhất quán của mục tiêu.
3. Xem phần nào mạnh hơn, và chọn một điều muốn rèn trong tháng 1.

Sáu câu này do 10X Excellence Hub soạn để tự nhìn lại, không phải thang đo gốc của Duckworth và không dùng để chẩn đoán hay so sánh với người khác.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-1.

Chia sẻ hôm nay: "Tự chấm tuần này, phần tôi mạnh hơn: .... Điều tôi muốn rèn trong tháng 1: ...".

Điểm số là của riêng mình, các anh chị và các bạn chỉ cần chia sẻ phần mạnh hơn và điều muốn rèn thôi nha.


## Bài 2: Ngày 2 (Thứ Ba 19/01)
@img 2_dam-me-kien-tri
@pdf 10XHub_GanGoc_PhieuNgay2_dam-me-kien-tri.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: ĐAM MÊ VÀ KIÊN TRÌ, HAI SỢI DÂY KHÁC NHAU

Khi nghe chữ "đam mê", nhiều người nghĩ đến cảm giác rất hứng thú, rất say sưa. Trong cách Angela Duckworth dùng, đam mê gần với một điều khác hơn: sự nhất quán của mối quan tâm qua thời gian. Hôm nay đặt hai thành phần của gan góc cạnh nhau, từng cặp một.

**Câu hỏi mỗi phần trả lời**

- Đam mê trả lời câu: mình đang đi về hướng nào, và hướng đó có giữ được nhiều năm không?
- Kiên trì trả lời câu: khi gặp khó, mình có tiếp tục bước không?

**Dấu hiệu khi phần đó mạnh**

- Đam mê mạnh: năm nay và năm sau vẫn quan tâm tới cùng một nhóm vấn đề; các mục tiêu nhỏ nối với nhau thành một con đường.
- Kiên trì mạnh: làm xong việc đã bắt đầu; một lần bị từ chối hay một lần làm hỏng không làm mình dừng lại.

**Dấu hiệu khi phần đó chững**

- Đam mê chững: mỗi quý lại muốn theo một hướng mới; đầu năm mục tiêu này, giữa năm đã quan tâm mục tiêu khác.
- Kiên trì chững: vẫn biết rõ mình muốn gì, nhưng gặp khó là trì hoãn, việc khó cứ nằm ở cột Cần làm.

**Ví dụ trong công việc**

- Một nhân viên kinh doanh rất quan tâm tới mảng khách hàng doanh nghiệp suốt ba năm nay (đam mê rõ), nhưng mỗi lần bị khách từ chối thì mất cả tuần mới gọi tiếp (kiên trì cần rèn).
- Một kỹ sư làm việc rất bền bỉ, việc gì nhận cũng làm đến cùng (kiên trì rõ), nhưng mỗi năm lại học một mảng mới không liên quan đến mảng cũ (đam mê cần định hướng).

**Phân tích tổng hợp năm 2017 nói gì**

Marcus Credé và cộng sự tổng hợp 88 mẫu nghiên cứu với hơn 66.000 người. Kết quả: phần kiên trì nỗ lực liên quan rõ hơn tới kết quả học tập và công việc so với phần nhất quán mối quan tâm. Điều này không có nghĩa đam mê vô ích. Nó gợi ý rằng trong ngắn hạn, những việc mình làm mỗi ngày quan trọng hơn cảm giác hứng thú. Với hành trình thói quen, đó là tin tốt: kiên trì là phần có thể luyện qua từng ngày giữ thói quen.

**Giữa tháng 1, phần nào thường chững trước?**

Với nhiều người, hướng đi vẫn còn nguyên, chỉ là nỗ lực mỗi ngày giảm dần. Với một số người khác, chính hướng đi bắt đầu lung lay. Biết phần nào đang chững giúp chọn đúng cách xử lý cho cả tuần.

**Ngày 2 (20 phút)**

1. Viết một điều trong công việc mình muốn quay lại nhiều năm, dù không phải lúc nào cũng hứng thú.
2. Viết lần gần nhất mình tiếp tục một việc dù khó.
3. Chọn phần đang chững trước trong tháng 1.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-2.

Chia sẻ hôm nay: "Đam mê trong công việc của tôi hướng về: .... Lần gần nhất tôi kiên trì dù khó: ...".


## Bài 3: Ngày 3 (Thứ Tư 20/01)
@img 3_ba-tang
@pdf 10XHub_GanGoc_PhieuNgay3_ba-tang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: MỤC TIÊU SỐ 1 NẰM Ở TẦNG NÀO?

**Một tình huống minh hoạ**

Chị Hạnh là kế toán trưởng của một công ty phân phối thiết bị. Mục tiêu số 1 năm 2027 của chị, chọn từ tuần Quy tắc 5/25, là "chốt sổ tháng trong 3 ngày làm việc". Tuần Kanban, chị tách nó thành các thẻ việc: ghi lại các bước chốt sổ tháng 12, hẹn bộ phận mua hàng chốt hạn gửi hoá đơn, thử một mẫu đối chiếu mới.

Đến tuần thứ ba của tháng 1, các thẻ vẫn nằm trên bảng, nhưng chị nhận ra mình bắt đầu thấy chúng là việc phải làm, không còn là việc muốn làm. Chốt sổ nhanh hơn một ngày thì có gì quan trọng?

Chị thử một bài tập trong sách "Grit" của Angela Duckworth: xếp mục tiêu thành ba tầng.

Ở tầng dưới là những việc cụ thể trong tuần: các thẻ trên bảng Kanban. Ở tầng giữa là mục tiêu số 1: chốt sổ trong 3 ngày. Còn tầng trên, chị tự hỏi: chốt sổ nhanh hơn để làm gì? Câu trả lời đến sau vài phút: để ban giám đốc có số liệu sớm, ra quyết định kịp thời; để đội kế toán không phải làm thêm giờ mỗi đầu tháng; và để chính chị dành được thời gian cho phần phân tích, phần việc chị muốn làm giỏi trong nhiều năm tới.

Câu trả lời cuối cùng là tầng trên của chị: "trở thành người kế toán giúp doanh nghiệp ra quyết định bằng số liệu". Duckworth gọi tầng này là mục tiêu cao nhất, điều cho các mục tiêu bên dưới một ý nghĩa.

Chị viết câu đó lên góc tấm bảng Kanban. Các thẻ việc vẫn vậy. Điều thay đổi là mỗi khi nhìn thẻ, chị thấy được nó nằm trên con đường nào.

**Ba tầng, nói ngắn gọn**

1. Tầng trên: lý do dài hạn, thường kéo dài nhiều năm, thường không đổi.
2. Tầng giữa: các mục tiêu năm, như năm mục tiêu của Mùa 2.
3. Tầng dưới: việc cụ thể trong tuần, như thẻ trên bảng Kanban.

Duckworth lưu ý: các mục tiêu tầng dưới có thể thay đổi, thậm chí nên thay đổi khi cách làm không hiệu quả. Điều cần giữ là tầng trên. Một thẻ việc không xong không có nghĩa là bỏ lý do dài hạn, chỉ là tìm một thẻ khác.

Tình huống của chị Hạnh là minh hoạ, nhưng câu hỏi "để làm gì?" dùng được cho mọi vị trí. Hỏi hai, ba lần liên tiếp, câu trả lời thường đi từ việc cụ thể lên một điều mình thật sự quan tâm.

**Ngày 3 (25 phút)**

1. Đặt mục tiêu số 1 vào tầng giữa.
2. Hỏi "để làm gì?" hai đến ba lần, viết câu trả lời cuối cùng vào ô lý do dài hạn.
3. Viết một thẻ việc tuần này ở tầng dưới, và viết lý do dài hạn lên góc tấm bảng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-3.

Chia sẻ hôm nay: "Lý do dài hạn của tôi: .... Mục tiêu số 1 phục vụ lý do đó bằng cách: ...".


## Bài 4: Ngày 4 (Thứ Năm 21/01)
@img 4_viec-kho
@pdf 10XHub_GanGoc_PhieuNgay4_viec-kho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: MỘT VIỆC KHÓ ĐỂ LUYỆN MỖI TUẦN

Hôm nay là một loạt câu hỏi và trả lời về "việc khó", ý tưởng trong sách "Grit" mà nhiều người đọc nhớ lâu nhất.

**Hỏi: "Quy tắc việc khó" là gì?**

Đáp: Duckworth kể rằng trong gia đình bà có một quy tắc gồm ba phần. Mỗi người chọn một việc khó, tức là việc cần luyện tập có chủ đích mỗi ngày. Có thể bỏ, nhưng chỉ ở một điểm dừng tự nhiên, như cuối mùa hay cuối khoá, không bỏ giữa chừng chỉ vì hôm đó nản. Và mỗi người tự chọn việc khó của mình, không ai chọn hộ. Tuần này mang quy tắc đó vào công việc.

**Hỏi: Việc khó trong công việc trông như thế nào?**

Đáp: Là một kỹ năng mình chưa giỏi nhưng cần cho mục tiêu số 1, và chỉ tiến bộ khi luyện đều. Ví dụ: thuyết trình trước khách hàng với người kinh doanh; phân tích số liệu với người kế toán; phỏng vấn tuyển dụng với người làm nhân sự; viết hướng dẫn kỹ thuật với kỹ sư; xử lý cuộc gọi khiếu nại khó với người chăm sóc khách hàng; góp ý trực tiếp cho thành viên với người quản lý.

**Hỏi: Khác gì với luyện tập có chủ đích của tuần #0027?**

Đáp: Tuần #0027 dạy cách luyện: một kỹ năng con, ngoài vùng quen, có phản hồi. Quy tắc việc khó trả lời câu hỏi khác: luyện đến bao giờ. Nó đặt ra một cam kết thời gian, để những tuần nản không trở thành điểm dừng.

**Hỏi: "Điểm dừng tự nhiên" trong công việc là gì?**

Đáp: Là một mốc đã biết trước: cuối quý 1, sau mười buổi thuyết trình, sau khi hoàn thành một khoá học. Đến mốc đó, mình nhìn lại và quyết định tiếp tục hay đổi việc khó khác. Trước mốc đó, ngày nản vẫn luyện, chỉ có thể luyện ít hơn.

**Hỏi: Một tuần luyện bao nhiêu là đủ?**

Đáp: Không có con số chung. Với hành trình này, gợi ý là một đến hai phiên mỗi tuần, mỗi phiên 20 đến 45 phút, đặt thành thẻ trên bảng Kanban. Đều đặn quan trọng hơn độ dài.

**Hỏi: Nếu việc khó quá sức thì sao?**

Đáp: Chia nhỏ hơn. Việc khó nên ở rìa khả năng hiện tại, khó vừa đủ để phải tập trung, không khó tới mức chỉ thấy thất bại. Nếu sau ba buổi vẫn không biết bắt đầu từ đâu, hãy hỏi một người làm giỏi việc đó một câu duy nhất: "Nếu bắt đầu lại, anh chị sẽ luyện phần nào trước?"

**Hỏi: Việc khó có liên quan gì đến thói quen then chốt?**

Đáp: Có thể là một, có thể là hai. Có người chọn chính thói quen then chốt làm việc khó. Có người giữ thói quen then chốt như cũ và thêm một phiên luyện mỗi tuần. Cả hai đều được, miễn là việc khó được viết ra và có điểm dừng.

**Ngày 4 (20 phút)**

1. Chọn một việc khó trong công việc, gắn với mục tiêu số 1.
2. Kiểm tra ba điều kiện: cần luyện đều, tự mình chọn, có điểm dừng tự nhiên.
3. Viết điểm dừng và đặt phiên luyện đầu tiên thành một thẻ trên bảng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-4.

Chia sẻ hôm nay: "Việc khó tôi luyện mỗi tuần: .... Tôi giữ đến: ...".


## Bài 5: Ngày 5 (Thứ Sáu 22/01)
@img 5_ngay-nan
@pdf 10XHub_GanGoc_PhieuNgay5_ngay-nan.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: NGÀY NẢN, LÀM PHIÊN BẢN TỐI THIỂU

Gan góc không có nghĩa là ngày nào cũng tràn đầy năng lượng. Người giữ được một hướng đi lâu thường có sẵn cách làm cho những ngày không muốn làm. Hôm nay là một bảng chọn theo mức năng lượng của chính ngày hôm đó. Mỗi sáng, chọn một mức, làm đúng phiên bản của mức đó.

**Mức Đầy: phiên bản đầy đủ**

Dấu hiệu: ngủ đủ, lịch làm việc thoáng, đầu óc tỉnh táo. Làm thói quen then chốt như đã thiết kế, và nếu có thể, làm thêm một phiên luyện việc khó. Ví dụ với thói quen "viết ba việc quan trọng nhất trước khi mở hộp thư": viết ba việc, nhìn bảng năm phút, làm luôn thẻ khó nhất trong 45 phút.

**Mức Vừa: phiên bản rút gọn**

Dấu hiệu: một ngày bình thường, có vài cuộc họp, năng lượng ở mức trung bình. Giữ phần cốt lõi của thói quen, bỏ phần mở rộng. Ví dụ: viết ba việc, nhìn bảng năm phút, chưa bắt buộc làm thẻ khó.

**Mức Cạn: phiên bản tối thiểu**

Dấu hiệu: sau một chuyến công tác, một tuần chốt số liệu, một ngày nhiều việc phát sinh, hoặc đơn giản là không muốn bắt đầu. Làm phiên bản nhỏ nhất vẫn giữ được bản sắc. Ví dụ: viết một việc quan trọng nhất lên giấy ghi chú. Hai phút là đủ.

**Vì sao phiên bản tối thiểu quan trọng?**

Mùa 1, tuần #0022 đã có phiên bản hai phút. Tuần này dùng lại nó với một mục đích khác: không để ngày nản cắt đứt chuỗi. Quy tắc "không bỏ lỡ hai lần liên tiếp" vẫn đúng. Phiên bản tối thiểu giúp ngày Cạn vẫn được đánh dấu trên bảng hành trình, và hôm sau quay lại mức Vừa dễ hơn nhiều so với bắt đầu lại từ đầu.

Nghiên cứu của Credé và cộng sự cho thấy phần kiên trì nỗ lực có giá trị dự báo rõ nhất trong gan góc. Kiên trì ở đây không đòi hỏi ngày nào cũng làm nhiều. Nó đòi hỏi ngày nào cũng làm một chút.

**Một lưu ý về nghỉ ngơi**

Phiên bản tối thiểu là cách giữ thói quen trong công việc, không phải lời khuyên làm việc khi cần nghỉ. Những ngày nghỉ phép, ngày nghỉ lễ, Chủ Nhật vẫn là ngày nghỉ. Ngày Cạn vì quá tải kéo dài là tín hiệu để trao đổi với cấp trên về khối lượng việc, điều tuần sau sẽ bàn kỹ hơn.

**Ngày 5 (20 phút)**

1. Viết ba phiên bản của thói quen then chốt: Đầy, Vừa, Cạn.
2. Chọn mức năng lượng của hôm nay, làm đúng phiên bản đó.
3. Đánh dấu bảng hành trình những ngày tuần này đã làm, kể cả ngày làm phiên bản tối thiểu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-5.

Chia sẻ hôm nay: "Ngày nản, phiên bản tối thiểu của thói quen của tôi là: .... Hôm nay tôi ở mức: ...".


## Bài 6: Ngày 6 (Thứ Bảy 23/01)
@img 6_thu-ngay-nan
@img2 9_the-thanh-tich
@pdf 10XHub_GanGoc_PhieuNgay6_thu-ngay-nan.pdf (phiếu thực hành và trang thư in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MỘT LÁ THƯ CHO NGÀY MUỐN BỎ CUỘC

Gửi các anh chị và các bạn của 10X Excellence Hub,

Hôm nay là Thứ Bảy của tuần thứ ba năm 2027. Bài cuối tuần này Trường viết theo dạng một lá thư, vì việc của ngày hôm nay cũng là viết một lá thư.

Ngày cuối năm 2026, nhiều người trong nhóm đã viết thư gửi chính mình, hẹn mở vào ngày 30.06 hoặc 31.12.2027. Lá thư đó có một ngày hẹn rõ ràng. Lá thư hôm nay khác: nó không có ngày mở cố định. Nó dành cho một ngày nào đó trong năm, khi các anh chị và các bạn ngồi trước tấm bảng Kanban, nhìn thói quen then chốt, và nghĩ: thôi, bỏ đi.

Ngày đó có thể đến vào tháng 3, khi chốt quý. Có thể vào tháng 6, khi dự án dồn dập. Có thể vào một buổi chiều rất bình thường. Theo những gì nghiên cứu về quyết tâm năm mới gợi ý, ngày đó đến với phần lớn chúng ta, không riêng ai.

Một lá thư cho ngày đó nên có bốn phần.

Phần một là lý do dài hạn, viết bằng lời của chính mình, câu đã tìm ra hôm Thứ Tư.

Phần hai là một bằng chứng: một lần mình đã tiếp tục dù khó, và điều gì đã xảy ra sau đó. Câu viết hôm Thứ Ba có thể dùng ở đây.

Phần ba là phiên bản tối thiểu: "Hôm nay chỉ cần làm điều này." Không cần làm hết, chỉ cần không bỏ.

Phần bốn là một lời dặn tử tế, như lời mình sẽ nói với một đồng nghiệp đang nản: không trách, không thúc ép, chỉ nhắc rằng một ngày nản không xoá được những ngày đã làm.

Lưu lá thư ở nơi dễ tìm: trang cuối sổ kế hoạch, một ghi chú trên điện thoại, mặt sau tấm thẻ 5 mục tiêu. Ghi rõ dấu hiệu để mở thư, ví dụ "khi hai ngày liền không muốn nhìn bảng".

Ba tuần qua, năm mục tiêu đã thành những thẻ việc, và giờ có thêm một lý do dài hạn đứng phía sau. Gan góc không phải là không bao giờ nản. Nó là việc biết mình sẽ làm gì vào ngày nản.

Trường

**Tuần sau: Đặt ranh giới**

Tuần 25.01 đến 30.01 là tuần nước rút trước Tết. Công thức #0037 Đặt ranh giới, bắt đầu Thứ Hai 25.01, giúp bảo vệ giờ làm việc quan trọng và thói quen then chốt giữa lúc việc cuối năm dồn lại, chốt việc và bàn giao để nghỉ Tết trọn vẹn. Thứ Bảy 30.01 cũng là ngày 23 tháng Chạp, ngày tiễn Ông Công Ông Táo.

**Ngày 6 (25 phút)**

1. Viết lá thư bốn phần trên sổ thực hành hoặc trên trang thư in được ở phiếu Ngày 6.
2. Ghi dấu hiệu để mở thư và nơi lưu thư.
3. Đọc lại bảng gom cả tuần: lý do dài hạn, mục tiêu số 1, việc khó, phiên bản tối thiểu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0036-ngay-6.

Chia sẻ hôm nay: "Tôi đã viết thư cho ngày muốn bỏ cuộc. Tôi sẽ mở thư khi: .... Lý do dài hạn tôi nhắc mình: ...".

Nội dung lá thư là của riêng mình, các anh chị và các bạn chỉ cần chia sẻ câu trên thôi nha.

**Thẻ thành tích**

Ai đánh dấu đã chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hình bậc thang: con số lớn là tổng số ngày đã giữ thói quen trên cả hành trình, chữ "ngày giữ thói quen", tên mình và lý do dài hạn. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần thứ ba đã qua, và thói quen vẫn còn đó.
