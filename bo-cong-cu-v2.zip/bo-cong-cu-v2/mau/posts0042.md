## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 01/03)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0042_Quy Luat Parkinson Hop Thoi Gian_VN.pdf (tài liệu đầy đủ của Công thức #0042)
@pdf 10XHub_HopThoiGian_PhieuNgay1_viec-phinh-ra.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0042.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỞ TUẦN #0042: QUY LUẬT PARKINSON, ĐỌC LẠI TỪ BÀI VIẾT GỐC

Thứ Bảy vừa rồi, cả nhóm đã làm lần chuyển việc đầu tiên: lật lại các trang sổ đầu dòng, chuyển những việc còn cần sang tháng 3, lên lịch một số việc cho các tháng sau và mạnh dạn gạch bỏ những việc không còn đáng làm. Mỗi người cũng đã chọn một ngày chuyển việc cố định cho các tháng tới. Hôm nay là ngày đầu tháng 3, tháng khép lại quý 1, và các bước của năm mục tiêu đã có chỗ trong sổ.

Câu hỏi tiếp theo: mỗi bước đó sẽ được làm trong bao lâu? Công thức #0042 của tuần này là Quy luật Parkinson và hộp thời gian.

**Nếu mới tham gia:** tuần này không cần biết gì về các tuần trước. Hôm nay mở sổ thực hành, viết một thói quen then chốt trong công việc (ví dụ: mỗi sáng làm 45 phút cho việc quan trọng nhất trước khi họp) và một mục tiêu quan trọng nhất của quý này, rồi làm bài Ngày 1. Cả tuần sẽ xoay quanh một bước nhỏ của chính mục tiêu đó.

**Một bài viết năm 1955**

Rất nhiều người từng nghe câu "công việc kéo dài ra để lấp đầy thời gian có được để hoàn thành nó". Ít người đọc bài viết gốc. Tuần này bắt đầu từ chính bài viết đó, vì nó nói nhiều hơn một câu trích dẫn.

Ngày 19.11.1955, tạp chí The Economist đăng một bài viết của C. Northcote Parkinson, một nhà sử học người Anh. Câu mở đầu bài chính là câu nổi tiếng ở trên. Ngay sau đó, Parkinson đưa ra một ví dụ: một bà cụ có nhiều thời gian rảnh có thể mất trọn một ngày để viết và gửi một tấm bưu thiếp cho cháu gái. Theo cách Parkinson kể, bà dành một giờ tìm tấm bưu thiếp, một giờ tìm kính, nửa giờ tìm địa chỉ, một giờ mười lăm phút để viết, và hai mươi phút phân vân có nên mang ô khi ra hòm thư ở phố bên. Cũng việc đó, một người bận rộn làm xong trong khoảng ba phút.

Nhưng bài viết không nhằm khuyên ai làm việc nhanh hơn. Đó là một bài viết châm biếm về bộ máy hành chính. Parkinson dẫn số liệu của Bộ Hải quân Anh: từ năm 1914 đến năm 1928, số tàu chiến chủ lực đang hoạt động giảm từ 62 xuống 20, nhưng số viên chức của Bộ lại tăng từ khoảng 2.000 lên 3.569 người. Ông giải thích bằng hai động lực: một viên chức muốn có thêm cấp dưới chứ không muốn có thêm đối thủ, và các viên chức tạo ra việc cho nhau. Theo cách tính nửa đùa nửa thật của ông, số nhân sự hành chính tăng đều khoảng 5,17 đến 6,56 phần trăm mỗi năm, bất kể khối lượng việc thật tăng hay giảm.

**Từ châm biếm đến nghiên cứu**

Năm 1967, Judith Bryan và Edwin Locke đưa ý tưởng này vào phòng thí nghiệm. Họ giao cho người tham gia những bài tính cộng, một nhóm được cho thời gian gấp đôi mức cần thiết, một nhóm được cho vừa đủ. Ở những lượt đầu, nhóm có nhiều thời gian làm chậm hơn, đúng như Parkinson mô tả. Nhưng điều đáng chú ý là cách các tác giả giải thích: thời gian được giao đã hoạt động như một mục tiêu ngầm. Người ta đặt nhịp làm việc theo khoảng thời gian mình nghĩ là được phép dùng.

Đây là điểm mấu chốt của cả tuần: nếu thời gian được giao là một mục tiêu ngầm, thì mình có thể chủ động đặt mục tiêu đó, cho từng bước, trên lịch. Đó là hộp thời gian.

**Sáu ngày của tuần**

- Thứ Hai: tìm những việc đã phình ra trong tuần trước.
- Thứ Ba: một phép thử nhỏ về ước lượng thời gian.
- Thứ Tư: hộp thời gian đầu tiên cho mục tiêu số 1.
- Thứ Năm: chia nhỏ một bước rồi mới đặt hạn chót và hộp thời gian.
- Thứ Sáu: đặt hộp thời gian lên lịch tuần sau.
- Thứ Bảy: một cuộc họp 20 phút với chính mình.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Những việc đã phình ra**

1. Mở sổ thực hành, xem lại thói quen đang giữ và mục tiêu số 1.
2. Lật lại các trang sổ đầu dòng của tuần trước (hoặc lịch làm việc, hộp thư đã gửi). Tìm ba việc đã chiếm nhiều thời gian hơn mức cần thiết. Gợi ý: một bản báo cáo sửa đi sửa lại, một cuộc họp kéo dài, một email soạn mất cả buổi sáng.
3. Với mỗi việc, ước lượng: nếu chỉ có một nửa thời gian, mình vẫn làm được ở mức chấp nhận được không?
4. Chọn một bước nhỏ của mục tiêu số 1 sẽ đặt vào hộp thời gian trong tuần này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-1.

Chia sẻ hôm nay: "Việc tuần trước kéo dài hơn cần thiết nhất: .... Bước của mục tiêu số 1 tôi sẽ đặt vào hộp thời gian tuần này: ...".

Việc phình ra không có nghĩa là mình làm việc kém, các anh chị và các bạn chỉ cần ghi lại thật lòng để tuần này có điểm bắt đầu nha.


## Bài 2: Ngày 2 (Thứ Ba 02/03)
@img 2_uoc-luong
@pdf 10XHub_HopThoiGian_PhieuNgay2_uoc-luong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: PHÉP THỬ ƯỚC LƯỢNG BA VIỆC

Quy luật Parkinson nói rằng việc có xu hướng kéo dài ra khi có nhiều thời gian. Nhưng có một xu hướng khác, đi theo chiều ngược lại, cũng mạnh không kém: chúng ta thường ước lượng thiếu thời gian cần để làm xong một việc. Hôm nay không đọc thêm lý thuyết. Hôm nay làm một phép thử nhỏ, ngay trong ngày làm việc.

**Phép thử**

Sáng nay, trước khi bắt tay vào việc, chọn ba việc sẽ làm trong ngày. Nên chọn ba loại khác nhau: một việc viết (báo cáo, đề xuất, email dài), một việc xử lý số liệu hoặc kỹ thuật, và một việc phải phối hợp với người khác. Với mỗi việc, ghi vào sổ thực hành số phút mình nghĩ sẽ cần. Viết ngay, đừng tính kỹ.

Trong ngày, khi làm từng việc, ghi giờ bắt đầu và giờ kết thúc vào sổ đầu dòng. Cuối ngày, nhập số phút thực tế vào sổ thực hành. Sổ tự cộng tổng ước lượng và tổng thực tế.

**Điều thường xảy ra**

Đến cuối ngày, nhiều người thấy tổng thực tế lớn hơn tổng ước lượng, có khi lớn hơn khá nhiều. Đây không phải chuyện riêng của ai.

Năm 1979, Daniel Kahneman và Amos Tversky đặt tên cho hiện tượng này là sai lệch lập kế hoạch. Năm 1994, Roger Buehler, Dale Griffin và Michael Ross công bố một nghiên cứu được nhắc lại rất nhiều: 37 sinh viên năm cuối ngành tâm lý học được hỏi bao lâu nữa sẽ hoàn thành luận văn. Trung bình họ dự đoán 33,9 ngày. Thực tế trung bình là 55,5 ngày. Chỉ khoảng 30 phần trăm hoàn thành trong thời gian mình dự đoán. Điều thú vị là ngay cả dự đoán "trường hợp xấu nhất" của họ, trung bình 48,6 ngày, cũng vẫn ngắn hơn thực tế.

**Hai xu hướng, một công cụ**

Đặt hai điều cạnh nhau sẽ thấy một nghịch lý. Khi được cho nhiều thời gian, việc phình ra. Khi tự ước lượng, mình lại ước lượng thiếu. Hộp thời gian xử lý cả hai: nó đặt một giới hạn rõ ràng để việc không phình ra, và vì có ghi lại kết quả thật sau mỗi hộp, nó giúp ước lượng lần sau sát hơn.

Phép thử hôm nay chính là dữ liệu đầu tiên cho việc đó. Nếu việc viết của mình thường mất gấp rưỡi ước lượng, lần sau đặt hộp cho việc viết dài hơn một chút, hoặc thu nhỏ phạm vi của việc.

**Bảng hành trình**

Tuần này bảng hành trình nằm ở Ngày 2. Đánh dấu những ngày đã làm thói quen then chốt, kể cả hôm qua.

**Ngày 2 (15 phút, chia trong ngày)**

1. Sáng: chọn ba việc khác loại, ghi số phút ước lượng.
2. Trong ngày: ghi giờ bắt đầu và kết thúc từng việc.
3. Cuối ngày: nhập số phút thực tế, đọc tổng sổ tự cộng.
4. Đánh dấu bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-2.

Chia sẻ hôm nay: "Tổng ước lượng ba việc hôm nay: ... phút; thực tế: ... phút. Việc lệch nhiều nhất: ...".

Lệch nhiều hay ít đều là dữ liệu tốt, không có kết quả đúng hay sai trong phép thử này nha.


## Bài 3: Ngày 3 (Thứ Tư 03/03)
@img 3_hop-dau-tien
@pdf 10XHub_HopThoiGian_PhieuNgay3_hop-dau-tien.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: HỘP THỜI GIAN ĐẦU TIÊN CHO MỤC TIÊU SỐ 1

Hôm nay đặt hộp thời gian đầu tiên. Bài viết theo dạng hỏi đáp, vì khi bắt đầu, câu hỏi thường gặp nhất không phải "hộp thời gian là gì" mà là "làm thế nào khi...".

**Hộp thời gian khác gì một việc trong danh sách?**

Một việc trong danh sách chỉ có tên: "soạn đề xuất cho khách hàng". Một hộp thời gian có thêm bốn điều: giờ bắt đầu, độ dài, kết quả "đủ" khi hết giờ, và một điểm dừng. Ví dụ: "Thứ Tư, 8:30 đến 9:15, viết xong phần giải pháp của bản đề xuất ở mức bản nháp, 9:15 dừng lại dù chưa hoàn hảo."

**Kết quả "đủ" nghĩa là gì?**

Là mức mà khi hết hộp, mình có thể dừng mà không thấy dở dang vô ích. Viết kết quả đủ trước khi bắt đầu. Đây là phần chống lại Quy luật Parkinson trực tiếp nhất: không có kết quả đủ, việc sẽ tự mở rộng tiêu chuẩn của nó, từ bản nháp thành bản hoàn chỉnh, từ hoàn chỉnh thành hoàn hảo.

**Hộp nên dài bao lâu?**

Với bước đầu tiên, 25 đến 45 phút là khoảng dễ giữ. Đủ dài để làm được việc có ý nghĩa, đủ ngắn để không bị cuộc họp hay cuộc gọi cắt ngang. Thứ Sáu sẽ có bảng chọn độ dài theo loại việc.

**Hết giờ mà chưa đạt kết quả đủ thì sao?**

Dừng lại, ghi vào sổ đầu dòng mình đã đến đâu, rồi chọn một trong hai: đặt thêm một hộp mới vào lịch (không kéo dài hộp hiện tại), hoặc thu nhỏ kết quả đủ cho lần sau. Kéo dài hộp ngay tại chỗ là cách nhanh nhất để hộp thời gian trở lại thành danh sách việc.

**Bị gián đoạn giữa hộp thì sao?**

Nếu gián đoạn ngắn và không tránh được, xử lý xong rồi quay lại, giữ nguyên giờ kết thúc. Nếu gián đoạn lớn, coi như hộp đó dừng, đặt lại hộp mới. Một cách giảm gián đoạn: đặt hộp vào khung giờ ít cuộc gọi nhất, và báo trước với đồng nghiệp ngồi gần.

**Có khác gì khối làm việc sâu ở tuần #0025?**

Khối làm việc sâu là một khoảng thời gian dài được bảo vệ cho loại việc cần tập trung cao. Hộp thời gian nhỏ hơn và cụ thể hơn: mỗi hộp gắn với một bước và một kết quả đủ. Một khối làm việc sâu 90 phút có thể chứa hai hộp thời gian.

**Có nên hẹn giờ không?**

Nên, nhất là những lần đầu. Sổ thực hành hôm nay có sẵn đồng hồ đếm ngược. Chọn độ dài, bấm Bắt đầu, làm đến khi hết giờ.

**Ngày 3 (khoảng 45 phút, gồm chính hộp thời gian)**

1. Lấy bước của mục tiêu số 1 đã chọn hôm Thứ Hai.
2. Viết bốn điều: giờ bắt đầu, độ dài, kết quả đủ, điểm dừng.
3. Làm hộp thời gian với đồng hồ đếm ngược trên sổ.
4. Ghi kết quả và viết quy tắc hộp thời gian của riêng mình. Quy tắc này được lưu cho cả hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-3.

Chia sẻ hôm nay: "Hộp thời gian đầu tiên của tôi: ..., ... phút. Kết quả: ...".


## Bài 4: Ngày 4 (Thứ Năm 04/03)
@img 4_chia-nho
@pdf 10XHub_HopThoiGian_PhieuNgay4_chia-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CHIA NHỎ RỒI MỚI ĐẶT HẠN

Hôm Thứ Ba, phép thử ước lượng ba việc đã cho thấy một điều quen thuộc: tổng thời gian thực tế thường dài hơn tổng ước lượng. Đó là sai lệch lập kế hoạch mà Buehler, Griffin và Ross mô tả năm 1994. Hôm nay là một cách chữa có nghiên cứu đi kèm, đặt hai cách ước lượng cạnh nhau để đối chiếu: chia nhỏ rồi mới đặt hạn.

**Nghiên cứu: liệt kê trước, ước lượng sau**

Năm 2004, Justin Kruger và Matt Evans công bố trên tạp chí Journal of Experimental Social Psychology bài báo có tên "If you don't want to be late, enumerate: Unpacking reduces the planning fallacy". Ý chính của bài báo: khi ước lượng một việc gồm nhiều phần, người ta thường nhìn việc đó như một khối, và bỏ sót những phần nhỏ nằm bên trong.

Trong các nghiên cứu, một số người tham gia ước lượng ngay thời gian cần cho một việc, ví dụ mua quà cho các dịp lễ cuối năm hay định dạng lại một văn bản. Một số người khác được đề nghị liệt kê các phần của việc trước, rồi mới ước lượng. Nhóm liệt kê trước đưa ra ước lượng dài hơn và sát với thời gian thực tế hơn. Mức cải thiện rõ hơn ở những việc phức tạp, gồm nhiều phần.

Một lưu ý để dùng cho đúng: các nghiên cứu về sau, ví dụ của Hadjichristidis, Summers và Thomas năm 2014, cho thấy tác dụng của việc liệt kê còn phụ thuộc vào việc con nào được đưa vào danh sách. Vì vậy điều quan trọng là liệt kê đủ, kể cả những phần ít ai nghĩ tới, chứ không chỉ những phần dễ thấy.

**Đối chiếu: cùng một bước, hai cách ước lượng**

Một chuyên viên nhân sự có bước "bản nháp bài đầu tiên của bộ tài liệu đào tạo nhân viên mới".

Cách thứ nhất, ước lượng nhanh: "khoảng 2 giờ, xong trong sáng Thứ Hai".

Cách thứ hai, liệt kê việc con trước:
1. Xin danh sách quy trình từ hai phòng liên quan: 20 phút.
2. Đọc tài liệu các phòng gửi về: 40 phút.
3. Viết dàn ý: 30 phút.
4. Viết nội dung bản nháp: 90 phút.
5. Gửi trưởng phòng xem và chỉnh theo góp ý: 40 phút.

Tổng sau khi chia nhỏ: 220 phút, gần 3 giờ 40 phút, chưa kể thời gian chờ các phòng gửi tài liệu. Hạn chót "sáng Thứ Hai" trở thành "Thứ Tư", và thay vì một hộp lớn, bước này cần bốn hộp thời gian trên lịch: 20 phút gửi đề nghị cho hai phòng ngay hôm nay, 70 phút đọc tài liệu và viết dàn ý, 90 phút viết bản nháp, 40 phút chỉnh theo góp ý.

Hai con số không nói ai đúng ai sai. Con số thứ hai chỉ cho thấy những phần đã bị gộp mất trong con số thứ nhất.

**Ba phần hay bị bỏ sót khi liệt kê**

- Phần chờ và phối hợp: xin số liệu, chờ phản hồi, hẹn lịch với người khác.
- Phần kiểm tra và sửa: đọc lại, đối chiếu, chỉnh theo góp ý.
- Phần gửi và bàn giao: đóng gói tệp, viết email kèm theo, cập nhật vào hệ thống.

**Ngày 4 (20 phút)**

1. Chọn một bước của năm mục tiêu, nên là bước gồm nhiều phần.
2. Ghi ngay số phút ước lượng nhanh, trước khi nghĩ kỹ.
3. Liệt kê các việc con (gợi ý tối đa năm việc), ước lượng từng việc, xem tổng.
4. Đặt hạn chót cho bước này và các hộp thời gian cuối cùng trên lịch, dựa trên con số sau khi chia nhỏ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-4.

Chia sẻ hôm nay: "Bước tôi chia nhỏ hôm nay: .... Ước lượng trước khi chia nhỏ: ... phút; sau khi chia nhỏ: ... phút. Hạn chót: ...; hộp thời gian cuối cùng: ...".

Chênh lệch giữa hai con số càng lớn thì bài tập hôm nay càng có ích, các anh chị và các bạn cứ ghi đúng con số của mình nha.


## Bài 5: Ngày 5 (Thứ Sáu 05/03)
@img 5_do-dai-hop
@pdf 10XHub_HopThoiGian_PhieuNgay5_lich-tuan-sau.pdf (phiếu thực hành và lịch hộp thời gian một tuần in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: HỘP BAO NHIÊU PHÚT CHO LOẠI VIỆC NÀO?

Hôm nay đặt hộp thời gian lên lịch tuần sau, từ Thứ Hai 08.03 đến Thứ Sáu 12.03. Câu hỏi đầu tiên luôn là: hộp nên dài bao lâu? Không có một con số đúng cho mọi việc. Bài hôm nay là một bảng chọn: tìm loại việc của mình, xem độ dài gợi ý, rồi điều chỉnh theo kết quả phép thử hôm Thứ Ba.

**Hộp 15 phút**

Hợp với: việc nhỏ, rõ ràng, làm một mạch được. Trả lời một nhóm email cần quyết định, gọi xác nhận lịch với hai khách hàng, duyệt một bảng chấm công.

Lưu ý: gom nhiều việc nhỏ cùng loại vào một hộp. Mười lăm phút cho năm email thường hiệu quả hơn năm lần mở hộp thư rải rác.

**Hộp 25 đến 30 phút**

Hợp với: bước khởi động của một việc lớn, việc mình đang ngại bắt đầu. Viết dàn ý báo cáo, đọc và đánh dấu một hợp đồng, chuẩn bị câu hỏi cho buổi phỏng vấn.

Lưu ý: hộp ngắn làm cho việc khó bắt đầu trở nên nhẹ hơn. Khi hết hộp, nếu đang vào nhịp, có thể đặt ngay thêm một hộp nữa sau năm phút nghỉ.

**Hộp 45 đến 60 phút**

Hợp với: phần lớn các bước của năm mục tiêu. Viết phần chính của một đề xuất, phân tích số liệu bán hàng tháng, thiết kế một quy trình mới.

Lưu ý: đây là độ dài nên dùng nhiều nhất. Đặt vào giờ năng lượng cao đã tìm ở tuần Quản lý năng lượng (#0024), nếu có thể.

**Hộp 90 phút**

Hợp với: việc cần tập trung sâu và liền mạch. Viết một chương tài liệu đào tạo, xử lý một sự cố kỹ thuật phức tạp, lập kế hoạch ngân sách quý.

Lưu ý: chỉ một hộp như vậy mỗi ngày là đủ. Bảo vệ nó như một cuộc họp với khách hàng quan trọng.

**Ba quy tắc khi đặt hộp lên lịch**

1. Chừa khoảng trống. Đừng lấp đầy lịch bằng hộp. Một nửa thời gian làm việc có hộp đã là nhiều với tuần đầu.
2. Mỗi mục tiêu trong năm mục tiêu nên có ít nhất một hộp trong tuần, mục tiêu số 1 có nhiều hộp nhất.
3. Đặt hộp như một cuộc hẹn thật trên lịch làm việc, có tên bước và kết quả đủ, để đồng nghiệp nhìn lịch cũng hiểu.

**Ngày 5 (25 phút)**

1. Xem lại kết quả phép thử Thứ Ba: loại việc nào mình hay ước lượng thiếu?
2. Chọn các bước sẽ làm tuần sau cho năm mục tiêu.
3. Đặt từng bước vào hộp có độ dài phù hợp trên lịch tuần 08.03 đến 12.03.
4. Đếm số hộp đã đặt, ghi hộp dài nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-5.

Chia sẻ hôm nay: "Tôi đã đặt ... hộp thời gian lên lịch tuần sau cho năm mục tiêu. Hộp dài nhất: ...".


## Bài 6: Ngày 6 (Thứ Bảy 06/03)
@img 6_tu-hop
@img2 9_the-thanh-tich
@pdf 10XHub_HopThoiGian_PhieuNgay6_tu-hop.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: CUỘC HỌP 20 PHÚT VỚI CHÍNH MÌNH

Cuối tuần Quy luật Parkinson, có một cách khép tuần rất hợp chủ đề: tổ chức một cuộc họp với chính mình, có chương trình, có giờ bắt đầu, giờ kết thúc, và đúng 20 phút. Nếu cuộc họp này kéo dài ra, chính nó sẽ là một ví dụ của Quy luật Parkinson.

Dưới đây là chương trình họp. Mở sổ thực hành, đặt đồng hồ, đi lần lượt từng mục.

**Chương trình cuộc họp**

*Thời gian: 20 phút. Thành phần: chính mình. Tài liệu: sổ đầu dòng, lịch làm việc, sổ thực hành.*

**Mục 1 (5 phút): Hộp nào đã giữ được?**

Đọc lại các hộp thời gian đã làm trong tuần, từ hộp đầu tiên hôm Thứ Tư. Chọn hộp giữ tốt nhất: bắt đầu đúng giờ, dừng đúng giờ, đạt kết quả đủ. Ghi lại vì sao hộp đó giữ được: giờ phù hợp, việc rõ, hay không bị gián đoạn?

**Mục 2 (5 phút): Hộp nào đã tràn?**

Chọn hộp tràn nhiều nhất hoặc không bắt đầu được. Tìm một nguyên nhân chính, không cần nhiều: ước lượng thiếu, kết quả đủ chưa rõ, bị gọi vào họp, hay đặt vào giờ năng lượng thấp. Viết một điều sẽ sửa ở tuần sau.

**Mục 3 (5 phút): Chấm ba điểm**

Trên sổ thực hành, chấm từ 1 đến 5 cho ba câu: mình bắt đầu hộp đúng giờ đến mức nào; mình dừng hộp đúng giờ đến mức nào; kết quả đủ có rõ ràng trước khi bắt đầu không. Điểm thấp nhất cho biết tuần sau cần chú ý điều gì.

**Mục 4 (5 phút): Chốt quy tắc hộp thời gian**

Đọc lại quy tắc hộp thời gian đã viết hôm Thứ Tư. Sửa cho sát với điều đã học trong tuần. Quy tắc tốt thường ngắn và cụ thể, ví dụ: "Mỗi sáng một hộp 45 phút cho mục tiêu số 1, bắt đầu 8:30, viết kết quả đủ từ chiều hôm trước, hết giờ thì dừng và đặt hộp mới." Quy tắc này được lưu cho cả hành trình.

**Kết thúc đúng giờ**

Hết 20 phút thì dừng, kể cả khi còn muốn viết thêm. Đó là bài tập cuối cùng của tuần.

**Tuần sau: Nghịch lý lựa chọn**

Thứ Hai tới, 08.03, là Ngày Quốc tế Phụ nữ, và cũng là ngày mở Công thức #0043 Nghịch lý lựa chọn. Tuần này giúp mỗi bước có một khoảng thời gian rõ ràng. Tuần sau bàn về một điều thường lấy mất thời gian mà ít ai để ý: số lựa chọn mình phải cân nhắc mỗi ngày, và khi nào nên chọn ở mức "đủ tốt" để dành sức cho mục tiêu lớn.

**Ngày 6 (20 phút, đúng 20 phút)**

1. Mục 1: hộp giữ tốt nhất và vì sao.
2. Mục 2: hộp tràn nhiều nhất và một điều sẽ sửa.
3. Mục 3: chấm ba điểm.
4. Mục 4: chốt quy tắc hộp thời gian.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0042-ngay-6.

Chia sẻ hôm nay: "Tuần hộp thời gian: hộp giữ tốt nhất là .... Quy tắc hộp thời gian tôi giữ: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hộp thời gian hiện ra: con số 6/6 trong hình mặt trời trên đường chân trời, tên mình và quy tắc hộp thời gian của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần sau mở đầu bằng một ngày rất đặc biệt.
