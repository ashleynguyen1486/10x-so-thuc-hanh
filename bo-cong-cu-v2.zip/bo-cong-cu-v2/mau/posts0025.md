## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 02/11)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0025_Cong Viec Sau_VN.pdf (tài liệu đầy đủ của Công thức #0025)
@pdf 10XHub_CongViecSau_PhieuNgay1_sau-va-nong.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0025.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** VIỆC SÂU, VIỆC NÔNG: HAI CHỮ ĐỔI CẢ LỊCH LÀM VIỆC

Tuần trước, cả nhóm đã chấm năng lượng ba lần trong ngày, tìm ra giờ vàng và dời thói quen then chốt vào đó, thêm một lần nghỉ ngắn có chủ đích, viết một câu ý nghĩa cho thói quen và sắp lịch năng lượng cho tuần này. Giờ vàng đã có. Tuần này bảo vệ nó.

**Nếu mới tham gia:** tuần này rất hợp để bắt đầu, vì cả tuần xoay quanh một câu hỏi ai cũng gặp: làm sao có được một khoảng thời gian tập trung trọn vẹn mỗi ngày. Hôm nay mở sổ thực hành Ngày 1, viết câu bản sắc và một thói quen then chốt, rồi chia sáu việc của một ngày làm việc gần nhất thành hai nhóm như hướng dẫn bên dưới.

**Giải nghĩa hai chữ của tuần**

Năm 2016, Cal Newport, người giảng dạy khoa học máy tính tại Đại học Georgetown (Mỹ), xuất bản cuốn Deep Work. Cả cuốn sách xoay quanh hai khái niệm.

**Công việc sâu** là những hoạt động chuyên môn được làm trong trạng thái tập trung không bị xao nhãng, đẩy năng lực suy nghĩ của mình đến gần giới hạn. Theo Newport, những việc này tạo ra giá trị mới, giúp mình giỏi lên, và người khác khó làm thay. Ví dụ: viết một đề xuất cho khách hàng mới, phân tích nguyên nhân chênh lệch số liệu, thiết kế lại một quy trình, chuẩn bị nội dung đào tạo.

**Công việc nông** là những việc mang tính hành chính, không đòi hỏi nhiều suy nghĩ, thường được làm trong lúc bị cắt ngang. Ví dụ: trả lời thư xác nhận lịch họp, cập nhật bảng theo dõi, sắp xếp tài liệu, điền biểu mẫu.

Việc nông không xấu. Mọi vị trí đều cần nó, và nhiều việc nông rất quan trọng. Vấn đề nằm ở tỷ lệ: một ngày làm việc tám tiếng có thể trôi qua hoàn toàn trong việc nông, mà cuối ngày vẫn thấy mình rất bận.

**Một câu hỏi để phân biệt**

Newport gợi ý một phép thử: cần bao nhiêu tháng để đào tạo một người mới tốt nghiệp đại học, thông minh nhưng chưa có chuyên môn trong lĩnh vực của mình, làm được việc này? Câu trả lời là vài tuần thì đó là việc nông. Câu trả lời là nhiều tháng, nhiều năm thì đó là việc sâu.

Thử với ba việc của một trưởng phòng kế toán: nhập hoá đơn vào phần mềm (vài tuần, việc nông), đối chiếu công nợ cuối tháng (vài tháng, ở giữa), giải thích cho ban giám đốc vì sao dòng tiền quý này giảm và đề xuất cách xử lý (nhiều năm, việc sâu).

**Nối với hành trình**

Tuần 0021, cả nhóm đã tìm hiểu trạng thái Dòng chảy, những phiên tập trung trọn vẹn. Công việc sâu là cách tạo điều kiện để Dòng chảy dễ xuất hiện hơn: một khối thời gian được bảo vệ, đặt đúng vào giờ vàng của tuần trước, với thói quen then chốt nằm ngay trong đó.

**Sáu ngày của tuần này**

Thứ Hai phân loại việc sâu và việc nông. Thứ Ba chọn nhịp làm việc sâu. Thứ Tư nghi thức bắt đầu. Thứ Năm gom việc nông. Thứ Sáu nghi thức kết thúc ngày. Thứ Bảy đo giờ làm việc sâu cả tuần. Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Việc nào cần cả bộ óc?**

1. Viết sáu việc đã làm trong một ngày làm việc gần nhất.
2. Với mỗi việc, hỏi câu hỏi của Newport, rồi xếp vào nhóm sâu hoặc nông.
3. Ước lượng hôm qua mình có bao nhiêu giờ làm việc sâu thật sự, không bị cắt ngang.
4. Chọn một việc sâu quan trọng nhất của tuần này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-1. Thói quen, giờ vàng và nghỉ ngắn của các tuần trước sẽ tự hiện lại.

Chia sẻ hôm nay: "Thói quen tôi đang giữ: .... Việc sâu quan trọng nhất tuần này: .... Hôm qua tôi có khoảng ... giờ làm việc sâu.". Con số thấp là chuyện rất bình thường ở ngày đầu tiên, cứ ghi đúng con số thật nha.


## Bài 2: Ngày 2 (Thứ Ba 03/11)
@img 2_nhip-lich
@pdf 10XHub_CongViecSau_PhieuNgay2_nhip-lich.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: BỐN NHỊP LÀM VIỆC SÂU, CHỌN MỘT

Newport mô tả bốn cách đưa công việc sâu vào cuộc sống. Đặt bốn cách cạnh nhau, mỗi người sẽ thấy ngay cách nào hợp với vị trí của mình, và cách nào chỉ hợp trên giấy.

**Nhịp 1: ẩn mình dài ngày**

Rút khỏi gần như mọi liên lạc trong thời gian dài để làm một việc lớn. Ví dụ Newport nêu là những người viết sách, nhà nghiên cứu không dùng email. Hợp khi: công việc gần như chỉ có một nhiệm vụ sâu. Với người làm trong doanh nghiệp: hiếm khi làm được.

**Nhịp 2: hai chế độ**

Chia thời gian thành những giai đoạn rõ ràng: vài ngày, thậm chí vài tuần dành trọn cho việc sâu, phần còn lại cho mọi việc khác. Hợp khi: có quyền chủ động lịch, ví dụ người làm dự án, chuyên gia, giảng viên. Với người đi làm: cần sự đồng ý của quản lý, ví dụ mỗi Thứ Năm làm việc ở phòng riêng.

**Nhịp 3: nhịp đều mỗi ngày**

Cùng một khung giờ, mỗi ngày làm việc, dành cho việc sâu. Không phải quyết định lại mỗi ngày, vì khung giờ đã có sẵn trên lịch. Hợp khi: phần lớn người đi làm, có lịch họp và việc phát sinh. Đây cũng là nhịp gần nhất với hành trình thói quen của chúng ta.

**Nhịp 4: tranh thủ khoảng trống**

Có khoảng trống trong lịch là chuyển ngay sang việc sâu, dù chỉ 30 phút. Newport lấy ví dụ một nhà báo tranh thủ viết sách giữa các bài báo. Hợp khi: đã quen làm việc sâu, chuyển trạng thái nhanh. Với người mới bắt đầu: rất khó, vì mỗi lần chuyển việc đều mất một khoảng để vào lại.

**Đặt cạnh nhau**

Ẩn mình và hai chế độ cho nhiều giờ sâu nhất, nhưng đòi hỏi nhiều quyền chủ động nhất. Tranh thủ khoảng trống linh hoạt nhất, nhưng khó duy trì nhất. Nhịp đều mỗi ngày nằm ở giữa: ít giờ hơn, nhưng đều đặn, dễ thành thói quen, và hợp với hầu hết các vị trí.

Newport cũng lưu ý rằng khả năng làm việc sâu có giới hạn: người mới bắt đầu thường chỉ duy trì được khoảng một giờ mỗi ngày, người đã luyện tập lâu có thể đến khoảng bốn giờ. Vì vậy, một khối 60 đến 90 phút mỗi ngày là điểm khởi đầu rất hợp lý.

**Ngày 2 (20 phút)**

1. Chọn nhịp làm việc sâu của mình.
2. Đặt khối làm việc sâu, ưu tiên trùng với giờ vàng của tuần trước.
3. Đặt khối thành lịch lặp lại, đặt tên rõ ràng và để trạng thái bận.
4. Báo quản lý hoặc đội về khung giờ này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-2.

Chia sẻ hôm nay: "Nhịp làm việc sâu của tôi: .... Khối làm việc sâu: ...". Ai làm theo ca hoặc lịch thay đổi thì ghi khối cho ca thường gặp nhất nha.


## Bài 3: Ngày 3 (Thứ Tư 04/11)
@img 3_nghi-thuc
@pdf 10XHub_CongViecSau_PhieuNgay3_nghi-thuc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NGHI THỨC NĂM PHÚT TRƯỚC KHỐI SÂU

Hôm nay đi theo dạng hỏi đáp, vì nghi thức bắt đầu thường gặp đúng mấy câu hỏi này.

**Hỏi: Đã có khối giờ trên lịch rồi, sao vẫn cần nghi thức?**

Đáp: Vì khoảng mười phút đầu của khối là lúc dễ trôi nhất. Mở máy, thấy một thư mới, "trả lời nhanh một chút", và khối 60 phút còn 40. Newport đề nghị mỗi người có một nghi thức bắt đầu cố định, để không phải dùng ý chí quyết định lại mỗi lần. Ở tuần 0022, cả nhóm đã gặp ý này dưới tên "tín hiệu": nghi thức chính là một chuỗi tín hiệu.

**Hỏi: Một nghi thức gồm những gì?**

Đáp: Newport gợi ý trả lời trước ba câu hỏi.

- Ở đâu và bao lâu? Chỗ ngồi cụ thể và thời lượng của khối. Ví dụ: phòng họp nhỏ tầng 3, 60 phút. Hoặc chính bàn mình, với tai nghe.
- Làm thế nào khi đã bắt đầu? Quy tắc trong khối. Ví dụ: tắt thông báo, điện thoại để ngoài tầm tay, không mở hộp thư.
- Điều gì giúp mình vào việc? Ví dụ: một ly nước, tài liệu mở sẵn từ chiều hôm trước, một tờ giấy ghi mục tiêu của khối.

**Hỏi: Văn phòng mở, không có phòng riêng thì sao?**

Đáp: Chỗ ngồi không cần đặc biệt, chỉ cần nhất quán. Cùng một bàn, cùng một tai nghe, cùng một tấm thẻ dựng trên bàn (tấm thẻ Nếu... thì... của tuần 0023 dùng được ở đây). Sau vài lần, chính những tín hiệu đó báo cho mình và cho đồng nghiệp rằng khối sâu đã bắt đầu.

**Hỏi: Nghi thức dài bao lâu là vừa?**

Đáp: Năm phút trở xuống. Nghi thức quá dài lại thành một việc phải làm. Ví dụ một nghi thức đủ dùng: rót nước, tắt thông báo, viết mục tiêu của khối lên một tờ giấy, rồi bắt đầu.

**Hỏi: Nếu trong khối chợt nhớ ra việc khác?**

Đáp: Ghi việc đó vào tờ giấy bên cạnh, rồi quay lại ngay. Việc đã ghi xuống thì không cần nhớ nữa, và sẽ được xử lý trong khung gom việc nông của ngày mai.

**Ngày 3 (20 phút, cộng một khối làm việc sâu)**

1. Trả lời ba câu hỏi của nghi thức.
2. Gom lại thành một câu nghi thức bắt đầu của mình.
3. Thử ngay: làm nghi thức, bấm đồng hồ trên sổ thực hành và làm việc sâu đến khi đồng hồ dừng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-3.

Chia sẻ hôm nay: "Nghi thức bắt đầu khối làm việc sâu của tôi: ...". Đọc nghi thức của nhau sẽ thấy nhiều cách rất gọn, các anh chị và các bạn mượn thoải mái nha.


## Bài 4: Ngày 4 (Thứ Năm 05/11)
@img 4_gom-viec-nong
@pdf 10XHub_CongViecSau_PhieuNgay4_gom-viec-nong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: MỘT BUỔI SÁNG VÀ DƯ ÂM CHÚ Ý

Bài hôm nay là nhật ký một buổi sáng của một kỹ sư thiết kế, ghi theo giờ. Đây là nhật ký mẫu, nhưng phần lớn chúng ta sẽ thấy buổi sáng của mình ở đâu đó trong này.

**Thứ Ba, trước khi gom việc nông**

"8 giờ 30. Bắt đầu khối sâu: vẽ lại bản thiết kế khung đỡ.

8 giờ 42. Tin nhắn nhóm dự án báo có thư mới. Mở xem, chỉ là xác nhận lịch họp. Trả lời một dòng.

8 giờ 45. Quay lại bản vẽ. Mất mấy phút mới nhớ mình đang tính đến đâu.

9 giờ 05. Thư của phòng mua hàng hỏi thông số vật liệu. Trả lời luôn cho xong.

9 giờ 10. Quay lại bản vẽ. Đầu vẫn còn nghĩ về thông số vật liệu.

9 giờ 40. Hết khối. Bản vẽ xong được khoảng một nửa so với dự định."

**Vì sao "chỉ một dòng" lại tốn nhiều đến vậy**

Năm 2009, nhà nghiên cứu hành vi tổ chức Sophie Leroy công bố một nghiên cứu trên tạp chí Organizational Behavior and Human Decision Processes. Bà gọi hiện tượng này là dư âm chú ý: khi chuyển từ việc A sang việc B, một phần sự chú ý vẫn còn bám ở việc A, nhất là khi việc A chưa xong. Trong các thử nghiệm của bà, người còn nhiều dư âm chú ý làm việc B kém hơn.

Mỗi lần mở tin nhắn "xem nhanh" trong khối sâu là một lần chuyển việc. Thư được trả lời rất nhanh, nhưng dư âm thì ở lại.

**Thứ Năm, sau khi gom việc nông**

"8 giờ 25. Báo trong nhóm: từ 8 giờ 30 đến 10 giờ mình tập trung vẽ khung đỡ, việc gấp gọi điện, còn lại 10 giờ mình trả lời. Bật chế độ không làm phiền.

8 giờ 30. Bắt đầu khối sâu.

9 giờ 55. Hết khối. Bản vẽ xong. Không có cuộc gọi nào.

10 giờ. Mở tin nhắn và hộp thư: bảy tin, trả lời hết trong 15 phút. Không tin nào cần trả lời trước 10 giờ."

Thay đổi duy nhất là gom việc nông vào một khung cố định và báo trước với đồng nghiệp.

**Ngày 4 (20 phút)**

1. Bấm bảng hành trình cho những ngày đã làm thói quen trong khối sâu từ Thứ Hai.
2. Đếm trong một buổi: mình chuyển sang hộp thư, tin nhắn bao nhiêu lần.
3. Chọn khung gom việc nông, ví dụ 11 giờ và 16 giờ.
4. Viết một câu báo trước với đồng nghiệp, và gửi nó trước khối sâu ngày mai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-4.

Chia sẻ hôm nay: "Tôi gom việc nông vào .... Câu báo trước với đồng nghiệp: ...". Con số đếm được trong một buổi có thể khá bất ngờ, ai muốn thì chia sẻ thêm cho cả nhóm cùng xem nha.


## Bài 5: Ngày 5 (Thứ Sáu 06/11)
@img 5_ket-thuc
@pdf 10XHub_CongViecSau_PhieuNgay5_ket-thuc.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: BỐN BƯỚC KHÉP NGÀY LÀM VIỆC

Một khối sâu tốt vào buổi sáng thường bắt đầu từ chiều hôm trước. Newport đề nghị kết thúc mỗi ngày làm việc bằng một nghi thức cố định, để công việc được khép lại có chủ đích, đầu óc được nghỉ thật, và sáng mai biết ngay mình bắt đầu từ đâu.

Hôm nay là một danh sách bốn bước, làm trong khoảng 15 phút trước khi rời bàn.

**1. Xem lại việc đang dở.**

Với mỗi việc chưa xong, ghi một dòng: bước tiếp theo là gì. Không cần làm, chỉ cần ghi. Một việc có bước tiếp theo rõ ràng sẽ ít quay lại trong đầu vào buổi tối hơn một việc chỉ ghi "chưa xong".

**2. Xem lịch ngày mai.**

Kiểm tra khối làm việc sâu ngày mai còn nguyên không. Nếu có cuộc họp mới chen vào, dời khối sang khung khác ngay bây giờ, hoặc dùng kế hoạch Nếu... thì... của tuần 0023.

**3. Chuẩn bị cho khối sâu ngày mai.**

Viết việc đầu tiên của khối sâu ngày mai thật cụ thể, ví dụ "viết phần giải pháp của đề xuất, trang 3" thay vì "làm đề xuất". Mở sẵn tài liệu đó trên màn hình. Sáng mai ngồi xuống là vào việc, không phải tìm.

**4. Câu kết thúc ngày.**

Newport kể rằng ông kết thúc nghi thức bằng một câu nói cố định, đại ý "đã khép ngày làm việc". Câu nói nghe đơn giản, nhưng nó là tín hiệu cho chính mình: những việc còn lại đã được ghi xuống, đã có chỗ, không cần nghĩ tiếp tối nay. Mỗi người chọn một câu của riêng mình.

**Vài lưu ý khi làm danh sách này**

- Làm đúng bốn bước, mỗi bước ngắn. Nghi thức kéo dài quá 15 phút dễ bị bỏ vào những ngày bận.
- Đặt một lời nhắc cố định trên lịch, ví dụ 17 giờ 15, tên là "Khép ngày".
- Ngày phải ra về đột xuất: làm riêng bước 3, mất hai phút.
- Ngày Thứ Bảy, bước 2 là xem lịch Thứ Hai tuần sau.

Điểm nối với thói quen then chốt: bước 3 làm cho khối sâu ngày mai dễ bắt đầu hơn, đúng như quy luật "làm cho dễ" của tuần 0022. Sổ thực hành của hôm nay có sẵn bốn ô đánh dấu cho bốn bước.

**Ngày 5 (15 phút, cuối ngày)**

1. Làm bốn bước trước khi rời bàn hôm nay.
2. Viết việc đầu tiên của khối sâu ngày mai.
3. Chọn câu kết thúc ngày của mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-5.

Chia sẻ hôm nay: "Câu kết thúc ngày của tôi: .... Việc đầu tiên của khối sâu ngày mai: ...". Hôm nay là Thứ Sáu, nên "ngày mai" có thể là sáng Thứ Bảy hoặc Thứ Hai tuần sau, tuỳ lịch của mỗi người nha.


## Bài 6: Ngày 6 (Thứ Bảy 07/11)
@img 6_do-gio
@img2 9_the-thanh-tich
@pdf 10XHub_CongViecSau_PhieuNgay6_do-gio.pdf (phiếu thực hành và bảng đo giờ sâu để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: BAO NHIÊU PHÚT THẬT SỰ LÀ CỦA VIỆC SÂU?

Một tuần có bao nhiêu phút mình thật sự làm việc sâu?

Phần lớn chúng ta chưa bao giờ đếm. Hôm nay đếm, không để chấm điểm, mà để có một con số làm mốc cho các tuần sau. Newport khuyến khích theo dõi số giờ làm việc sâu, vì điều được đo thì dễ được chú ý hơn.

**Cách đếm**

Với mỗi ngày từ Thứ Hai đến hôm nay, ghi số phút tập trung thật sự: không mở hộp thư, không chuyển việc. Một khối 60 phút bị cắt ngang hai lần thì không phải 60 phút sâu. Ước lượng trung thực là đủ, không cần chính xác đến từng phút. Ngày không có khối sâu thì ghi 0.

**Ba câu hỏi cho con số của mình**

Khối sâu nào trọn vẹn nhất tuần này, và vì sao? Thường câu trả lời nằm ở việc chuẩn bị: tài liệu mở sẵn, đã báo trước với đồng nghiệp, khối nằm đúng giờ vàng.

Điều gì cắt ngang khối sâu nhiều nhất? Một kênh liên lạc, một cuộc họp định kỳ, hay chính mình tự mở điện thoại?

Tuần sau mình giữ gì, đổi gì? Giữ khung giờ đang chạy tốt. Đổi một điều nhỏ nhất làm khối bị cắt ngang.

**Một vài câu hỏi mở để suy nghĩ thêm trong Chủ Nhật**

Nếu mỗi tuần có thêm một giờ làm việc sâu, sau ba tháng mình sẽ làm xong việc gì mà hiện giờ vẫn đang hoãn?

Việc sâu quan trọng nhất của mình trong quý này là gì, và nó đã có chỗ trong lịch chưa?

Trong đội của mình, ai cũng cần một khối sâu. Mình có thể giúp đồng nghiệp bảo vệ khối của họ bằng cách nào?

**Sáng nay (20 phút)**

1. Ghi số phút làm việc sâu mỗi ngày trong tuần trên sổ thực hành. Sổ tự cộng tổng.
2. Trả lời ba câu hỏi nhìn lại.
3. Xem bảng khối làm việc sâu mang sang tuần sau: thói quen, khối sâu, nghi thức bắt đầu, giờ vàng, nghỉ ngắn sau khối.

Tuần sau, Công thức #0026 Ăn con ếch sẽ đặt việc quan trọng nhất trong ngày vào đầu ngày, ngay cạnh thói quen then chốt, và khối làm việc sâu của tuần này chính là chỗ để "ăn con ếch" đó.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0025-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi có ... phút làm việc sâu. Điều cắt ngang nhiều nhất: .... Tuần sau tôi giữ khối ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Công việc sâu hiện ra, với tổng số phút làm việc sâu của tuần in lớn trên dải đỏ và khung giờ khối sâu của mình. Nhập tên, tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật là ngày không có khối sâu nào cả, các anh chị và các bạn nghỉ ngơi trọn vẹn nha. Chuỗi thói quen không bị tính là lỡ.
