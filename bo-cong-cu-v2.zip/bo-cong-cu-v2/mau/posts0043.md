## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 08/03)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0043_Nghich Ly Lua Chon_VN.pdf (tài liệu đầy đủ của Công thức #0043)
@pdf 10XHub_NghichLyLuaChon_PhieuNgay1_dem-lua-chon.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0043.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** 08.03 VÀ CÔNG THỨC #0043: NGHỊCH LÝ LỰA CHỌN

Hôm nay là Ngày Quốc tế Phụ nữ. Trường xin gửi lời cảm ơn đến các đồng nghiệp nữ trong cộng đồng 10X Excellence Hub và ở mọi tổ chức các anh chị và các bạn đang làm việc: những chị trưởng phòng đang dẫn dắt đội nhóm qua quý cao điểm, những bạn kỹ sư, kế toán, chuyên viên kinh doanh, chăm sóc khách hàng đang giữ chất lượng của từng sản phẩm, từng con số, từng cuộc hẹn. Nhiều quyết định quan trọng ở chỗ làm được đưa ra mỗi ngày bởi chính các chị, các bạn. Một cách tri ân thiết thực trong tuần này: nói với một đồng nghiệp nữ một đóng góp cụ thể của chị ấy mà mình đã ghi nhận, như cách cả nhóm đã luyện ở tuần Lòng biết ơn.

Tuần trước, mỗi người đã đặt hộp thời gian cho các bước của năm mục tiêu, thử ước lượng thời gian của chính mình, và khép tuần bằng một cuộc họp 20 phút với chính mình để chốt quy tắc hộp thời gian. Tuần này đi tiếp một câu hỏi gần với các hộp đó: trong mỗi hộp, bao nhiêu thời gian đang dành cho việc cân nhắc lựa chọn?

**Nếu mới tham gia:** tuần này bắt đầu bằng một việc rất nhẹ: đếm. Hôm nay mở sổ thực hành, viết một thói quen then chốt trong công việc (ví dụ: mỗi sáng chọn một việc quan trọng nhất trong 5 phút, không cân nhắc thêm), rồi làm bài Ngày 1. Không cần biết gì về các tuần trước.

**Hai phía của một cuộc tranh luận**

Năm 2004, nhà tâm lý học Barry Schwartz xuất bản cuốn "The Paradox of Choice". Ý chính của sách: nhiều lựa chọn hơn không phải lúc nào cũng tốt hơn; quá nhiều lựa chọn có thể khiến người ta khó quyết định hơn, và kém hài lòng hơn với điều đã chọn. Nhưng ý tưởng này không đứng yên. Nó trở thành một cuộc tranh luận khoa học thật sự, và tuần này nên bắt đầu từ cả hai phía.

**Phía ủng hộ: thí nghiệm mứt**

Năm 2000, Sheena Iyengar và Mark Lepper công bố một thí nghiệm tại cửa hàng thực phẩm Draeger's ở Menlo Park, California. Có những giờ, quầy nếm thử bày 24 loại mứt; có những giờ, chỉ bày 6 loại. Quầy 24 loại thu hút nhiều người dừng lại hơn: khoảng 60 phần trăm khách đi ngang, so với khoảng 40 phần trăm ở quầy 6 loại. Nhưng trong số người đã dừng lại, chỉ khoảng 3 phần trăm mua mứt ở quầy 24 loại, so với khoảng 30 phần trăm ở quầy 6 loại. Thí nghiệm này được nhắc lại rất nhiều trong kinh doanh và thiết kế sản phẩm.

**Phía phản biện: tổng hợp các thí nghiệm**

Năm 2010, Benjamin Scheibehenne, Rainer Greifeneder và Peter Todd tổng hợp 63 điều kiện từ 50 thí nghiệm, với hơn 5.000 người tham gia. Kết quả: hiệu ứng trung bình của "quá nhiều lựa chọn" gần như bằng 0. Có thí nghiệm thấy nhiều lựa chọn gây bất lợi, có thí nghiệm thấy ngược lại, đặc biệt khi người chọn đã biết rõ mình muốn gì.

**Điều hai phía cùng chỉ ra**

Năm 2015, Alexander Chernev và cộng sự tổng hợp thêm 99 kết quả, với hơn 7.000 người tham gia, và tìm ra điều kiện khiến quá nhiều lựa chọn thật sự gây khó: các phương án phức tạp, khó so sánh; nhiệm vụ chọn khó; người chọn chưa rõ mình muốn gì; và người chọn muốn quyết định nhanh, ít tốn sức.

Nói cách khác: không phải lúc nào nhiều lựa chọn cũng có hại. Nhưng trong công việc, bốn điều kiện trên xuất hiện rất thường xuyên. Đó là lý do tuần này không bàn chuyện "ít lựa chọn là tốt", mà bàn chuyện chủ động quyết định việc nào cần chọn kỹ, việc nào chỉ cần chọn đủ tốt, để giữ sức cho năm mục tiêu.

**Sáu ngày của tuần**

- Thứ Hai: đếm các lựa chọn nhỏ trong một buổi sáng.
- Thứ Ba: tối đa hoá hay chọn đủ tốt?
- Thứ Tư: đặt tiêu chí đủ tốt trước khi chọn.
- Thứ Năm: rút bớt phương án khi trình bày cho người khác.
- Thứ Sáu: dành sức chọn kỹ cho việc lớn.
- Thứ Bảy: quy ước chọn lựa của riêng mình.

Chủ Nhật nghỉ.

**Ngày 1 (15 phút, chia trong buổi sáng): Đếm lựa chọn**

1. Mở sổ thực hành, xem lại thói quen đang giữ và quy tắc hộp thời gian.
2. Từ lúc bắt đầu làm việc đến giờ nghỉ trưa, mỗi khi phải chọn giữa hai phương án trở lên, đánh một dấu vào sổ đầu dòng: chọn mẫu tài liệu, chọn việc làm trước, chọn cách trả lời một email, chọn nhà cung cấp để gọi.
3. Cuối buổi sáng, đếm tổng số dấu, và ghi lựa chọn nhỏ đã tốn nhiều thời gian nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-1.

Chia sẻ hôm nay: "Buổi sáng nay tôi đếm được ... lựa chọn nhỏ. Lựa chọn tốn thời gian nhất: ...".

Con số nhiều hay ít đều không có đúng sai, các anh chị và các bạn chỉ cần đếm thật để có dữ liệu cho cả tuần nha.


## Bài 2: Ngày 2 (Thứ Ba 09/03)
@img 2_toi-da-hoa
@pdf 10XHub_NghichLyLuaChon_PhieuNgay2_toi-da-hoa.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: TỐI ĐA HOÁ HAY CHỌN ĐỦ TỐT?

Hôm nay bắt đầu bằng năm câu tự chấm. Đọc từng câu, chấm từ 1 (rất không giống mình) đến 5 (rất giống mình), rồi mới đọc phần giải thích bên dưới. Năm câu này do 10X Excellence Hub soạn theo tinh thần nghiên cứu của Barry Schwartz và cộng sự, chỉ để tự nhìn lại, không phải thang đo khoa học và không dùng để đánh giá ai.

**Năm câu tự chấm**

1. Khi chọn mẫu trình bày cho một bản báo cáo, tôi thường xem hết các mẫu có sẵn rồi mới quyết định.
2. Sau khi đã gửi một email quan trọng, tôi hay nghĩ lại xem có cách viết nào tốt hơn không.
3. Khi đặt lịch họp, tôi thường cân nhắc nhiều khung giờ dù khung giờ đầu tiên đã phù hợp.
4. Khi chọn một nhà cung cấp cho việc nhỏ, tôi muốn so sánh thêm vài nơi nữa cho chắc.
5. Tôi thấy khó chịu khi phải quyết định mà chưa xem hết các phương án.

Sổ thực hành tự cộng điểm, từ 5 đến 25.

**Hai kiểu chọn**

Năm 1956, nhà kinh tế học Herbert Simon, người sau này nhận giải Nobel Kinh tế, đưa ra từ "satisficing", ghép từ hai chữ "thoả mãn" và "đủ". Theo Simon, trong thực tế con người hiếm khi có đủ thông tin và thời gian để tìm phương án tốt nhất; người ta thường chọn phương án đầu tiên đạt một ngưỡng chấp nhận được. Tài liệu tuần này gọi cách chọn đó là chọn đủ tốt.

Năm 2002, Barry Schwartz và các cộng sự đặt hai kiểu chọn cạnh nhau. Người thiên về tối đa hoá muốn tìm phương án tốt nhất, nên thường xem xét nhiều phương án và so sánh kỹ. Người thiên về đủ tốt đặt ra tiêu chí, và dừng lại khi gặp phương án đầu tiên đạt tiêu chí. Trong các khảo sát của nhóm nghiên cứu, người có điểm tối đa hoá cao thường cho biết họ ít hài lòng hơn với lựa chọn của mình và hay hối tiếc hơn.

Hai lưu ý quan trọng. Một là, đây là các khảo sát tương quan, không chứng minh rằng tối đa hoá gây ra sự kém hài lòng. Hai là, các nghiên cứu sau đó cho thấy kết quả phụ thuộc khá nhiều vào cách đo, và cách đo "tối đa hoá" vẫn đang được bàn thảo.

**Vậy điểm của mình nói lên điều gì?**

Không có điểm tốt hay điểm xấu. Tối đa hoá rất có giá trị khi chọn những điều lớn và khó đảo ngược: chọn người cho một vị trí then chốt, chọn đối tác cho hợp đồng ba năm. Vấn đề chỉ nảy sinh khi cách chọn đó được dùng cho mọi việc, kể cả chọn mẫu báo cáo hay khung giờ họp. Mục tiêu của tuần là dùng đúng kiểu chọn cho đúng loại việc.

**Ngày 2 (15 phút)**

1. Chấm năm câu trên sổ thực hành.
2. Nhìn lại danh sách lựa chọn đã đếm hôm qua. Chọn ba việc nhỏ mình hay cân nhắc lâu hơn mức cần thiết.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-2.

Chia sẻ hôm nay: "Điểm tối đa hoá tự chấm của tôi: .../25. Ba việc nhỏ tôi hay cân nhắc quá lâu: ...".

Điểm số là chuyện riêng của mỗi người, ai thấy không tiện thì chỉ chia sẻ ba việc nhỏ là đủ nha.


## Bài 3: Ngày 3 (Thứ Tư 10/03)
@img 3_nguong-du-tot
@pdf 10XHub_NghichLyLuaChon_PhieuNgay3_nguong-du-tot.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: ĐẶT NGƯỠNG ĐỦ TỐT TRƯỚC KHI CHỌN

Chọn đủ tốt không có nghĩa là chọn qua loa. Nó có nghĩa là quyết định trước khi bắt đầu tìm: thế nào là đủ, và tìm đến đâu thì dừng. Hôm nay đi qua một ví dụ làm mẫu, từng bước một, rồi mỗi người áp dụng cho một việc của chính mình.

**Ví dụ làm mẫu: chọn công cụ khảo sát khách hàng**

Chị Thảo là chuyên viên chăm sóc khách hàng. Trưởng phòng giao chị chọn một công cụ khảo sát trực tuyến để gửi phiếu đánh giá sau mỗi đơn hàng. Đây là một việc nhỏ, phục vụ mục tiêu số 3 của chị: "đo được mức hài lòng của khách hàng mỗi tháng". Lần trước làm việc tương tự, chị mất gần hai ngày để so sánh mười hai công cụ. Lần này chị làm theo ba bước. (Tình huống là minh hoạ.)

**Bước 1: viết tiêu chí trước khi tìm**

Chị viết ra ba tiêu chí bắt buộc: gửi được qua email và tin nhắn; xuất được kết quả ra bảng tính; nằm trong ngân sách phòng đã duyệt. Thêm một tiêu chí nên có: giao diện tiếng Việt. Chỉ ba tiêu chí bắt buộc, vì càng nhiều tiêu chí, việc so sánh càng khó.

**Bước 2: đặt giới hạn tìm kiếm**

Chị quyết định: xem tối đa bốn công cụ, trong một hộp thời gian 45 phút. Giới hạn này được đặt trước, không phải khi đã mệt.

**Bước 3: chọn phương án đầu tiên đạt ngưỡng**

Đến công cụ số 2, chị thấy nó đạt đủ ba tiêu chí bắt buộc và có giao diện tiếng Việt. Chị dừng lại, không xem thêm hai công cụ còn lại. Chị gửi trưởng phòng một tin nhắn ngắn: công cụ đã chọn, ba lý do, và đề xuất dùng thử một tháng rồi đánh giá lại.

**Điều làm cho cách chọn này hiệu quả**

- Tiêu chí được viết trước, nên khi gặp phương án đạt, chị biết ngay là đạt, không cần so thêm.
- Giới hạn tìm kiếm là một hộp thời gian, đúng như tuần trước.
- Đề xuất "dùng thử một tháng" biến một quyết định có vẻ quan trọng thành một quyết định đảo ngược được. Điều này giảm áp lực phải chọn hoàn hảo ngay từ đầu.

Nếu sau một tháng công cụ không phù hợp, chị đổi. Thời gian chị tiết kiệm được trong lần chọn này đã dành cho việc thiết kế câu hỏi khảo sát, phần quan trọng hơn nhiều với mục tiêu số 3.

**Áp dụng cho việc của mình**

Chọn một việc nhỏ sắp phải quyết định trong tuần này, hoặc một trong ba việc đã ghi hôm qua. Viết ba tiêu chí bắt buộc, một giới hạn tìm kiếm, rồi chọn theo ngưỡng. Việc này được lưu trên sổ thực hành là "việc chọn kiểu đủ tốt" của mình, dùng tiếp cho các tuần sau.

**Ngày 3 (20 phút)**

1. Chọn một việc nhỏ cần quyết định.
2. Viết ba tiêu chí bắt buộc và một giới hạn tìm kiếm (số phương án hoặc thời gian).
3. Chọn phương án đầu tiên đạt ngưỡng, ghi lại kết quả.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-3.

Chia sẻ hôm nay: "Việc tôi chọn kiểu đủ tốt: .... Tiêu chí đủ tốt: ...".


## Bài 4: Ngày 4 (Thứ Năm 11/03)
@img 4_rut-phuong-an
@pdf 10XHub_NghichLyLuaChon_PhieuNgay4_rut-phuong-an.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BẢY PHƯƠNG ÁN, RÚT LẠI CÒN BA

Ba ngày qua nói về lựa chọn của chính mình. Hôm nay đổi góc nhìn: mình là người tạo ra lựa chọn cho người khác. Mỗi khi trình bày phương án cho cấp trên, cho khách hàng, cho đồng nghiệp ở bộ phận khác, mình đang quyết định họ phải chọn giữa bao nhiêu phương án. Bài hôm nay đặt một bản đề xuất trước và sau khi chỉnh.

**Trước: bản đề xuất bảy phương án**

Một trưởng nhóm kinh doanh chuẩn bị đề xuất gói dịch vụ cho một khách hàng doanh nghiệp mới. Để thể hiện sự chu đáo, anh đưa vào bảy phương án: ba mức giá, hai thời hạn hợp đồng, hai hình thức thanh toán, kèm các tuỳ chọn cộng thêm. Mỗi phương án có một bảng so sánh riêng.

Buổi trình bày kéo dài. Khách hàng hỏi nhiều câu so sánh giữa phương án 3 và phương án 5. Cuối buổi, khách hàng nói sẽ "trao đổi nội bộ thêm". Hai tuần sau, chưa có phản hồi. (Tình huống là minh hoạ.)

**Sau: bản đề xuất ba phương án và một khuyến nghị**

Lần sau, với một khách hàng tương tự, anh làm khác. Trước buổi gặp, anh hỏi kỹ khách hàng ba điều: ngân sách dự kiến, thời hạn mong muốn, điều quan trọng nhất với họ. Từ đó anh chỉ đưa ra ba phương án, mỗi phương án phục vụ một ưu tiên rõ ràng, và đánh dấu một phương án là khuyến nghị của mình, kèm hai lý do. Các tuỳ chọn cộng thêm được để ở phụ lục.

Buổi trình bày gọn hơn. Câu hỏi của khách hàng tập trung vào phương án được khuyến nghị.

**Vì sao bản sau dễ chọn hơn?**

Tổng hợp năm 2015 của Chernev và cộng sự chỉ ra bốn điều kiện khiến quá nhiều lựa chọn gây khó. Bản đề xuất trước chạm cả bốn: các phương án phức tạp, nhiều chiều khó so sánh; nhiệm vụ chọn khó; khách hàng chưa rõ mình muốn gì; và khách hàng muốn quyết định nhanh. Bản đề xuất sau giảm cả bốn: ít phương án hơn, mỗi phương án gắn với một ưu tiên, ưu tiên đã được hỏi trước, và có một khuyến nghị để bắt đầu.

Lưu ý: kết quả của tình huống minh hoạ không phải lời hứa. Có khách hàng thích được xem nhiều phương án, nhất là khi họ đã biết rõ mình muốn gì. Vì vậy bước hỏi trước mới là phần quan trọng nhất.

**Bốn câu hỏi trước khi trình phương án**

1. Người chọn đã biết rõ ưu tiên của họ chưa? Nếu chưa, hỏi trước.
2. Mỗi phương án phục vụ ưu tiên nào? Phương án nào không phục vụ ưu tiên nào rõ ràng thì bỏ.
3. Mình khuyến nghị phương án nào, vì sao?
4. Phần nào có thể để vào phụ lục?

**Ngày 4 (25 phút)**

1. Chọn một bản đề xuất, báo cáo hoặc tin nhắn có nhiều phương án sắp gửi đi (hoặc đã gửi gần đây).
2. Đi qua bốn câu hỏi, rút số phương án xuống còn hai hoặc ba.
3. Viết một khuyến nghị kèm hai lý do.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-4.

Chia sẻ hôm nay: "Tôi rút ... từ ... xuống ... phương án, kèm một khuyến nghị.".


## Bài 5: Ngày 5 (Thứ Sáu 12/03)
@img 5_chon-ky
@pdf 10XHub_NghichLyLuaChon_PhieuNgay5_chon-ky.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: DÀNH SỨC CHỌN KỸ CHO VIỆC LỚN

Chọn đủ tốt cho việc nhỏ chỉ có ý nghĩa nếu sức tiết kiệm được dành cho việc lớn. Hôm nay phân loại các quyết định sắp tới của mình vào bốn ô, dựa trên hai câu hỏi.

**Câu hỏi 1: quyết định này có ảnh hưởng lớn đến năm mục tiêu không?**

Ví dụ ảnh hưởng lớn: chọn nhà cung cấp chính cho quý 2, chọn người phụ trách một dự án then chốt, chọn hướng tiếp cận cho một nhóm khách hàng mới. Ví dụ ảnh hưởng nhỏ: chọn mẫu trình bày báo cáo tuần, chọn quán cho bữa trưa với đồng nghiệp, chọn khung giờ cho cuộc gọi nội bộ.

**Câu hỏi 2: nếu chọn sai, có dễ đổi lại không?**

Dễ đổi: đổi mẫu báo cáo, đổi công cụ đang dùng thử, đổi lịch họp. Khó đổi: ký hợp đồng dài hạn, tuyển dụng một vị trí, công bố một chính sách mới với khách hàng.

**Bốn ô**

**Ô 1: ảnh hưởng lớn, khó đổi.** Đây là chỗ đáng tối đa hoá. Dành hộp thời gian dài, xem nhiều phương án, hỏi ý kiến người có kinh nghiệm, viết lý do lựa chọn. Ví dụ: chọn đối tác cho hợp đồng ba năm.

**Ô 2: ảnh hưởng lớn, dễ đổi.** Chọn đủ tốt nhưng có kế hoạch kiểm tra. Đặt tiêu chí rõ, thử trong một thời gian ngắn, hẹn ngày đánh giá lại. Ví dụ: chọn kênh liên hệ thử nghiệm với nhóm khách hàng mới trong một tháng.

**Ô 3: ảnh hưởng nhỏ, khó đổi.** Ít gặp hơn, nhưng có. Chọn đủ tốt, đọc kỹ điều khoản trước khi chốt. Ví dụ: đăng ký một gói phần mềm nhỏ có hợp đồng một năm.

**Ô 4: ảnh hưởng nhỏ, dễ đổi.** Chọn nhanh, theo ngưỡng đủ tốt hoặc theo một quy tắc có sẵn. Phần lớn lựa chọn đếm được hôm Thứ Hai thường nằm ở ô này. Ví dụ: chọn mẫu trình bày, chọn thời điểm trả lời một email thường.

**Điều thường thấy khi phân loại**

Nhiều người nhận ra mình đang dành rất nhiều thời gian cân nhắc ở ô 4, trong khi quyết định ở ô 1 lại được đưa ra vội vì đã hết sức và hết thời gian. Phân loại không làm cho quyết định dễ hơn, nhưng nó giúp đặt sức đúng chỗ.

**Bảng hành trình**

Tuần này bảng hành trình nằm ở Ngày 5. Đánh dấu những ngày đã làm thói quen then chốt.

**Ngày 5 (20 phút)**

1. Ghi bốn quyết định sắp tới trong công việc.
2. Xếp mỗi quyết định vào một trong bốn ô trên sổ thực hành.
3. Chọn một quyết định ở ô 1 xứng đáng để mình chọn kỹ trong tuần tới, và đặt hộp thời gian cho nó.
4. Đánh dấu bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-5.

Chia sẻ hôm nay: "Quyết định xứng đáng để tôi chọn kỹ tuần tới: .... Việc tôi chọn đủ tốt: ...".


## Bài 6: Ngày 6 (Thứ Bảy 13/03)
@img 6_quy-uoc
@img2 9_the-thanh-tich
@pdf 10XHub_NghichLyLuaChon_PhieuNgay6_quy-uoc.pdf (phiếu thực hành và thẻ quy ước chọn lựa in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: QUY ƯỚC CHỌN LỰA CỦA RIÊNG MÌNH

Công ty nào cũng có quy chế: quy chế chi tiêu, quy chế phê duyệt, quy chế mua hàng. Một trong những lý do quy chế tồn tại là để mỗi lần gặp tình huống quen, không ai phải cân nhắc lại từ đầu. Hôm nay mỗi người viết một bản quy ước chọn lựa ngắn cho chính mình, theo đúng hình thức một văn bản quy chế. Dưới đây là bản mẫu.

**QUY ƯỚC CHỌN LỰA TRONG CÔNG VIỆC (bản mẫu)**

*Áp dụng cho: chính mình. Hiệu lực: từ Thứ Hai 15.03.2027. Xem lại: cùng ngày chuyển việc cuối tháng.*

**Điều 1. Phạm vi chọn đủ tốt.** Các lựa chọn thuộc ô 4 (ảnh hưởng nhỏ, dễ đổi) được quyết định theo ngưỡng đủ tốt, không so sánh thêm khi đã có một phương án đạt tiêu chí.

**Điều 2. Giới hạn tìm kiếm.** Với việc nhỏ, xem tối đa ba phương án hoặc trong tối đa 15 phút, tuỳ điều kiện nào đến trước.

**Điều 3. Việc chọn kiểu đủ tốt đã xác định.** Ghi rõ một đến ba việc cụ thể, ví dụ: chọn mẫu báo cáo tuần; chọn khung giờ họp nội bộ; chọn nhà cung cấp văn phòng phẩm.

**Điều 4. Phạm vi chọn kỹ.** Các quyết định thuộc ô 1 (ảnh hưởng lớn đến năm mục tiêu, khó đổi) được dành ít nhất một hộp thời gian riêng, có tiêu chí viết trước và có ý kiến của ít nhất một người có kinh nghiệm.

**Điều 5. Khi trình phương án cho người khác.** Tối đa ba phương án, kèm một khuyến nghị và lý do.

**Điều 6. Hối tiếc.** Khi một lựa chọn đủ tốt hoá ra chưa tốt, ghi lại một dòng rút kinh nghiệm vào sổ đầu dòng rồi điều chỉnh tiêu chí lần sau, không tự trách.

Bản mẫu chỉ để tham khảo. Mỗi người chọn những điều phù hợp với mình, sửa câu chữ, và có thể chỉ cần ba điều. Phiếu Ngày 6 có một thẻ quy ước in được để đặt cạnh thẻ năm mục tiêu.

**Tuần sau: Luật Hick và quy tắc mặc định**

Tuần này bàn về sự hài lòng: khi nào nên chọn kỹ, khi nào chọn đủ tốt. Tuần sau, Công thức #0044 Luật Hick và quy tắc mặc định, bắt đầu Thứ Hai 15.03, bàn về tốc độ: thời gian để đưa ra một quyết định tăng lên khi số lựa chọn tăng lên, và cách biến những quyết định lặp lại thành quy tắc mặc định để bắt đầu thói quen then chốt nhanh hơn mỗi ngày. Bản quy ước hôm nay sẽ là điểm khởi đầu rất tốt cho tuần sau.

**Ngày 6 (25 phút)**

1. Đọc bản mẫu, chọn ba đến sáu điều phù hợp với mình.
2. Viết lại bằng câu chữ của mình trên sổ thực hành.
3. Điền thẻ quy ước in được (hoặc chép tay), đặt cạnh thẻ năm mục tiêu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0043-ngay-6.

Chia sẻ hôm nay: "Quy ước chọn lựa của tôi có ... điều. Điều tôi thấy quan trọng nhất: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần Nghịch lý lựa chọn hiện ra: một dấu ngoặc kép lớn với điều quan trọng nhất trong quy ước của mình, chữ "ĐỦ TỐT", tên mình và việc mình chọn kiểu đủ tốt. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha, và nếu có phải chọn quán cho bữa trưa cuối tuần thì cứ chọn quán đầu tiên đạt tiêu chí.
