## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 25/01)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0037_Dat Ranh Gioi_VN.pdf (tài liệu đầy đủ của Công thức #0037)
@pdf 10XHub_RanhGioi_PhieuNgay1_dieu-lan-gio.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0037.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN NƯỚC RÚT TRƯỚC TẾT: MỘT HÀNG RÀO CHO GIỜ QUAN TRỌNG

Hai mảnh đất nằm cạnh nhau. Nếu không có hàng rào, người ta vẫn sống được, nhưng sẽ có ngày không ai rõ cây xoài ở giữa là của nhà nào, ai tưới, ai hái. Hàng rào không để ngăn hàng xóm. Nó để cả hai bên biết đâu là phần mình chăm sóc.

Năm 1992, hai nhà tâm lý học lâm sàng người Mỹ, Henry Cloud và John Townsend, dùng đúng hình ảnh ranh giới đất đai này trong cuốn sách "Boundaries". Theo hai tác giả, ranh giới cho biết đâu là trách nhiệm của mình, đâu không phải. Không có ranh giới, người ta dễ nhận về những việc không phải của mình, và bỏ quên chính những việc mình cần chăm.

Tuần trước, cả nhóm đã tìm ra một lý do dài hạn cho mục tiêu số 1, chọn một việc khó để luyện đến điểm dừng tự nhiên, viết ba phiên bản Đầy, Vừa, Cạn của thói quen then chốt và một lá thư cho ngày muốn bỏ cuộc. Tuần này là tuần cuối cùng của tháng 1, và cũng là tuần nước rút trước Tết. Báo cáo cuối năm, đơn hàng chốt trước Tết, lời nhờ vả "anh làm giúp em trước khi nghỉ nha" đều dồn về những ngày này. Giờ làm việc quan trọng và thói quen then chốt là những điều dễ bị lấn nhất.

Công thức #0037 của tuần là Đặt ranh giới.

**Nếu mới tham gia:** tuần này cực kỳ thực tế, ai cũng dùng được ngay. Hôm nay chỉ cần mở sổ thực hành, viết một thói quen nhỏ muốn giữ trong công việc và một câu "Tôi là người ...", rồi liệt kê những điều đang lấn vào giờ làm việc của mình. Cuối tuần, các anh chị và các bạn sẽ có một danh sách bàn giao và một email trả lời tự động sẵn sàng cho kỳ nghỉ Tết.

**Vì sao ranh giới cũng là chuyện năng suất?**

Nhà tâm lý học tổ chức Sabine Sonnentag và các cộng sự đã nghiên cứu nhiều năm về việc phục hồi sau giờ làm. Năm 2007, Sonnentag và Charlotte Fritz mô tả bốn trải nghiệm giúp phục hồi: tách khỏi công việc về mặt tâm trí, thư giãn, học hỏi điều mới ngoài công việc, và tự chủ thời gian của mình. Trong đó, việc tách khỏi công việc trong giờ nghỉ được các nghiên cứu tiếp theo liên hệ với mức kiệt sức thấp hơn và năng lượng làm việc tốt hơn vào hôm sau.

Năm 2015, Larissa Barber và Alecia Santuzzi đặt tên cho một cảm giác rất quen: áp lực phải trả lời tin nhắn và email công việc ngay lập tức. Người cảm thấy áp lực này mạnh hơn thường khó tách khỏi công việc hơn trong giờ nghỉ.

Nói cách khác, ranh giới không làm mình làm ít đi. Nó giúp những giờ làm việc thật sự là giờ làm việc, và những giờ nghỉ thật sự là giờ nghỉ.

**Sáu ngày, đếm ngược đến 23 tháng Chạp**

Còn sáu ngày (Thứ Hai): nhìn ra những điều đang lấn vào giờ quan trọng. Còn năm ngày (Thứ Ba): một câu nói ranh giới lịch sự. Còn bốn ngày (Thứ Tư): email trả lời tự động cho kỳ nghỉ Tết. Còn ba ngày (Thứ Năm): danh sách bàn giao. Còn hai ngày (Thứ Sáu): một cuộc trao đổi với cấp trên hoặc đồng nghiệp. Ngày cuối (Thứ Bảy 30.01, tức 23 tháng Chạp): tiễn năm cũ, dọn bàn làm việc. Chủ Nhật nghỉ.

Thói quen then chốt và tấm bảng Kanban vẫn đi tiếp. Lớp thêm của tuần này là một ranh giới bảo vệ chính giờ làm thói quen và giờ làm việc sâu.

**Ngày 1 (20 phút): Những điều đang lấn vào giờ quan trọng**

1. Mở sổ thực hành, đọc lại thói quen đang giữ và lý do dài hạn.
2. Nhớ lại ba ngày làm việc gần nhất. Liệt kê những lần giờ quan trọng bị cắt ngang: một cuộc họp đột xuất, một tin nhắn lúc 21 giờ, một lời nhờ "chỉ mất 5 phút".
3. Chọn điều lấn vào nhiều nhất.
4. Viết khung giờ quan trọng nhất trong ngày mà mình muốn bảo vệ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-1.

Chia sẻ hôm nay: "Điều đang lấn vào giờ quan trọng của tôi nhiều nhất: .... Khung giờ tôi muốn bảo vệ: ...".

Không cần nêu tên ai trong danh sách, các anh chị và các bạn chỉ cần ghi loại việc thôi nha.


## Bài 2: Ngày 2 (Thứ Ba 26/01)
@img 2_cau-noi
@pdf 10XHub_RanhGioi_PhieuNgay2_cau-noi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: NÓI RANH GIỚI SAO CHO LỊCH SỰ

Nhiều người biết rõ mình cần ranh giới, nhưng đến lúc nói thì không biết nói thế nào cho khỏi mất lòng. Hôm nay là bộ câu mẫu theo từng tình huống. Mỗi câu có ba phần: ghi nhận người kia, nói rõ ranh giới, đưa ra một lựa chọn khác.

**Khi có lời mời họp vào giờ làm việc sâu**

"Em cảm ơn chị đã mời. Từ 8 đến 10 giờ sáng em đang dành cho báo cáo quý, nên em xin phép không nhận họp khung này. Chiều nay sau 14 giờ em có thể tham gia, hoặc em gửi ý kiến bằng văn bản trước 11 giờ được không chị?"

**Khi đồng nghiệp nhờ "chỉ 5 phút" lúc đang làm việc quan trọng**

"Anh hỏi đúng lúc em đang làm dở phần số liệu. 11 giờ em qua chỗ anh mình xem cùng nha, như vậy em tập trung được cho việc của anh hơn."

**Khi khách hàng nhắn tin công việc lúc 22 giờ**

Không cần trả lời ngay. Sáng hôm sau: "Chào anh, em đã nhận tin nhắn tối qua. Em gửi anh bảng giá cập nhật trước 10 giờ sáng nay ạ." Nếu là việc khẩn đã thống nhất từ trước, xử lý theo quy định của công ty.

**Khi cấp trên giao thêm việc lúc khối lượng đã đầy**

"Em nhận việc này được. Để làm tốt, em cần anh giúp chọn việc nào ưu tiên: hiện em đang có báo cáo cuối năm và hồ sơ thầu cần xong trước Thứ Sáu. Việc nào em có thể lùi sang sau Tết ạ?"

Câu này không từ chối. Nó đặt ranh giới bằng cách làm rõ giới hạn của thời gian, và để cấp trên tham gia quyết định. Đây cũng là tinh thần của giới hạn việc dở trên bảng Kanban.

**Khi có lời nhờ trong ngày nghỉ**

"Em đang nghỉ đến hết mùng 6. Việc này anh Minh đang nhận bàn giao, anh liên hệ anh Minh giúp em nha. Nếu thật sự khẩn, anh gọi số của em."

**Ba lưu ý khi dùng câu mẫu**

1. Ranh giới nói một lần cho rõ, rồi giữ nhất quán. Một ranh giới hôm có hôm không thì người khác khó tôn trọng.
2. Ranh giới cần hợp với vai trò và văn hoá công ty. Người làm vận hành, trực sự cố hay chăm sóc khách hàng có ca trực riêng; ranh giới của họ là ranh giới ngoài ca trực.
3. Ranh giới không thay cho trách nhiệm. Câu nói tốt luôn đi kèm một lựa chọn khác để công việc vẫn chạy.

**Ngày 2 (20 phút)**

1. Viết ranh giới của mình thành một câu: khung giờ nào, bảo vệ việc gì, ngoại lệ nào.
2. Chọn tình huống mình hay gặp nhất, soạn câu nói theo ba phần.
3. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-2.

Chia sẻ hôm nay: "Ranh giới của tôi: .... Câu tôi sẽ nói: ...".


## Bài 3: Ngày 3 (Thứ Tư 27/01)
@img 3_email-tet
@pdf 10XHub_RanhGioi_PhieuNgay3_email-tet.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: EMAIL TRẢ LỜI TỰ ĐỘNG CHO KỲ NGHỈ TẾT

Email trả lời tự động là ranh giới viết sẵn: nó nói thay mình khi mình không có mặt. Hôm nay là một bản nháp mẫu, kèm chú thích từng phần. Các anh chị và các bạn đọc, rồi viết bản của mình.

**Bản nháp mẫu**

Tiêu đề: Nghỉ Tết Nguyên Đán đến hết ngày ...

(1) Kính chào anh chị,

(2) Em đang nghỉ Tết Nguyên Đán từ ngày ... đến hết ngày ..., và sẽ trả lời email từ sáng ngày ....

(3) Trong thời gian này, các việc về đơn hàng và giao nhận, anh chị vui lòng liên hệ chị Lan, email ..., điện thoại .... Các việc về hợp đồng và thanh toán, anh chị liên hệ anh Minh, email ....

(4) Nếu có việc khẩn liên quan đến sự cố giao hàng, anh chị gọi số trực Tết của công ty: ....

(5) Chúc anh chị và gia đình một năm mới an khang, nhiều niềm vui.

Trân trọng,
Tên, chức danh, công ty.

**Chú thích**

1. Lời chào ngắn, đúng mực. Không cần giải thích lý do nghỉ.
2. Ngày nghỉ và ngày trả lời rõ ràng. "Ngày trả lời" quan trọng hơn ngày nghỉ, vì nó cho người gửi biết khi nào họ có câu trả lời. Nên để ngày trả lời muộn hơn ngày đi làm lại một ngày, để có thời gian đọc hết hộp thư.
3. Người liên hệ thay, chia theo loại việc. Chỉ ghi tên người đã đồng ý nhận bàn giao (việc của Thứ Năm).
4. Kênh khẩn theo quy định của công ty, nếu có. Phần này giúp người gửi yên tâm, và giúp mình không phải mở hộp thư mỗi ngày "cho chắc".
5. Lời chúc Tết. Đây là điểm khác của email tự động dịp Tết ở Việt Nam: nó vừa là thông báo, vừa là một lời chào năm mới tới khách hàng và đối tác.

**Còn email sau giờ làm thì sao?**

Năm 2015, nghiên cứu của Barber và Santuzzi về áp lực phải trả lời ngay cho thấy cảm giác này đi cùng việc khó nghỉ ngơi thật sự. Một số quốc gia đã đưa chuyện này vào luật: từ ngày 01.01.2017, luật lao động của Pháp yêu cầu các doanh nghiệp từ 50 nhân viên trở lên thương lượng về quyền ngắt kết nối ngoài giờ làm việc.

Ở quy mô một người, có ba quy tắc thường được dùng. Một là không trả lời sau một giờ nhất định, trừ việc khẩn đã thống nhất. Hai là chỉ trả lời việc khẩn, việc còn lại để sáng hôm sau. Ba là vẫn viết khi có ý, nhưng hẹn giờ gửi vào sáng hôm sau, để người nhận không cảm thấy phải trả lời ngay trong đêm. Chọn một quy tắc phù hợp với vai trò, và nói rõ với nhóm.

**Ngày 3 (25 phút)**

1. Viết email trả lời tự động theo năm phần, để trống ngày nếu công ty chưa chốt lịch nghỉ.
2. Cài sẵn trong hộp thư, hẹn giờ bật vào ngày bắt đầu nghỉ (nếu hộp thư hỗ trợ), hoặc đặt lời nhắc để bật.
3. Chọn quy tắc trả lời email sau giờ của mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-3.

Chia sẻ hôm nay: "Email trả lời tự động dịp Tết của tôi đã soạn xong, người liên hệ thay: .... Quy tắc email sau giờ của tôi: ...".


## Bài 4: Ngày 4 (Thứ Năm 28/01)
@img 4_ban-giao
@pdf 10XHub_RanhGioi_PhieuNgay4_ban-giao.pdf (phiếu thực hành và mẫu danh sách bàn giao in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: DANH SÁCH BÀN GIAO ĐỂ NGHỈ TẾT TRỌN VẸN

Một kỳ nghỉ trọn vẹn thường bắt đầu từ một danh sách bàn giao tốt. Không có danh sách, người ở lại phải gọi hỏi, người đi nghỉ phải mở điện thoại. Hôm nay là một danh sách kiểm gồm mười câu hỏi. Đi qua từng câu, bản bàn giao sẽ tự thành hình.

**Phần một: việc nào cần bàn giao?**

1. Việc nào có thể phát sinh trong thời gian nghỉ? Đơn hàng sau Tết, hợp đồng chờ ký, khách hàng hay liên hệ vào dịp Tết.
2. Việc nào đang dở trên cột Đang làm của bảng Kanban? Việc nào làm xong được trước khi nghỉ, việc nào cần người khác theo dõi?
3. Việc nào có thể lùi sang sau Tết mà không ảnh hưởng ai? Ghi rõ để khỏi phải nghĩ về nó trong kỳ nghỉ.

**Phần hai: mỗi việc cần ghi gì?**

4. Tình trạng hiện tại: đã làm tới đâu, bước tiếp theo là gì (viết bằng một động từ, như thẻ việc tuần Kanban).
5. Tài liệu nằm ở đâu: thư mục nào, tệp nào, đường dẫn nội bộ nào.
6. Ai là đầu mối bên ngoài: tên, bộ phận, cách liên hệ.
7. Khi nào cần quyết định, và ai được quyết định khi mình vắng mặt.

**Phần ba: bàn giao thế nào?**

8. Người nhận đã đồng ý chưa? Bàn giao là một cuộc trao đổi, không phải một email gửi lúc 17 giờ ngày cuối.
9. Quyền truy cập đã được cấp đúng cách chưa? Không ghi mật khẩu vào danh sách bàn giao; cấp quyền theo quy định bảo mật của công ty.
10. Cấp trên đã biết ai nhận việc gì chưa? Một dòng báo cáo ngắn là đủ.

**Bàn giao cũng là ranh giới**

Cloud và Townsend viết rằng ranh giới giúp phân biệt việc của mình và việc không phải của mình. Danh sách bàn giao làm điều đó theo thời gian: trong những ngày này, việc này là của người nhận bàn giao, không phải của mình. Khi đã bàn giao rõ ràng, việc không mở hộp thư trong kỳ nghỉ không còn là sự bỏ bê. Đó là sự tin tưởng đã được chuẩn bị.

Bàn giao cũng là một cách cảm ơn người ở lại: một danh sách rõ ràng giúp họ làm việc nhẹ hơn rất nhiều.

**Ngày 4 (30 phút)**

1. Đi qua mười câu hỏi, viết danh sách bàn giao (mẫu in được ở phiếu Ngày 4).
2. Ghi người nhận bàn giao chính và hẹn một buổi trao đổi 15 phút trước khi nghỉ.
3. Đánh dấu ba ô kiểm tra: tài liệu, quyền truy cập, cấp trên đã biết.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-4.

Chia sẻ hôm nay: "Danh sách bàn giao Tết của tôi có ... việc. Người nhận bàn giao chính: ...".


## Bài 5: Ngày 5 (Thứ Sáu 29/01)
@img 5_trao-doi
@pdf 10XHub_RanhGioi_PhieuNgay5_trao-doi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MƯỜI LĂM PHÚT TRAO ĐỔI VỀ RANH GIỚI

Ranh giới chỉ có tác dụng khi người xung quanh biết đến nó. Hôm nay là một đoạn hội thoại minh hoạ giữa anh Tuấn, kỹ sư bảo trì, và chị Phương, trưởng phòng kỹ thuật. Nhân vật không có thật. Cấu trúc của cuộc trao đổi thì dùng được cho mọi vị trí.

**Bối cảnh**

Thói quen then chốt của anh Tuấn là 45 phút đầu ca sáng viết hướng dẫn thao tác cho dây chuyền mới, việc khó anh chọn từ tuần Gan góc. Hai tuần nay, khung giờ này liên tục bị cắt ngang bởi các cuộc gọi hỏi việc không gấp. Trước Tết, anh còn cần bàn giao lịch bảo trì cho đồng nghiệp trực.

**Cuộc trao đổi**

Anh Tuấn: Chị Phương, em xin chị 15 phút để thống nhất hai việc trước Tết được không chị?

Chị Phương: Được, em nói đi.

Anh Tuấn: Việc thứ nhất về khung giờ. Em đang ưu tiên bộ hướng dẫn thao tác cho dây chuyền B, vì quý 1 có hai công nhân mới vào. Em đề xuất từ 7 giờ 30 đến 8 giờ 15 mỗi sáng em không nhận cuộc gọi việc không gấp, trừ khi máy dừng. Các việc khác em trả lời ngay sau 8 giờ 15.

Chị Phương: Nếu máy có vấn đề thì sao?

Anh Tuấn: Máy dừng hoặc có nguy cơ an toàn thì vẫn gọi em ngay, em giữ điện thoại bên cạnh. Chỉ những câu hỏi có thể chờ 45 phút thì để sau.

Chị Phương: Được. Chị sẽ nói lại với các tổ trưởng.

Anh Tuấn: Việc thứ hai là bàn giao Tết. Em đã có danh sách sáu việc, người nhận chính là anh Hoà trực Tết. Chiều Thứ Năm tuần sau em ngồi với anh Hoà 15 phút. Em gửi chị bản danh sách để chị nắm.

Chị Phương: Tốt. Gửi chị trước Thứ Tư nha.

**Cấu trúc của cuộc trao đổi**

1. Xin thời gian ngắn, nói trước số việc cần thống nhất.
2. Nói điều mình đang ưu tiên, gắn với mục tiêu chung (công nhân mới, dây chuyền mới), không gắn với sự thoải mái của riêng mình.
3. Đề xuất ranh giới cụ thể: khung giờ, loại việc, ngoại lệ.
4. Chủ động nói trước ngoại lệ an toàn, khẩn cấp, để người nghe yên tâm.
5. Cam kết phần của mình: trả lời sau khung giờ, gửi danh sách bàn giao.

Ở cuộc trao đổi này, ranh giới không phải lời từ chối. Nó là một thoả thuận làm việc, và người kia được tham gia vào thoả thuận đó.

**Nếu cuộc trao đổi không như mong muốn**

Có những vai trò, những giai đoạn mà ranh giới đề xuất chưa được chấp nhận. Khi đó, hỏi thêm một câu: "Vậy khung giờ nào trong ngày em có thể dành cho việc này?" Một ranh giới nhỏ hơn vẫn tốt hơn không có ranh giới nào.

**Ngày 5 (20 phút, cộng 15 phút trao đổi)**

1. Chọn người cần trao đổi: cấp trên, đồng nghiệp, khách hàng hay nhóm của mình.
2. Chuẩn bị ba câu: điều mình đang ưu tiên, ranh giới đề xuất, điều mình cam kết.
3. Trao đổi trong hôm nay hoặc đặt lịch trước Thứ Tư tuần sau, ghi lại kết quả.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-5.

Chia sẻ hôm nay: "Hôm nay tôi trao đổi về: .... Người tôi trao đổi: .... Kết quả: ...".


## Bài 6: Ngày 6 (Thứ Bảy 30/01, 23 tháng Chạp)
@img 6_tien-nam-cu
@img2 9_the-thanh-tich
@pdf 10XHub_RanhGioi_PhieuNgay6_tien-nam-cu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: 23 THÁNG CHẠP, TIỄN NĂM CŨ VÀ DỌN BÀN LÀM VIỆC

Hôm nay là ngày 23 tháng Chạp. Theo phong tục, nhiều gia đình Việt tiễn Ông Công Ông Táo về trời, để báo lại chuyện một năm của gia đình. Những ngày này, nhà nhà dọn dẹp, lau chùi, chuẩn bị đón năm mới. Nhiều văn phòng cũng chọn dịp này để tổng vệ sinh trước kỳ nghỉ.

Bài cuối tuần mượn hai hình ảnh đó, theo cách của người đi làm: một bản "báo cáo" ngắn về năm làm việc theo âm lịch sắp qua, và một bàn làm việc gọn gàng để năm mới bắt đầu nhẹ nhàng.

**"Báo cáo" năm làm việc**

Không cần dài. Ba câu là đủ:

- Một điều đã làm tốt trong năm, đáng cảm ơn chính mình.
- Một điều muốn tiễn đi, để lại năm cũ: một cách làm việc không còn hợp, một nỗi lo đã qua, một việc đã quyết định không theo đuổi nữa.
- Một điều muốn mang sang năm Đinh Mùi: thói quen then chốt, lý do dài hạn, hay một ranh giới vừa đặt tuần này.

**Dọn bàn làm việc, năm bước**

1. Giấy tờ: phân loại thành ba chồng: lưu trữ, bàn giao, bỏ đi. Giấy tờ có thông tin khách hàng thì huỷ theo quy định của công ty.
2. Tệp trên máy tính: gom tệp trên màn hình chính vào đúng thư mục.
3. Tấm bảng Kanban: gỡ các thẻ ở cột Xong của tháng 1, đọc lại một lượt trước khi gỡ. Thẻ nào ở Cần làm không còn cần nữa thì bỏ đi, không cần mang sang năm mới.
4. Danh sách bàn giao và email trả lời tự động: kiểm tra lần cuối.
5. Bàn làm việc: lau sạch, để lại trên bàn đúng ba vật cần cho ngày đi làm lại: thẻ 5 mục tiêu, tấm bảng, và một thẻ việc đầu tiên của năm mới.

Trong sản xuất tinh gọn có 5S (Sàng lọc, Sắp xếp, Sạch sẽ, Săn sóc, Sẵn sàng), phương pháp tổ chức nơi làm việc bắt nguồn từ Nhật Bản. Một ý quan trọng của 5S: dọn dẹp không chỉ để đẹp, mà để những điều bất thường lộ ra. Một bàn làm việc gọn trước Tết cũng vậy: ngày đi làm lại, mình nhìn thấy ngay việc cần làm đầu tiên.

**Tuần sau: Tự trắc ẩn trong công việc**

Tuần 01.02 đến 06.02 là tuần giáp Tết, việc mỗi ngày rất nhẹ, chỉ 5 đến 15 phút. Công thức #0038 Tự trắc ẩn trong công việc, bắt đầu Thứ Hai 01.02, giúp nhìn lại một năm làm việc công bằng với chính mình, và giữ thói quen qua kỳ nghỉ bằng một phiên bản tối thiểu kiểu Tết. Thứ Sáu 05.02 là tối giao thừa, Thứ Bảy 06.02 là mùng 1 Tết Đinh Mùi.

**Ngày 6 (20 phút)**

1. Viết ba câu "báo cáo" năm làm việc.
2. Dọn bàn làm việc theo năm bước, đánh dấu từng bước trên sổ.
3. Đọc lại bảng gom cả tuần: ranh giới, quy tắc email sau giờ, người nhận bàn giao.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0037-ngay-6.

Chia sẻ hôm nay: "23 tháng Chạp, tôi tiễn đi: .... Điều tôi mang sang năm mới: ...".

Ai muốn có thể chụp một tấm ảnh bàn làm việc đã dọn gọn (không có giấy tờ, thông tin của khách hàng) đăng kèm bình luận nha.

**Thẻ thành tích**

Ai đánh dấu đã chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần: một con dấu tròn với chữ TẾT lớn, dòng "nghỉ trọn vẹn", tên mình và ranh giới của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Chúc các anh chị và các bạn một ngày tiễn Ông Công Ông Táo ấm áp bên gia đình.
