## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 19/04)
@img 1_trang-cornell
@pdf 10XHub_CongThuc_0049_Ghi Chep Cornell_VN.pdf (tài liệu đầy đủ của Công thức #0049)
@pdf 10XHub_Cornell_PhieuNgay1_trang-cornell.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0049.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỘT TRANG GIẤY CHIA BA VÙNG CHO MỖI BUỔI HỌC

Tuần trước, cả nhóm đã thử trang giấy trắng, viết câu hỏi buộc mình phải nhớ lại, chạy một thí nghiệm nhỏ giữa đọc lại và tự kiểm tra, nhìn lại mười cách học theo bằng chứng, và trong ngày Giỗ Tổ đã nhớ đến người dạy mình nghề. Thứ Bảy, mỗi người chọn một cách tự kiểm tra để giữ trong 20 phút học.

Công thức #0049 của tuần là Ghi chép Cornell.

**Nếu mới tham gia:** chỉ cần một tờ giấy và một cây bút. Trên sổ thực hành Ngày 1, viết thói quen then chốt và một điều đang muốn học trong công việc, rồi chia tờ giấy theo hướng dẫn bên dưới và dùng nó ngay trong buổi học hoặc cuộc họp gần nhất hôm nay. Tuần này tự đứng được, không cần đọc lại các tuần trước.

Bài hôm nay được viết theo đúng cấu trúc của một trang Cornell: phần ghi chép, phần câu hỏi gợi nhớ, và phần tóm tắt. Đọc xong cũng là xem xong một trang mẫu.

**PHẦN GHI CHÉP (cột bên phải, chiếm khoảng hai phần ba trang)**

- Nguồn gốc: Walter Pauk, giảng viên Đại học Cornell (Mỹ), phát triển cách ghi chép này từ những năm 1950 và đưa vào cuốn How to Study in College, bản đầu năm 1962. Sách được tái bản nhiều lần.
- Bố cục: một đường dọc chia trang thành cột trái hẹp (khoảng một phần ba bề ngang) và cột phải rộng. Một dải ngang khoảng 5 cm ở cuối trang.
- Cột phải: ghi trong lúc học, nghe, họp. Ghi ý, không ghi nguyên câu.
- Cột trái: viết sau buổi học, là những câu hỏi hoặc từ khoá gợi nhớ cho từng ý bên phải.
- Dải cuối trang: hai đến ba câu tóm tắt cả trang, bằng lời của mình.
- Cách dùng thường được tóm thành năm bước: ghi, rút gọn, tự nhắc lại (che cột phải, trả lời từ cột trái), suy ngẫm, ôn lại.

**PHẦN CÂU HỎI GỢI NHỚ (cột bên trái)**

- Ai đưa ra cách ghi này, và trong cuốn sách nào?
- Cột trái và cột phải khác nhau ở chỗ nào: viết lúc nào, viết gì?
- Dải cuối trang dùng để làm gì?
- Vì sao cột câu hỏi nối trực tiếp với tuần Truy hồi chủ động?

**PHẦN TÓM TẮT (dải cuối trang)**

Trang Cornell chia ghi chép thành ba vùng: ghi trong lúc học, câu hỏi sau khi học, tóm tắt cuối trang. Giá trị lớn nhất nằm ở cột câu hỏi, vì nó biến mỗi trang ghi chép thành một bài tự kiểm tra.

**Lớp của tuần này**

Thói quen then chốt, rồi 20 phút học, và từ tuần trước là năm phút tự kiểm tra. Tuần này, mỗi buổi 20 phút để lại một trang Cornell. Cột câu hỏi chính là chỗ đặt những câu hỏi tự kiểm tra của tuần trước, nên đến lịch ôn chỉ cần che cột phải lại là có bài kiểm tra. Ngoài giờ học, trang Cornell còn dùng được cho cuộc họp, buổi đào tạo nội bộ, hay khi đọc một tài liệu dài.

Mỗi trang là một bước nhỏ trên dự án học của quý 2, và cũng là một dấu vết cho thấy mình đang tiến về phía phiên bản 10X của chính mình bằng việc làm cụ thể.

**Sáu ngày của tuần**

- Thứ Hai: chia trang, ghi cột phải.
- Thứ Ba: ghi gì và rút gọn thế nào.
- Thứ Tư: cột câu hỏi, che cột phải và tự trả lời.
- Thứ Năm: biên bản họp kiểu Cornell.
- Thứ Sáu: nghiên cứu nói gì về cách ghi này.
- Thứ Bảy: nhìn lại sáu trang, chọn cách dùng Cornell sẽ giữ.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Trang đầu tiên**

1. Lấy một tờ giấy A4 hoặc một trang sổ. Kẻ một đường ngang cách mép dưới khoảng 5 cm.
2. Kẻ một đường dọc cách mép trái khoảng một phần ba bề ngang, từ đầu trang xuống đến đường ngang.
3. Ghi tên chủ đề và ngày ở đầu trang.
4. Trong 20 phút học (hoặc một cuộc họp hôm nay), chỉ ghi vào cột phải. Cột trái và dải dưới để trống, ngày mai và ngày kia sẽ dùng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-1.

Chia sẻ hôm nay: "Trang Cornell đầu tiên của tôi: ..., ghi trong ...".

Trang đầu chưa đẹp cũng không sao, các anh chị và các bạn cứ giữ lại tờ giấy hôm nay nha, cả tuần sẽ còn dùng tới nó.


## Bài 2: Ngày 2 (Thứ Ba 20/04)
@img 2_cot-ghi-chep
@pdf 10XHub_Cornell_PhieuNgay2_cot-ghi-chep.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: GHI GÌ VÀ RÚT GỌN THẾ NÀO

Cột phải là nơi ghi trong lúc học, nghe hoặc họp. Cột này dễ thành một bản chép lại dài và khó đọc. Hôm nay giải nghĩa năm khái niệm giúp cột phải gọn mà vẫn đủ, rồi làm bước rút gọn trên trang của hôm qua.

**"Ý chính"**

Một ý chính là một điều có thể đứng riêng thành một dòng: một định nghĩa, một con số, một bước, một quyết định. Ghi ý, không ghi nguyên câu. Ví dụ, thay vì chép "Người trình bày cho biết từ tháng 5 công ty sẽ áp dụng quy trình duyệt mới với các đơn hàng trên 200 triệu đồng", chỉ cần ghi "Từ 05: đơn > 200 tr → quy trình duyệt mới".

**"Ký hiệu"**

Một bộ ký hiệu nhỏ, dùng nhất quán, giúp ghi nhanh hơn mà đọc lại vẫn hiểu. Ví dụ: mũi tên cho dẫn đến, dấu chấm hỏi cho điều chưa rõ, dấu sao cho điều quan trọng, chữ V khoanh tròn cho việc cần làm. Năm đến bảy ký hiệu là đủ, nhiều hơn dễ rối.

**"Khoảng trống"**

Để cách một dòng giữa các ý, và chừa chỗ cuối mỗi đoạn. Khoảng trống là nơi bổ sung khi người trình bày quay lại một ý, hoặc khi rút gọn mình muốn thêm một ví dụ.

**"Rút gọn"**

Pauk khuyên rút gọn càng sớm càng tốt sau buổi học, tốt nhất trong ngày. Rút gọn là đọc lại cột phải một lượt, đánh dấu ba đến năm ý quan trọng nhất, bổ sung chỗ còn thiếu, gạch những dòng không cần. Đây không phải chép lại cho đẹp, mà là chọn lọc.

**"Ví dụ của mình"**

Sau mỗi ý quan trọng, nếu được, thêm một ví dụ từ chính công việc của mình, đánh dấu riêng (ví dụ chữ VD). Ví dụ của mình giúp nhớ ý đó lâu hơn và cho biết mình đã thật sự hiểu hay chưa.

**Một lưu ý về việc tô đậm**

Tuần trước, tô đậm và gạch chân nằm ở nhóm có bằng chứng hạn chế. Đánh dấu ba đến năm ý khi rút gọn vẫn có ích, nhưng chỉ là bước chuẩn bị để viết câu hỏi vào cột trái ngày mai, không thay cho việc tự kiểm tra.

**Ngày 2 (20 phút)**

1. Trong 20 phút học hôm nay, ghi một trang Cornell mới, thử dùng bộ ký hiệu của mình.
2. Rút gọn trang của hôm qua và trang hôm nay: đánh dấu ba đến năm ý chính, bổ sung chỗ thiếu.
3. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-2.

Chia sẻ hôm nay: "Sau khi rút gọn, ba ý chính của trang hôm nay: ...".


## Bài 3: Ngày 3 (Thứ Tư 21/04)
@img 3_cot-cau-hoi
@pdf 10XHub_Cornell_PhieuNgay3_cot-cau-hoi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: CHE CỘT PHẢI, TRẢ LỜI TỪ CỘT TRÁI

**Một tình huống minh hoạ**

Anh Khoa là kỹ sư đảm bảo chất lượng ở một nhà máy linh kiện. Thứ Hai, anh dự buổi đào tạo nội bộ một giờ về quy trình kiểm soát thay đổi mới. Lần này anh ghi kiểu Cornell: cột phải kín các bước, các mốc thời gian, các biểu mẫu.

Trước đây, sau những buổi như vậy, anh thường cất sổ và chỉ mở lại khi cần tra cứu. Lần này, tối Thứ Ba, anh dành 10 phút viết vào cột trái. Bên cạnh dòng "thay đổi loại B: trưởng ca + kỹ sư chất lượng ký, trong 24 giờ", anh viết câu hỏi "Thay đổi loại B cần ai ký, trong bao lâu?". Bên cạnh dòng về biểu mẫu, anh viết "Biểu mẫu nào dùng khi thay đổi nhà cung cấp linh kiện?". Cả trang có bảy câu hỏi.

Sáng Thứ Tư, trong 20 phút học, anh lấy một tờ giấy che cột phải lại, đọc từng câu hỏi ở cột trái và trả lời thành tiếng. Năm câu trả lời trôi chảy. Hai câu anh ngập ngừng: thời hạn của thay đổi loại C và người phê duyệt cuối. Anh mở cột phải đối chiếu, đánh dấu hai câu đó để hỏi lại vào Thứ Sáu.

Tuần sau, khi một trưởng ca hỏi về thay đổi loại B, anh trả lời ngay, không phải mở tài liệu.

Tình huống trên là minh hoạ. Điều đáng chú ý là anh không đọc lại trang ghi chép. Anh dùng nó như một bài tự kiểm tra.

**Ba điều làm cột trái hiệu quả**

- **Viết câu hỏi, không chỉ viết từ khoá.** Từ khoá "loại B" chỉ gợi cảm giác quen. Câu hỏi "Thay đổi loại B cần ai ký, trong bao lâu?" buộc mình phải lấy câu trả lời ra từ trí nhớ, đúng như năm cặp câu hỏi của tuần trước.
- **Viết sau buổi học, không viết ngay trong buổi.** Khoảng cách vài giờ đến một ngày giúp chọn đúng điều đáng hỏi.
- **Che thật sự.** Dùng một tờ giấy, một cuốn sổ khác hay gập trang lại. Liếc sang cột phải là mất phần giá trị nhất.

**Cột trái và lịch ôn**

Trang Cornell có cột câu hỏi là một bài tự kiểm tra sẵn có. Đến lịch ôn 1, 3, 7, 14 ngày của tuần #0040, chỉ cần lấy các trang ra, che cột phải, trả lời từ cột trái. Cách tự kiểm tra mình chọn giữ tuần trước có ngay một chỗ để làm.

**Ngày 3 (20 phút)**

1. Viết ba đến bảy câu hỏi vào cột trái cho trang Thứ Hai và Thứ Ba.
2. Che cột phải, trả lời từng câu (nói thành tiếng hoặc viết ra).
3. Đối chiếu, đánh dấu câu còn ngập ngừng để hỏi lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-3.

Chia sẻ hôm nay: "Tôi viết ... câu hỏi ở cột trái, che cột phải và trả lời được ... câu".


## Bài 4: Ngày 4 (Thứ Năm 22/04)
@img 4_bien-ban-hop
@pdf 10XHub_Cornell_PhieuNgay4_bien-ban-hop.pdf (phiếu thực hành và mẫu biên bản họp kiểu Cornell)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BIÊN BẢN HỌP KIỂU CORNELL

Trang Cornell sinh ra cho giảng đường, nhưng cấu trúc ba vùng rất hợp với cuộc họp. Hôm nay đặt hai bản ghi của cùng một cuộc họp cạnh nhau để thấy khác biệt.

Cuộc họp minh hoạ: giao ban kinh doanh sáng Thứ Năm, 30 phút, bàn về tiến độ quý 2 và chương trình cho khách hàng gia hạn.

**Bản ghi thường**

Một danh sách dài theo trình tự cuộc họp: anh Nam báo doanh số tuần, khu vực phía Bắc chậm; chị Hoa đề xuất ưu đãi gia hạn; mọi người bàn mức ưu đãi; trưởng phòng hỏi về hai khách hàng lớn; chốt ưu đãi 5%; anh Nam gửi danh sách khách hàng trước Thứ Hai; bàn lịch hội thảo khách hàng tháng 5, chưa chốt...

Đọc lại sau một tuần, mất vài phút mới tìm ra mình cần làm gì và điều gì còn bỏ ngỏ.

**Bản ghi kiểu Cornell**

- **Cột phải (diễn biến):** ghi gọn các ý chính theo cuộc họp, như bản ghi thường nhưng ngắn hơn, có ký hiệu.
- **Cột trái (việc cần làm và câu hỏi mở):** "V: anh Nam gửi danh sách khách hàng gia hạn, trước Thứ Hai"; "V: mình soạn email ưu đãi 5%, trước Thứ Tư"; "?: lịch hội thảo tháng 5, ai chốt, khi nào?".
- **Dải cuối trang (tóm tắt):** "Chốt ưu đãi gia hạn 5% cho khách hàng có hợp đồng trên một năm. Khu vực phía Bắc chậm, cần kế hoạch riêng tuần sau."

Đọc lại sau một tuần, chỉ cần nhìn cột trái và dải tóm tắt là biết ngay việc của mình và điều còn mở.

**Cột trái trong cuộc họp dùng cho điều gì?**

Với buổi học, cột trái là câu hỏi gợi nhớ. Với cuộc họp, cột trái thường hữu ích hơn khi dành cho việc cần làm (ai, việc gì, khi nào) và câu hỏi còn mở. Cũng có thể dùng cả hai, với ký hiệu riêng.

**Hai lưu ý**

- Dải tóm tắt hai câu có thể dùng luôn làm nội dung tin nhắn gửi nhóm sau họp, nếu nhóm chưa có người viết biên bản chính thức.
- Biên bản họp có thông tin khách hàng và nội bộ: giữ bảo mật theo quy định của công ty, không chụp gửi ra ngoài.

**Ngày 4 (20 phút)**

1. Dùng trang Cornell cho một cuộc họp hôm nay (nếu không có họp, dùng cho 20 phút học).
2. Sau họp, viết cột trái và dải tóm tắt hai câu.
3. Làm vòng tự kiểm tra ngắn cho trang Thứ Hai: che cột phải, trả lời từ cột trái.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-4.

Chia sẻ hôm nay: "Biên bản kiểu Cornell cho .... Tóm tắt: ...".


## Bài 5: Ngày 5 (Thứ Sáu 23/04)
@img 5_bang-chung
@pdf 10XHub_Cornell_PhieuNgay5_bang-chung.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: CORNELL CÓ THẬT SỰ HIỆU QUẢ KHÔNG?

Cách ghi Cornell rất phổ biến, được nhiều trường đại học giới thiệu cho sinh viên. Nhưng phổ biến không có nghĩa là đã được chứng minh. Hôm nay là một bảng kiểm bằng chứng: điều có cơ sở, và điều chưa chắc.

**Điều có cơ sở**

1. **Tự kiểm tra từ cột câu hỏi.** Che cột phải và trả lời từ cột trái chính là truy hồi chủ động. Đây là phần có nhiều bằng chứng nhất, với các nghiên cứu đã gặp ở tuần trước như Roediger và Karpicke (2006).
2. **Ôn lại các trang theo lịch cách quãng.** Học cách quãng cũng nằm ở mức hữu ích cao trong tổng quan của Dunlosky và cộng sự (2013).
3. **Hợp với những việc cần tổng hợp và vận dụng.** Một nghiên cứu của Jacobs (2008) với học sinh trung học so sánh Cornell với cách ghi theo dàn ý có sẵn do giáo viên phát. Cornell có lợi hơn khi học sinh phải tổng hợp, vận dụng, đánh giá thông tin; cách ghi theo dàn ý có sẵn lại tốt hơn cho việc nhớ dữ kiện đơn lẻ.

**Điều chưa chắc**

1. **Bản thân việc chia trang.** Một nghiên cứu của Quintus và cộng sự (2012) trong một lớp trung học không thấy khác biệt có ý nghĩa thống kê về điểm kiểm tra giữa học sinh ghi theo Cornell và học sinh tự chọn cách ghi. Một số nghiên cứu khác cho kết quả tích cực hơn. Nhìn chung, bằng chứng về riêng hình thức Cornell còn lẫn lộn, và phần lớn được làm với học sinh, sinh viên, không phải người đi làm.
2. **Dải tóm tắt.** Tóm tắt nằm ở mức hữu ích thấp trong tổng quan năm 2013, chủ yếu vì hiệu quả phụ thuộc nhiều vào việc người học có biết tóm tắt hay không. Tóm tắt hai câu bằng lời của mình, viết không nhìn cột phải, sẽ gần với tự kiểm tra hơn.

**Vậy nên dùng Cornell thế nào?**

Coi Cornell là một khung, không phải phép màu. Giá trị đến từ việc dùng khung đó để làm những điều có bằng chứng: viết câu hỏi, che cột phải để tự kiểm tra, ôn theo lịch. Một trang Cornell đẹp nhưng không bao giờ được che cột phải sẽ không khác bao nhiêu so với một trang ghi chép thường.

**Ngày 5 (20 phút)**

1. Viết dải tóm tắt hai câu cho các trang trong tuần, không nhìn cột phải.
2. Nhìn lại: tuần này mình đã che cột phải để tự kiểm tra ở bao nhiêu trang?
3. Chọn phần của Cornell mình sẽ giữ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-5.

Chia sẻ hôm nay: "Phần của Cornell tôi giữ: ...".


## Bài 6: Ngày 6 (Thứ Bảy 24/04)
@img 6_tom-tat-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_Cornell_PhieuNgay6_tom-tat-tuan.pdf (phiếu thực hành và mẫu trang Cornell in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: SÁU TRANG CORNELL VÀ NĂM CÂU HỎI MỞ

Sáu ngày, khoảng sáu trang Cornell, có trang cho buổi học, có trang cho cuộc họp. Sáng nay đặt cả xấp lên bàn và đi qua năm câu hỏi mở. Không có câu trả lời đúng hay sai, chỉ có cách ghi hợp với mình.

**Câu hỏi 1: Khi che cột phải, trang nào mình lấy ra được nhiều nhất?**

Thường đó là trang có câu hỏi cụ thể nhất ở cột trái. Nhìn kỹ những câu hỏi đó: chúng có điểm gì chung?

**Câu hỏi 2: Câu hỏi nào ở cột trái vẫn khó sau cả tuần?**

Những câu này là chỗ cần luyện riêng trong 20 phút học tuần sau. Chép chúng sang thẻ gập đôi của tuần trước, hoặc khoanh lại để ôn theo lịch.

**Câu hỏi 3: Cornell hợp nhất với tình huống nào của mình?**

Buổi học 20 phút, cuộc họp, buổi đào tạo nội bộ, hay lúc đọc một tài liệu dài. Có người thấy hợp nhất với cuộc họp, có người chỉ dùng cho việc học. Cả hai đều ổn.

**Câu hỏi 4: Mình muốn đổi gì cho hợp với mình?**

Cột trái rộng hơn hay hẹp hơn, tóm tắt hai câu hay ba gạch đầu dòng, giấy hay ghi trên máy. Khung chỉ là điểm bắt đầu. Điều cần giữ là ba việc: ghi gọn, viết câu hỏi, che cột phải để tự kiểm tra.

**Câu hỏi 5: Dự án học đi thêm được bước nào nhờ những trang tuần này?**

Một mục trong bộ kịch bản, một phần của mẫu báo cáo, vài câu hỏi phỏng vấn mới. Những trang Cornell của tuần này là nguyên liệu cho dự án học của quý 2.

**Sáng nay (15 phút)**

1. Đặt các trang Cornell trong tuần lên bàn, đi qua năm câu hỏi trên.
2. Viết một câu: mình sẽ dùng trang Cornell ở đâu và theo quy ước nào.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In vài bản mẫu trang Cornell ở phiếu Ngày 6, kẹp vào sổ cùng bản đồ dự án học, để tuần sau chỉ việc lấy ra dùng.

**Tuần sau: Xếp chồng kỹ năng**

Tuần sau là tuần có hai ngày nghỉ lễ 30.4 và 1.5. Bài sẽ nhẹ dần về cuối tuần, và mở ra một góc nhìn rộng hơn: kỹ năng mình đang học cộng thêm vào bộ kỹ năng sẵn có ở đâu để tạo lợi thế riêng trong công việc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0049-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi có ... trang Cornell. Tôi giữ: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Cornell hiện ra: một mảng đỏ cắt chéo với chữ số 6 lớn, dòng "NGÀY GHI CORNELL", tên mình và cách mình dùng trang Cornell. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Ba tuần đầu của Mùa 3 đã đi qua: một kỹ năng, một cách tự kiểm tra, và giờ là một cách ghi để giữ lại điều đã học. Hẹn gặp lại sáng Thứ Hai.
