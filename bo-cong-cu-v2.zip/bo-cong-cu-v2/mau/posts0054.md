## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 24/05)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0054_Phan Loai Bloom_VN.pdf (tài liệu đầy đủ của Công thức #0054)
@pdf 10XHub_PhanLoaiBloom_PhieuNgay1_dang-o-tang-nao.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0054.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** SÁU CÂU HỎI, SÁU TẦNG CỦA VIỆC HỌC

Một trung tâm, vài nhánh, vài hình nhỏ, một đường nối ngang: suốt tuần Bản đồ tư duy, mỗi buổi 20 phút học của cả nhóm đã khép lại bằng một trang giấy vẽ từ trí nhớ, mở tài liệu bổ sung bằng mực đỏ sau. Thứ Bảy, mỗi người đặt các bản đồ cạnh nhau và chốt một quy ước khép buổi học cho riêng mình. Ai chưa kịp làm Ngày 6 vẫn mở lại được trên sổ thực hành. Hãy để sẵn các bản đồ đó trên bàn, sáng nay sẽ dùng đến.

Công thức #0054 của tuần là Phân loại Bloom.

**Nếu mới tham gia:** tuần này chỉ cần một chủ đề công việc mình đang học thêm, dù mới bắt đầu. Viết chủ đề đó và một thói quen nhỏ mỗi ngày vào Ngày 1 trên sổ thực hành, rồi đọc sáu câu hỏi bên dưới và xem mình trả lời được đến câu nào. Không cần biết gì về các tuần trước.

**Sáu câu hỏi về cùng một chủ đề**

Giả sử chủ đề của buổi học là "chính sách chiết khấu cho khách hàng đại lý" của công ty. Đọc sáu câu hỏi dưới đây theo thứ tự.

1. Chính sách hiện có mấy mức chiết khấu, mỗi mức áp dụng cho doanh số bao nhiêu?
2. Vì sao công ty đặt mức chiết khấu theo doanh số quý thay vì theo từng đơn hàng?
3. Một đại lý đạt doanh số quý vừa đủ mức 2 nhưng có hai đơn trả lại. Chiết khấu quý này tính thế nào?
4. So với chính sách của năm ngoái, thay đổi nào ảnh hưởng nhiều nhất đến các đại lý nhỏ?
5. Đại lý lớn nhất đề nghị một mức chiết khấu riêng. Nên đồng ý, đồng ý có điều kiện hay từ chối, vì sao?
6. Hãy đề xuất một chương trình khuyến khích cho các đại lý mới, phù hợp với chính sách hiện có.

Câu 1 chỉ cần nhớ. Câu 2 cần hiểu. Câu 3 cần đem quy định áp vào một tình huống. Câu 4 cần tách ra, so sánh. Câu 5 cần cân nhắc và bảo vệ một lựa chọn. Câu 6 cần tạo ra một điều chưa có. Cùng một chủ đề, nhưng mỗi câu đòi hỏi một kiểu suy nghĩ khác, và khó dần lên.

**Phân loại Bloom**

Năm 1956, Benjamin Bloom cùng một nhóm chuyên gia khảo thí ở các trường đại học Hoa Kỳ công bố một bảng phân loại mục tiêu giáo dục cho lĩnh vực nhận thức. Mục đích ban đầu khá thực tế: giúp các giảng viên ở nhiều trường dùng chung một ngôn ngữ khi soạn câu hỏi kiểm tra. Bảng gồm sáu bậc: kiến thức, thông hiểu, áp dụng, phân tích, tổng hợp, đánh giá.

Năm 2001, Lorin Anderson, David Krathwohl (một thành viên của nhóm năm 1956) và cộng sự công bố bản sửa đổi. Sáu bậc được viết lại thành động từ: nhớ, hiểu, vận dụng, phân tích, đánh giá, sáng tạo. Hai bậc cuối đổi chỗ cho nhau, và "tổng hợp" được đổi thành "sáng tạo". Tuần này dùng bản sửa đổi.

Một điều cần nói ngay: hình kim tự tháp quen thuộc gắn với Bloom không có trong cuốn sách năm 1956, cũng không có trong bản sửa đổi năm 2001. Và bản sửa đổi nói rõ các tầng có thể chồng lên nhau, không bắt buộc phải đi tuần tự từ dưới lên.

**Lớp mới của hành trình**

Thói quen then chốt vẫn là trục, ngay sau đó là 20 phút học có chủ đích cho kỹ năng đã chọn ở tuần Siêu học. Các tuần trước giúp nhớ lâu hơn: truy hồi, Cornell, cung điện trí nhớ, học xen kẽ, bản đồ. Tuần này đặt một câu hỏi khác cho chính 20 phút đó: mình đang dừng ở tầng nào, và làm sao đẩy buổi học lên tầng cao hơn bằng chính những câu hỏi mình tự đặt ra.

Đây là bước rất gần với phiên bản 10X của chính mình trong công việc: không chỉ biết quy định, mà dùng được, phân tích được, đề xuất được.

**Sáu ngày của tuần**

- Thứ Hai: mình đang dừng ở tầng nào?
- Thứ Ba: sáu động từ, sáu câu hỏi cho kỹ năng đang học.
- Thứ Tư: một buổi học 20 phút đi lên các tầng.
- Thứ Năm: hỏi đáp về những hiểu lầm quanh Bloom.
- Thứ Sáu: chọn hoạt động học theo tầng cho tuần sau.
- Thứ Bảy: một câu hỏi khép mỗi buổi học.

Chủ Nhật nghỉ.

**Ngày 1 (khoảng 25 phút): Mình đang dừng ở tầng nào?**

1. Mở sổ thực hành, xem lại thói quen đang giữ, kỹ năng và dự án học của quý 2.
2. Lấy một bản đồ của tuần trước (hoặc chủ đề buổi học hôm nay). Đọc lại sáu câu hỏi mẫu, rồi tự viết sáu câu tương tự cho chủ đề của mình, mỗi tầng một câu, không cần hay.
3. Thử trả lời từng câu, không mở tài liệu. Dừng ở câu đầu tiên mình thấy chưa trả lời được.
4. Ghi tầng cao nhất mình trả lời được hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-1.

Chia sẻ hôm nay: "Với chủ đề ..., hôm nay tôi trả lời được đến tầng ...".

Dừng ở tầng nhớ hay hiểu sau vài tuần học là điều rất bình thường, đó chính là điểm xuất phát của tuần này, các anh chị và các bạn cứ ghi đúng hiện trạng nha.


## Bài 2: Ngày 2 (Thứ Ba 25/05)
@img 2_sau-dong-tu
@pdf 10XHub_PhanLoaiBloom_PhieuNgay2_sau-dong-tu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: SÁU ĐỘNG TỪ, SÁU CÂU HỎI CHO KỸ NĂNG ĐANG HỌC

Bản sửa đổi năm 2001 chọn động từ thay cho danh từ vì một lý do rất thực tế: động từ mô tả điều người học làm được. Mỗi tầng còn được chia nhỏ thành các quá trình cụ thể, tổng cộng 19 quá trình. Hôm nay giải nghĩa sáu động từ, mỗi động từ kèm cách đặt câu hỏi cho kỹ năng mình đang học.

**Nhớ**

Nhận ra và nhắc lại được thông tin đã học: tên gọi, con số, các bước, định nghĩa. Hai quá trình: nhận ra và nhớ lại. Câu hỏi thường bắt đầu bằng "là gì", "gồm những gì", "bao nhiêu". Ví dụ cho kế toán: "Báo cáo lưu chuyển tiền tệ gồm mấy phần?"

**Hiểu**

Giải thích được ý nghĩa bằng lời của mình. Bảy quá trình: diễn giải, nêu ví dụ, phân loại, tóm tắt, suy luận, so sánh, giải thích. Câu hỏi: "vì sao", "nghĩa là gì", "cho một ví dụ". Ví dụ: "Vì sao công ty có lãi mà vẫn có thể thiếu tiền?"

**Vận dụng**

Dùng điều đã học trong một tình huống cụ thể. Hai quá trình: thực hiện (với tình huống quen) và triển khai (với tình huống mới). Câu hỏi: "trong trường hợp này thì làm thế nào", "tính cho số liệu sau". Ví dụ: "Lập phần lưu chuyển tiền từ hoạt động kinh doanh cho số liệu tháng 4."

**Phân tích**

Tách một vấn đề thành các phần và thấy chúng liên quan với nhau thế nào. Ba quá trình: phân biệt, sắp xếp, quy kết (nhận ra quan điểm hay mục đích đằng sau). Câu hỏi: "yếu tố nào", "khác nhau ở đâu", "nguyên nhân chính". Ví dụ: "Dòng tiền kinh doanh quý này giảm chủ yếu do khoản nào?"

**Đánh giá**

Đưa ra nhận định dựa trên tiêu chí. Hai quá trình: kiểm tra (tìm chỗ sai, chỗ không nhất quán) và phê bình (cân nhắc giữa các phương án). Câu hỏi: "nên chọn phương án nào", "có hợp lý không". Ví dụ: "Đề xuất kéo dài thời hạn thanh toán cho khách hàng lớn có nên chấp nhận không?"

**Sáng tạo**

Ghép các phần thành một điều mới. Ba quá trình: đề xuất, lập kế hoạch, tạo ra. Câu hỏi: "hãy đề xuất", "hãy thiết kế". Ví dụ: "Thiết kế một bảng theo dõi dòng tiền hằng tuần cho ban giám đốc."

**Một chiều thứ hai: loại kiến thức**

Bản sửa đổi còn thêm một chiều: loại kiến thức đang học. Kiến thức sự kiện (thuật ngữ, chi tiết), kiến thức khái niệm (nguyên lý, mô hình), kiến thức quy trình (cách làm) và kiến thức siêu nhận thức (hiểu biết về cách mình học). Tuần này chỉ dùng sáu động từ, nhưng biết chiều này giúp hiểu vì sao "nhớ một quy trình" và "nhớ một con số" là hai việc khác nhau.

**Ngày 2 (khoảng 25 phút)**

1. Học 15 phút cho kỹ năng đang học.
2. Viết sáu câu hỏi cho chủ đề buổi học hôm nay, mỗi động từ một câu, dùng các từ mở câu gợi ý ở trên.
3. Đánh dấu câu ở tầng cao nhất mình muốn trả lời được vào cuối tuần.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-2.

Chia sẻ hôm nay: "Câu hỏi ở tầng cao nhất tôi viết hôm nay: “...”.".


## Bài 3: Ngày 3 (Thứ Tư 26/05)
@img 3_nhat-ky-20-phut
@pdf 10XHub_PhanLoaiBloom_PhieuNgay3_nhat-ky-20-phut.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NHẬT KÝ MỘT BUỔI HỌC 20 PHÚT ĐI LÊN CÁC TẦNG

Hôm nay là một trang nhật ký minh hoạ. Chị Lan là chuyên viên tuyển dụng ở một công ty bán lẻ. Kỹ năng chị chọn cho quý 2 là "phỏng vấn theo năng lực". Dự án học của chị: đến cuối tháng 6, tự thiết kế bộ câu hỏi phỏng vấn cho vị trí cửa hàng trưởng. Dưới đây là buổi học 20 phút của chị sáng Thứ Tư, ghi theo từng mốc phút.

**7 giờ 45. Thói quen then chốt xong**

Chị vừa xong thói quen then chốt: 15 phút rà danh sách ứng viên trong ngày. Mở bìa hồ sơ học, hẹn giờ 20 phút.

**Phút 0 đến 4. Nhớ**

Úp tài liệu xuống, vẽ lại bản đồ tuần trước về cấu trúc câu trả lời theo năng lực: tình huống, nhiệm vụ, hành động, kết quả. Nhớ đủ bốn nhánh, quên mất ví dụ về câu hỏi gợi mở ở nhánh "hành động". Bổ sung bằng mực đỏ.

**Phút 4 đến 7. Hiểu**

Viết một câu bằng lời của mình: "Hỏi theo năng lực là hỏi về việc người ta đã làm, không hỏi về việc người ta sẽ làm, vì hành vi đã xảy ra là căn cứ đáng tin hơn lời hứa." Chị đọc lại tài liệu, thấy câu này đúng ý.

**Phút 7 đến 13. Vận dụng**

Viết ba câu hỏi phỏng vấn thật cho năng lực "xử lý khiếu nại của khách hàng" ở vị trí cửa hàng trưởng. Câu đầu tiên chị viết là "Anh chị sẽ làm gì nếu khách hàng nổi giận?" Chị nhận ra đây là câu hỏi giả định, sửa lại: "Hãy kể về lần gần nhất anh chị xử lý một khách hàng không hài lòng."

**Phút 13 đến 18. Phân tích**

Lấy hai câu trả lời mẫu trong tài liệu đào tạo. Tách mỗi câu trả lời theo bốn phần. Câu trả lời thứ nhất kể rất dài về tình huống nhưng gần như không có hành động cụ thể của người kể. Câu thứ hai ngắn hơn nhưng có đủ bốn phần.

**Phút 18 đến 20. Đánh giá**

Viết một dòng: "Nếu chỉ được chọn một trong hai ứng viên dựa trên câu trả lời này, tôi chọn người thứ hai, vì có hành động và kết quả kiểm chứng được." Hết giờ.

**Đọc lại trang nhật ký**

Trong 20 phút, chị Lan chỉ dành khoảng 7 phút cho nhớ và hiểu. Mười ba phút còn lại ở vận dụng, phân tích và đánh giá. Chị không cố chạm đến tầng sáng tạo hôm nay; đó là việc của dự án cuối quý. Điều chị thay đổi so với tuần trước không phải là học nhiều hơn, mà là đặt câu hỏi khác đi.

Tình huống trên là minh hoạ. Các anh chị và các bạn không cần chia phút chính xác như vậy. Chỉ cần thử một nguyên tắc: ít nhất một nửa buổi học ở tầng vận dụng trở lên.

**Ngày 3 (khoảng 25 phút)**

1. Học 20 phút, chia làm hai phần: nửa đầu nhớ và hiểu, nửa sau ở tầng vận dụng trở lên.
2. Ghi lại số phút đã dành cho các tầng từ vận dụng trở lên và việc cụ thể đã làm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-3.

Chia sẻ hôm nay: "Hôm nay tôi dành ... phút trong buổi học cho các tầng từ vận dụng trở lên: ...".


## Bài 4: Ngày 4 (Thứ Năm 27/05)
@img 4_hoi-dap
@pdf 10XHub_PhanLoaiBloom_PhieuNgay4_hoi-dap.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BLOOM CÓ PHẢI LÀ MỘT CÁI THANG?

Phân loại Bloom là một trong những khung được nhắc đến nhiều nhất trong đào tạo, và vì thế cũng bị hiểu sai nhiều. Hôm nay là năm câu hỏi thường gặp.

**Hỏi: Có phải phải học xong tầng dưới mới được lên tầng trên?**

Không hẳn. Krathwohl, khi giới thiệu bản sửa đổi năm 2002, viết rằng yêu cầu về một thứ bậc chặt chẽ đã được nới lỏng, cho phép các tầng chồng lên nhau. Ví dụ, giải thích một khái niệm phức tạp (tầng hiểu) có khi khó hơn áp dụng một công thức quen (tầng vận dụng). Trong thực tế, người ta thường đi lên đi xuống nhiều lần trong một buổi học.

**Hỏi: Vậy có cần học thuộc kiến thức trước rồi mới luyện câu hỏi khó?**

Năm 2019, Pooja Agarwal công bố trên Journal of Educational Psychology một loạt thí nghiệm với học sinh trung học cơ sở và sinh viên đại học. Nhóm tự kiểm tra bằng câu hỏi tầng cao (hoặc trộn cả hai loại) làm bài kiểm tra tầng cao tốt hơn, trong khi nhóm chỉ tự kiểm tra bằng câu hỏi sự kiện thì không có lợi thế tương tự ở bài kiểm tra tầng cao. Nghĩa là không nhất thiết phải chờ thuộc hết rồi mới hỏi câu khó. Kết quả này đến từ môi trường trường học, nên khi áp vào công việc cần xem là một gợi ý, không phải quy luật.

**Hỏi: Tầng cao quan trọng hơn tầng thấp?**

Không. Một kế toán không nhớ đúng thời hạn nộp tờ khai thì phân tích giỏi đến đâu cũng gặp rủi ro. Tầng nhớ là nền. Điều tuần này muốn thay đổi là tỷ lệ: đừng để cả 20 phút chỉ dừng ở nền.

**Hỏi: Làm sao biết mình đang ở tầng nào?**

Nhìn vào câu hỏi mình trả lời được, không nhìn vào cảm giác. Đọc đi đọc lại một tài liệu dễ tạo cảm giác đã hiểu, nhưng nếu không giải thích được bằng lời của mình (tầng hiểu) hay không làm được bài với số liệu mới (tầng vận dụng), mình vẫn đang ở tầng nhớ. Đây cũng là lý do bộ câu hỏi hôm Thứ Ba hữu ích hơn một bảng tự chấm.

**Hỏi: Sáng tạo có phải là phải nghĩ ra điều hoàn toàn mới?**

Không. Trong bản sửa đổi, sáng tạo gồm đề xuất, lập kế hoạch và tạo ra một sản phẩm. Viết một quy trình mới cho bộ phận, thiết kế một biểu mẫu, soạn một buổi hướng dẫn cho đồng nghiệp: đều là tầng sáng tạo. Dự án học của quý 2 phần lớn nằm ở tầng này.

**Ngày 4 (khoảng 25 phút)**

1. Học 10 phút cho kỹ năng đang học.
2. Mở lại sáu câu hỏi viết hôm Thứ Ba. Thử trả lời hai câu ở tầng cao nhất, không mở tài liệu, mỗi câu khoảng 5 phút.
3. Ghi lại câu ở tầng cao nhất mình đã trả lời được, và tầng còn thấy khó nhất.
4. Đánh dấu bảng hành trình trên sổ thực hành.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-4.

Chia sẻ hôm nay: "Tôi đã trả lời được câu hỏi ở tầng .... Tầng còn khó nhất với tôi: ...".


## Bài 5: Ngày 5 (Thứ Sáu 28/05)
@img 5_bang-chon
@pdf 10XHub_PhanLoaiBloom_PhieuNgay5_bang-chon.pdf (phiếu thực hành và lịch tầng tuần sau in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: CHỌN HOẠT ĐỘNG HỌC THEO TỪNG TẦNG

Biết các tầng rồi, câu hỏi tiếp theo là: trong 20 phút, cụ thể làm gì để ở đúng tầng đó? Bài hôm nay là một bảng chọn. Tìm tầng mình muốn luyện, chọn một hoạt động hợp với công việc của mình, rồi xếp vào lịch tuần sau.

**Tầng nhớ: khi cần nền vững**

- Vẽ lại bản đồ từ trí nhớ, như tuần trước.
- Tự đố mình bằng thẻ câu hỏi, như tuần Truy hồi chủ động.
- Viết lại các bước của một quy trình không nhìn tài liệu.

**Tầng hiểu: khi cần giải thích được**

- Giải thích điều vừa học trong ba câu cho một đồng nghiệp mới vào nghề, như tuần Feynman.
- Tự nêu một ví dụ và một ví dụ ngược.
- Tóm tắt một tài liệu dài bằng một đoạn.

**Tầng vận dụng: khi cần làm được**

- Làm lại một bài tập với số liệu thật của bộ phận mình.
- Áp một quy định vào một hồ sơ đang xử lý.
- Thử một kỹ thuật mới trong một cuộc gọi hoặc cuộc họp thật, rồi ghi lại kết quả.

**Tầng phân tích: khi cần thấy nguyên nhân**

- So sánh hai trường hợp, một thành công, một không, tìm điểm khác.
- Tách một kết quả thành các yếu tố đóng góp.
- Vẽ sơ đồ nguyên nhân cho một sự cố đã gặp.

**Tầng đánh giá: khi cần quyết định**

- Chấm một bản đề xuất theo ba tiêu chí tự đặt.
- Tìm lỗi trong một tài liệu mẫu hoặc trong bài làm cũ của mình.
- Viết lý do chọn một trong hai phương án.

**Tầng sáng tạo: khi cần tạo ra điều mới**

- Phác thảo một bước của dự án học quý 2.
- Thiết kế một biểu mẫu, một danh sách kiểm, một bộ câu hỏi.
- Soạn dàn ý một buổi chia sẻ 10 phút cho nhóm.

**Một gợi ý khi xếp lịch**

Không cần dùng đủ sáu tầng trong một tuần. Với kỹ năng mới bắt đầu, nhiều buổi ở nhớ và hiểu là hợp lý, chỉ cần mỗi tuần có ít nhất hai buổi ở tầng vận dụng trở lên. Với kỹ năng đã có nền, có thể dành hầu hết các buổi cho phân tích, đánh giá và sáng tạo. Hoạt động nào cũng nên kèm một sản phẩm nhỏ nhìn thấy được: một trang, một bảng, một câu trả lời.

**Ngày 5 (khoảng 25 phút)**

1. Học 15 phút cho kỹ năng đang học.
2. Trên sổ thực hành, xếp lịch tầng cho năm buổi học tuần sau, từ Thứ Hai đến Thứ Sáu, mỗi buổi một tầng.
3. Ghi hoạt động cụ thể cho buổi ở tầng cao nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-5.

Chia sẻ hôm nay: "Tuần sau tôi đưa 20 phút học lên các tầng: ...".


## Bài 6: Ngày 6 (Thứ Bảy 29/05)
@img 6_cau-hoi-khep
@img2 9_the-thanh-tich
@pdf 10XHub_PhanLoaiBloom_PhieuNgay6_cau-hoi-khep.pdf (phiếu thực hành và thẻ câu hỏi theo tầng in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: THƯ CUỐI TUẦN VÀ MỘT CÂU HỎI KHÉP BUỔI HỌC

Bài hôm nay là một lá thư ngắn Trường gửi các anh chị và các bạn, thay cho phần tổng kết.

Các anh chị và các bạn thân mến,

Tuần này, nhiều người lần đầu tự hỏi một câu tưởng đơn giản: sau 20 phút học, mình đang dừng ở đâu? Có người nhận ra mình nhớ rất tốt các quy định nhưng chưa từng thử áp chúng vào một hồ sơ thật. Có người viết được câu hỏi tầng đánh giá nhưng lúng túng khi phải giải thích một khái niệm cơ bản bằng lời của mình. Cả hai phát hiện đều quý như nhau, vì chúng cho biết buổi học tiếp theo nên bắt đầu từ đâu.

Trường muốn nhắc lại một điều đã nói hôm Thứ Năm: tầng nhớ không thấp kém. Nó là nền của mọi tầng khác. Điều tuần này thay đổi chỉ là tỷ lệ: một buổi học không nên chỉ dừng ở nền.

Mùa 3 đã đi được tám tuần. Từ tuần Siêu học đến hôm nay, mỗi người đã có một kỹ năng, một dự án học, một thói quen 20 phút ngay sau thói quen then chốt, và một bộ công cụ để nhớ lâu hơn. Tuần này thêm một điều nhỏ mà có tác dụng lâu dài: một câu hỏi để tự đặt ra cuối mỗi buổi học.

Vài ví dụ:

- "Điều vừa học dùng được vào việc nào trong tuần này?" (vận dụng)
- "Điều này khác với cách mình đang làm ở đâu?" (phân tích)
- "Nếu phải chọn, mình sẽ giữ cách cũ hay đổi sang cách mới, vì sao?" (đánh giá)
- "Mình có thể biến điều này thành một biểu mẫu hay một bước của dự án học không?" (sáng tạo)

Chọn một câu, viết nó lên góc trang đầu tiên của bìa hồ sơ học, và trả lời nó trong hai phút cuối mỗi buổi. Chỉ một câu thôi. Một câu hỏi được dùng mỗi ngày có ích hơn sáu câu hỏi hay nằm yên trong sổ.

Phiên bản 10X của chính mình không phải là người biết nhiều hơn, mà là người dùng được điều mình biết vào đúng việc, đúng lúc. Cảm ơn các anh chị và các bạn đã cùng đi qua tuần này với rất nhiều câu hỏi thật.

Trường

**Sáng nay (khoảng 20 phút)**

1. Chọn câu hỏi khép buổi học của mình, viết lên sổ thực hành. Câu này được lưu cho cả hành trình.
2. Chọn tầng mình muốn chạm tới thường xuyên trong tháng 6 với kỹ năng đang học.
3. In thẻ câu hỏi theo tầng ở phiếu Ngày 6, kẹp vào bìa hồ sơ học.

**Tuần sau: Zettelkasten, hộp thẻ ghi chú**

Mỗi buổi học có bản đồ để nhìn toàn cảnh và câu hỏi để lên tầng. Tuần sau thêm một nơi để những ý hay nhất không bị thất lạc: mỗi buổi học kết thúc bằng một thẻ ghi chú viết bằng lời của mình, nối với những thẻ đã có.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0054-ngay-6.

Chia sẻ hôm nay: "Câu hỏi tôi tự đặt cuối mỗi buổi học: “...”. Tầng tôi muốn chạm tới trong tháng 6: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hiện ra: nửa mặt trời đỏ đang lên với chữ 6/6, dòng "NGÀY HỌC LÊN TẦNG", tên mình và câu hỏi khép buổi học. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Hẹn gặp lại sáng Thứ Hai, ngày cuối cùng của tháng 5.
