import sys; sys.path.insert(0, '/tmp/f30/b')
import tpl
from tpl import page, cover, disclaimer, build
from vnkeep import keep
tpl.CSS = tpl.CSS.replace('url(lato', 'url(file:///tmp/f30/b/lato')
SP = '/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
N = '0046'
P = []
add = lambda inner, **k: P.append(page(len(P) + 1, N, inner, **k))

P.append(cover(N, ['SAI LẦM', 'CHI PHÍ CHÌM'],
  'Nhìn lại quý 1 bằng chặng đường phía trước. Khép Mùa 2.',
  'Phương pháp luận: nghiên cứu về chi phí chìm của Arkes và Blumer, nghiên cứu về leo thang cam kết của Staw, áp dụng cho lần nhìn lại năm mục tiêu sau một quý.',
  'Nguồn gốc: Arkes và Blumer (1985), Staw (1976), Dawkins và Carlisle (1976). 10X Excellence Hub biên soạn lại với ví dụ công việc. Người viết: Trường.'))

add('''<h1>HAI CÁCH NHÌN MỘT MỤC TIÊU SAU BA THÁNG</h1>
<div class="lead">Ngày 31.03.2027, quý 1 khép lại. Mỗi mục tiêu chọn từ tuần đầu năm đã nhận gần ba tháng thời gian và công sức.</div>
<p>Khi nhìn lại một mục tiêu, có hai hướng nhìn. Một hướng nhìn ra phía sau: mình đã bỏ vào đó bao nhiêu buổi, bao nhiêu công sức. Một hướng nhìn ra phía trước: từ hôm nay, mục tiêu này còn mang lại gì cho quý 2 và cho năm 2027.</p>
<table class="t"><tr><th style="width:24%"></th><th style="width:38%">Nhìn ra phía sau</th><th>Nhìn ra phía trước</th></tr>
<tr><td class="k">Câu hỏi</td><td>Mình đã đầu tư bao nhiêu?</td><td>Nếu hôm nay bắt đầu, mình có chọn lại không?</td></tr>
<tr><td class="k">Cảm giác thường gặp</td><td>"Bỏ thì phí"</td><td>"Thời gian quý 2 nên đi về đâu?"</td></tr>
<tr><td class="k">Kết quả thường gặp</td><td>Giữ mọi mục tiêu, kể cả mục tiêu đã lỗi thời</td><td>Giữ, sửa hoặc dừng từng mục tiêu có lý do</td></tr></table>
<div class="stats"><div><b>1985</b><span>Arkes và Blumer công bố nghiên cứu về chi phí chìm</span></div><div><b>1976</b><span>Staw công bố nghiên cứu về leo thang cam kết</span></div><div><b>13 tuần</b><span>chặng đường Mùa 2, khép ngày 03.04.2027</span></div></div>
<div class="box"><div class="h">Ý chính của tuần này</div><div class="c">
<p>Nhìn lại năm mục tiêu sau một quý bằng <b>chặng đường phía trước</b>, không bằng phần đã bỏ ra phía sau. Phần lớn mục tiêu sẽ được giữ, có mục tiêu cần sửa cho vừa, có mục tiêu nên mạnh dạn dừng. Điều chắc chắn được giữ là <b>thói quen then chốt</b>. Tuần này cũng khép quý 1 (Thứ Tư 31.03) và khép Mùa 2 (Thứ Bảy 03.04).</p></div></div>''')

add('''<h1>ARKES VÀ BLUMER, 1985</h1>
<div class="sub">"The Psychology of Sunk Cost", Organizational Behavior and Human Decision Processes.</div>
<p>Năm 1985, Hal Arkes và Catherine Blumer ở Đại học Ohio công bố một loạt thí nghiệm về điều hai nhà nghiên cứu gọi là hiệu ứng chi phí chìm: xu hướng tiếp tục một việc khi đã đầu tư vào đó tiền bạc, công sức hoặc thời gian.</p>
<h2>Câu hỏi hai chuyến trượt tuyết</h2>
<p>Người tham gia được yêu cầu hình dung đã trả 100 đô la cho chuyến trượt tuyết ở Michigan, rồi trả thêm 50 đô la cho chuyến ở Wisconsin mà họ tin là sẽ vui hơn. Sau đó họ phát hiện hai chuyến trùng ngày và không thể hoàn tiền. Hơn một nửa chọn chuyến Michigan, chuyến đắt hơn nhưng kém vui hơn. Về mặt lý trí, 150 đô la đã mất dù chọn chuyến nào; điều duy nhất còn chọn được là chuyến nào vui hơn.</p>
<h2>Thí nghiệm vé xem kịch cả mùa</h2>
<table class="t"><tr><th style="width:30%">Nhóm</th><th style="width:30%">Giá vé cả mùa</th><th>Kết quả</th></tr>
<tr><td class="k">Trả giá đầy đủ</td><td>15 đô la</td><td rowspan="3">Trong nửa đầu mùa diễn, nhóm trả giá đầy đủ đi xem nhiều buổi hơn hai nhóm được giảm giá. Ở nửa sau mùa diễn, khác biệt không còn rõ.</td></tr>
<tr><td class="k">Giảm 2 đô la</td><td>13 đô la</td></tr>
<tr><td class="k">Giảm 7 đô la</td><td>8 đô la</td></tr></table>
<p>Người mua vé tại quầy của nhà hát trường được chia ngẫu nhiên vào ba nhóm giá. Vở diễn như nhau, chỗ ngồi như nhau; khác biệt duy nhất là số tiền đã trả.</p>
<p class="note">Các con số giá vé lấy theo mô tả phổ biến của nghiên cứu. Bài đăng chỉ dùng ý chính: người đã trả nhiều hơn có xu hướng tiếp tục nhiều hơn.</p>''')

add('''<h1>VÌ SAO MÌNH NÍU GIỮ?</h1>
<div class="sub">Một xu hướng rất con người, và có tên riêng trong nhiều ngành.</div>
<p>Arkes và Blumer cho rằng một nguyên nhân quan trọng là mong muốn không lãng phí: bỏ dở một việc đã đầu tư cảm giác như thừa nhận phần đầu tư trước đó là phí. Tiết kiệm là một đức tính tốt trong nhiều hoàn cảnh, nhưng với phần đã chi và không lấy lại được, nó dễ dẫn mình đi sai hướng.</p>
<table class="t"><tr><th style="width:30%">Lý do thường gặp</th><th>Trong công việc nghe như thế nào</th></tr>
<tr><td class="k">Không muốn lãng phí</td><td>"Đã làm ba tháng rồi, bỏ thì phí."</td></tr>
<tr><td class="k">Muốn nhất quán</td><td>"Đầu năm mình đã chọn mục tiêu này, đổi bây giờ thì kỳ."</td></tr>
<tr><td class="k">Giữ hình ảnh</td><td>"Mình đã nói với cả nhóm là sẽ làm được."</td></tr>
<tr><td class="k">Hy vọng không có căn cứ</td><td>"Thêm một tháng nữa chắc sẽ khác."</td></tr></table>
<h2>Sai lầm Concorde</h2>
<p>Trong sinh học hành vi, xu hướng này còn được gọi là sai lầm Concorde, theo tên dự án máy bay chở khách siêu thanh mà Anh và Pháp tiếp tục đầu tư dù triển vọng thương mại đã kém. Tên gọi xuất hiện trong bài viết của Richard Dawkins và Tamsin Carlisle trên tạp chí Nature năm 1976.</p>
<div class="box"><div class="h">Điều cần nhớ</div><div class="c"><p>Chi phí chìm không có nghĩa là mọi việc đã đầu tư đều nên dừng. Nó chỉ có nghĩa là phần đã bỏ ra không nên là lý do chính để tiếp tục. Một mục tiêu đáng giữ vì những gì nó mang lại từ hôm nay trở đi.</p></div></div>''')

add('''<h1>STAW 1976: LEO THANG CAM KẾT</h1>
<div class="sub">"Knee-deep in the Big Muddy", Organizational Behavior and Human Performance.</div>
<p>Barry Staw đặt câu hỏi: khi một quyết định đầu tư bắt đầu cho kết quả xấu, người ra quyết định sẽ rút lại hay đầu tư thêm? Trong nghiên cứu, sinh viên trường kinh doanh đóng vai lãnh đạo một công ty, phân bổ ngân sách nghiên cứu và phát triển cho một trong hai bộ phận. Sau đó họ nhận thông tin về kết quả của bộ phận đã chọn và được giao phân bổ thêm một khoản ngân sách.</p>
<table class="t"><tr><th style="width:36%">Điều kiện</th><th>Kết quả chính</th></tr>
<tr><td class="k">Tự mình ra quyết định ban đầu, kết quả kém</td><td>Dồn thêm nhiều tiền nhất vào chính bộ phận đang kém</td></tr>
<tr><td class="k">Quyết định ban đầu do người khác đưa ra</td><td>Phân bổ thêm ít hơn cho bộ phận đó</td></tr></table>
<p>Staw gọi hiện tượng này là leo thang cam kết: càng chịu trách nhiệm cá nhân cho lựa chọn ban đầu, càng có xu hướng đầu tư thêm để chứng minh lựa chọn đó đúng.</p>
<h2>Liên hệ với năm mục tiêu</h2>
<p>Năm mục tiêu của Mùa 2 do chính mỗi người chọn, viết ra, và nhiều người đã chia sẻ trước cả nhóm. Đó là điều tốt cho cam kết, nhưng cũng là điều kiện để leo thang cam kết xuất hiện khi một mục tiêu không còn đúng. Nhận ra điều đó không phải để nghi ngờ mọi lựa chọn, mà để nhìn lại một cách công bằng.</p>
<p class="note">Các nghiên cứu sau này cho thấy leo thang cam kết chịu ảnh hưởng của nhiều yếu tố như thông tin phản hồi, áp lực xã hội và cách tổ chức đánh giá quyết định. Tài liệu này chỉ dùng ý chính.</p>''')

add('''<h1>NẾU HÔM NAY BẮT ĐẦU LẠI</h1>
<div class="sub">Đổi câu hỏi là cách gỡ chi phí chìm đơn giản nhất.</div>
<p>Thay vì hỏi "mình đã bỏ vào mục tiêu này bao nhiêu?", hỏi "nếu hôm nay mới bắt đầu, với những gì đang biết, mình có chọn mục tiêu này không?". Câu hỏi này đặt mọi mục tiêu về cùng một vạch xuất phát.</p>
<table class="t"><tr><th style="width:6%">#</th><th style="width:46%">Câu hỏi</th><th>Vì sao hỏi</th></tr>
<tr><td class="k">1</td><td>Hôm nay mới bắt đầu, có chọn mục tiêu này không?</td><td>Câu hỏi chính, nhìn ra phía trước</td></tr>
<tr><td class="k">2</td><td>Lý do chọn từ tháng 1 còn đúng không?</td><td>Vai trò, ưu tiên, dự án có thể đã đổi</td></tr>
<tr><td class="k">3</td><td>Bảng điểm nói gì?</td><td>Sao Bắc Cực của tuần #0045 cho biết hướng đi</td></tr>
<tr><td class="k">4</td><td>Kết quả còn trong tầm ảnh hưởng của mình không?</td><td>Có mục tiêu đã chuyển sang phụ thuộc người khác</td></tr>
<tr><td class="k">5</td><td>Cần sửa phạm vi, thời hạn hay cách làm?</td><td>Nhiều mục tiêu chỉ cần sửa, không cần dừng</td></tr>
<tr><td class="k">6</td><td>Dừng thì thời gian dôi ra dành cho mục tiêu nào?</td><td>Thấy giá trị của việc dồn sức</td></tr></table>
<div class="box"><div class="h">Mục tiêu do công ty giao</div><div class="c"><p>Chỉ tiêu của bộ phận không tự dừng được. Với những mục tiêu này, câu hỏi số 5 quan trọng nhất. Nếu cần điều chỉnh, trao đổi với cấp trên bằng số liệu từ bảng điểm và đề xuất cụ thể (phạm vi mới, thời hạn mới, nguồn lực cần thêm).</p></div></div>''')

add('''<h1>GIỮ, SỬA HAY DỪNG</h1>
<div class="sub">Ba kết luận, mỗi kết luận có lý do nhìn ra phía trước.</div>
<table class="t"><tr><th style="width:16%">Kết luận</th><th style="width:40%">Khi nào</th><th>Làm gì tiếp</th></tr>
<tr><td class="k">Giữ</td><td>Mục tiêu vẫn đúng, đang đi đúng hướng hoặc chỉ chậm vì lý do tạm thời</td><td>Giữ Sao Bắc Cực và chỉ số hành động, tiếp tục nhịp tuần</td></tr>
<tr><td class="k">Sửa</td><td>Vẫn đáng theo đuổi nhưng không còn vừa với thực tế</td><td>Chọn một trong bốn kiểu sửa bên dưới, ghi lý do</td></tr>
<tr><td class="k">Dừng</td><td>Không còn phù hợp với vai trò, ưu tiên hoặc điều kiện mới</td><td>Dừng hẳn hoặc chuyển vào danh sách tránh, chọn mục tiêu nhận phần thời gian dôi ra</td></tr></table>
<h2>Bốn kiểu sửa hay gặp</h2>
<table class="t"><tr><th style="width:24%">Kiểu sửa</th><th>Ví dụ</th></tr>
<tr><td class="k">Thu hẹp phạm vi</td><td>"12 khách hàng doanh nghiệp" thành "6 khách hàng doanh nghiệp ở khu vực phía Nam"</td></tr>
<tr><td class="k">Lùi thời hạn có lý do</td><td>"Xong trong quý 2" thành "xong trong quý 3, sau khi hệ thống mới vận hành"</td></tr>
<tr><td class="k">Đổi cách đo</td><td>Thêm Sao Bắc Cực cho mục tiêu chưa có con số</td></tr>
<tr><td class="k">Đổi cách làm</td><td>Đổi chỉ số hành động khi con số làm đều mà kết quả không đổi</td></tr></table>
<p>Dừng một mục tiêu không làm ba tháng qua trở nên vô ích. Những gì đã học, những mối quan hệ đã xây, những kỹ năng đã luyện vẫn ở lại và thường được dùng cho mục tiêu khác.</p>''')

add('''<h1>BA CÂU NÓI BÁO HIỆU VÀ CÁCH GIỮ UY TÍN</h1>
<div class="sub">Nhận ra chi phí chìm trong chính lời mình nói.</div>
<table class="t"><tr><th style="width:42%">Câu nói báo hiệu</th><th>Câu hỏi thay thế</th></tr>
<tr><td class="k">"Đã làm đến đây rồi, bỏ thì phí."</td><td>Từ hôm nay, mục tiêu này còn mang lại gì?</td></tr>
<tr><td class="k">"Thêm một tháng nữa chắc sẽ khác."</td><td>Điều gì cụ thể sẽ thay đổi trong tháng tới?</td></tr>
<tr><td class="k">"Mình đã nói với cả nhóm là sẽ làm được."</td><td>Cách điều chỉnh nào giữ uy tín tốt nhất?</td></tr></table>
<h2>Nói về việc dừng hoặc sửa với người khác</h2>
<p>Một kế hoạch được điều chỉnh rõ ràng, có lý do và có số liệu, thường giữ uy tín tốt hơn một mục tiêu được níu giữ mà không còn ai tin. Ba phần của một lời thông báo điều chỉnh:</p>
<ol class="n"><li><b>Điều đã thay đổi:</b> "Công ty quyết định thay 6 trong 14 máy vào tháng 7."</li>
<li><b>Quyết định:</b> "Mục tiêu chuẩn hoá tài liệu được sửa thành 8 máy được giữ lại, xong trong quý 2."</li>
<li><b>Phần đã làm được dùng thế nào:</b> "Hai tài liệu đã viết cho máy sắp thay sẽ làm mẫu khi tiếp nhận máy mới."</li></ol>
<div class="box"><div class="h">Tinh thần đồng hành</div><div class="c"><p>Nhìn lại không phải để chấm điểm mình hay người khác. Đó là cách để quý 2 bắt đầu với năm mục tiêu mà mình thật sự tin, và một thói quen then chốt tiếp tục đi cùng mỗi sáng.</p></div></div>''')

add('''<h1>KHÉP QUÝ 1: NĂM CÂU HỎI</h1>
<div class="sub">Thứ Tư 31.03.2027, ngày cuối cùng của quý 1.</div>
<table class="t"><tr><th style="width:6%">#</th><th style="width:44%">Câu hỏi</th><th>Gợi ý</th></tr>
<tr><td class="k">1</td><td>Kết quả nào trong quý 1 mình tự hào nhất?</td><td>Không cần lớn, cần gọi được tên</td></tr>
<tr><td class="k">2</td><td>Thói quen then chốt đã đi cùng mình bao nhiêu ngày?</td><td>Bảng hành trình đã đếm sẵn</td></tr>
<tr><td class="k">3</td><td>Công cụ nào của Mùa 2 dùng nhiều nhất?</td><td>Có công cụ thành nếp, có công cụ chỉ dùng một tuần</td></tr>
<tr><td class="k">4</td><td>Nếu bắt đầu lại quý 1, làm khác điều gì?</td><td>Câu hỏi về bài học, không phải về lỗi</td></tr>
<tr><td class="k">5</td><td>Muốn cảm ơn ai về quý 1?</td><td>Một tin nhắn ngắn ngay hôm nay</td></tr></table>
<h2>Quý 1 năm 2027 trong một trang</h2>
<p>Quý 1 có tuần đầu năm, tuần nước rút trước Tết, kỳ nghỉ Tết Đinh Mùi (giao thừa tối Thứ Sáu 05.02, mùng 1 Thứ Bảy 06.02), tuần khởi động lại sau Tết, và tháng 3 làm việc trọn vẹn. Thói quen then chốt đã đi qua tất cả những giai đoạn đó, có lúc đầy đủ, có lúc chỉ là phiên bản tối thiểu. Mỗi ngày đã làm đều được ghi lại trên bảng hành trình.</p>
<div class="box"><div class="h">Một lưu ý</div><div class="c"><p>Câu chia sẻ Ngày 3 tự hiện tổng số ngày giữ thói quen trên cả hành trình. Con số nào cũng là kết quả thật của chính mình, không so với người khác.</p></div></div>''')

rows = [('0034', 'Quy tắc 5/25'), ('0035', 'Bảng Kanban cá nhân'), ('0036', 'Gan góc'), ('0037', 'Đặt ranh giới'), ('0038', 'Tự trắc ẩn trong công việc'), ('0039', 'Đừng bao giờ ăn một mình'), ('0040', 'Đường cong quên'), ('0041', 'Sổ đầu dòng'), ('0042', 'Hộp thời gian'), ('0043', 'Nghịch lý lựa chọn'), ('0044', 'Luật Hick và quy tắc mặc định'), ('0045', 'Chỉ số Sao Bắc Cực'), ('0046', 'Chi phí chìm và nhìn lại quý 1')]
add('''<h1>MỤC TIÊU CÓ THỂ ĐỔI, THÓI QUEN THÌ GIỮ</h1>
<div class="sub">Lớp cuối của Mùa 2.</div>
<p>Mục tiêu trả lời câu hỏi "đi đâu", và câu trả lời có thể thay đổi khi công việc thay đổi. Thói quen trả lời câu hỏi "mình là người làm việc như thế nào", và câu trả lời đó được xây qua nhiều tháng. Khi sửa hoặc dừng một mục tiêu, giữ tín hiệu và khung giờ của thói quen, chỉ cập nhật phần nội dung cho vừa mục tiêu mới.</p>
<table class="t" style="font-size:8.6pt;line-height:12pt"><tr><th style="width:12%">Tuần</th><th style="width:40%">Công thức của Mùa 2</th><th style="width:12%">Tuần</th><th>Công thức của Mùa 2</th></tr>''' +
 ''.join(f'<tr><td class="k">{rows[i][0]}</td><td>{rows[i][1]}</td><td class="k">{rows[i+7][0] if i+7 < len(rows) else ""}</td><td>{rows[i+7][1] if i+7 < len(rows) else ""}</td></tr>' for i in range(7)) + '''</table>
<div class="box"><div class="h">Lưu cho cả hành trình</div><div class="c"><p>Sổ thực hành lưu thêm <b>mục tiêu đã dừng hoặc sửa</b> và <b>điều giữ sang quý 2</b>. Ngày 6 gom lại mọi điều đã lưu trong Mùa 2: thói quen, năm mục tiêu, danh sách tránh, quy tắc mặc định, Sao Bắc Cực, chỉ số hành động.</p></div></div>''')

add('''<h1>ÁP DỤNG THEO VỊ TRÍ CÔNG VIỆC</h1>
<div class="sub">Một mục tiêu cần xem lại, một quyết định, một điều giữ sang quý 2.</div>
<table class="t"><tr><th style="width:14%">Vị trí</th><th style="width:28%">Mục tiêu cần xem lại</th><th style="width:30%">Quyết định và lý do</th><th>Giữ sang quý 2</th></tr>
<tr><td class="k">Quản lý</td><td>Tổ chức đào tạo nội bộ hằng tháng</td><td>Sửa thành mỗi quý một buổi, vì nhóm đang tuyển thêm người</td><td>Kèm cặp một một mỗi tuần</td></tr>
<tr><td class="k">Kinh doanh</td><td>12 khách hàng doanh nghiệp mới</td><td>Sửa phạm vi thành 6 khách hàng ở khu vực phía Nam, theo phân vùng mới</td><td>20 phút gọi hẹn lịch mỗi sáng</td></tr>
<tr><td class="k">Kế toán</td><td>Tự động hoá báo cáo công nợ</td><td>Lùi sang quý 3, chờ hệ thống mới vận hành</td><td>Đối chiếu cuối ngày</td></tr>
<tr><td class="k">Nhân sự</td><td>Khảo sát gắn kết toàn công ty</td><td>Chuyển vào danh sách tránh, vì công ty đã giao cho đơn vị khác</td><td>Trao đổi với nhân viên mới</td></tr>
<tr><td class="k">Kỹ thuật</td><td>Tài liệu chuẩn cho 14 máy</td><td>Sửa thành 8 máy được giữ lại, vì 6 máy sẽ thay vào tháng 7</td><td>15 phút đầu ca kiểm tra máy</td></tr>
<tr><td class="k">Chăm sóc khách hàng</td><td>Xây kênh hỗ trợ mới</td><td>Giữ, nhưng đổi chỉ số hành động sang số câu trả lời mẫu</td><td>Viết một câu trả lời mẫu mỗi sáng</td></tr></table>
<p>Các ví dụ chỉ mang tính gợi ý. Quyết định với mục tiêu do công ty giao cần được trao đổi với cấp trên trước khi thay đổi.</p>''')

days = [
 ('Thứ Hai 29.03', 'Đặt lên bàn', 'Trạng thái năm mục tiêu, mục tiêu nhận nhiều thời gian nhất', '20 phút'),
 ('Thứ Ba 30.03', 'Bắt đầu lại', 'Sáu câu hỏi, kết luận giữ, sửa hay dừng cho từng mục tiêu', '20 phút'),
 ('Thứ Tư 31.03', 'Khép quý 1', 'Năm câu hỏi khép quý, bảng hành trình, một lời cảm ơn', '20 phút'),
 ('Thứ Năm 01.04', 'Dừng hoặc sửa', 'Ba câu nói báo hiệu, cách xử lý, lý do nhìn ra phía trước', '20 phút'),
 ('Thứ Sáu 02.04', 'Giữ thói quen', 'Năm mục tiêu cho quý 2, điều giữ sang quý 2', '20 phút'),
 ('Thứ Bảy 03.04', 'Khép Mùa 2', 'Bảng gom Mùa 2, điều tự hào, điều mang sang Mùa 3', '25 phút')]
r = ''.join(f'<tr><td class="k">{a}</td><td><b>{b}</b></td><td>{c}</td><td>{d}</td></tr>' for a, b, c, d in days)
add(f'''<h1>LỘ TRÌNH 6 NGÀY</h1>
<div class="lead">Từ Thứ Hai 29.03 đến Thứ Bảy 03.04.2027, tuần khép quý 1 và khép Mùa 2. Chủ Nhật nghỉ, hoặc làm bù một ngày còn thiếu.</div>
<table class="t"><tr><th style="width:19%">Ngày</th><th style="width:19%">Trọng tâm</th><th>Việc chính</th><th style="width:13%">Thời lượng</th></tr>{r}</table>
<div class="box"><div class="h">Cách làm bài mỗi ngày</div><div class="c"><ul class="b">
<li>Mở sổ thực hành tại <b>10xexcellence.co/so-thuc-hanh</b>, chọn tuần 29.03 và đúng ngày.</li>
<li>Điền vào các ô, sổ tự ghép câu chia sẻ ở cuối trang.</li>
<li>Dán câu chia sẻ vào bình luận bài hôm đó, rồi bấm Đánh dấu đã chia sẻ.</li>
<li>Tuần này bảng hành trình nằm ở Ngày 3, ngày khép quý.</li>
<li>Đủ 6 ngày, thẻ thành tích khung Q1 hiện ra trên sổ để tải về.</li></ul></div></div>
<p class="note">Thứ Năm 01.04 là ngày đầu tiên của quý 2. Từ Thứ Hai 05.04, Mùa 3 "Học nhanh, nhớ lâu" bắt đầu.</p>''')

def day(d, tag, tm, title, tagline, body):
    return f'''<div class="dh"><div><div class="d">{d}</div><div class="tag">{tag}</div></div><div class="tm">Thời lượng<b>{tm}</b></div></div>
<div class="dt">{title}</div><div class="di">{tagline}</div>{body}'''
def ci(t): return f'<div class="ci"><b>Câu chia sẻ mẫu:</b> {t}</div>'

add(day('THỨ 2', 'Đặt lên bàn · 29.03', '20 phút', 'Đặt năm mục tiêu lên bàn',
 'Hôm nay chỉ nhìn, chưa quyết định gì.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Mở sổ thực hành, xem lại thói quen đang giữ, năm mục tiêu và bảng điểm tuần trước.</li>
<li>Chọn trạng thái cho từng mục tiêu: đúng hướng, chậm, đứng yên.</li>
<li>Chọn mục tiêu đang nhận nhiều thời gian nhất mỗi tuần.</li></ol>
<table class="t"><tr><th style="width:22%">Trạng thái</th><th>Nghĩa là</th></tr>
<tr><td class="k">Đúng hướng</td><td>Đang tiến như dự kiến</td></tr>
<tr><td class="k">Chậm</td><td>Có tiến nhưng chậm hơn dự kiến</td></tr>
<tr><td class="k">Đứng yên</td><td>Gần như chưa thay đổi trong vài tuần</td></tr></table>
<p>Mục tiêu đứng yên không có nghĩa là mình làm chưa tốt. Có khi công việc đã đổi hướng.</p>''' +
 ci('"Sau gần một quý, 3 trong 5 mục tiêu của tôi đang đúng hướng. Mục tiêu tôi dành nhiều thời gian nhất: mục tiêu số 3."')))

add(day('THỨ 3', 'Bắt đầu lại · 30.03', '20 phút', 'Nếu hôm nay bắt đầu lại, có chọn lại không?',
 'Nhìn ra phía trước, không nhìn ra phía sau.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Đi qua sáu câu hỏi (trang 7) với từng mục tiêu, bắt đầu từ mục tiêu số 1.</li>
<li>Ghi kết luận giữ, sửa hay dừng cho mỗi mục tiêu.</li>
<li>Ghi tên mục tiêu cần xem lại kỹ hơn vào Thứ Năm.</li></ol>
<table class="t"><tr><th style="width:18%">Mục tiêu</th><th style="width:50%">Câu trả lời mẫu cho câu hỏi 1</th><th>Kết luận</th></tr>
<tr><td class="k">Số 1</td><td>Có, vẫn là ưu tiên của bộ phận</td><td>Giữ</td></tr>
<tr><td class="k">Số 3</td><td>Có, nhưng 6 máy sắp được thay</td><td>Sửa</td></tr>
<tr><td class="k">Số 5</td><td>Không, dự án đã chuyển cho nhóm khác</td><td>Dừng</td></tr></table>''' +
 ci('"Nếu bắt đầu lại hôm nay, tôi vẫn chọn 4 mục tiêu. Mục tiêu cần xem lại: chuẩn hoá tài liệu cho toàn bộ 14 máy."')))

add(day('THỨ 4', 'Khép quý 1 · 31.03', '20 phút', 'Hôm nay khép lại quý 1 năm 2027',
 'Không có câu trả lời đúng hay sai, chỉ có câu trả lời của mình.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Trả lời năm câu hỏi khép quý (trang 10) trên sổ thực hành.</li>
<li>Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen, xem tổng số ngày của cả hành trình.</li>
<li>Nếu được, gửi một lời cảm ơn ngắn cho người mình nghĩ tới ở câu hỏi 5.</li></ol>
<div class="box"><div class="h">Câu trả lời mẫu</div><div class="c"><ul class="b">
<li><b>Tự hào nhất:</b> hợp đồng đầu tiên với một khách hàng doanh nghiệp mới.</li>
<li><b>Công cụ dùng nhiều nhất:</b> hộp thời gian.</li>
<li><b>Làm khác nếu bắt đầu lại:</b> dựng bảng điểm ngay từ tháng 1.</li>
<li><b>Cảm ơn:</b> chị Mai, đã nhận giúp việc trong tuần nghỉ Tết.</li></ul></div></div>''' +
 ci('"Quý 1 khép lại. Kết quả tôi tự hào nhất: hợp đồng đầu tiên với một khách hàng doanh nghiệp mới. Thói quen đã giữ 118 ngày trên cả hành trình."')))

add(day('THỨ 5', 'Dừng hoặc sửa · 01.04', '20 phút', 'Mạnh dạn dừng hoặc sửa một mục tiêu',
 'Ngày đầu tiên của quý 2.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Chọn một mục tiêu cần dừng hoặc sửa. Nếu tất cả đều là "giữ", chọn mục tiêu cần sửa nhỏ nhất.</li>
<li>Đánh dấu những câu nói báo hiệu mình từng nghĩ tới.</li>
<li>Chọn cách xử lý: dừng hẳn, vào danh sách tránh, sửa phạm vi, sửa thời hạn, sửa cách đo hoặc cách làm.</li>
<li>Viết một câu lý do dựa vào chặng đường phía trước.</li></ol>
<table class="t"><tr><th style="width:40%">Trước khi sửa</th><th>Sau khi sửa</th></tr>
<tr><td>Chuẩn hoá tài liệu cho toàn bộ 14 máy</td><td>Tài liệu chuẩn cho 8 máy được giữ lại, xong trong quý 2</td></tr></table>
<p>Lý do: 6 máy sẽ được thay vào tháng 7. Hai tài liệu đã viết cho máy sắp thay được giữ làm mẫu.</p>''' +
 ci('"Mục tiêu tôi mạnh dạn dừng hoặc sửa: tài liệu chuẩn cho 8 máy được giữ lại, xong trong quý 2. Lý do: 6 máy sẽ được thay vào tháng 7."')))

add(day('THỨ 6', 'Giữ thói quen · 02.04', '20 phút', 'Mục tiêu có thể đổi, thói quen thì giữ',
 'Sửa nội dung, giữ tín hiệu và khung giờ.',
 '''<h2>Việc cần làm</h2><ol class="n">
<li>Viết lại năm mục tiêu cho quý 2 trên sổ thực hành: giữ nguyên, sửa, hoặc thay mục tiêu đã dừng.</li>
<li>Viết điều giữ sang quý 2: thói quen then chốt và một công cụ của Mùa 2 dùng hiệu quả nhất.</li>
<li>Nếu thói quen cần cập nhật, sửa phần nội dung, giữ tín hiệu và khung giờ.</li></ol>
<table class="t"><tr><th style="width:30%"></th><th style="width:35%">Quý 1</th><th>Quý 2</th></tr>
<tr><td class="k">Tín hiệu</td><td>Đầu mỗi ca</td><td>Đầu mỗi ca</td></tr>
<tr><td class="k">Thời lượng</td><td>15 phút</td><td>15 phút</td></tr>
<tr><td class="k">Nội dung</td><td>Kiểm tra một máy trong danh sách 14 máy</td><td>Kiểm tra một máy trong danh sách 8 máy, thêm hai điểm cho máy hay dừng</td></tr></table>''' +
 ci('"Sang quý 2, tôi giữ: 15 phút đầu ca kiểm tra máy, cùng bảng điểm mỗi chiều Thứ Sáu."')))

add(day('THỨ 7', 'Khép Mùa 2 · 03.04', '25 phút', 'Khép Mùa 2, một chặng đường đáng tự hào',
 'Mười ba tuần, năm mục tiêu, một thói quen đi qua tất cả.',
 '''<h2>Sáng nay (15 phút)</h2><ol class="n">
<li>Đọc lại bảng gom Mùa 2 trên sổ thực hành.</li>
<li>Viết điều tự hào nhất về Mùa 2 và một điều mang sang mùa tiếp theo.</li></ol>
<h2>Trước khi nghỉ Chủ Nhật (10 phút)</h2>
<ol class="n"><li>In trang tổng kết Mùa 2 (trang 19 hoặc phiếu Ngày 6), điền và kẹp vào sổ kế hoạch, cạnh thẻ 5 mục tiêu từ tuần đầu năm.</li></ol>
<div class="box"><div class="h">Từ Thứ Hai 05.04</div><div class="c"><p>Mùa 3 "Học nhanh, nhớ lâu" chuyển sang một năng lực đi cùng mọi mục tiêu: học điều mới nhanh hơn và nhớ được lâu hơn. Thói quen then chốt tiếp tục là trục của hành trình.</p></div></div>''' +
 ci('"Mùa 2 của tôi: giữ thói quen qua cả tuần Tết bằng phiên bản tối thiểu. Mang sang Mùa 3: 15 phút chiều Thứ Sáu với bảng điểm."')))

def rows5(labels, h=19):
    return ''.join(f'<tr><td class="k" style="width:26%">{l}</td><td style="height:{h}pt"></td></tr>' for l in labels)
gsd = ''.join(f'<tr><td class="k">Số {i}</td><td style="height:19pt"></td><td style="text-align:center">Giữ · Sửa · Dừng</td><td></td></tr>' for i in range(1, 6))
add(f'''<h1>CÔNG CỤ IN ĐƯỢC: TỔNG KẾT MÙA 2</h1>
<div class="sub">Điền, kẹp vào sổ kế hoạch, cạnh thẻ 5 mục tiêu từ tuần đầu năm.</div>
<div style="border:1.2pt solid #7b1f23;padding:10pt 12pt;background:#fff">
<div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-weight:900;font-size:15pt;color:#7b1f23">MÙA 2 · 04.01 ĐẾN 03.04.2027</div><div style="font-size:8pt;color:#666">10X Excellence Hub · Công thức #0046</div></div>
<table class="t" style="margin:6pt 0;font-size:9pt">{rows5(['Thói quen then chốt', 'Tổng số ngày đã giữ', 'Tự hào nhất', 'Công cụ dùng nhiều nhất', 'Mang sang Mùa 3'])}</table>
<table class="t" style="font-size:9pt;margin-bottom:0"><tr><th style="width:12%">Mục tiêu</th><th>Nội dung cho quý 2</th><th style="width:26%;text-align:center">Kết luận (khoanh)</th><th style="width:22%">Sao Bắc Cực</th></tr>{gsd}</table></div>
<div style="margin-top:12pt;border:1pt dashed #7b1f23;padding:9pt 12pt">
<div style="font-weight:900;font-size:11pt;color:#7b1f23">LỜI CẢM ƠN KHÉP QUÝ</div>
<table class="t" style="font-size:9pt;margin:5pt 0 0">{rows5(['Gửi', 'Vì đã', 'Đã gửi ngày'], 20)}</table></div>''')

add('''<h1>TỪ MÙA 2 SANG MÙA 3</h1>
<div class="sub">Mùa 2 đặt đúng mục tiêu và giữ hướng. Mùa 3 học nhanh hơn, nhớ lâu hơn.</div>
<table class="t"><tr><th style="width:22%"></th><th style="width:39%">Mùa 2</th><th>Mùa 3</th></tr>
<tr><td class="k">Thời gian</td><td>04.01 đến 03.04.2027</td><td>Từ Thứ Hai 05.04.2027</td></tr>
<tr><td class="k">Tên mùa</td><td>Mục tiêu và ưu tiên năm mới</td><td>Học nhanh, nhớ lâu</td></tr>
<tr><td class="k">Câu hỏi</td><td>Thói quen then chốt phục vụ mục tiêu nào, và làm sao giữ hướng?</td><td>Làm sao học điều mới nhanh hơn và nhớ được lâu hơn?</td></tr>
<tr><td class="k">Điều đi tiếp</td><td colspan="2">Thói quen then chốt, bảng hành trình, năm mục tiêu cho quý 2, quy tắc mặc định, bảng điểm</td></tr></table>
<h2>Một năng lực đi cùng mọi mục tiêu</h2>
<p>Dù mục tiêu là khách hàng mới, quy trình gọn hơn hay một nhóm làm việc tốt hơn, phần lớn đều cần học điều mới: kiến thức về sản phẩm, kỹ năng chuyên môn, cách làm việc của một khách hàng. Mùa 3 tập trung vào năng lực đó. Tuần Đường cong quên và lặp lại cách quãng của Mùa 2 là một bước làm quen.</p>
<div class="q"><div class="t">"Mục tiêu có thể đổi khi công việc đổi. Thói quen then chốt thì giữ, và mang theo sang mùa mới."</div>
<div class="s">Tinh thần của Công thức #0046</div></div>''')

src = ('Các trích dẫn, số liệu và ví dụ được tổng hợp từ các nguồn công khai bao gồm: '
 'Arkes, H. R. và Blumer, C. (1985), "The Psychology of Sunk Cost", <i>Organizational Behavior and Human Decision Processes</i>, 35(1), 124 đến 140; '
 'Staw, B. M. (1976), "Knee-deep in the Big Muddy: A Study of Escalating Commitment to a Chosen Course of Action", <i>Organizational Behavior and Human Performance</i>, 16(1), 27 đến 44; '
 'Dawkins, R. và Carlisle, T. R. (1976), "Parental Investment, Mate Desertion and a Fallacy", <i>Nature</i>, 262, 131 đến 133. '
 'Mô tả các thí nghiệm được tóm tắt theo các nguồn giới thiệu nghiên cứu, không phải bản dịch nguyên văn. Các câu trong ngoặc kép là câu mẫu hoặc diễn giải. Các ví dụ công việc và tình huống do 10X Excellence Hub biên soạn.')
P.append(disclaimer(len(P) + 1, N, 'Công thức #' + N + ': Sai lầm Chi phí chìm và Nhìn lại Quý 1', src))

sys.path.insert(0, SP + '/w0046n'); from nbnum import nb
P = [nb(keep(x)) for x in P]
out = f'{SP}/w0046n/formula/10XHub_CongThuc_0046_Sai Lam Chi Phi Chim_VN.pdf'
over = build(P, f'{SP}/w0046n/formula/0046.html', out)
print('pages', len(P), 'overflow', over)
