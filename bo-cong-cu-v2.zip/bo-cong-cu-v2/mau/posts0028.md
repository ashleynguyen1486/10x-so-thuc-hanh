## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 23/11)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0028_Phuong phap Feynman_VN.pdf (tài liệu đầy đủ của Công thức #0028)
@pdf 10XHub_Feynman_PhieuNgay1_chon-dieu.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0028.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi thư điện tử cho cả nhóm

**Tiêu đề bài trên Skool:** HIỂU THẬT LÀ GIẢNG LẠI ĐƯỢC BẰNG LỜI ĐƠN GIẢN

Tuần Luyện tập có chủ đích vừa qua để lại cho mỗi người ba điều trên sổ thực hành: một kỹ năng con, một bậc thang bốn tuần, và tên một người sẵn lòng góp ý. Nhiều anh chị và các bạn còn gửi đi những lời cảm ơn nhân Ngày Nhà giáo. Bậc thang đó vẫn chạy tiếp trong tuần này, cùng với thói quen then chốt.

**Nếu mới tham gia:** tuần này hợp với người mới. Chỉ cần chọn một điều mình biết rõ trong công việc, một quy trình, một khái niệm hay một mẹo nghề, rồi cùng cả nhóm tập giải thích nó cho người mới vào nghề. Ở Ngày 1, viết thêm câu bản sắc và một thói quen nhỏ làm mỗi ngày để bắt đầu hành trình.

**Một bài giảng không thể viết**

Richard Feynman (1918 đến 1988) là nhà vật lý đoạt giải Nobel năm 1965, nổi tiếng với khả năng giải thích những điều rất phức tạp bằng lời rất đơn giản. Đồng nghiệp của ông ở Caltech, giáo sư David Goodstein, kể lại một câu chuyện trên tạp chí Physics Today năm 1989.

Goodstein nhờ Feynman giải thích một hiện tượng trong vật lý lượng tử. Feynman nhận lời, nói sẽ chuẩn bị một bài giảng cho sinh viên năm nhất về đề tài đó. Vài ngày sau ông quay lại và thừa nhận: ông không làm được. Theo lời Goodstein, Feynman kết luận rằng không đưa được về mức sinh viên năm nhất nghĩa là chính giới vật lý cũng chưa thật sự hiểu điều đó.

Một nhà khoa học hàng đầu dùng khả năng giải thích đơn giản làm thước đo cho việc hiểu. Đó là tinh thần của tuần này.

**Một phép thử nhỏ trước khi bắt đầu**

Thử chấm điểm từ 1 đến 7: mình hiểu cách một chiếc khoá kéo hoạt động đến mức nào? Rồi thử viết ra từng bước nó hoạt động. Năm 2002, Leonid Rozenblit và Frank Keil (Đại học Yale) làm đúng phép thử này với nhiều đồ vật quen thuộc. Sau khi phải viết lời giải thích, người tham gia tự chấm lại điểm hiểu biết của mình thấp hơn rõ rệt. Các tác giả gọi đó là ảo tưởng về độ sâu của lời giải thích.

Trong công việc cũng vậy. Quy trình duyệt chi, cách tính giá vốn, cách xử lý một khiếu nại: làm hằng ngày thì thấy quen, nhưng giải thích cho người mới mới lộ ra chỗ mình chưa nắm chắc.

**Về cái tên "kỹ thuật Feynman"**

Feynman không đặt ra cái tên này và cũng không viết một phương pháp bốn bước nào. Cách làm bốn bước mà nhiều người biết là do những người viết về cách học hệ thống hoá về sau, dựa trên tinh thần của ông, phổ biến rộng trên mạng từ khoảng năm 2011. Tuần này dùng bốn bước đó như một công cụ thực hành.

**Lớp mới cho hành trình thói quen**

Thói quen then chốt giữ nguyên. Tuần này thêm một bản sắc: người chia sẻ kiến thức. Sáu ngày đi theo nhịp sau: Thứ Hai chọn một điều đã học. Thứ Ba giải thích bằng lời đơn giản cho người mới vào nghề. Thứ Tư tìm chỗ còn vấp và quay lại tài liệu. Thứ Năm rút gọn và thêm ví dụ. Thứ Sáu giảng lại cho một đồng nghiệp trong 10 phút. Thứ Bảy chia sẻ bản giải thích trong cộng đồng để giúp người mới. Chủ Nhật nghỉ.

**Ngày 1 (15 phút): Chọn một điều để giảng lại**

1. Mở sổ thực hành, xem lại thói quen và kỹ năng con đang luyện. Người mới điền câu bản sắc và thói quen.
2. Chọn một điều đã học: từ một công thức trong hành trình, từ kỹ năng con, hoặc từ chính chuyên môn của mình.
3. Viết cụ thể điều sẽ giảng lại, đủ hẹp để giải thích trong 10 phút.
4. Tự chấm mức hiểu hiện tại từ 1 đến 7, để cuối tuần chấm lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-1.

Chia sẻ hôm nay: "Thói quen tôi đang giữ: .... Điều tôi sẽ giảng lại tuần này: ...". Người mới thêm chữ THAM GIA để cả nhóm cùng chào đón nha.


## Bài 2: Ngày 2 (Thứ Ba 24/11)
@img 2_giai-thich
@pdf 10XHub_Feynman_PhieuNgay2_giai-thich.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: GIẢI THÍCH CHO NGƯỜI MỚI VÀO NGHỀ

Hôm nay đặt hai bản giải thích cùng một khái niệm cạnh nhau. Khái niệm được chọn là "giá vốn hàng bán", vì phòng nào cũng nghe đến nhưng không phải ai cũng giải thích được.

**Bản thứ nhất, viết cho người trong nghề**

"Giá vốn hàng bán là tổng chi phí trực tiếp cấu thành nên sản phẩm đã tiêu thụ trong kỳ, bao gồm nguyên vật liệu trực tiếp, nhân công trực tiếp và chi phí sản xuất chung được phân bổ, được ghi nhận đồng thời với doanh thu theo nguyên tắc phù hợp."

Câu này đúng. Nhưng một nhân viên kinh doanh mới vào nghề đọc xong vẫn chưa biết nó liên quan gì đến việc mình chào giá cho khách.

**Bản thứ hai, viết cho người mới vào nghề**

"Giá vốn là số tiền công ty đã bỏ ra để có được món hàng mình vừa bán. Ví dụ một chiếc bàn bán 3 triệu đồng, tiền gỗ, tiền công thợ và một phần tiền điện, tiền xưởng cộng lại là 2 triệu, thì giá vốn là 2 triệu. Phần còn lại 1 triệu mới là khoản để trả lương văn phòng, quảng cáo và tạo ra lợi nhuận. Vì vậy khi giảm giá cho khách, phần bị giảm trước tiên chính là khoản 1 triệu đó."

Bản thứ hai dài hơn, nhưng người nghe hiểu ngay và dùng được ngay.

**Bốn điều làm nên khác biệt**

- **Từ ngữ thường ngày:** "số tiền đã bỏ ra" thay cho "chi phí trực tiếp cấu thành".
- **Một ví dụ cụ thể có con số:** chiếc bàn 3 triệu, giá vốn 2 triệu.
- **Nối với việc của người nghe:** giảm giá cho khách thì phần nào bị ảnh hưởng.
- **Không thuật ngữ nào chưa được giải thích:** nếu buộc phải dùng một từ chuyên môn, giải thích nó ngay trong câu.

Mẹo nhỏ: hình dung một người cụ thể đang ngồi đối diện, ví dụ bạn thực tập sinh mới vào tuần trước. Viết như đang nói với người đó. Bản giải thích có thể chưa hay, hôm nay chỉ cần viết ra trọn vẹn. Ngày mai sẽ tìm chỗ hổng.

**Ngày 2 (20 phút)**

1. Chọn người nghe hình dung: thực tập sinh, nhân viên mới, đồng nghiệp phòng khác hay khách hàng.
2. Viết bản giải thích điều đã chọn hôm qua, như đang nói với người đó.
3. Kiểm tra bốn điều: từ thường ngày, ví dụ có con số, nối với việc của người nghe, không thuật ngữ chưa giải thích.
4. Tóm lại toàn bộ trong một câu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-2.

Chia sẻ hôm nay: "Bản giải thích một câu cho người mới vào nghề: .... Người nghe tôi hình dung: ...".


## Bài 3: Ngày 3 (Thứ Tư 25/11)
@img 3_cho-hong
@pdf 10XHub_Feynman_PhieuNgay3_cho-hong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: CHỖ VẤP LÀ CHỖ CẦN HỌC LẠI

Khi chuẩn bị cho kỳ thi vấn đáp thời nghiên cứu sinh, Feynman mở một cuốn sổ mới và đề ở trang đầu một dòng, được nhà báo James Gleick kể lại trong cuốn tiểu sử Genius (1992): "Sổ ghi những điều tôi chưa biết". Ông không ôn lại những gì đã vững, mà lần lượt đi qua từng mảng kiến thức để tìm chỗ còn mơ hồ.

Bài hôm nay là một trang sổ mẫu như vậy, từ bản giải thích "quy trình duyệt chi" của một trưởng nhóm hành chính giả định. Đọc để thấy chỗ vấp trông như thế nào trên giấy.

**Trang sổ mẫu: Quy trình duyệt chi**

Dòng 1: "Nhân viên lập đề nghị thanh toán, gửi trưởng phòng ký." Rõ, không vấp.

Dòng 2: "Khoản trên 20 triệu thì cần thêm chữ ký giám đốc." Vấp: không chắc mức 20 triệu là trước thuế hay sau thuế. Gạch dưới, ghi "kiểm tra lại quy chế tài chính".

Dòng 3: "Kế toán kiểm tra hoá đơn rồi chuyển khoản." Vấp: không giải thích được kế toán kiểm tra những gì. Mình chỉ biết "kế toán hay trả lại hồ sơ". Gạch dưới, ghi "hỏi chị kế toán năm tiêu chí kiểm tra".

Dòng 4: "Thường mất ba ngày." Vấp: "thường" là bao nhiêu phần trăm số hồ sơ? Có trường hợp nào mất một tuần không? Gạch xoá, viết lại "phần lớn mất ba ngày, hồ sơ thiếu hoá đơn có thể lâu hơn".

Dòng 5: "Vì sao cần ba cấp duyệt?" Không trả lời được. Đây là chỗ hổng lớn nhất.

**Ba dấu hiệu của một chỗ vấp**

- **Dùng từ mơ hồ:** "thường", "khoảng", "kiểu như", "nói chung là".
- **Lặp lại thuật ngữ thay cho giải thích:** "kế toán kiểm tra tính hợp lệ" mà không nói hợp lệ là gì.
- **Không trả lời được câu hỏi "vì sao":** biết làm thế nào nhưng không biết vì sao làm như vậy.

**Quay lại tài liệu đúng chỗ**

Không cần đọc lại toàn bộ. Với mỗi chỗ vấp, tìm đúng một nguồn: quy chế, tài liệu đào tạo, một đồng nghiệp hiểu rõ. Đọc hoặc hỏi xong, viết lại riêng câu đó bằng lời của mình.

**Ngày 3 (25 phút)**

1. Đọc to bản giải thích hôm qua, gạch dưới mọi chỗ mình ngập ngừng.
2. Ghi ba chỗ vấp rõ nhất, chọn chỗ quan trọng nhất.
3. Tìm một nguồn cho chỗ đó và viết lại câu giải thích bằng lời của mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-3.

Chia sẻ hôm nay: "Chỗ tôi vấp khi giải thích: .... Tài liệu tôi quay lại: ...". Tìm ra chỗ vấp là tiến bộ thật sự của hôm nay, cứ chia sẻ thoải mái nha.


## Bài 4: Ngày 4 (Thứ Năm 26/11)
@img 4_rut-gon
@pdf 10XHub_Feynman_PhieuNgay4_rut-gon.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: TỪ PHỨC TẠP ĐẾN ĐƠN GIẢN, CÓ VÍ DỤ

Bản giải thích đã đầy đủ hơn sau ngày hôm qua. Hôm nay làm ngược lại: rút gọn. Bài viết đi qua ba vòng rút gọn của cùng một bản giải thích, để thấy mỗi vòng bỏ đi điều gì và giữ lại điều gì.

Điều được giải thích: "khách hàng than phiền thì xử lý thế nào", viết cho một nhân viên chăm sóc khách hàng mới.

**Vòng 1: khoảng 100 chữ**

"Khi khách than phiền, việc đầu tiên là lắng nghe hết, không ngắt lời, kể cả khi mình biết khách hiểu nhầm. Sau đó nhắc lại vấn đề bằng một câu ngắn để khách thấy mình đã hiểu đúng. Tiếp theo là xin lỗi về trải nghiệm của khách, chưa cần bàn ai đúng ai sai. Rồi mới đưa ra hướng xử lý, nói rõ ai làm, làm gì và khi nào xong. Cuối cùng hẹn thời điểm gọi lại để báo kết quả, và gọi đúng hẹn. Nhiều khách hài lòng không phải vì vấn đề được giải quyết nhanh, mà vì được lắng nghe và được báo tin đúng hẹn."

**Vòng 2: khoảng 50 chữ**

"Nghe hết, không ngắt lời. Nhắc lại vấn đề trong một câu. Xin lỗi về trải nghiệm của khách. Nói rõ ai làm, làm gì, khi nào xong. Hẹn giờ gọi lại và gọi đúng hẹn. Khách cần được lắng nghe và được báo tin, không chỉ cần được giải quyết nhanh."

**Vòng 3: một câu**

"Nghe hết, nhắc lại, xin lỗi, hẹn rõ, gọi lại đúng hẹn."

**Điều gì được giữ lại qua các vòng?**

- Thứ tự các bước, vì đó là xương sống của cách làm.
- Động từ cụ thể: nghe, nhắc lại, xin lỗi, hẹn, gọi lại.
- Một lý do ngắn ở vòng 2, để người mới hiểu vì sao phải làm đủ năm bước.

**Thêm một ví dụ và một hình ảnh so sánh**

Bản rút gọn dễ nhớ, nhưng người mới cần một ví dụ để áp dụng. Ví dụ tốt nhất lấy từ chính công việc: "Tuần trước có khách gọi vì giao hàng trễ hai ngày. Bạn Lan nghe hết, nhắc lại 'anh nhận hàng trễ hai ngày so với hẹn', xin lỗi, hẹn 15 giờ chiều báo lịch giao bù, và gọi lại lúc 14 giờ 50."

Một hình ảnh so sánh cũng giúp người nghe nhớ lâu, ví dụ: "Xử lý khiếu nại giống thợ sửa xe giỏi: nghe khách tả hết, nói lại cho chắc, rồi mới sửa." Hình ảnh nào cũng được, miễn quen thuộc với người nghe.

**Ngày 4 (20 phút)**

1. Rút bản giải thích của mình còn khoảng 50 chữ, rồi còn một câu.
2. Thêm một ví dụ lấy từ công việc thật, có tình huống và kết quả.
3. Thêm một hình ảnh so sánh quen thuộc với người nghe, nếu tìm được.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-4.

Chia sẻ hôm nay: "Bản rút gọn của tôi: .... Ví dụ trong công việc: ...".


## Bài 5: Ngày 5 (Thứ Sáu 27/11)
@img 5_day-lai
@pdf 10XHub_Feynman_PhieuNgay5_day-lai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: MƯỜI PHÚT GIẢNG LẠI CHO ĐỒNG NGHIỆP

Hôm nay là ngày giảng thật. Một đồng nghiệp, mười phút, một điều đã chuẩn bị bốn ngày. Nghiên cứu cho thấy cả hai giai đoạn đều có ích. Nhóm của John Nestojko (Memory & Cognition, 2014) thấy rằng người học với ý định sẽ giảng lại cho người khác nhớ đầy đủ hơn, có tổ chức hơn và trả lời tốt hơn các câu hỏi về ý chính. Logan Fiorella và Richard Mayer (Contemporary Educational Psychology, 2013) thấy rằng người thực sự giảng lại làm bài kiểm tra muộn tốt hơn người chỉ chuẩn bị để giảng.

Dưới đây là danh sách kiểm tra cho ba thời điểm: trước, trong và sau mười phút.

**Trước khi giảng (5 phút)**

- Chọn một đồng nghiệp có lợi khi biết điều này: người mới vào, người phòng khác, người sắp nhận việc liên quan.
- Hẹn giờ cụ thể, nói rõ chỉ cần 10 phút, ví dụ ngay sau cuộc họp giao ban.
- Mang theo bản rút gọn và ví dụ của Ngày 4, không cần trình chiếu.
- Nói trước với người nghe: "Mình đang tập giải thích, chỗ nào chưa rõ cứ hỏi nha."

**Trong khi giảng (10 phút)**

- Mở đầu bằng câu rút gọn một câu.
- Kể ví dụ trước, giải thích nguyên tắc sau.
- Dừng lại sau mỗi ý, hỏi: "Đến đây có chỗ nào chưa rõ không?"
- Ghi nhanh mọi câu hỏi người nghe đặt ra. Câu hỏi là phản hồi quý nhất.
- Gần cuối, nhờ người nghe giải thích lại bằng lời của họ trong một đến hai câu.

**Sau khi giảng (5 phút)**

- Ghi câu hỏi khó nhất nhận được.
- Ghi người nghe giải thích lại được đến đâu: trọn vẹn, một phần hay chưa.
- Đánh dấu chỗ cần sửa trong bản giải thích trước khi chia sẻ ở Ngày 6.
- Cảm ơn người nghe đã dành thời gian.

**Nếu không có đồng nghiệp nào rảnh**

Giảng cho một người thân không làm cùng nghề, hoặc ghi âm mình giảng trong 10 phút rồi nghe lại. Cách nào cũng tốt hơn chỉ đọc thầm bản giải thích. Tuy vậy, một người nghe thật biết đặt câu hỏi vẫn là lựa chọn tốt nhất, nên hẹn lại vào tuần sau nếu hôm nay chưa được.

**Ngày 5 (20 phút, gồm 10 phút giảng)**

1. Hẹn một đồng nghiệp và giảng lại trong 10 phút, bấm giờ trên sổ.
2. Ghi câu hỏi khó nhất và mức người nghe giải thích lại được.
3. Đánh dấu thói quen trên bảng hành trình nếu hôm nay đã làm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-5.

Chia sẻ hôm nay: "Hôm nay tôi giảng lại cho ... trong ... phút. Câu hỏi khó nhất tôi nhận được: ...". Chúc các anh chị và các bạn một buổi chiều Thứ Sáu nhẹ nhàng sau mười phút làm người dẫn dắt nha.


## Bài 6: Ngày 6 (Thứ Bảy 28/11)
@img 6_chia-se
@img2 9_the-thanh-tich
@pdf 10XHub_Feynman_PhieuNgay6_chia-se.pdf (phiếu thực hành và trang bản giải thích để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MỘT BẢN GIẢI THÍCH, NHIỀU NGƯỜI HỌC

Hôm nay là một lời mời. Bản giải thích đã đi qua bốn bước: viết cho người mới, tìm chỗ vấp, rút gọn kèm ví dụ, giảng thử cho đồng nghiệp. Giờ là lúc chia sẻ nó trong cộng đồng, để những thành viên mới vào sau có một tài liệu ngắn, dễ hiểu từ chính người đi trước.

**Một bài chia sẻ tốt có năm phần**

1. **Tên điều được giải thích:** một dòng.
2. **Một câu rút gọn:** câu đã viết ở Ngày 4.
3. **Giải thích ngắn:** khoảng 50 chữ, từ ngữ thường ngày.
4. **Một ví dụ từ công việc thật:** có tình huống và kết quả, không nêu tên khách hàng hay thông tin nội bộ.
5. **Một câu hỏi người nghe từng hỏi:** kèm câu trả lời.

Khi viết thành bài chia sẻ, câu chữ nên chỉnh lại cho chuẩn mực: thay từ ngữ nói bằng từ ngữ viết như "điều", "việc", "yếu tố", giữ giọng thân thiện nhưng chuyên nghiệp.

**Mẫu bài chia sẻ**

"Điều tôi giảng lại: quy trình xử lý khiếu nại.
Một câu: Nghe hết, nhắc lại, xin lỗi, hẹn rõ, gọi lại đúng hẹn.
Giải thích ngắn: Khách cần được lắng nghe và được báo tin, không chỉ cần được giải quyết nhanh. Năm bước này giữ đúng thứ tự đó.
Ví dụ: Khách nhận hàng trễ hai ngày. Nhân viên nghe hết, nhắc lại vấn đề, xin lỗi, hẹn 15 giờ báo lịch giao bù và gọi lại đúng giờ. Khách đồng ý chờ thêm một ngày.
Câu hỏi từng nhận: Nếu chưa biết khi nào xử lý xong thì hẹn thế nào? Hẹn giờ báo tiến độ, không cần hẹn giờ xong."

**Nhịp chia sẻ kiến thức**

Bản sắc "người chia sẻ kiến thức" không cần một bài giảng lớn. Một nhịp nhỏ và đều là đủ: mỗi tháng giảng lại một điều vừa học cho nhóm 10 phút, hay mỗi khi có người mới vào phòng thì giải thích cho họ một quy trình. Nhịp này được lưu trên sổ thực hành cho cả hành trình.

**Ngày 6 (25 phút)**

1. Viết bài chia sẻ theo năm phần, chỉnh câu chữ cho chuẩn mực.
2. Đăng vào bình luận dưới bài này.
3. Chọn nhịp chia sẻ kiến thức sẽ giữ từ nay.
4. Chấm lại mức hiểu của mình từ 1 đến 7, so với Thứ Hai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0028-ngay-6.

Chia sẻ hôm nay: "Nhịp chia sẻ kiến thức tôi giữ: .... Bản giải thích của tôi cho người mới: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Kỹ thuật Feynman hiện ra, với một dấu ngoặc kép lớn và câu rút gọn của chính mình in trên thẻ. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

**Tuần sau**

Tháng 12 đến với tất niên, báo cáo cuối năm và lịch rất dày. Đây cũng là lúc nhiều thói quen tốt bị gián đoạn. Tuần sau, Công thức #0029 về Tiên liệu thất bại giúp cả nhóm hình dung trước những điều có thể làm thói quen dừng lại, và chuẩn bị sẵn cách bảo vệ nó qua mùa cuối năm và Tết.

Chủ Nhật nghỉ trọn vẹn nha. Thói quen then chốt cũng được nghỉ, chuỗi ngày không bị tính là lỡ.
