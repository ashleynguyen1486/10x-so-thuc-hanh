## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 21/06)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0058_Xay Dung Cong Khai_VN.pdf (tài liệu đầy đủ của Công thức #0058)
@pdf 10XHub_XayCongKhai_PhieuNgay1_noi-chia-se.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0058.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** VIẾT RA ĐIỀU MÌNH HỌC ĐỂ HỌC SÂU HƠN

Hôm nay, Thứ Hai 21.06, là Ngày Báo chí Cách mạng Việt Nam. Trường xin gửi lời trân trọng tới những người làm nghề báo, và tới các anh chị và các bạn đang làm công việc truyền thông trong doanh nghiệp. Nghề viết có một chuẩn mực mà ai làm việc với thông tin cũng nên học: kiểm tra trước khi chia sẻ, viết rõ cho người đọc, và tôn trọng điều không được phép công bố. Tuần này, cả nhóm mượn chuẩn mực đó cho một việc rất gần với mỗi người: viết ra và chia sẻ điều mình đã học.

Tuần trước, cả nhóm đã đặt cảm giác cạnh bằng chứng: tự chấm kỹ năng đang học, đối chiếu thang năm mức, làm một bài kiểm tra nhỏ có bước dự đoán, xin một phản hồi cụ thể và đặt một vòng tự đánh giá đều đặn. Nhiều người đã thấy rõ mình đang ở đâu, và phần nào cần 20 phút học ưu tiên. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Công thức #0058 của tuần này là Xây dựng công khai: chia sẻ điều mình học.

**Nếu mới tham gia:** hãy nghĩ về một điều mình vừa học được trong công việc gần đây, dù rất nhỏ, ví dụ một cách lọc dữ liệu nhanh hơn hay một câu hỏi giúp khách hàng nói rõ nhu cầu. Viết điều đó, cùng một thói quen nhỏ mỗi ngày, vào Ngày 1 trên sổ thực hành. Đến Thứ Năm, mình sẽ chia sẻ điều đó với vài đồng nghiệp. Không cần đọc lại các tuần trước.

**"Xây dựng công khai" nghĩa là gì?**

Năm 2014, Austin Kleon xuất bản cuốn "Show Your Work!", tạm hiểu là "cho người khác thấy cách mình làm". Ý chính của cuốn sách: không cần là thiên tài mới có điều đáng chia sẻ; hãy chia sẻ quá trình, không chỉ sản phẩm cuối cùng; chia sẻ những phần nhỏ một cách đều đặn; và dạy lại điều mình biết. Kleon cũng nhắc người đọc đừng biến việc chia sẻ thành quảng cáo bản thân.

Trong công việc, "xây dựng công khai" không có nghĩa là đăng mọi điều lên mạng. Nó có nghĩa là thỉnh thoảng nói ra điều mình đang học, với những người có thể dùng được hoặc góp ý được: nhóm của mình, buổi họp tuần, cộng đồng 10X. Không khoe kết quả, chỉ kể điều mình hiểu ra.

**Năm câu hỏi của người viết, cho một bài chia sẻ ngắn**

Người làm báo thường kiểm tra một bản tin bằng những câu hỏi cơ bản. Tuần này mượn tinh thần đó cho một bài chia sẻ chỉ dài vài câu:

1. **Mình đã học được điều gì?** Một ý, không phải cả khoá học.
2. **Mình học được trong tình huống nào?** Buổi học 20 phút, một dự án, một sai sót đã sửa.
3. **Vì sao điều đó có ích cho người khác?** Ai trong nhóm có thể dùng được.
4. **Áp dụng như thế nào?** Một ví dụ hoặc một bước cụ thể.
5. **Điều gì mình còn chưa chắc?** Một câu hỏi để mời người khác góp ý.

**Vì sao chia sẻ lại giúp chính mình học sâu hơn?**

Năm 2014, nhóm nghiên cứu của John Nestojko tại Đại học California, Los Angeles cho thấy người học nhớ ý chính tốt hơn và sắp xếp kiến thức mạch lạc hơn khi họ chuẩn bị để dạy lại cho người khác, so với khi chuẩn bị để làm bài kiểm tra. Ý tưởng này rất gần với kỹ thuật giảng lại kiểu Feynman cả nhóm đã luyện ở #0028. Thứ Năm này sẽ nói kỹ hơn về nghiên cứu đó.

**Lớp mới cho hành trình**

Mỗi tuần, chia sẻ một điều đã học từ dự án học, rồi ghi lại nhịp chia sẻ. Từ chỗ học một mình trong 20 phút, kỹ năng đang học bắt đầu có mặt trong công việc của cả nhóm. Đó là một bước rất cụ thể của phiên bản 10X: không chỉ giỏi hơn cho riêng mình, mà còn giúp những người xung quanh làm tốt hơn.

**Sáu ngày của tuần**

- Thứ Hai: chọn nơi chia sẻ và điều đầu tiên.
- Thứ Ba: chia sẻ được gì, giữ riêng gì.
- Thứ Tư: viết bài chia sẻ ngắn.
- Thứ Năm: chuẩn bị như thể sắp giảng lại, rồi chia sẻ.
- Thứ Sáu: đón nhận phản hồi, đặt nhịp chia sẻ.
- Thứ Bảy: nhìn lại Mùa 3.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Chọn nơi chia sẻ và điều đầu tiên**

1. Ngay sau thói quen then chốt, mở sổ thực hành, xem lại kỹ năng và dự án học.
2. Chọn nơi chia sẻ phù hợp nhất: nhóm của mình, buổi họp tuần, một đồng nghiệp đang học cùng kỹ năng, hoặc cộng đồng 10X.
3. Viết ra ba điều mình đã học từ dự án học, chọn một điều để chia sẻ đầu tiên.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-1.

Chia sẻ hôm nay: "Tôi sẽ chia sẻ điều mình học với .... Điều đầu tiên: ...".

Điều nhỏ cũng đáng chia sẻ, các anh chị và các bạn đừng đợi tới khi thật giỏi mới bắt đầu nha.


## Bài 2: Ngày 2 (Thứ Ba 22/06)
@img 2_chia-se-gi
@pdf 10XHub_XayCongKhai_PhieuNgay2_chia-se-gi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CHIA SẺ ĐƯỢC GÌ, GIỮ RIÊNG GÌ?

Trước khi viết, cần một ranh giới rõ ràng. Một bài chia sẻ tốt giúp người khác học được điều gì đó, và không làm lộ thông tin của công ty hay của khách hàng. Hôm nay là một bảng chọn ba vùng để tự kiểm tra từng nội dung.

**Vùng 1: Chia sẻ được**

- Cách làm, phương pháp, kỹ thuật mình vừa học: "bảng tổng hợp trong Excel có thể nhóm theo tháng chỉ với hai bước".
- Bài học từ một sai sót của chính mình, kể ở mức chung: "tôi từng gửi báo giá thiếu thuế, giờ tôi kiểm tra theo ba bước".
- Tài liệu công khai: sách, bài báo, khoá học mở.
- Câu hỏi mình đang tìm câu trả lời.

**Vùng 2: Chia sẻ được sau khi làm mờ**

- Ví dụ từ công việc thật, nhưng bỏ tên khách hàng, tên dự án, con số cụ thể. Thay "khách hàng A ở Bình Dương giảm 18% đơn hàng" bằng "một khách hàng sản xuất giảm đơn hàng đáng kể".
- Mẫu biểu do mình tự làm, sau khi xoá dữ liệu thật.
- Ảnh chụp màn hình, chỉ khi đã che toàn bộ thông tin nội bộ.

**Vùng 3: Giữ riêng**

- Thông tin khách hàng, hợp đồng, giá bán, số liệu tài chính chưa công bố.
- Tài liệu nội bộ có quy định bảo mật, quy trình công ty chưa cho phép chia sẻ ra ngoài.
- Nhận xét về đồng nghiệp hay cấp trên.
- Bất cứ điều gì mình phân vân. Khi chưa chắc, hỏi quản lý trực tiếp trước.

**Một phép thử nhanh**

Trước khi đăng, tự hỏi: "Nếu khách hàng hoặc quản lý của mình đọc bài này, họ có thấy thoải mái không?" Nếu câu trả lời là chưa chắc, chuyển nội dung đó xuống một vùng.

Phép thử này cũng áp dụng cho chính cộng đồng 10X: những gì các anh chị và các bạn chia sẻ ở đây cũng nên là cách làm và bài học, không phải thông tin của nơi mình làm việc.

**Ngày 2 (20 phút)**

1. Lấy ba điều đã viết hôm qua, xếp từng điều vào một trong ba vùng.
2. Với điều thuộc vùng 2, viết lại phần ví dụ sau khi đã làm mờ.
3. Ghi lại một điều mình sẽ giữ riêng và lý do.
4. Đánh dấu bảng hành trình những ngày tuần này đã giữ thói quen và 20 phút học.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-2.

Chia sẻ hôm nay: "Điều tôi chia sẻ được: .... Điều tôi giữ riêng: ...".

Ở câu chia sẻ hôm nay, phần "giữ riêng" chỉ cần ghi loại thông tin, ví dụ "số liệu của khách hàng", không ghi nội dung cụ thể nha.


## Bài 3: Ngày 3 (Thứ Tư 23/06)
@img 3_giai-phau-bai
@pdf 10XHub_XayCongKhai_PhieuNgay3_giai-phau-bai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: GIẢI PHẪU MỘT BÀI CHIA SẺ NGẮN

Hôm nay không có lý thuyết mới. Trường đặt ra đây một bài chia sẻ mẫu, rồi tách từng phần để thấy mỗi phần làm nhiệm vụ gì. Bài mẫu là minh hoạ, của một người làm kế toán đang học phân tích số liệu bằng Excel.

**Bài mẫu**

"Tuần này tôi học được cách dùng bảng tổng hợp để xem chi phí theo từng bộ phận và từng tháng trong cùng một bảng. Trước đây tôi phải lọc dữ liệu rồi cộng tay, mất gần một giờ mỗi lần làm báo cáo tháng. Giờ chỉ cần kéo hai cột vào đúng chỗ. Nếu ai trong nhóm cũng làm báo cáo theo bộ phận, tôi có thể chỉ trong 10 phút. Điều tôi chưa chắc: khi dữ liệu gốc thêm dòng mới, có cách nào để bảng tự cập nhật không? Ai biết thì chỉ giúp tôi với."

**Phần 1: Câu mở, nói thẳng điều đã học**

"Tuần này tôi học được cách dùng bảng tổng hợp..." Người đọc biết ngay bài nói về điều gì. Không cần mở bằng câu chào dài hay lý do vì sao mình học.

**Phần 2: Tình huống trước đó**

"Trước đây tôi phải lọc dữ liệu rồi cộng tay..." Một câu về cách làm cũ giúp người đọc thấy giá trị của điều mới, mà không cần khen ngợi gì.

**Phần 3: Cách làm cụ thể**

"Giờ chỉ cần kéo hai cột vào đúng chỗ." Ngắn, đủ để người khác hình dung và tự thử.

**Phần 4: Lời mời dùng chung**

"Nếu ai trong nhóm cũng làm báo cáo theo bộ phận, tôi có thể chỉ trong 10 phút." Đây là phần biến bài chia sẻ thành sự giúp đỡ, không phải lời khoe.

**Phần 5: Điều còn chưa chắc**

"Khi dữ liệu gốc thêm dòng mới, có cách nào..." Một câu hỏi thật mở cửa cho phản hồi. Nó cũng cho thấy mình đang học, chưa phải chuyên gia, nên người khác thoải mái góp ý.

**Vì sao bài mẫu chỉ có năm câu?**

Một bài chia sẻ ngắn được đọc hết. Một bài dài thường bị lướt qua. Nếu có nhiều điều muốn nói, chia thành nhiều tuần: đó cũng chính là nhịp chia sẻ đều đặn mà tuần này hướng tới.

Lưu ý: bài mẫu không có tên bộ phận thật, không có con số chi phí thật. Đó là vùng 1 và vùng 2 của hôm qua.

**Ngày 3 (20 phút)**

1. Lấy điều đã chọn ở vùng 1 hoặc vùng 2.
2. Viết bài chia sẻ theo năm phần, mỗi phần một câu.
3. Đọc lại một lượt bằng phép thử hôm qua.
4. Đặt một tiêu đề ngắn cho bài.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-3.

Chia sẻ hôm nay: "Bài chia sẻ đầu tiên của tôi đã có bản nháp: ...".

Hôm nay chỉ cần bản nháp, chưa cần đăng. Ngày mai mình sẽ chuẩn bị thêm một bước nhỏ trước khi chia sẻ thật nha.


## Bài 4: Ngày 4 (Thứ Năm 24/06)
@img 4_giang-lai
@pdf 10XHub_XayCongKhai_PhieuNgay4_giang-lai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CHUẨN BỊ NHƯ THỂ SẮP GIẢNG LẠI

Hôm nay là ngày chia sẻ thật. Trước đó, Trường kể lại hai nghiên cứu giải thích vì sao bước chuẩn bị hôm nay đáng làm cẩn thận.

**Nghiên cứu năm 2014: chỉ cần nghĩ rằng mình sẽ dạy lại**

John Nestojko, Dung Bui, Nate Kornell và Elizabeth Bjork công bố hai thí nghiệm trên tạp chí Memory & Cognition. Sinh viên Đại học California, Los Angeles đọc một bài viết dài khoảng 1.500 chữ trong khoảng mười phút. Một nhóm được dặn chuẩn bị để làm bài kiểm tra. Nhóm kia được dặn chuẩn bị để dạy lại bài này cho một bạn khác.

Điều thú vị: không ai thật sự phải dạy cả. Đến lúc kiểm tra, cả hai nhóm làm cùng một bài.

Kết quả của thí nghiệm thứ nhất: nhóm chuẩn bị để dạy lại nhớ được nhiều ý hơn, trình bày lại theo trình tự mạch lạc hơn, và trả lời đúng nhiều câu hỏi về ý chính hơn. Ở thí nghiệm thứ hai, lợi thế chủ yếu nằm ở các ý chính, còn với chi tiết nhỏ thì hai nhóm gần như ngang nhau.

Cách giải thích của nhóm tác giả: khi biết mình sẽ phải giải thích cho người khác, người học tự tìm ý chính và sắp xếp kiến thức thành một mạch, thay vì cố nhớ từng chi tiết rời rạc.

**Nghiên cứu năm 2013: giảng lại thật còn đi xa hơn**

Logan Fiorella và Richard Mayer so sánh nhóm chỉ chuẩn bị để dạy với nhóm chuẩn bị rồi giảng lại thật bằng một đoạn ghi hình ngắn. Chuẩn bị để dạy giúp kết quả kiểm tra ngay sau đó tốt hơn, nhưng sau một tuần thì lợi thế đó mờ đi. Nhóm giảng lại thật có kết quả tốt nhất ở bài kiểm tra một tuần sau.

Hai nghiên cứu này thực hiện với sinh viên và bài đọc ngắn, nên không thể hứa một con số cho mọi người. Nhưng chúng gợi ý một trình tự rất hợp lý cho hôm nay: chuẩn bị như thể sắp giảng lại, rồi chia sẻ thật.

**Liên hệ với kỹ thuật Feynman**

Ở #0028, cả nhóm đã luyện giảng lại một khái niệm bằng lời đơn giản như nói với người mới vào nghề. Hôm nay là bước tiếp theo: lời giảng đó được nói ra với người thật, trong công việc thật.

**Ngày 4 (20 phút)**

1. Đọc lại bản nháp hôm qua, hình dung mình sắp giải thích nó cho một đồng nghiệp mới.
2. Viết ra ba ý chính mà người nghe cần nhớ, theo đúng trình tự.
3. Sửa bản nháp nếu cần, rồi chia sẻ ở nơi đã chọn từ Thứ Hai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-4.

Chia sẻ hôm nay: "Tôi đã chia sẻ bài ... với .... Ba ý chính khi chuẩn bị để giảng lại: ...".

Ai chia sẻ trong buổi họp hay nói trực tiếp với đồng nghiệp cũng được tính, không nhất thiết phải là một bài viết nha.


## Bài 5: Ngày 5 (Thứ Sáu 25/06)
@img 5_don-phan-hoi
@pdf 10XHub_XayCongKhai_PhieuNgay5_don-phan-hoi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: PHẢN HỒI LÀM BÀI HỌC SÂU HƠN

Sau khi chia sẻ, điều gì xảy ra? Hôm nay là nhật ký minh hoạ một tuần của chị Thảo, chuyên viên nhân sự, người vừa chia sẻ lần đầu trong nhóm. Tên nhân vật và tình huống là giả định.

**Nhật ký của chị Thảo**

**Thứ Năm, 16 giờ.** Mình gửi vào nhóm chat của phòng năm câu về cách đặt câu hỏi đào sâu khi phỏng vấn theo năng lực, kỹ năng mình học suốt Mùa 3. Câu cuối mình hỏi: "Khi ứng viên trả lời chung chung lần thứ hai, mọi người thường hỏi tiếp thế nào?" Gửi xong hơi hồi hộp.

**Thứ Năm, 17 giờ.** Chưa ai trả lời. Mình tự nhắc: mọi người đang bận cuối ngày, không sao cả.

**Thứ Sáu, 8 giờ 30.** Anh Quân, trưởng nhóm tuyển dụng, trả lời: "Anh hay đề nghị ứng viên kể lại đúng một lần cụ thể, có thời gian và kết quả." Một bạn mới vào nói đã thử câu hỏi của mình trong buổi phỏng vấn sáng nay.

**Thứ Sáu, 9 giờ.** Mình cảm ơn từng người, rồi ghi câu gợi ý của anh Quân vào một thẻ ghi chú, nối với thẻ cũ về câu hỏi đào sâu. Điều anh Quân nói chính là phần mình còn yếu khi tự đánh giá tuần trước.

**Thứ Sáu, 16 giờ 45.** Trong khung dọn bốn ngăn, mình đặt luôn nhịp chia sẻ: chiều Thứ Năm mỗi tuần, một điều học được, gửi vào nhóm chat của phòng.

**Bốn điều nhật ký cho thấy**

- **Im lặng ban đầu là bình thường.** Phản hồi thường đến chậm hơn mình mong.
- **Câu hỏi cuối bài mở cửa cho phản hồi.** Anh Quân trả lời đúng vào câu hỏi đó.
- **Cảm ơn trước, giải thích sau.** Không cần tranh luận với góp ý, chỉ cần ghi nhận và chọn điều dùng được.
- **Phản hồi quay lại thành việc học.** Gợi ý của người khác đi vào hộp thẻ, vào 20 phút học tuần sau.

**Nếu không có phản hồi nào?**

Vẫn có giá trị. Nghiên cứu hôm qua cho thấy phần lớn lợi ích đến từ việc chuẩn bị để giải thích, ngay cả khi không ai hỏi lại. Và một bài chia sẻ hôm nay có thể được ai đó dùng vào một ngày khác mà mình không biết.

**Ngày 5 (20 phút)**

1. Xem lại phản hồi đã nhận được (nếu có), cảm ơn người đã góp ý.
2. Ghi lại một điều mình học thêm nhờ phản hồi, đưa vào hộp thẻ hoặc thư mục dự án học.
3. Đặt nhịp chia sẻ: thời điểm cố định mỗi tuần, nơi chia sẻ, mỗi lần một điều.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-5. Nhịp chia sẻ được lưu cho cả hành trình.

Chia sẻ hôm nay: "Nhịp chia sẻ của tôi: .... Điều tôi học thêm nhờ phản hồi: ...".

Nếu chưa nhận được phản hồi, ở phần sau của câu chia sẻ các anh chị và các bạn ghi điều mình hiểu rõ hơn khi chuẩn bị để giảng lại nha.


## Bài 6: Ngày 6 (Thứ Bảy 26/06)
@img 6_nhin-lai-mua-3
@img2 9_the-thanh-tich
@pdf 10XHub_XayCongKhai_PhieuNgay6_nhin-lai-mua-3.pdf (phiếu thực hành và trang Mùa 3 in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: NHÌN LẠI MƯỜI HAI TUẦN MÙA 3

Từ Thứ Hai 05.04 đến hôm nay, Mùa 3 "Học nhanh, nhớ lâu" đã đi qua mười hai tuần. Trước khi làm bài, Trường mời các anh chị và các bạn nhìn lại chặng đường đó theo bốn chặng, vì mỗi chặng đều có một phần công sức của chính mình.

**Chặng 1: Chọn hướng đi**

Mùa 3 mở đầu bằng Học chuyên sâu tự định hướng (#0047). Mỗi người thêm 20 phút học có chủ đích ngay sau thói quen then chốt, chọn một kỹ năng phục vụ mục tiêu đang giữ, và một dự án học cho quý 2. Tuần Xếp chồng kỹ năng (#0050), giữa kỳ nghỉ lễ 30.4 và 1.5, giúp nhìn kỹ năng đó trong toàn bộ bộ kỹ năng của mình, để thấy nó cộng thêm vào đâu.

**Chặng 2: Học sao cho nhớ**

Bốn tuần với những cách học có bằng chứng nghiên cứu. Truy hồi chủ động (#0048) thay đọc lại bằng tự kiểm tra. Cung điện trí nhớ (#0051) gắn ý chính vào những điểm dừng quen thuộc. Học xen kẽ và khó khăn có ích (#0052) cho thấy cảm giác khó hơn có khi là dấu hiệu học sâu. Bản đồ tư duy (#0053) gom một buổi học vào một trang.

**Chặng 3: Giữ và sắp xếp kiến thức**

Ghi chép Cornell (#0049) cho mỗi buổi học một trang có câu hỏi gợi nhớ. Hộp thẻ Zettelkasten (#0055) giữ ý tưởng bằng lời của chính mình và nối chúng với nhau. Phương pháp PARA (#0056) cho tài liệu học một chỗ đứng rõ ràng.

**Chặng 4: Hiểu sâu, tự đánh giá, chia sẻ**

Phân loại Bloom (#0054) đẩy câu hỏi học lên những tầng cao hơn. Hiệu ứng Dunning-Kruger và tự đánh giá (#0057) đặt cảm giác cạnh bằng chứng. Và tuần này, Xây dựng công khai (#0058) đưa điều mình học ra khỏi 20 phút một mình, tới những người cùng làm việc.

**Điều đáng tự hào nhất**

Mười hai tuần, có hai kỳ nghỉ lễ, có những tuần công việc dồn dập cuối quý. Thói quen then chốt vẫn được giữ, và giờ nó mang theo một kỹ năng đang lớn lên từng tuần: có sản phẩm trong thư mục dự án học, có thẻ ghi chú, có một mức thạo được chứng minh bằng bằng chứng, và hôm nay, có những người đồng nghiệp đã học được điều gì đó từ mình. Đó là phiên bản 10X của chính mình, được xây bằng những việc rất cụ thể.

**Sáng nay (15 phút)**

1. Đọc lại bảng gom Mùa 3 trên sổ thực hành.
2. Viết điều mình tự hào nhất về Mùa 3, và một điều muốn mang vào tuần khép mùa.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In trang Mùa 3 ở phiếu Ngày 6, điền và kẹp vào thư mục dự án học, cạnh bảng đối chiếu của tuần trước.

**Tuần sau: tuần khép Mùa 3**

Thứ Hai 28.06 là Ngày Gia đình Việt Nam, và Thứ Tư 30.06 quý 2 khép lại. Tuần sau, cả nhóm cùng khép Mùa 3: dự án học của quý 2 đi tới đích, và mỗi người nhìn lại kỹ năng của mình đã thay đổi ra sao sau một quý. Trường sẽ giới thiệu công thức của tuần vào sáng Thứ Hai.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0058-ngay-6.

Chia sẻ hôm nay: "Mùa 3 của tôi: .... Điều tôi mang vào tuần khép mùa: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: một dải đỏ với tổng số ngày giữ thói quen trên cả hành trình, chuỗi sáu mắt xích theo những ngày tuần này, tên mình và nhịp chia sẻ mình vừa đặt. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Cảm ơn các anh chị và các bạn đã học cùng nhau suốt mười hai tuần qua. Chủ Nhật nghỉ ngơi trọn vẹn nha, hẹn gặp lại sáng Thứ Hai ở tuần khép mùa.
