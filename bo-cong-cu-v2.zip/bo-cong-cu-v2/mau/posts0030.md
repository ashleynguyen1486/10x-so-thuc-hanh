## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 07/12)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0030_Hieu Ung Viec Do Dang_VN.pdf (tài liệu đầy đủ của Công thức #0030)
@pdf 10XHub_ViecDoDang_PhieuNgay1_gom-viec.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0030.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** VIỆC NÀO CÒN CHẠY TRONG ĐẦU LÚC 22 GIỜ?

Tối qua, lúc đã rời văn phòng khá lâu, việc nào trong công việc vẫn còn quay lại trong đầu các anh chị và các bạn? Một email chưa trả lời? Một báo giá còn thiếu số liệu? Một cuộc trao đổi với nhân viên cứ hẹn mãi chưa làm?

Câu hỏi đó là điểm bắt đầu của tuần này. Không cần trả lời ngay, chỉ cần để ý: những việc quay lại trong đầu gần như luôn là những việc chưa xong.

Tuần trước, cả nhóm đã dựng một lá chắn cuối năm cho thói quen then chốt: ba rủi ro chính, biện pháp cho từng rủi ro, người nhắc và tín hiệu cảnh báo sớm. Lá chắn đó tiếp tục làm việc của nó. Tuần này đi vào một lớp khác: những việc còn treo đang lấy đi bao nhiêu chú ý của mình mỗi ngày.

**Nếu mới tham gia:** tuần này rất dễ bắt đầu. Hôm nay chỉ cần hai việc: viết một thói quen nhỏ mình muốn giữ mỗi ngày làm việc vào sổ thực hành, rồi gom ra giấy mọi việc đang dở dang. Không cần biết gì về các tuần trước. Đến Thứ Năm, thói quen của mình sẽ có thêm một nghi thức kết thúc ngày.

**Còn ba tuần nữa là hết năm 2026**

Tính từ hôm nay, năm 2026 còn ba tuần làm việc trọn vẹn, cộng thêm vài ngày cuối tháng 12. Đây là thời điểm hợp lý để đặt một câu hỏi thực tế: những việc nào mình muốn khép lại trước khi năm cũ kết thúc, để năm mới không bắt đầu bằng một danh sách treo từ năm trước?

**Việc dở dang và sự chú ý**

Câu chuyện thường được kể lại như sau: nhà tâm lý học Kurt Lewin để ý thấy những người phục vụ trong một quán cà phê ở Berlin nhớ rất rõ các món chưa thanh toán, nhưng quên gần như ngay khi khách đã trả tiền. Học trò của ông, Bluma Zeigarnik, kiểm tra điều này trong phòng thí nghiệm và công bố năm 1927. Người tham gia làm khoảng hai mươi bài tập nhỏ, một nửa bị ngắt giữa chừng. Trong nghiên cứu của bà, các bài bị ngắt được nhớ lại nhiều hơn, gần gấp đôi các bài đã làm xong. Hiện tượng này được gọi là hiệu ứng Zeigarnik.

Cần nói thêm cho đầy đủ: các nghiên cứu lặp lại sau này cho kết quả không đồng nhất. Một tổng hợp năm 2025 của Ghibellini và Meier cho thấy lợi thế về trí nhớ không ổn định. Điều ổn định hơn là xu hướng quay lại làm tiếp việc bị bỏ dở, được Maria Ovsiankina, một học trò khác của Lewin, mô tả năm 1928. Nói cách khác, việc dở dang có xu hướng kéo mình quay lại với nó.

Phát hiện hữu ích nhất cho công việc đến từ E. J. Masicampo và Roy Baumeister năm 2011. Trong các thí nghiệm của họ, mục tiêu chưa hoàn thành làm người tham gia hay bị suy nghĩ chen ngang khi làm việc khác. Nhưng khi họ viết ra một kế hoạch cụ thể cho mục tiêu đó, các suy nghĩ chen ngang giảm rõ rệt, dù việc vẫn chưa làm xong.

Đây là tin tốt. Không cần làm xong mọi việc mới có một buổi tối yên tĩnh. Chỉ cần mỗi việc dở có một chỗ đứng rõ ràng: làm ngay, lên lịch, giao cho người khác, hoặc chủ động bỏ.

**Sáu ngày của tuần**

- Thứ Hai: gom mọi việc dở dang ra giấy.
- Thứ Ba: phân loại thành làm ngay, lên lịch, giao, bỏ.
- Thứ Tư: khép ba việc treo lâu nhất.
- Thứ Năm: thiết kế nghi thức kết thúc ngày, gắn với thói quen then chốt.
- Thứ Sáu: dừng giữa chừng có chủ đích để sáng mai dễ bắt đầu.
- Thứ Bảy: danh sách việc khép năm 2026.

**Ngày 1 (25 phút): Gom tất cả ra giấy**

1. Mở sổ thực hành, kiểm tra dòng "Thói quen đang giữ". Người mới điền câu bản sắc và thói quen ở hai ô bên dưới.
2. Đặt hẹn giờ 15 phút. Viết ra mọi việc trong công việc đang dở dang, lớn hay nhỏ: thư chưa trả lời, tài liệu chưa đọc, lời hứa với đồng nghiệp, hồ sơ chưa nộp, cuộc gọi chưa gọi.
3. Đừng phân loại, đừng đánh giá. Chỉ cần ra khỏi đầu và nằm trên giấy.
4. Đếm tổng số việc, và khoanh tròn việc quay lại trong đầu nhiều nhất.

Nhiều người ngạc nhiên với con số cuối cùng. Đó là chuyện bình thường của mùa cuối năm, và cũng là lý do để bắt đầu từ hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-1.

Chia sẻ hôm nay: "Tôi đã gom được ... việc dở dang. Việc tôi nghĩ đến nhiều nhất: ...". Bình luận kèm câu này để cả nhóm cùng bắt đầu tuần khép việc nha.


## Bài 2: Ngày 2 (Thứ Ba 08/12)
@img 2_phan-loai
@pdf 10XHub_ViecDoDang_PhieuNgay2_phan-loai.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: BỐN NGĂN CHO MỌI VIỆC DỞ DANG

Chị Hà là trưởng nhóm chăm sóc khách hàng. Hôm qua, sau 15 phút gom việc, danh sách của chị có 23 dòng. Sáng nay chị ngồi lại với tờ giấy đó, trước giờ mở hộp thư, và chia từng dòng vào bốn ngăn. (Chị Hà là nhân vật giả định, nhưng danh sách thì rất quen với nhiều người làm quản lý.)

**Ngăn thứ nhất: làm ngay**

Quy tắc của chị dựa trên quy tắc hai phút của David Allen, tác giả cuốn Getting Things Done: việc nào làm xong trong khoảng hai phút thì làm luôn, vì ghi lại và theo dõi nó còn tốn công hơn. Chị tìm được sáu việc như vậy: trả lời xác nhận lịch họp, chuyển tiếp một biểu mẫu, gửi lại số điện thoại cho đồng nghiệp. Mười lăm phút sau, danh sách còn 17 dòng.

**Ngăn thứ hai: lên lịch**

Những việc quan trọng nhưng cần nhiều hơn hai phút. Điểm mấu chốt là lên lịch bằng một ngày giờ cụ thể, không ghi "tuần sau". Chị đặt "soạn quy trình xử lý khiếu nại mới" vào 9 giờ sáng Thứ Năm, "đánh giá năm của ba nhân viên" vào ba buổi chiều tuần sau. Bảy việc vào ngăn này.

**Ngăn thứ ba: giao**

Những việc người khác làm phù hợp hơn, hoặc vốn thuộc phần việc của người khác. Giao không phải đẩy việc. Giao đúng cách nghĩa là nói rõ kết quả mong muốn và thời hạn, rồi ghi lại để theo dõi. Chị giao hai việc: tổng hợp số liệu cuộc gọi tháng 11 cho một nhân viên mới cần thêm kinh nghiệm, và đặt phòng họp tổng kết cho bộ phận hành chính.

**Ngăn thứ tư: bỏ**

Ngăn khó nhất, và cũng nhẹ nhõm nhất. Có những việc đã treo quá lâu đến mức không còn cần thiết: một ý tưởng cải tiến đã được làm theo cách khác, một tài liệu đọc "cho biết" từ tháng 6. Bỏ không có nghĩa là thất bại. Đó là một quyết định rõ ràng, và một quyết định rõ ràng tốt hơn một việc treo không hồi kết. Chị bỏ hai việc.

Sau 30 phút, 23 dòng đã có chỗ đứng. Danh sách vẫn còn việc, nhưng không còn việc nào "lơ lửng".

**Ngày 2 (20 đến 30 phút)**

1. Mở danh sách gom hôm qua.
2. Với mỗi việc, chọn một ngăn: làm ngay, lên lịch, giao hoặc bỏ.
3. Làm luôn những việc dưới hai phút.
4. Việc lên lịch: ghi ngày giờ cụ thể. Việc giao: ghi người nhận và thời hạn.
5. Đếm số việc ở mỗi ngăn.

Sổ thực hành hiện lại các việc đã gom ở Ngày 1, chỉ cần bấm chọn ngăn cho từng việc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-2.

Chia sẻ hôm nay: "Hôm nay tôi làm ngay ... việc dưới hai phút, lên lịch ... việc, giao ... việc và bỏ ... việc.".


## Bài 3: Ngày 3 (Thứ Tư 09/12)
@img 3_khep-viec
@pdf 10XHub_ViecDoDang_PhieuNgay3_khep-viec.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: KHÉP BA VIỆC TREO LÂU NHẤT

Hôm nay viết theo dạng một trang nhật ký làm việc giả định, của một kỹ sư phụ trách bảo trì. Ba việc treo lâu nhất trong danh sách của anh, và cách anh khép từng việc trong một ngày Thứ Tư.

**7 giờ 45.** Mở danh sách. Ba việc treo lâu nhất: cập nhật quy trình kiểm tra máy nén khí (treo từ tháng 8), trả lời đề xuất mua thiết bị đo của tổ trưởng (treo ba tuần), và đọc báo cáo sự cố của nhà cung cấp (treo hai tháng). Cả ba đều thuộc loại "lúc nào rảnh sẽ làm".

**8 giờ 00.** Việc thứ nhất quá lớn để xong trong một buổi. Không cố làm xong. Mở tệp quy trình cũ, viết đúng một câu: "Bước tiếp theo: đối chiếu bản cũ với hướng dẫn mới của hãng, 45 phút, sáng Thứ Hai 14.12." Đặt lịch. Cảm giác nhẹ hẳn, dù việc chưa xong.

**10 giờ 30.** Việc thứ hai hoá ra chỉ thiếu một câu hỏi. Anh gọi tổ trưởng mười phút, hỏi rõ ngân sách và hạn dùng thiết bị. Trả lời đề xuất ngay sau đó. Việc treo ba tuần, khép trong hai mươi phút.

**14 giờ 00.** Việc thứ ba: đọc lướt báo cáo. Phần lớn nội dung đã được xử lý từ tháng trước. Anh gửi một thư ngắn cho nhà cung cấp xác nhận đã nhận báo cáo, rồi lưu vào thư mục. Việc này thật ra đã có thể bỏ từ lâu.

**17 giờ 15.** Ghi lại: một việc làm xong, một việc khép bằng câu hỏi, một việc khép bằng kế hoạch cụ thể.

**Điều trang nhật ký cho thấy**

Khép một việc không nhất thiết là làm xong việc đó. Có bốn cách khép:

- Làm xong, nếu thật sự làm được trong hôm nay.
- Viết bước tiếp theo thật cụ thể, kèm ngày giờ. Đây chính là điều Masicampo và Baumeister quan sát được: một kế hoạch cụ thể làm việc dở bớt chen ngang vào đầu.
- Hỏi người liên quan, khi việc đang treo vì thiếu một thông tin.
- Chủ động bỏ, và báo cho người cần biết.

Ba việc treo lâu nhất thường không phải ba việc khó nhất. Chúng thường là ba việc thiếu một bước tiếp theo rõ ràng.

**Ngày 3 (30 đến 45 phút)**

1. Chọn ba việc treo lâu nhất trong danh sách.
2. Với mỗi việc, chọn một cách khép.
3. Làm ngay cách khép đó trong hôm nay. Việc lớn: viết bước tiếp theo kèm ngày giờ và đặt lịch.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-3.

Chia sẻ hôm nay: "Ba việc treo tôi khép hôm nay: ...; ...; ...".


## Bài 4: Ngày 4 (Thứ Năm 10/12)
@img 4_ket-thuc-ngay
@pdf 10XHub_ViecDoDang_PhieuNgay4_ket-thuc-ngay.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: NGHI THỨC KẾT THÚC NGÀY LÀM VIỆC

Hôm nay viết theo dạng một lá thư. Người nhận là chính mình, lúc 17 giờ của một ngày làm việc bình thường.

*Gửi mình lúc 17 giờ,*

*Mình biết cảm giác lúc này. Hộp thư vẫn còn thư mới, danh sách việc vẫn còn dòng chưa gạch, và có một việc nhỏ mình định làm "thêm năm phút nữa". Thường thì năm phút đó thành ba mươi phút, rồi mình mang cả ngày làm việc theo về nhà, trong đầu.*

*Hôm nay thử một cách khác. Trước khi đứng dậy, dành mười lăm phút cho năm bước, lúc nào cũng theo đúng thứ tự:*

*Một, xem hộp thư lần cuối, chỉ để chắc không có việc gấp thật sự. Hai, ghi mọi việc dở trong ngày vào danh sách, đừng để việc nào chỉ nằm trong đầu. Ba, nhìn lịch ngày mai và chọn việc quan trọng nhất cho buổi sáng. Bốn, làm thói quen then chốt nếu hôm nay chưa làm, rồi bấm ô trên bảng hành trình. Năm, nói một câu khép ngày, cùng một câu mỗi ngày.*

*Câu khép ngày nghe có vẻ hình thức. Nhưng khi đã nói câu đó, nếu một việc công việc quay lại trong đầu buổi tối, mình có câu trả lời: việc đó đã được ghi lại, đã có chỗ của nó, mai sẽ xử lý.*

*Mình của buổi sáng ngày mai sẽ cảm ơn mình của 17 giờ hôm nay.*

**Vì sao nghi thức này có cơ sở**

Cal Newport, tác giả cuốn Deep Work (2016), mô tả một nghi thức kết thúc ngày như trên và dùng một câu khép cố định cho chính mình. Ông dựa một phần vào hiệu ứng Zeigarnik và nghiên cứu của Masicampo và Baumeister: việc dở dang hay chen vào đầu, nhưng một kế hoạch cụ thể giúp chúng yên xuống.

**Gắn với thói quen then chốt**

Nghi thức kết thúc ngày là lớp mới của tuần này cho hành trình. Có hai cách gắn:

- Nếu thói quen then chốt làm buổi sáng, nghi thức buổi chiều chuẩn bị cho nó: chọn sẵn việc, mở sẵn tệp, đặt sẵn tài liệu.
- Nếu thói quen chưa làm trong ngày, nghi thức là lần nhắc cuối cùng, kèm phiên bản tối thiểu.

**Ngày 4 (20 phút)**

1. Chọn các bước cho nghi thức kết thúc ngày của mình, không quá năm bước.
2. Chọn giờ bắt đầu nghi thức mỗi ngày.
3. Viết câu khép ngày của riêng mình.
4. Làm thử nghi thức ngay chiều nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-4.

Chia sẻ hôm nay: "Nghi thức kết thúc ngày của tôi: .... Câu khép ngày: ...".


## Bài 5: Ngày 5 (Thứ Sáu 11/12)
@img 5_dung-giua-chung
@pdf 10XHub_ViecDoDang_PhieuNgay5_dung-giua-chung.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: DỪNG GIỮA CHỪNG ĐỂ MAI DỄ BẮT ĐẦU

Bốn ngày qua là để khép việc. Hôm nay đi theo hướng ngược lại: cố ý để một việc dở dang. Nghe có vẻ mâu thuẫn, nên đặt hai cách dừng cạnh nhau sẽ rõ hơn.

**Cách thứ nhất: dừng ở cuối một phần việc**

Một chuyên viên nhân sự soạn xong toàn bộ mục 3 của quy chế khen thưởng lúc 17 giờ, gập máy, về. Sáng hôm sau, chị mở tệp và nhìn vào trang trắng của mục 4. Phải đọc lại cả mục 3 để nhớ mạch, phải nghĩ mục 4 bắt đầu từ đâu. Hai mươi phút trôi qua trước khi viết được câu đầu tiên. Khởi động lại từ con số không là phần tốn sức nhất của buổi sáng.

**Cách thứ hai: dừng ở giữa, khi đã biết bước tiếp theo**

Cùng công việc đó, nhưng chị dừng lúc đã viết xong hai ý đầu của mục 4 và ghi sẵn ý thứ ba bằng một câu dở: "Ý 3: mức thưởng cho sáng kiến được áp dụng toàn công ty, cần đối chiếu với...". Sáng hôm sau, chị chỉ cần đọc câu dở đó và viết tiếp. Đầu óc vào việc ngay trong vài phút.

**Khác biệt nằm ở đâu**

- Dừng ở cuối phần việc: cảm giác hoàn thành tối nay, nhưng khởi động khó sáng mai.
- Dừng giữa chừng có chủ đích: tối nay việc vẫn còn dở, nhưng nó dở có kiểm soát, đã được ghi lại, và sáng mai có điểm vào sẵn.

Nhà văn Ernest Hemingway kể trong hồi ký A Moveable Feast rằng ông thường dừng viết khi đã biết đoạn tiếp theo sẽ diễn ra thế nào, để hôm sau dễ viết tiếp. Cách làm này kết hợp tốt với xu hướng quay lại làm tiếp việc dở mà Ovsiankina mô tả.

**Điều cần lưu ý**

Dừng giữa chừng chỉ có ích khi đi kèm nghi thức kết thúc ngày đã thiết kế hôm qua: việc dở phải được ghi lại rõ, có điểm vào cụ thể. Một việc dở không ghi lại sẽ quay về đúng tình trạng của Thứ Hai: chạy trong đầu lúc 22 giờ.

Với thói quen then chốt, cách này đặc biệt hữu ích khi thói quen là một phiên làm việc sâu hay một việc viết dài. Chuẩn bị điểm vào cho phiên ngày mai chính là phiên bản hai phút được làm sẵn từ chiều hôm trước.

**Ngày 5 (15 phút)**

1. Chọn một việc đang làm dài ngày.
2. Chiều nay, dừng ở giữa, khi đã biết bước tiếp theo.
3. Viết sẵn một câu dở hoặc một ghi chú ngắn làm điểm vào cho sáng mai.
4. Sáng Thứ Hai, ghi lại mất bao lâu để vào việc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-5.

Chia sẻ hôm nay: "Hôm nay tôi dừng có chủ đích ở: .... Sáng mai bắt đầu bằng: ...".


## Bài 6: Ngày 6 (Thứ Bảy 12/12)
@img 6_khep-nam
@img2 9_the-thanh-tich
@pdf 10XHub_ViecDoDang_PhieuNgay6_khep-nam.pdf (phiếu thực hành và danh sách việc khép năm 2026 để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: DANH SÁCH VIỆC KHÉP NĂM 2026

Năm 2026 còn đúng ba tuần làm việc. Hôm nay mỗi người viết một danh sách ngắn những việc muốn khép lại trước ngày 31.12, theo năm bước dưới đây.

**Năm bước viết danh sách việc khép năm**

1. Mở danh sách gom từ Thứ Hai và các việc đã lên lịch ở Thứ Ba. Tìm những việc mà nếu mang sang năm 2027 sẽ thành gánh nặng.
2. Thêm những việc "cuối năm" hay bị quên: hồ sơ cần nộp trước khi kết thúc năm tài chính, lời cảm ơn chưa gửi, thư mục cần sắp xếp lại, tài khoản cần đối chiếu.
3. Giữ danh sách ngắn: tối đa năm việc. Một danh sách dài vào cuối năm dễ thành thêm một nguồn lo.
4. Mỗi việc ghi một ngày khép cụ thể, không muộn hơn 31.12.2026.
5. Gắn danh sách vào nghi thức kết thúc ngày: mỗi chiều, nhìn danh sách một lần.

**Hỏi nhanh**

Chỉ có ba việc thôi có được không? Được. Ba việc khép thật tốt hơn năm việc khép dở.

Việc lớn không thể xong trước 31.12 thì sao? Khép bằng một kế hoạch: viết bước đầu tiên của năm 2027, kèm ngày giờ. Việc vẫn sang năm, nhưng không còn treo.

Có nên cho việc cá nhân vào không? Tuần này chỉ tập trung vào việc trong công việc, để danh sách đủ ngắn và rõ.

**Bảng hành trình tuần này**

Bảng hành trình nằm ở Ngày 6. Bấm các ngày đã làm thói quen từ Thứ Hai. Ngày nào làm nghi thức kết thúc ngày kèm thói quen, cứ bấm như bình thường.

**Sáng nay (15 phút)**

Viết danh sách việc khép năm 2026, tối đa năm việc, mỗi việc một ngày khép.

**Trước khi nghỉ Chủ Nhật (15 phút)**

Bấm bảng hành trình. In trang danh sách trong phiếu đính kèm, đặt cạnh trang lá chắn của tuần trước.

Tuần sau, Công thức #0031 về Kaizen sẽ nhìn lại cả năm 2026 theo tinh thần cải tiến: ba việc mình đã làm tốt hơn trong năm, và một cải tiến nhỏ nhất cho thói quen then chốt mỗi tuần. Danh sách khép năm hôm nay sẽ là một nguồn để nhìn lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0030-ngay-6.

Chia sẻ hôm nay: "Trước 31.12.2026, tôi khép: ...; ...; .... Thói quen tôi mang sang tuần sau: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Khép việc dở dang hiện ra, có sáu vòng tròn theo các ngày đã làm thói quen, tên mình và nghi thức kết thúc ngày. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Việc dở đã có chỗ đứng, cuối tuần là của mình.
