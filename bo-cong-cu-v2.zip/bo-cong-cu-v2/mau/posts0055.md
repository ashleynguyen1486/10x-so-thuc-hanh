## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 31/05)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0055_Zettelkasten_VN.pdf (tài liệu đầy đủ của Công thức #0055)
@pdf 10XHub_Zettelkasten_PhieuNgay1_the-dau-tien.pdf (phiếu thực hành và mẫu thẻ in được)
@pdf 10XHub_HuongDan_SoThucHanh_0055.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MỖI BUỔI HỌC ĐỂ LẠI MỘT THẺ GHI CHÚ

Một tuần dùng câu hỏi khép buổi học đã cho ra những câu trả lời nào? Tuần Phân loại Bloom vừa qua, cả nhóm đã tự đặt sáu câu hỏi cho kỹ năng đang học, dành ít nhất một nửa buổi học cho các tầng vận dụng, phân tích, đánh giá, xếp lịch tầng cho tuần này, và chọn một câu hỏi tầng cao để khép mỗi buổi học. Ai chưa kịp làm Ngày 6 vẫn mở lại được trên sổ thực hành.

Những câu trả lời đó thường là phần quý nhất của buổi học. Tuần này đi tìm một nơi để giữ chúng. Công thức #0055 của tuần là Zettelkasten, hộp thẻ ghi chú.

**Nếu mới tham gia:** tuần này bắt đầu bằng một tấm thẻ giấy nhỏ, không cần biết gì về các tuần trước. Viết vào Ngày 1 trên sổ thực hành một thói quen nhỏ mỗi ngày và một chủ đề công việc mình đang muốn học thêm, học 20 phút, rồi viết tấm thẻ đầu tiên như hướng dẫn bên dưới.

**Hỏi đáp nhanh trước khi bắt đầu**

**Hỏi: Zettelkasten là gì?**

Đây là một từ tiếng Đức, nghĩa đen là "hộp phiếu" hay "hộp thẻ". Người ta dùng tên này để chỉ một cách ghi chép: mỗi ý tưởng viết trên một tấm thẻ riêng, bằng lời của chính mình, rồi nối các thẻ với nhau. Theo thời gian, hộp thẻ trở thành một mạng lưới ý tưởng có thể dùng lại.

**Hỏi: Ai đã làm cho cách này nổi tiếng?**

Niklas Luhmann (1927 đến 1998), nhà xã hội học người Đức. Theo Kho lưu trữ Niklas Luhmann của Đại học Bielefeld, ông để lại khoảng 90.000 tấm thẻ ghi chú, viết từ năm 1951 đến 1996. Ông cũng là một trong những nhà khoa học xã hội viết nhiều nhất thế kỷ 20, và trong một bài viết năm 1981 đã mô tả hộp thẻ như một người đối thoại trong công việc của mình.

**Hỏi: Có sách nào hướng dẫn dễ áp dụng không?**

Có. Năm 2017, Sönke Ahrens xuất bản cuốn "How to Take Smart Notes", trình bày lại cách làm của Luhmann cho người đọc ngày nay, nhất là sinh viên và người làm công việc cần viết, cần suy nghĩ. Tuần này dựa chủ yếu vào cách Ahrens mô tả.

**Hỏi: Có cần phần mềm không?**

Không. Luhmann dùng thẻ giấy và hộp gỗ. Tuần này cũng vậy: một xấp thẻ nhỏ hoặc giấy A4 cắt làm tư, một chiếc hộp hay một bìa kẹp. Ai đã quen một phần mềm ghi chú vẫn dùng được, miễn giữ đúng nguyên tắc: mỗi thẻ một ý, viết bằng lời của mình, có số và có liên kết.

**Hỏi: Hộp thẻ khác gì bản đồ và trang Cornell đã học?**

Trang Cornell ghi trong lúc học. Bản đồ gom một buổi học lên một trang. Thẻ giữ lại một ý đáng giữ nhất của buổi học, viết sao cho sáu tháng sau đọc lại vẫn hiểu, và nối nó với những ý đã có từ các buổi trước.

**Lớp mới của hành trình**

Thói quen then chốt, rồi 20 phút học cho kỹ năng đã chọn ở tuần Siêu học, khép bằng bản đồ và câu hỏi tầng cao. Tuần này thêm một bước cuối, chỉ khoảng 5 phút: viết một tấm thẻ cho ý đáng giữ nhất, và nối nó với ít nhất một thẻ cũ. Sau một quý, hộp thẻ của dự án học sẽ là kho ý tưởng cho chính công việc của mình, một tài sản rất cụ thể trên đường đến phiên bản 10X.

**Sáu ngày của tuần**

- Thứ Hai: tấm thẻ đầu tiên.
- Thứ Ba 01.06: một câu hỏi tò mò, một tấm thẻ mới.
- Thứ Tư: ba loại ghi chú, chuyển ghi chú tạm thành thẻ.
- Thứ Năm: chép lại và viết bằng lời của mình.
- Thứ Sáu: đánh số và nối các thẻ.
- Thứ Bảy: một tuần của hộp thẻ, chốt quy ước.

Chủ Nhật nghỉ.

**Ngày 1 (khoảng 25 phút): Tấm thẻ đầu tiên**

1. Mở sổ thực hành, xem lại thói quen đang giữ, kỹ năng, dự án học và câu hỏi khép buổi học.
2. Học 20 phút như mọi ngày, trả lời câu hỏi khép buổi học của mình.
3. Lấy một tấm thẻ. Góc trên bên phải ghi số "1". Viết một ý đáng giữ nhất của buổi học, bằng lời của mình, trong không quá năm câu.
4. Dòng cuối thẻ ghi nguồn (tài liệu, trang hoặc buổi họp) và ngày.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-1.

Chia sẻ hôm nay: "Thẻ số 1 trong hộp thẻ của tôi: “...”.".

Tấm thẻ đầu tiên không cần hay, chỉ cần là ý của mình. Các anh chị và các bạn cứ viết thật ngắn, thật rõ nha.


## Bài 2: Ngày 2 (Thứ Ba 01/06)
@img 2_to-mo
@pdf 10XHub_Zettelkasten_PhieuNgay2_to-mo.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: HÔM NAY HỎI "VÌ SAO" NHƯ MỘT ĐỨA TRẺ

Hôm nay, 01.06, là Ngày Quốc tế Thiếu nhi. Ai từng ở cạnh một đứa trẻ bốn, năm tuổi đều biết câu hỏi quen thuộc nhất của các bé: "Vì sao?". Vì sao trời mưa, vì sao xe phải dừng ở đèn đỏ, vì sao người lớn phải đi làm. Câu trả lời nào cũng mở ra một câu "vì sao" mới.

Khi đi làm lâu năm, câu hỏi đó thường thưa dần. Quy trình đã quen, công việc đã chạy. Bài hôm nay là bốn câu hỏi mở để các anh chị và các bạn thử mang lại một chút tò mò đó vào 20 phút học.

**Tò mò có giúp học tốt hơn không?**

Năm 2014, Matthias Gruber, Bernard Gelman và Charan Ranganath ở Đại học California, Davis công bố trên tạp chí Neuron một nghiên cứu với 19 người tham gia. Họ chấm mức tò mò của mình với hơn 100 câu đố kiến thức, rồi xem lại các câu đố trong lúc được chụp não. Người tham gia nhớ được khoảng 71% đáp án của những câu họ rất tò mò, so với khoảng 54% ở những câu ít tò mò. Điều bất ngờ hơn: họ cũng nhận ra tốt hơn những gương mặt lạ được chiếu thoáng qua trong lúc đang chờ đáp án của câu hỏi khiến họ tò mò. Lợi thế này vẫn còn khi kiểm tra lại vào ngày hôm sau.

Đây là một nghiên cứu nhỏ trong phòng thí nghiệm, nên chỉ nên xem như một gợi ý: trạng thái tò mò có thể giúp ghi nhớ cả những điều đi kèm.

**Câu hỏi 1: Về kỹ năng đang học, câu "vì sao" nào mình chưa trả lời được?**

Ví dụ: "Vì sao công ty quy định đối chiếu công nợ vào ngày 25 mà không phải cuối tháng?" Câu hỏi nhỏ, cụ thể, liên quan đến việc mình làm hằng ngày.

**Câu hỏi 2: Điều gì trong buổi học tuần trước làm mình ngạc nhiên?**

Ngạc nhiên là dấu hiệu điều mình vừa biết khác với điều mình tưởng. Đó thường là chỗ đáng viết thành thẻ nhất.

**Câu hỏi 3: Nếu được hỏi một người giỏi nhất về kỹ năng này một câu, mình sẽ hỏi gì?**

Câu này giúp thấy phần mình đang thiếu, và đôi khi gợi ý đúng người để hỏi trong chính công ty.

**Câu hỏi 4: Câu hỏi nào mình đã ngại hỏi trong một cuộc họp?**

Nhiều câu hỏi bị giữ lại vì sợ bị cho là chưa biết. Viết nó lên thẻ là bước đầu tiên để tìm câu trả lời.

**Từ câu hỏi đến tấm thẻ**

Trong hộp thẻ, một câu hỏi hay cũng đáng một tấm thẻ như một câu trả lời. Viết câu hỏi ở dòng đầu, rồi ghi những gì mình đã tìm được sau 20 phút học, dù chưa đầy đủ. Nếu nó tiếp nối ý của thẻ số 1, đánh số "1a". Nếu là một hướng mới, đánh số "2".

**Ngày 2 (khoảng 25 phút)**

1. Chọn một trong bốn câu hỏi trên, viết câu "vì sao" của mình.
2. Học 20 phút để đi tìm câu trả lời.
3. Viết tấm thẻ thứ hai: câu hỏi ở dòng đầu, điều đã tìm được ở dưới, đánh số "1a" hoặc "2".
4. Đánh dấu bảng hành trình trên sổ thực hành.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-2.

Chia sẻ hôm nay: "Câu hỏi tò mò của tôi hôm nay: “...”. Thẻ mới mang số ...".

Chúc các bạn nhỏ trong gia đình của các anh chị và các bạn một ngày 01.06 thật vui nha.


## Bài 3: Ngày 3 (Thứ Tư 02/06)
@img 3_ba-loai-ghi-chu
@pdf 10XHub_Zettelkasten_PhieuNgay3_ba-loai-ghi-chu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: BA LOẠI GHI CHÚ, CHỈ MỘT LOẠI VÀO HỘP

Mỗi tuần, ai cũng tạo ra rất nhiều ghi chú: một dòng trên giấy dán, một tin nhắn tự gửi cho mình, vài chữ bên lề tài liệu, một trang ghi biên bản họp. Phần lớn sẽ không bao giờ được đọc lại. Ahrens chia ghi chú thành ba loại, và chỉ một loại đi vào hộp thẻ. Hôm nay là danh sách ba loại đó, kèm cách xử lý từng loại.

**1. Ghi chú tạm**

- Là gì: một ý chợt đến, viết vội để khỏi quên. Một dòng trên giấy dán, một tin nhắn tự gửi, một chữ bên lề.
- Ví dụ: "Hỏi lại chị Thu vụ chiết khấu đại lý mới."
- Xử lý: đọc lại trong vòng một hai ngày. Ý nào đáng giữ thì chuyển thành thẻ, còn lại bỏ đi. Ghi chú tạm không vào hộp.

**2. Ghi chú tài liệu**

- Là gì: ghi lại điều mình hiểu từ một nguồn cụ thể: một cuốn sách, một tài liệu nội bộ, một buổi đào tạo. Viết ngắn, bằng lời của mình, kèm nguồn.
- Ví dụ: "Tài liệu đào tạo bán hàng, trang 12: khách hàng doanh nghiệp thường có ba người tham gia quyết định, người dùng, người duyệt ngân sách và người ký."
- Xử lý: giữ cùng thông tin nguồn, trong một tập riêng theo tài liệu. Trang Cornell và bản đồ của các tuần trước chính là ghi chú tài liệu.

**3. Thẻ lâu dài**

- Là gì: một ý duy nhất, viết đầy đủ bằng câu hoàn chỉnh, sao cho người khác (hoặc chính mình sáu tháng sau) đọc vẫn hiểu mà không cần mở lại nguồn.
- Ví dụ: "Khi chào giá cho khách hàng doanh nghiệp, cần chuẩn bị ba phiên bản lập luận cho ba người khác nhau: người dùng quan tâm sự tiện lợi, người duyệt ngân sách quan tâm tổng chi phí, người ký quan tâm rủi ro. (Nối với thẻ 3: cách hỏi nhu cầu.)"
- Xử lý: đánh số, nối với thẻ cũ, đặt vào hộp. Đây là loại duy nhất vào hộp thẻ.

**Vì sao phải tách ba loại?**

Nếu cho mọi ghi chú vào cùng một chỗ, hộp thẻ sẽ đầy những dòng chỉ mình hiểu lúc viết. Ba loại có ba nhiệm vụ khác nhau: ghi chú tạm để không quên, ghi chú tài liệu để không mất nguồn, thẻ lâu dài để suy nghĩ tiếp. Việc chuyển từ loại này sang loại kia, viết lại bằng lời của mình, chính là lúc mình học.

**Ngày 3 (khoảng 25 phút)**

1. Học 15 phút cho kỹ năng đang học.
2. Gom các ghi chú tạm của tuần: giấy dán, tin nhắn tự gửi, chữ bên lề.
3. Chọn những ý đáng giữ, viết lại thành thẻ lâu dài. Bỏ đi phần còn lại mà không tiếc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-3.

Chia sẻ hôm nay: "Hôm nay tôi gom ... ghi chú tạm và giữ lại ... thẻ lâu dài.".


## Bài 4: Ngày 4 (Thứ Năm 03/06)
@img 4_loi-cua-minh
@pdf 10XHub_Zettelkasten_PhieuNgay4_loi-cua-minh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CHÉP LẠI HAY VIẾT BẰNG LỜI CỦA MÌNH?

Nguyên tắc khó nhất của hộp thẻ là viết bằng lời của mình. Chép lại thì nhanh và cảm giác rất chắc chắn, vì câu chữ là của người viết gốc. Nhưng khi chép, mình gần như không phải nghĩ. Hôm nay đặt ba cặp thẻ cạnh nhau, một thẻ chép và một thẻ viết lại, để thấy khác biệt.

**Cặp 1: kế toán, một quy định nội bộ về khoá sổ**

Thẻ chép: "Các bộ phận gửi đề nghị thanh toán kèm đủ chứng từ về phòng kế toán chậm nhất ngày làm việc thứ ba của tháng sau để kịp khoá sổ."

Thẻ viết lại: "Kế toán cần chứng từ sớm vì sau mốc đó còn phải đối chiếu rồi mới khoá sổ được. Chứng từ đến muộn bị dồn sang kỳ sau, làm chi phí của bộ phận lệch giữa hai tháng. Vì vậy mình nên nhắc các trưởng bộ phận từ cuối tháng, không đợi đến hạn. (Nối với thẻ 4: lịch đối chiếu với các bộ phận.)"

Thẻ viết lại dài hơn một chút, nhưng có thêm hai điều: hệ quả cho công việc của mình, và một liên kết.

**Cặp 2: nhân sự, một ý từ sách quản trị**

Thẻ chép: "Phản hồi hiệu quả cần cụ thể, kịp thời và tập trung vào hành vi thay vì con người."

Thẻ viết lại: "Lần sau góp ý cho nhân viên mới, nói trong vòng hai ngày, nêu đúng một việc đã xảy ra ('báo cáo hôm Thứ Ba thiếu số liệu kho'), không nói về tính cách ('em hơi ẩu'). Câu đầu tiên phải là điều đã thấy, không phải nhận xét."

Thẻ viết lại biến một nguyên tắc chung thành một việc làm được ở tuần sau.

**Cặp 3: chăm sóc khách hàng, một ghi chú từ buổi đào tạo**

Thẻ chép: "Bước 2: xác nhận lại vấn đề của khách hàng."

Thẻ viết lại: "Sau khi khách nói xong, nhắc lại vấn đề bằng một câu, bắt đầu bằng 'Như vậy là anh chị đang gặp...'. Mình thấy cuộc gọi thường ngắn hơn khi khách được nghe lại đúng vấn đề của họ. (Câu hỏi để kiểm chứng: thử đếm số cuộc gọi phải gọi lại trong hai tuần.)"

Thẻ viết lại có cả một quan sát của chính mình và một câu hỏi để kiểm chứng.

**Ba dấu hiệu của một thẻ viết bằng lời của mình**

- Không mở lại nguồn vẫn hiểu.
- Có ít nhất một câu nói điều này có nghĩa là gì với công việc của mình.
- Có một liên kết hoặc một câu hỏi tiếp theo.

Trích nguyên văn vẫn có chỗ dùng, ví dụ một con số hay một định nghĩa pháp lý cần chính xác. Khi đó, ghi trong ngoặc kép kèm nguồn, rồi viết thêm một câu bằng lời của mình bên dưới.

**Ngày 4 (khoảng 25 phút)**

1. Học 15 phút cho kỹ năng đang học.
2. Tìm một đoạn mình đã gạch chân hoặc chép nguyên văn trong tài liệu học.
3. Viết lại thành một thẻ bằng lời của mình, không quá năm câu, có một câu về ý nghĩa với công việc và một liên kết hoặc câu hỏi tiếp theo.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-4.

Chia sẻ hôm nay: "Tôi viết lại một đoạn chép nguyên văn thành thẻ bằng lời của mình: “...”.".


## Bài 5: Ngày 5 (Thứ Sáu 04/06)
@img 5_noi-the
@pdf 10XHub_Zettelkasten_PhieuNgay5_noi-the.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: THẺ 1, THẺ 1A, THẺ 1A1, CÁCH CÁC Ý NỐI VỚI NHAU

**Một tình huống minh hoạ**

Anh Tâm là kỹ sư kiểm soát chất lượng ở một nhà máy linh kiện nhựa. Kỹ năng anh chọn cho quý 2 là "kiểm soát quá trình bằng biểu đồ kiểm soát". Dự án học: đến cuối tháng 6, tự dựng biểu đồ kiểm soát cho độ dày sản phẩm ở một dây chuyền ép.

Sau bốn ngày, hộp thẻ của anh có năm thẻ. Thứ Sáu, anh dành 20 phút học, rồi 10 phút xếp và nối chúng lại.

Thẻ 1: "Biểu đồ kiểm soát giúp tách biến động thông thường của quá trình với biến động có nguyên nhân đặc biệt."

Anh đọc lại thẻ thứ hai: "Giới hạn kiểm soát tính từ dữ liệu của chính quá trình, không lấy từ yêu cầu của khách hàng." Thẻ này đi tiếp ý của thẻ 1, nên anh đánh số "1a".

Thẻ thứ ba nói về một lỗi anh từng mắc: "Đem giới hạn dung sai của bản vẽ vẽ lên biểu đồ kiểm soát là sai, vì đó là yêu cầu của khách, không phải tiếng nói của quá trình." Thẻ này đi sâu thêm một bậc từ thẻ 1a, nên anh đánh số "1a1".

Thẻ thứ tư là câu hỏi tò mò hôm Thứ Ba: "Vì sao chọn mẫu năm sản phẩm mỗi giờ mà không phải mười?" Đây là một hướng khác của thẻ 1, nên anh đánh số "1b".

Thẻ thứ năm nói về cách đo độ dày bằng thước cặp điện tử. Ý này không đi tiếp thẻ nào, nên anh mở một nhánh mới: thẻ "2".

Cuối cùng, anh nhận ra thẻ 2 (cách đo) có liên quan đến thẻ 1a (giới hạn tính từ dữ liệu): nếu cách đo không ổn định, dữ liệu sai và giới hạn cũng sai. Anh ghi ở cuối thẻ 2: "Xem thêm 1a." Và ở cuối thẻ 1a: "Xem thêm 2."

Anh viết thêm một thẻ mục lục: "Biểu đồ kiểm soát → 1. Đo lường → 2."

Tình huống trên là minh hoạ. Điều đáng chú ý là ba quyết định của anh Tâm:

- Đánh số theo vị trí trong dòng suy nghĩ, không theo chủ đề hay ngày viết. Thẻ mới đặt ngay sau thẻ mà nó đi tiếp.
- Liên kết hai chiều, ghi ở cả hai thẻ.
- Một thẻ mục lục ngắn để biết mỗi dòng suy nghĩ bắt đầu từ thẻ nào.

**Cách đánh số kiểu Luhmann, tóm gọn**

- Ý hoàn toàn mới: số tiếp theo (1, 2, 3...).
- Đi tiếp một thẻ: thêm một chữ cái (1 → 1a, 1b...).
- Đi sâu từ thẻ có chữ: thêm một số (1a → 1a1, 1a2...).
- Số đã đặt thì không đổi. Nhờ vậy, liên kết luôn đúng.

**Ngày 5 (khoảng 30 phút)**

1. Học 20 phút cho kỹ năng đang học, viết thẻ của hôm nay.
2. Xếp các thẻ của tuần, đánh lại số theo cách trên nếu chưa đánh.
3. Tìm hai thẻ có liên quan, ghi "Xem thêm" ở cả hai thẻ.
4. Viết một thẻ mục lục cho dự án học.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-5.

Chia sẻ hôm nay: "Hộp thẻ của tôi có ... thẻ. Liên kết mới: thẻ ... nối với thẻ ...".


## Bài 6: Ngày 6 (Thứ Bảy 05/06)
@img 6_mot-tuan
@img2 9_the-thanh-tich
@pdf 10XHub_Zettelkasten_PhieuNgay6_mot-tuan.pdf (phiếu thực hành và thẻ mục lục in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: NHẬT KÝ MỘT TUẦN CỦA HỘP THẺ

Hôm nay mở đầu bằng một trang nhật ký minh hoạ, ghi lại một tuần của một hộp thẻ mới. Người viết là một trưởng nhóm kinh doanh, kỹ năng đang học là tìm hiểu nhu cầu khách hàng doanh nghiệp.

**Thứ Hai.** Viết thẻ số 1 sau buổi học: khách hàng doanh nghiệp thường có ba người tham gia quyết định. Mất 6 phút, lâu hơn mình nghĩ, vì phải viết lại ba lần mới thành câu của mình.

**Thứ Ba.** Câu hỏi tò mò: vì sao khách lớn hay hỏi về điều khoản bảo hành trước khi hỏi giá? Thẻ 1a. Chưa có câu trả lời đầy đủ, chỉ ghi được hai giả thuyết.

**Thứ Tư.** Gom được chín ghi chú tạm trong điện thoại và trên giấy dán. Giữ lại hai, viết thành thẻ 2 và thẻ 2a. Bỏ bảy ghi chú còn lại, nhẹ cả người.

**Thứ Năm.** Viết lại một đoạn chép từ sách bán hàng. Thẻ chép dài ba dòng, thẻ viết lại có thêm một câu: "Lần gặp khách tuần sau, hỏi người ký quan tâm điều gì trước." Lần đầu tiên một thẻ biến thành một việc cụ thể.

**Thứ Sáu.** Đánh số lại, nối thẻ 1a với thẻ 2a: cả hai đều nói về rủi ro mà khách hàng lo ngại. Viết thẻ mục lục.

**Thứ Bảy.** Sáu thẻ. Không nhiều, nhưng đọc lại thấy rõ suy nghĩ của mình về khách hàng doanh nghiệp đã đi từ đâu đến đâu trong một tuần.

**Đọc lại trang nhật ký**

Sáu thẻ sau một tuần là một khởi đầu rất tốt. Điều quan trọng không nằm ở số lượng, mà ở hai điều nhật ký cho thấy: thẻ đầu tiên luôn mất thời gian nhất, và giá trị của hộp thẻ bắt đầu lộ ra từ lúc có liên kết đầu tiên. Luhmann viết khoảng 90.000 thẻ trong hơn bốn mươi năm. Nếu chia đều, đó là khoảng năm, sáu thẻ mỗi ngày, không phải hàng chục.

**Sáng nay (khoảng 25 phút)**

1. Đếm số thẻ trong hộp, đọc lại từ thẻ 1.
2. Tìm một thẻ gợi ý được điều gì đó cho dự án học của quý 2.
3. Viết quy ước hộp thẻ của mình, ví dụ: "cuối mỗi buổi học, một thẻ bằng lời của mình, nối với ít nhất một thẻ cũ". Quy ước này được lưu cho cả hành trình.
4. In thẻ mục lục ở phiếu Ngày 6, đặt ở đầu hộp.

**Tuần sau: Phương pháp PARA**

Tuần này mỗi ý đáng giữ có một tấm thẻ. Nhưng quanh việc học còn rất nhiều tài liệu khác: tệp bài giảng, biểu mẫu, email, bản ghi họp, tài liệu của dự án học. Tuần sau sắp xếp tất cả vào bốn nhóm Dự án, Lĩnh vực, Tài nguyên, Lưu trữ để tìm lại nhanh, và mỗi công cụ đã học (sổ đầu dòng, hộp thẻ, thư mục) giữ một vai trò riêng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0055-ngay-6.

Chia sẻ hôm nay: "Sau một tuần, hộp thẻ của tôi có ... thẻ. Quy ước của tôi: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hiện ra: một tấm thẻ trắng viền đỏ với chữ "Tò mò" viết nghiêng, con số 6/6, dòng "NGÀY GHI THẺ", tên mình và quy ước hộp thẻ. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Hẹn gặp lại sáng Thứ Hai.
