## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 21/12)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0032_Long Biet On_VN.pdf (tài liệu đầy đủ của Công thức #0032)
@pdf 10XHub_BietOn_PhieuNgay1_ba-dieu-biet-on.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0032.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN GIÁNG SINH: MỘT LỜI CẢM ƠN SAU MỖI THÓI QUEN

Tuần trước, cả nhóm đã nhìn lại năm 2026 theo tinh thần cải tiến và chọn một thay đổi nhỏ nhất cho thói quen then chốt của mình: bớt một bước, dời một khung giờ, đổi một tín hiệu. Cải tiến nhỏ đó tiếp tục chạy trong tuần này, không cần làm lại. Ai chưa xong Ngày 6 của tuần Kaizen vẫn mở lại được trên sổ thực hành.

Tuần này là tuần Giáng sinh, cũng là tuần làm việc trọn vẹn cuối cùng của năm 2026. Lịch của nhiều người dày lên với tất niên, chốt sổ, gửi quà cho đối tác. Vì vậy công thức tuần này nhẹ hơn, mỗi ngày chỉ 15 đến 20 phút, và ấm hơn: Công thức #0032, Lòng biết ơn trong công việc.

**Nếu mới tham gia:** tuần này rất dễ bắt đầu. Hôm nay chỉ cần hai việc trên sổ thực hành: viết một thói quen then chốt trong công việc mà mình muốn giữ, ví dụ "viết ba việc quan trọng nhất trước 8 giờ", rồi làm bài Ngày 1 ngay bên dưới. Các tuần trước có thể đọc sau, không cần đọc lại mới theo kịp.

**Một buổi chiều cuối năm** (tình huống minh hoạ)

Hãy hình dung chị Hạnh, trưởng phòng kế toán của một công ty phân phối. Chiều 21.12, chị mở sổ để chuẩn bị buổi họp tổng kết. Trang đầu là danh sách việc chưa xong: hai khoản công nợ chưa đối chiếu, báo cáo quý 4 còn chờ số liệu, một vị trí tuyển dụng còn trống. Danh sách dài, và càng đọc càng thấy năm nay chưa làm được bao nhiêu.

Rồi chị lật sang một trang trắng và tự hỏi một câu khác: năm nay, ai và điều gì đã giúp công việc của mình chạy được? Câu trả lời đến chậm, nhưng rõ dần. Bạn kế toán mới tự học cách dùng phần mềm đối chiếu, giảm gần một nửa thời gian chốt sổ cuối tháng. Anh phụ trách kho luôn gửi phiếu xuất trước 5 giờ chiều. Một khách hàng lâu năm đồng ý thanh toán đúng hạn sau một cuộc trao đổi thẳng thắn.

Không việc nào trong danh sách chưa xong biến mất. Nhưng chị bước vào buổi họp với hai trang thay vì một, và buổi họp hôm đó bắt đầu bằng lời cảm ơn cụ thể dành cho từng người.

Tình huống trên chỉ là minh hoạ, nhưng điều nó mô tả đã được nghiên cứu khá kỹ. Năm 2003, hai nhà tâm lý học Robert Emmons và Michael McCullough đề nghị một nhóm người tham gia ghi lại những điều mình biết ơn mỗi tuần, trong hơn hai tháng. So với nhóm ghi những phiền toái và nhóm ghi sự kiện bình thường, nhóm ghi điều biết ơn lạc quan hơn về tuần sắp tới và hài lòng hơn với cuộc sống nói chung. Trong một nghiên cứu khác của cùng bài báo, người ghi điều biết ơn mỗi ngày cũng cho biết mình hỗ trợ người khác nhiều hơn.

**Lớp mới cho thói quen then chốt**

Mỗi tuần của hành trình thêm một lớp cho cùng một thói quen. Lớp của tuần này rất nhỏ: sau mỗi lần làm thói quen then chốt, gửi đi một lời cảm ơn cụ thể. Có thể là một dòng nhắn cho đồng nghiệp đã gửi số liệu sớm, một câu nói trực tiếp với anh bảo vệ, hay một dòng ghi vào sổ cảm ơn của riêng mình.

Sáu ngày tuần này đi qua những người đã cùng mình làm việc trong năm 2026:

- Thứ Hai: ba điều biết ơn trong công việc năm nay.
- Thứ Ba: cảm ơn cụ thể một đồng nghiệp.
- Thứ Tư: cảm ơn một khách hàng hoặc đối tác.
- Thứ Năm 24.12: cảm ơn người âm thầm hỗ trợ.
- Thứ Sáu 25.12: nhìn lại hành trình của chính mình.
- Thứ Bảy: lá thư cảm ơn năm 2026 gửi cộng đồng.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Ba điều biết ơn trong công việc năm nay**

1. Mở sổ thực hành, xem lại thói quen đang giữ. Người mới thì viết câu bản sắc và thói quen của mình vào hai ô đầu trang.
2. Viết ba điều mình biết ơn trong công việc năm 2026. Mỗi điều nên gắn với một người, một cơ hội hoặc một bài học cụ thể, tránh viết chung chung như "đồng nghiệp tốt".
3. Chọn điều đáng nhớ nhất và viết một câu: điều đó đã thay đổi công việc của mình ra sao.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-1.

Chia sẻ hôm nay: "Ba điều tôi biết ơn trong công việc năm 2026: ...; ...; .... Điều đáng nhớ nhất: ...".

Tuần cuối năm thường bận, các anh chị và các bạn cứ làm bài vào lúc nào thuận tiện trong ngày nha. Ba dòng là đủ cho hôm nay.


## Bài 2: Ngày 2 (Thứ Ba 22/12)
@img 2_ba-phan
@pdf 10XHub_BietOn_PhieuNgay2_dong-nghiep.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: CẢM ƠN ĐÚNG NGƯỜI, ĐÚNG VIỆC

"Cảm ơn" là một trong những từ được nói nhiều nhất ở chỗ làm. Cũng vì nói nhiều nên nó dễ trôi qua. Hôm nay đi chậm lại, giải nghĩa từng phần của một lời cảm ơn có sức nặng.

**Cụ thể nghĩa là gì?**

Cụ thể là người nghe biết chính xác mình được cảm ơn vì việc nào. "Cảm ơn em đã hỗ trợ" là lịch sự. "Cảm ơn em đã ở lại tới 7 giờ để kiểm lại 40 đơn hàng giao Tết" là cụ thể. Câu sau cho người nghe biết việc của họ đã được nhìn thấy, và được nhìn thấy đúng.

**Tác động nghĩa là gì?**

Tác động là điều đã thay đổi nhờ việc đó: khách nhận hàng đúng hẹn, báo cáo nộp sớm một ngày, giám đốc không phải hỏi lại. Phần này hay bị bỏ quên nhất, vì người cảm ơn biết rõ tác động nên nghĩ người kia cũng biết. Thực tế, người làm ở khâu giữa của quy trình nhiều khi không thấy được kết quả cuối cùng.

**Vì sao một lời cảm ơn làm người ta muốn giúp tiếp?**

Năm 2010, Adam Grant và Francesca Gino công bố một loạt thí nghiệm về câu hỏi này. Trong một thí nghiệm, người tham gia góp ý cho thư xin việc của một sinh viên. Khi sinh viên đó gửi lại lời cảm ơn, 66% người tham gia nhận lời giúp thêm lần nữa, so với 32% ở nhóm không nhận được lời cảm ơn nào.

Ở một thí nghiệm khác với nhân viên gọi điện gây quỹ cho một trường đại học, nhóm được giám đốc đến cảm ơn trực tiếp đã tăng số cuộc gọi trong tuần sau đó thêm khoảng một nửa. Nhóm không được cảm ơn gần như giữ nguyên.

Grant và Gino giải thích rằng lời cảm ơn làm người giúp thấy mình có giá trị với người khác. Cảm giác đó khiến họ sẵn lòng giúp tiếp, kể cả giúp một người khác.

**Lớp mới của hành trình nghĩa là gì?**

Từ hôm nay, sau mỗi lần làm thói quen then chốt, thêm một lời cảm ơn cụ thể. Thói quen là lập kế hoạch đầu ngày thì cảm ơn người đã giúp việc quan trọng nhất hôm qua. Thói quen là gọi lại cho khách hàng thì cảm ơn đồng nghiệp đã chuẩn bị báo giá. Lời cảm ơn đặt ngay sau thói quen dùng chính thói quen làm tín hiệu, nên không cần nhớ thêm điều gì.

**Ngày 2 (15 phút)**

1. Chọn một đồng nghiệp đã giúp công việc của mình trong năm. Khi chia sẻ có thể ghi vai trò thay cho tên.
2. Viết lời cảm ơn đủ ba phần: ai, việc cụ thể, tác động. Gửi đi ngay hôm nay, nói trực tiếp hay nhắn đều được.
3. Chọn cách cảm ơn sẽ đi kèm thói quen then chốt từ nay, rồi bấm đánh dấu những ngày tuần này đã làm thói quen trên bảng hành trình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-2.

Chia sẻ hôm nay: "Hôm nay tôi cảm ơn ... vì đã .... Sau mỗi lần làm thói quen, tôi ...".


## Bài 3: Ngày 3 (Thứ Tư 23/12)
@img 3_nguoi-nhan
@pdf 10XHub_BietOn_PhieuNgay3_doi-tac.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: NGƯỜI NHẬN VUI HƠN MÌNH NGHĨ

Cuối năm, hộp thư của khách hàng và đối tác đầy thiệp chúc mừng. Phần lớn giống nhau: một hình đẹp, một câu chúc sức khoẻ và thành công, chữ ký của công ty. Hôm nay đặt hai cách làm cạnh nhau để thấy chỗ khác.

**Thiệp chúc chung và lời cảm ơn riêng**

- Gửi cho ai: thiệp chung gửi cả danh sách khách hàng. Lời cảm ơn riêng gửi một người.
- Nói về điều gì: thiệp chung nói về mùa lễ. Lời cảm ơn riêng nói về một việc cụ thể người đó đã làm cùng mình trong năm.
- Người nhận làm gì: thiệp chung thường được đọc trong vài giây. Lời cảm ơn riêng hay được đọc lại, có khi được chuyển cho cả nhóm của người nhận cùng xem.
- Mất bao lâu: thiệp chung mất vài giây cho mỗi người nhận. Lời cảm ơn riêng mất khoảng năm phút.

Hai cách đều có chỗ dùng. Nhưng chỉ cách sau cho đối tác biết họ đã làm được một điều có ý nghĩa với mình.

**Điều người viết nghĩ và điều người nhận cảm thấy**

Năm 2018, Amit Kumar và Nicholas Epley công bố trên tạp chí Psychological Science một loạt thí nghiệm về thư cảm ơn. Người tham gia viết thư cảm ơn gửi một người đã giúp mình, rồi đoán người nhận sẽ cảm thấy thế nào. Sau đó, nhóm nghiên cứu hỏi chính người nhận.

- Người viết đoán người nhận sẽ thấy hơi ngại. Người nhận cho biết họ ít ngại hơn nhiều so với dự đoán.
- Người viết lo câu chữ chưa hay. Người nhận chú ý đến sự chân thành nhiều hơn câu chữ.
- Người viết đoán người nhận vui ở mức vừa phải. Người nhận vui hơn rõ rệt so với dự đoán.

Kumar và Epley cho rằng chính khoảng cách giữa dự đoán và thực tế khiến nhiều người ngại nói lời cảm ơn, dù việc đó chỉ mất vài phút.

**Với khách hàng và đối tác**

Lời cảm ơn gửi khách hàng hay đối tác không cần là một lá thư dài. Ba câu là đủ: một việc cụ thể họ đã làm trong năm (thanh toán đúng hạn, góp ý thẳng thắn, giới thiệu thêm khách mới, linh hoạt khi bên mình giao chậm), điều đó giúp gì cho bên mình, và một lời chúc riêng cho năm tới. Lời cảm ơn nên tách riêng khỏi chuyện chào hàng, để người nhận hiểu đây chỉ là lời cảm ơn.

**Ngày 3 (20 phút)**

1. Chọn một khách hàng, nhà cung cấp hoặc đồng nghiệp ở bộ phận khác đã giúp mình trong năm 2026.
2. Trước khi viết, ghi dự đoán trên sổ: người nhận sẽ vui đến đâu, sẽ ngại đến đâu.
3. Viết ba câu cảm ơn và gửi đi. Khi người nhận trả lời, so với dự đoán của mình.

Hôm nay, lời cảm ơn này cũng có thể chính là lời cảm ơn đi kèm thói quen then chốt.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-3.

Chia sẻ hôm nay: "Đối tác tôi cảm ơn hôm nay: .... Điều tôi cảm ơn: ...".

Khi chia sẻ trong cộng đồng, các anh chị và các bạn ghi loại đối tác thay cho tên công ty để giữ thông tin của khách hàng nha.


## Bài 4: Ngày 4 (Thứ Năm 24/12)
@img 4_am-tham
@pdf 10XHub_BietOn_PhieuNgay4_am-tham.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CẢM ƠN NGƯỜI ÂM THẦM HỖ TRỢ

Hôm nay là 24.12, đêm Giáng sinh. Nhiều văn phòng đã treo đèn, có nơi tổ chức tiệc nhỏ cuối giờ. Giữa không khí đó, có những người vẫn làm đúng việc của mình như mọi ngày mà ít ai để ý. Ngày 4 dành cho họ.

Một danh sách để gợi nhớ, mỗi người kèm một việc thường bị xem là đương nhiên:

- Anh chị bảo vệ: mở cổng từ sáng sớm, nhớ biển số xe của khách quen, giữ hộ bưu phẩm khi mình đi vắng.
- Cô chú tạp vụ: phòng họp sạch trước 8 giờ, nước pha sẵn, bàn làm việc gọn gàng dù hôm trước mình để bừa.
- Bạn hỗ trợ kỹ thuật: khôi phục tệp bị xoá nhầm, cài lại máy ngay trước buổi thuyết trình.
- Lễ tân: đón khách thay mình khi mình còn trong phòng họp, nhớ tên khách quen.
- Anh chị giao nhận, tài xế: đưa hàng tới đúng hẹn trong những ngày đường đông nhất năm.
- Đồng nghiệp hành chính, kho, hậu cần: những người khiến mọi việc "tự nhiên chạy".
- Người trực ca trong kỳ nghỉ lễ: để hệ thống, nhà máy, tổng đài không dừng lại.

Lời cảm ơn cho những người này có hai điểm đáng lưu ý.

Điểm đầu tiên: nói đúng việc họ làm. "Cảm ơn chú" nghe dễ chịu. "Cảm ơn chú, sáng nào phòng họp cũng sẵn sàng trước khi khách tới" cho chú biết việc của mình đã được nhìn thấy.

Điểm còn lại: chọn cách hợp với người nhận. Có người thích được nói trực tiếp. Có người ngại đứng giữa nhiều người, khi đó một tấm thiệp nhỏ hay một lời nhắn tới quản lý của họ sẽ hợp hơn. Một ly nước, một phần bánh Giáng sinh mang tới tận chỗ cũng là một cách nói cảm ơn.

Ở Ngày 2, nghiên cứu của Grant và Gino cho thấy cảm giác mình có giá trị với người khác khiến người ta sẵn lòng giúp tiếp. Với những công việc ít khi được ghi nhận, cảm giác đó càng hiếm, nên một lời cảm ơn càng có ý nghĩa.

**Ngày 4 (15 phút)**

1. Chọn một người âm thầm hỗ trợ công việc của mình trong năm.
2. Viết ra một việc cụ thể họ làm mà ít ai thấy.
3. Cảm ơn họ trong hôm nay, theo cách hợp với họ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-4.

Chia sẻ hôm nay: "Ngày 24.12, tôi cảm ơn ... vì ...".

Chúc các anh chị và các bạn một buổi tối Giáng sinh ấm áp bên những người thân yêu nha.


## Bài 5: Ngày 5 (Thứ Sáu 25/12)
@img 5_hanh-trinh
@pdf 10XHub_BietOn_PhieuNgay5_hanh-trinh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: NGÀY GIÁNG SINH, NHÌN LẠI HÀNH TRÌNH CỦA MÌNH

Bốn ngày qua, lời cảm ơn đi ra ngoài: tới đồng nghiệp, khách hàng, những người âm thầm hỗ trợ. Hôm nay, ngày Giáng sinh, lời cảm ơn quay về một người ít khi được nhắc tới: chính mình, người đã giữ thói quen then chốt qua từng tuần của hành trình.

Hôm nay không có bài giảng, chỉ có sáu câu hỏi. Các anh chị và các bạn chọn ít nhất ba câu để trả lời, viết ngắn cũng được.

**1. Khi mới bắt đầu, thói quen của mình trông như thế nào?**

Mở sổ thực hành. Bảng ở Ngày 5 gom lại các lớp đã thêm cho thói quen qua từng tuần: câu bản sắc, giờ và chỗ, kế hoạch Nếu... thì..., khung giờ năng lượng, khối làm việc sâu, việc quan trọng nhất đầu ngày, kỹ năng đang luyện, nghi thức kết thúc ngày, cải tiến nhỏ nhất. Ô nào trống cũng không sao, mỗi người bước vào hành trình ở một thời điểm khác nhau.

**2. Tuần nào khó nhất, và điều gì đã giúp mình không bỏ?**

Có thể là một kế hoạch Nếu... thì... đã viết sẵn, một người cùng theo dõi, hay đơn giản là không muốn làm đứt chuỗi trên bảng hành trình.

**3. Có ngày nào rất bận mà mình vẫn làm? Hôm đó mình đã làm phiên bản nhỏ nhất nào?**

**4. Ai đã nhận ra thay đổi của mình, có khi trước cả mình?**

Một đồng nghiệp hỏi "dạo này sao báo cáo gửi sớm thế", một khách hàng nhận xét phản hồi nhanh hơn, một người quản lý giao thêm việc quan trọng.

**5. Điều mình tự hào nhất về chính mình trong hành trình này là gì?**

Không cần là một kết quả lớn. Một hành động mình đã chọn lặp lại, ngày này qua ngày khác, đã là điều đáng tự hào.

**6. Nếu viết một lời ghi nhận cho chính mình, mình sẽ viết gì?**

Phần nhìn lại này không nhằm chấm điểm. Khi nhìn lại, nhiều người dễ nhớ những ngày lỡ hơn những ngày làm được. Một trang ghi lại những ngày làm được giúp cân lại bức tranh, trước khi bước sang tuần cuối năm, tuần sẽ tổng kết cả năm 2026 bằng bảng hành trình.

**Ngày 5 (20 phút)**

1. Mở bảng tổng hợp hành trình ở Ngày 5 trên sổ thực hành.
2. Trả lời ít nhất ba trong sáu câu hỏi trên.
3. Viết một câu về điều mình tự hào nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-5.

Chia sẻ hôm nay: "Hành trình của tôi đến hôm nay: ... ngày giữ thói quen .... Điều tôi tự hào nhất: ...".

Giáng sinh an lành, các anh chị và các bạn nha.


## Bài 6: Ngày 6 (Thứ Bảy 26/12)
@img 6_la-thu
@img2 9_the-thanh-tich
@pdf 10XHub_BietOn_PhieuNgay6_la-thu.pdf (phiếu thực hành và bốn thiệp cảm ơn in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: LÁ THƯ CẢM ƠN NĂM 2026

Bài cuối của tuần Giáng sinh, Trường viết theo dạng một lá thư. Cuối bài là phần việc của Ngày 6, cũng là một lá thư.

Gửi các anh chị và các bạn trong cộng đồng 10X Excellence Hub,

Từ tháng 10, chúng ta bắt đầu một cách làm khác: mỗi người giữ một thói quen then chốt qua nhiều tuần, mỗi tuần thêm một lớp. Có tuần mọi người viết kế hoạch Nếu... thì... cho những ngày họp dồn. Có tuần mọi người dời thói quen vào khung giờ năng lượng tốt nhất, bảo vệ một khối làm việc sâu, làm việc khó nhất trước 10 giờ. Có tuần mọi người giảng lại cho đồng nghiệp điều mình học được, có tuần mọi người dựng lá chắn cho thói quen trước mùa cuối năm.

Trường cảm ơn những câu chia sẻ dưới mỗi bài, kể cả những câu chỉ có một dòng. Mỗi câu như vậy cho người mới thấy một thói quen trong công việc thật sự trông như thế nào.

Trường cảm ơn những chia sẻ về ngày lỡ. Nói ra một ngày mình chưa làm được cần nhiều can đảm hơn khoe một chuỗi dài, và chính những chia sẻ đó giúp cả nhóm học cách quay lại.

Trường cảm ơn những anh chị đã trả lời câu hỏi của người mới, đã gợi ý một phiên bản hai phút, một câu từ chối lịch sự, một cách đặt tín hiệu.

Hành trình này không thuộc về người viết công thức. Nó thuộc về những người lặp lại một việc nhỏ mỗi ngày làm việc, trong một năm có rất nhiều việc lớn.

Cảm ơn các anh chị và các bạn đã đi cùng nhau trong năm 2026.

Trường

**Ngày 6 (30 phút): Lá thư của mình**

Sáng nay (15 phút): mở sổ thực hành. Bảng ở Ngày 6 gom lại những lời cảm ơn trong tuần: điều đáng nhớ nhất năm, đồng nghiệp, đối tác, người âm thầm hỗ trợ, điều tự hào nhất và cách cảm ơn đi kèm thói quen. Đọc lại một lượt.

Trước khi nghỉ Chủ Nhật (15 phút): viết một lá thư cảm ơn năm 2026 gửi cộng đồng, gồm ba đoạn ngắn:

1. Một điều mình học được từ hành trình.
2. Một người hoặc một chia sẻ trong cộng đồng đã giúp mình.
3. Một điều mình mang theo sang năm 2027.

Đăng thư vào bình luận dưới bài này, kèm câu chia sẻ. Phiếu đính kèm còn có bốn thiệp cảm ơn in được, dùng cho những lời cảm ơn trực tiếp trong tuần tới.

Tuần sau là tuần chuyển năm. Công thức #0033 Sức mạnh thói quen sẽ tổng kết năm 2026 bằng bảng hành trình và cùng nhau quyết định thói quen then chốt cho năm 2027: giữ, nâng cấp hay đổi. Lời cảm ơn sau thói quen vẫn đi tiếp.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0032-ngay-6.

Chia sẻ hôm nay: "Gửi cộng đồng 10X Excellence Hub: .... Lời cảm ơn tôi mang sang năm mới: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Lòng biết ơn hiện ra, trông như một tấm thiệp, ghi tên mình và thói quen đang giữ. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Tuần sau là tuần cuối cùng của năm 2026.
