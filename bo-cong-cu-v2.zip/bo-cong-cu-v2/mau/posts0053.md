## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 17/05)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0053_Ban Do Tu Duy_VN.pdf (tài liệu đầy đủ của Công thức #0053)
@pdf 10XHub_BanDoTuDuy_PhieuNgay1_ban-do-dau-tien.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0053.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** CẢ BUỔI HỌC NẰM GỌN TRÊN MỘT TRANG GIẤY

Trộn nhiều dạng bài trong cùng 20 phút học, và chấp nhận rằng buổi học vì thế có cảm giác khó hơn: đó là điều cả nhóm đã làm suốt tuần Học xen kẽ và khó khăn có ích vừa qua. Cảm giác "chưa trơn tay" không còn bị xem là dấu hiệu học kém, mà là dấu hiệu bộ não đang phải làm việc thật. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Sau những tuần tập trung vào kỹ thuật học, tuần này chuyển sang một câu hỏi khác: học xong rồi, những gì vừa học nằm ở đâu? Công thức #0053 của tuần là Bản đồ tư duy.

**Nếu mới tham gia:** tuần này chỉ cần một tờ giấy trắng và một chủ đề mình đang muốn học thêm cho công việc, ví dụ đọc báo cáo tài chính, kỹ năng thuyết trình, hay một quy trình mới của công ty. Viết chủ đề đó và một thói quen nhỏ mỗi ngày vào Ngày 1 trên sổ thực hành, học 20 phút, rồi vẽ bản đồ đầu tiên cùng mọi người. Tuần này tự đứng được.

**Một bản đồ ra đời trên sóng truyền hình**

Năm 1974, đài BBC phát loạt chương trình "Use Your Head" do Tony Buzan, một tác giả người Anh viết về trí nhớ và cách học, dẫn dắt. Cuốn sách cùng tên ra đời cùng năm. Trong đó, Buzan giới thiệu một cách ghi chép mà ông gọi là Mind Map: chủ đề đặt ở giữa trang, các ý chính toả ra thành nhánh, mỗi nhánh mang một từ khoá, có màu và hình nhỏ đi kèm.

Cách vẽ những sơ đồ toả nhánh không phải do Buzan nghĩ ra đầu tiên. Nhưng chính ông là người đưa nó đến với rất nhiều người trong nhiều thập kỷ sau, từ lớp học đến phòng họp. Ở Việt Nam, cách ghi chép này thường được gọi là bản đồ tư duy.

**Bằng chứng nói gì?**

Bản đồ tư duy được giới thiệu rất nhiều, nhưng nghiên cứu kiểm chứng thì ít hơn và có kết quả khiêm tốn hơn lời giới thiệu. Có ba điểm đáng biết.

Một là, năm 2002, Paul Farrand và cộng sự ở Luân Đôn cho 50 sinh viên y khoa đọc một đoạn văn khoảng 600 chữ. Nhóm được hướng dẫn vẽ bản đồ tư duy nhớ được nhiều chi tiết hơn sau một tuần so với nhóm tự chọn cách học, mức chênh khoảng 10%. Cũng nhóm đó cho biết họ thấy kém hứng thú hơn với cách học mới.

Hai là, năm 2006, John Nesbit và Olusola Adesope tổng hợp 55 nghiên cứu về bản đồ khái niệm, một họ hàng gần của bản đồ tư duy, với hơn 5.800 người học. Dùng bản đồ đi kèm với nhớ tốt hơn, nhưng mức tác động khác nhau nhiều tuỳ cách dùng.

Ba là, và quan trọng nhất cho tuần này: năm 2011, Jeffrey Karpicke và Janell Blunt so sánh hai cách học trên tạp chí Science. Một tuần sau, nhóm tự viết lại những gì nhớ được làm bài tốt hơn nhóm vẽ bản đồ khái niệm trong lúc mở tài liệu. Tuần Truy hồi chủ động đã cho thấy điều này. Vì vậy, bản đồ của tuần này được vẽ theo một thứ tự riêng: vẽ từ trí nhớ trước, mở tài liệu ra bổ sung sau.

**Lớp mới của hành trình**

Thói quen then chốt vẫn là trục. Ngay sau nó là 20 phút học có chủ đích cho kỹ năng đã chọn ở tuần Học chuyên sâu tự định hướng, phục vụ dự án học của quý 2. Tuần này thêm một bước rất ngắn ở cuối: khoảng 5 phút gom buổi học lên một trang giấy, một trung tâm, vài nhánh, vài hình nhỏ.

Sau sáu ngày, mỗi người sẽ có vài bản đồ của chính kỹ năng mình đang học. Đó là bằng chứng cụ thể, nhìn thấy được, rằng mình đang tiến dần về phía phiên bản 10X của chính mình: không phải bằng một quyết tâm lớn, mà bằng từng trang giấy sau từng buổi học.

**Sáu ngày của tuần**

- Thứ Hai: bản đồ đầu tiên, một trung tâm và ba đến năm nhánh.
- Thứ Ba: đặt danh sách, bản đồ tư duy và bản đồ khái niệm cạnh nhau.
- Thứ Tư: phép thử vẽ lại từ trí nhớ.
- Thứ Năm: tóm một tài liệu công việc dài thành một trang.
- Thứ Sáu: chữ và hình, thêm ký hiệu riêng.
- Thứ Bảy: đặt các bản đồ cạnh nhau, chốt quy ước khép buổi học.

Chủ Nhật nghỉ.

**Ngày 1 (khoảng 25 phút): Bản đồ đầu tiên**

1. Mở sổ thực hành, xem lại thói quen đang giữ, kỹ năng và dự án học của quý.
2. Học 20 phút như mọi ngày.
3. Úp tài liệu xuống. Đặt một tờ giấy nằm ngang, viết chủ đề buổi học ở giữa trang, khoanh lại.
4. Vẽ ba đến năm nhánh chính toả ra, mỗi nhánh một từ khoá, không viết thành câu dài.

Hôm nay chưa cần đẹp, chưa cần màu. Chỉ cần trung tâm và các nhánh chính.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-1.

Chia sẻ hôm nay: "Bản đồ đầu tiên của tôi: trung tâm là ..., có ... nhánh chính.".

Chụp ảnh tờ giấy nếu muốn, nhưng không bắt buộc đăng lên. Bản đồ vẽ tay nguệch ngoạc vẫn là một bản đồ tốt, các anh chị và các bạn cứ thoải mái nha.


## Bài 2: Ngày 2 (Thứ Ba 18/05)
@img 2_dat-canh-nhau
@pdf 10XHub_BanDoTuDuy_PhieuNgay2_dat-canh-nhau.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: DANH SÁCH, BẢN ĐỒ TƯ DUY HAY BẢN ĐỒ KHÁI NIỆM?

Cùng một buổi đào tạo nội bộ về quy trình xử lý đơn hàng, ba người ghi lại theo ba cách. Hôm nay đặt ba trang ghi chép đó cạnh nhau để thấy mỗi cách mạnh ở đâu.

**Cách 1: danh sách dọc**

Ý này nối tiếp ý kia, từ trên xuống dưới, đúng thứ tự người giảng trình bày: nhận đơn, kiểm tra tồn kho, xác nhận giá, xuất kho, giao hàng, xuất hoá đơn.

- Mạnh ở: ghi nhanh, giữ đúng trình tự, dễ đọc lại khi cần làm theo từng bước.
- Yếu ở: mọi ý trông quan trọng như nhau, và rất khó thấy ý nào liên quan đến ý nào. Ví dụ, việc "xác nhận giá" ảnh hưởng ngược lại đến "kiểm tra tồn kho" khi có khuyến mãi, nhưng danh sách không cho thấy điều đó.

**Cách 2: bản đồ tư duy**

Chủ đề "xử lý đơn hàng" nằm giữa trang. Các nhánh chính toả ra: khách hàng, kho, giá, giao hàng, chứng từ. Mỗi nhánh có nhánh con.

- Mạnh ở: nhìn một lần thấy toàn cảnh, dễ thêm ý mới vào đúng chỗ, hợp để tóm một chủ đề và để ôn lại.
- Yếu ở: mọi liên kết đều đi từ trung tâm ra, nên quan hệ ngang giữa hai nhánh dễ bị bỏ qua nếu không chủ động vẽ thêm.

**Cách 3: bản đồ khái niệm**

Không có một trung tâm duy nhất. Các khái niệm nằm trong ô, nối với nhau bằng mũi tên, và trên mỗi mũi tên có một cụm từ nói rõ quan hệ: "tồn kho thấp → làm chậm → giao hàng", "khuyến mãi → thay đổi → giá". Cách này do Joseph Novak và cộng sự ở Đại học Cornell phát triển từ thập niên 1970.

- Mạnh ở: buộc mình nói rõ vì sao hai ý liên quan, rất hợp với kiến thức có nhiều quan hệ nhân quả.
- Yếu ở: mất thời gian hơn, cần luyện mới vẽ nhanh được.

**Chọn cách nào?**

Không có cách tốt nhất cho mọi việc. Cần làm theo từng bước thì danh sách là đủ. Cần nhìn toàn cảnh một chủ đề thì bản đồ tư duy. Cần hiểu vì sao điều này dẫn đến điều kia thì bản đồ khái niệm. Tuần này dùng chủ yếu bản đồ tư duy, nhưng mượn một điểm mạnh của bản đồ khái niệm: mỗi bản đồ có ít nhất một đường nối ngang giữa hai nhánh, kèm vài chữ nói rõ quan hệ.

**Ngày 2 (khoảng 25 phút)**

1. Học 20 phút cho kỹ năng đang học.
2. Tìm lại một trang ghi chép dạng danh sách gần đây (trang Cornell từ tuần #0049 rất hợp), chuyển sang một bản đồ tư duy.
3. Tìm một liên kết giữa hai nhánh mà danh sách không cho thấy, nối bằng một đường ngang và ghi vài chữ lên đường nối.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-2.

Chia sẻ hôm nay: "Chuyển ghi chép sang bản đồ, tôi thấy một liên kết mới: ... có liên quan đến ....".


## Bài 3: Ngày 3 (Thứ Tư 19/05)
@img 3_ve-tu-tri-nho
@pdf 10XHub_BanDoTuDuy_PhieuNgay3_ve-tu-tri-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: PHÉP THỬ VẼ LẠI BẢN ĐỒ TỪ TRÍ NHỚ

Hôm nay không đọc thêm lý thuyết. Hôm nay làm một phép thử nhỏ, mất khoảng 10 phút, với chính bản đồ đã vẽ hôm Thứ Hai hoặc Thứ Ba.

**Phép thử**

Bước 1. Úp bản đồ cũ và tài liệu xuống bàn, cất ra khỏi tầm mắt.

Bước 2. Lấy một tờ giấy mới. Đặt hẹn giờ 5 phút. Vẽ lại bản đồ đó từ trí nhớ: trung tâm, các nhánh chính, rồi nhánh con nào nhớ được thì thêm vào. Không nhìn trộm.

Bước 3. Hết giờ, lật bản đồ cũ lên. Dùng một bút màu khác (màu đỏ là dễ thấy nhất) bổ sung những nhánh mình đã quên.

Bước 4. Đếm hai con số: số nhánh nhớ được, số nhánh phải bổ sung bằng màu đỏ. Ghi lại nhánh hay quên nhất.

**Vì sao phải úp tài liệu xuống?**

Năm 2011, Karpicke và Blunt cho sinh viên đọc một đoạn văn khoa học rồi học theo hai cách: một nhóm vẽ bản đồ khái niệm trong lúc tài liệu vẫn mở, một nhóm cất tài liệu đi và tự viết lại những gì nhớ được. Một tuần sau, nhóm tự viết lại làm bài kiểm tra tốt hơn, kể cả khi bài kiểm tra yêu cầu vẽ bản đồ.

Ba năm sau, năm 2014, Janell Blunt và Jeffrey Karpicke thử một cách kết hợp: vẽ bản đồ khái niệm ngay từ trí nhớ, không nhìn tài liệu. Cách này cho kết quả tốt tương đương với tự viết lại. Nghĩa là vấn đề không nằm ở bản đồ, mà ở việc mình vẽ khi nhìn tài liệu hay vẽ bằng những gì đã nhớ.

Cũng cần nói rõ: năm 2023, một nhóm nghiên cứu ở Đức chỉ ra rằng một phần lợi thế trong nghiên cứu năm 2011 có thể đến từ thời gian ôn thêm của nhóm tự viết lại. Tranh luận khoa học vẫn đang tiếp tục. Điều khá vững là: tự lấy kiến thức ra từ trí nhớ là một trong những cách học được nghiên cứu nhiều và có kết quả tốt nhất.

**Đọc kết quả của mình thế nào?**

- Nhớ được phần lớn nhánh chính, quên nhiều nhánh con: rất bình thường. Nhánh chính là khung, nhánh con là chi tiết, và chi tiết luôn mờ nhanh hơn.
- Quên cả một nhánh chính: đánh dấu nhánh đó, đưa vào lịch ôn cách quãng như đã làm từ tuần Đường cong quên.
- Nhớ gần hết: tuyệt vời, lần sau thử vẽ lại sau ba ngày thay vì một ngày.

Những nhánh màu đỏ không phải điểm trừ. Chúng chính là bản đồ chỉ đường cho buổi học tiếp theo.

**Ngày 3 (khoảng 25 phút)**

1. Học 15 phút cho kỹ năng đang học.
2. Làm phép thử vẽ lại từ trí nhớ với bản đồ hôm trước, khoảng 10 phút.
3. Đánh dấu bảng hành trình trên sổ thực hành những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-3.

Chia sẻ hôm nay: "Vẽ lại từ trí nhớ, tôi nhớ được ... nhánh, phải bổ sung ... nhánh. Nhánh hay quên nhất: ....".


## Bài 4: Ngày 4 (Thứ Năm 20/05)
@img 4_mot-trang
@pdf 10XHub_BanDoTuDuy_PhieuNgay4_mot-trang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BỐN MƯƠI TRANG TÀI LIỆU, MỘT TRANG BẢN ĐỒ

**Một tình huống minh hoạ**

Chị Hạnh là chuyên viên mua hàng ở một công ty sản xuất bao bì. Kỹ năng chị chọn cho quý 2 là "đọc hiểu và đàm phán điều khoản hợp đồng mua hàng". Dự án học của chị: đến cuối tháng 6, tự rà được một hợp đồng mua nguyên liệu trước khi chuyển sang bộ phận pháp chế.

Đầu tuần, phòng pháp chế gửi bộ quy định mới về hợp đồng mua hàng, dài hơn 40 trang. Chị đã đọc hai lần trong 20 phút học mỗi sáng. Đến Thứ Tư, khi đồng nghiệp hỏi "điều khoản phạt chậm giao hàng giờ tính thế nào?", chị vẫn phải mở tài liệu ra tìm.

Thứ Năm, chị thử cách của tuần này. Chị úp tài liệu xuống, đặt tờ giấy nằm ngang, viết "Hợp đồng mua hàng" ở giữa. Chị vẽ được năm nhánh từ trí nhớ: giá, thanh toán, giao hàng, chất lượng, phạt vi phạm. Nhánh "thanh toán" có ba nhánh con. Nhánh "phạt vi phạm" chỉ có một chữ: "chậm giao".

Sau đó chị mở tài liệu ra. Chị bổ sung bằng màu đỏ: mức phạt theo ngày chậm, mức trần, trường hợp được miễn phạt. Chị nhận ra nhánh "chất lượng" và nhánh "phạt vi phạm" có liên quan: hàng không đạt chất lượng mà phải giao lại cũng tính vào thời gian chậm giao. Chị nối hai nhánh bằng một đường ngang và ghi "giao lại = tính chậm".

Bản đồ cuối cùng có năm nhánh chính, khoảng hai mươi từ khoá, một đường nối ngang. Chị kẹp nó vào bìa hồ sơ hợp đồng. Lần sau có người hỏi, chị nhìn bản đồ trước, mở tài liệu sau.

Tình huống trên là minh hoạ. Điều đáng chú ý là ba lựa chọn của chị Hạnh:

- Chọn một tài liệu phục vụ thẳng dự án học, không chọn tài liệu cho vui.
- Vẽ từ trí nhớ trước, mở tài liệu sau, như phép thử hôm qua.
- Giữ bản đồ ở đúng nơi sẽ cần đến nó, không để trong một tập giấy riêng.

**Một trang có giới hạn**

Một bản đồ tóm tài liệu dài dễ biến thành một trang chữ kín đặc. Ba giới hạn giúp nó vẫn là bản đồ:

- Tối đa bảy nhánh chính. Nhiều hơn thì gộp lại.
- Mỗi nhánh tối đa ba đến bốn từ. Câu dài là dấu hiệu mình đang chép, chưa phải đang tóm.
- Chừa khoảng trống. Khoảng trống là chỗ cho những gì sẽ học thêm.

**Ngày 4 (khoảng 30 phút)**

1. Chọn một tài liệu công việc dài phục vụ dự án học: quy trình, hợp đồng mẫu, báo cáo, tài liệu sản phẩm, quy chế.
2. Đọc lướt trong 15 phút. Úp xuống, vẽ bản đồ một trang từ trí nhớ.
3. Mở tài liệu, bổ sung bằng màu khác, thêm một đường nối ngang.
4. Cất bản đồ ở nơi sẽ dùng đến nó.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-4.

Chia sẻ hôm nay: "Tôi đã tóm tài liệu ... thành một bản đồ một trang, có ... nhánh chính.".


## Bài 5: Ngày 5 (Thứ Sáu 21/05)
@img 5_chu-va-hinh
@pdf 10XHub_BanDoTuDuy_PhieuNgay5_chu-va-hinh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: CHỮ VÀ HÌNH, HAI ĐƯỜNG VÀO TRÍ NHỚ

Buzan khuyên dùng màu và hình trên bản đồ. Lời khuyên đó có cơ sở, nhưng cơ sở ấy không nằm ở chỗ bản đồ phải đẹp. Hôm nay giải nghĩa năm khái niệm, để thêm hình vào bản đồ một cách có chủ đích.

**Mã hoá kép là gì?**

Allan Paivio, nhà tâm lý học người Canada, đề xuất thuyết mã hoá kép từ thập niên 1970 (cuốn "Imagery and Verbal Processes", 1971). Ý chính: bộ não xử lý thông tin qua hai hệ thống liên kết với nhau, một hệ cho lời nói và chữ viết, một hệ cho hình ảnh. Một ý được ghi lại bằng cả chữ và hình có hai đường để lấy ra khi cần nhớ, thay vì một.

Điều này giải thích vì sao những từ chỉ vật cụ thể, dễ hình dung ("máy in", "xe tải") thường dễ nhớ hơn những từ trừu tượng ("hiệu quả", "tuân thủ"). Với từ trừu tượng, một hình nhỏ do chính mình chọn giúp tạo thêm đường thứ hai.

**Từ khoá là gì?**

Từ khoá là một hoặc hai chữ đủ để gợi lại cả một ý. "Phạt chậm giao" là từ khoá. "Nếu nhà cung cấp giao chậm thì sẽ bị phạt theo số ngày" là một câu chép lại. Bản đồ tốt gồm toàn từ khoá, vì chính việc chọn từ khoá buộc mình phải hiểu ý trước khi viết.

**Hình nhỏ là gì?**

Hình nhỏ là một nét vẽ trong vài giây, không phải tranh. Một chiếc đồng hồ cho hạn chót, một dấu chấm than cho rủi ro, một ký hiệu tiền cho chi phí, một hình người cho khách hàng. Không cần vẽ đẹp. Điều quan trọng là hình do mình chọn, vì việc chọn hình là một lần nữa xử lý ý đó.

**Màu là gì?**

Màu dùng để phân lớp, không để trang trí. Ví dụ: mực đen cho những gì vẽ từ trí nhớ, mực đỏ cho những gì phải bổ sung khi mở tài liệu. Chỉ cần hai đến ba màu, mỗi màu một ý nghĩa cố định.

**Quy ước ký hiệu là gì?**

Quy ước ký hiệu là một bảng nhỏ ghi ý nghĩa của từng hình mình hay dùng, giữ nguyên qua mọi bản đồ. Khi quy ước ổn định, mỗi lần nhìn thấy ký hiệu là một lần nhớ lại ý nghĩa của nó mà không phải đọc chữ.

Một lưu ý cho đúng: thuyết mã hoá kép có nhiều bằng chứng với từ ngữ và hình ảnh cụ thể, nhưng không có nghĩa là thêm thật nhiều hình thì nhớ nhiều hơn. Vài hình đúng chỗ tốt hơn một trang đầy hình.

**Ngày 5 (khoảng 25 phút)**

1. Học 20 phút cho kỹ năng đang học, khép bằng một bản đồ từ trí nhớ như những ngày trước.
2. Thêm ba hình nhỏ vào bản đồ, ưu tiên cho các từ khoá trừu tượng nhất.
3. Viết quy ước ký hiệu của mình: ba đến năm hình hay dùng và ý nghĩa của chúng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-5.

Chia sẻ hôm nay: "Tôi thêm ... hình nhỏ vào bản đồ. Ký hiệu tôi dùng nhiều nhất: ....".


## Bài 6: Ngày 6 (Thứ Bảy 22/05)
@img 6_nhin-lai
@img2 9_the-thanh-tich
@pdf 10XHub_BanDoTuDuy_PhieuNgay6_khep-tuan.pdf (phiếu thực hành và trang quy ước bản đồ in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: ĐẶT CÁC BẢN ĐỒ CẠNH NHAU VÀ NHÌN LẠI

Sáng Thứ Bảy, các anh chị và các bạn thử lấy hết những bản đồ đã vẽ trong tuần, đặt cạnh nhau trên bàn. Bài hôm nay là năm câu hỏi mở. Không có câu trả lời đúng hay sai, chỉ có điều mình nhìn thấy trên chính những tờ giấy đó.

**Câu hỏi 1: Bản đồ nào mình thấy rõ ràng nhất, và vì sao?**

Có thể vì chủ đề quen, vì vẽ ngay sau buổi học, hay vì có một đường nối ngang làm cả bản đồ sáng ra. Gọi được lý do là đã có cách để lặp lại nó.

**Câu hỏi 2: Giữa bản đồ Thứ Hai và bản đồ hôm qua, điều gì đã khác?**

Số nhánh, độ ngắn của từ khoá, số hình nhỏ, tốc độ vẽ. Thay đổi nhỏ trong một tuần là điều rất đáng ghi nhận, vì nó cho thấy kỹ năng tóm ý cũng đang được luyện cùng với kỹ năng chính.

**Câu hỏi 3: Nhánh nào xuất hiện màu đỏ nhiều lần nhất?**

Nếu một nhánh tuần này cứ phải bổ sung lại, đó là phần kiến thức cần ôn thêm. Đưa nhánh đó vào lịch ôn cách quãng tuần sau.

**Câu hỏi 4: Đặt các bản đồ cạnh nhau, mình thấy kỹ năng đang học rõ hơn ở đâu?**

Câu này nhìn về dự án học của quý 2. Có khi chỉ sau một tuần, mình đã thấy dự án đang thiếu một mảng, hoặc hai mảng tưởng riêng rẽ lại nối với nhau. Đó là lúc điều chỉnh kế hoạch học cho tuần tới.

**Câu hỏi 5: Từ nay, mỗi buổi học sẽ khép lại như thế nào?**

Đây là câu quan trọng nhất của tuần. Ví dụ: "sau mỗi buổi 20 phút, 5 phút vẽ bản đồ từ trí nhớ, rồi bổ sung bằng mực đỏ"; hoặc "mỗi Thứ Sáu gom các ghi chép của tuần thành một bản đồ". Chọn cách vừa với nhịp làm việc của mình, vì cách nhỏ mà giữ được tốt hơn cách đầy đủ mà bỏ giữa chừng.

**Sáng nay (khoảng 25 phút)**

1. Đặt các bản đồ của tuần cạnh nhau, trả lời năm câu hỏi trên sổ thực hành.
2. Viết quy ước khép buổi học của mình. Quy ước này được lưu cho cả hành trình.
3. In trang quy ước bản đồ ở phiếu Ngày 6, kẹp cùng các bản đồ của tuần.

**Tuần sau: Phân loại Bloom**

Tuần này mỗi buổi học có một trang để nhìn toàn cảnh. Tuần sau đặt một câu hỏi khác cho chính trang đó: mình đang dừng ở mức nhớ và hiểu, hay đã vận dụng, phân tích, đánh giá được điều vừa học? Thói quen then chốt và 20 phút học tiếp tục là trục, các bản đồ của tuần này sẽ được dùng lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0053-ngay-6.

Chia sẻ hôm nay: "Tuần này tôi vẽ ... bản đồ cho kỹ năng .... Từ nay mỗi buổi học khép lại bằng: ....".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hiện ra: sáu cột cho sáu ngày trong tuần, cột nào đã làm thói quen thì tô đỏ và cao dần, dòng "6/6 NGÀY VẼ BẢN ĐỒ", tên mình và quy ước khép buổi học. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha, để bộ não có thời gian sắp xếp lại những gì đã học trong tuần. Hẹn gặp lại sáng Thứ Hai.
