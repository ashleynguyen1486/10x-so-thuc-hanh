## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 05/04)
@img 1_mo-mua-3
@pdf 10XHub_CongThuc_0047_Sieu Hoc_VN.pdf (tài liệu đầy đủ của Công thức #0047)
@pdf 10XHub_SieuHoc_PhieuNgay1_mo-mua-3.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0047.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MÙA 3 BẮT ĐẦU: MỖI NGÀY 20 PHÚT HỌC CÓ CHỦ ĐÍCH

Tuần trước, cả nhóm đã đặt năm mục tiêu lên bàn, hỏi lại từng mục tiêu bằng câu "nếu hôm nay bắt đầu lại", khép quý 1 vào Thứ Tư 31.03, mạnh dạn sửa hoặc dừng một mục tiêu, rồi viết lại năm mục tiêu cho quý 2. Thứ Bảy, Mùa 2 khép lại cùng một điều mỗi người giữ sang quý 2. Ngày 6 tuần trước vẫn mở lại được trên sổ thực hành.

Hôm nay mở Mùa 3 "Học nhanh, nhớ lâu", với Công thức #0047: Siêu học.

**Nếu mới tham gia:** mùa mới là điểm vào rất tự nhiên. Trên sổ thực hành Ngày 1, viết một câu "Tôi là người...", một việc nhỏ mình làm mỗi ngày trong công việc (đó sẽ là thói quen then chốt), rồi ghi ba kỹ năng muốn giỏi hơn trong quý 2. Các tuần tiếp theo của Mùa 3 đều dùng lại kỹ năng chọn ở tuần này, nên bắt đầu từ hôm nay là vừa khớp, không cần đọc lại hai mùa trước.

**Hai chặng đã đi, một chặng mới**

**Chặng 1, Mùa 1 (tháng 10 đến tháng 12.2026): xây một thói quen.** Mỗi người chọn một thói quen then chốt trong công việc, rồi thêm từng lớp: bản sắc, bốn quy luật, Nếu... thì..., việc sâu, luyện tập có chủ đích.

**Chặng 2, Mùa 2 (tháng 1 đến tháng 3.2027): cho thói quen một hướng đi.** Năm mục tiêu 2027, Kanban, đường cong quên, hộp thời gian, Sao Bắc Cực. Thói quen then chốt phục vụ mục tiêu số 1.

**Chặng 3, Mùa 3 (tháng 4 đến tháng 6.2027): thêm cho thói quen một năng lực.** Thói quen đã vững, mục tiêu đã rõ. Điều tiếp theo là năng lực đi cùng mọi mục tiêu: học điều mới đủ nhanh và nhớ đủ lâu để dùng được trong công việc.

Tiềm năng 10X không đến từ một bước nhảy. Nó được ghép từ những lớp nhỏ đặt chồng lên nhau, lớp sau đứng trên lớp trước. Mùa 3 là lớp thứ ba trên chính thói quen các anh chị và các bạn đã giữ suốt hai mùa qua.

**Lớp mới: 20 phút học có chủ đích, ngay sau thói quen then chốt**

Từ tuần này, ngay sau thói quen then chốt, thêm 20 phút học. Ví dụ: "Sau khi viết ba việc quan trọng nhất trước 8 giờ, tôi học 20 phút về cách đọc báo cáo tài chính của khách hàng." Đây là cách xếp chồng thói quen của Mùa 1: thói quen cũ là tín hiệu cho việc mới.

Có chủ đích nghĩa là 20 phút đó có một kỹ năng cụ thể, một phần việc cụ thể và một cách biết mình tiến bộ. Đọc lướt tin tức chuyên ngành chưa phải là học có chủ đích. Viết lại đoạn mở đầu một email chào hàng ba lần, rồi so với bản mẫu của trưởng nhóm, là học có chủ đích. Tuần #0027 Luyện tập có chủ đích đã đặt nền cho cách học này.

**Siêu học là gì?**

Siêu học là cách tuần này gọi khái niệm "ultralearning" trong cuốn sách cùng tên của Scott H. Young, xuất bản năm 2019. Young định nghĩa siêu học là một chiến lược để có kỹ năng và kiến thức, vừa tự định hướng vừa có cường độ cao. Cuốn sách gom lại chín nguyên tắc. Mùa 3 không theo cường độ trong các dự án tự học của tác giả, mà đặt các nguyên tắc đó vào nhịp vừa với người đi làm.

**Một kỹ năng, một dự án học, đến hết quý 2**

Tuần này chọn hai điều đi cùng cả mùa, với 20 phút mỗi ngày: một kỹ năng phục vụ mục tiêu đang giữ sau quý 1, và một dự án học nhỏ, tức một sản phẩm cụ thể dùng được trong công việc, xong trước 30.06. Các tuần sau, mỗi công thức mới sẽ được thử ngay trên kỹ năng và dự án này, và sổ thực hành lưu cả hai cho cả hành trình.

**Sáu ngày của tuần**

- Thứ Hai: chỗ đứng cho 20 phút học, ba kỹ năng ứng viên.
- Thứ Ba: bảng chọn, giữ lại một kỹ năng.
- Thứ Tư: vẽ bản đồ cho kỹ năng đã chọn.
- Thứ Năm: chín nguyên tắc và dự án học của quý 2.
- Thứ Sáu: buổi 20 phút có chủ đích đầu tiên.
- Thứ Bảy: lá thư gửi mình ngày 30.06.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Chỗ đứng cho 20 phút học**

1. Mở sổ thực hành, xem lại thói quen đang giữ và điều giữ sang quý 2.
2. Chọn chỗ đặt 20 phút học: ngay sau thói quen then chốt, hoặc một khung giờ cố định khác.
3. Viết ba kỹ năng muốn giỏi hơn trong quý 2, mỗi kỹ năng gắn với một mục tiêu đang giữ.
4. Đặt 20 phút đó vào lịch cho cả tuần.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-1.

Chia sẻ hôm nay: "Mùa 3, tôi thêm 20 phút học có chủ đích sau thói quen then chốt. Ba kỹ năng tôi đang cân nhắc: ..., ..., ...".

Hôm nay chưa cần chọn đúng ngay, các anh chị và các bạn cứ viết ra những kỹ năng mình thật sự muốn có, ngày mai mình cùng chọn nha.


## Bài 2: Ngày 2 (Thứ Ba 06/04)
@img 2_chon-ky-nang
@pdf 10XHub_SieuHoc_PhieuNgay2_chon-ky-nang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: BẢNG CHỌN MỘT KỸ NĂNG CHO CẢ QUÝ 2

Ba kỹ năng nằm trên sổ, nhưng chỉ một kỹ năng nhận 20 phút mỗi ngày trong mười hai tuần tới. Chọn một là có chủ ý: Young gọi nguyên tắc này là tập trung, và tuần Quy tắc 5/25 đầu năm cũng cho thấy giữ ít thì đi được xa hơn. Hôm nay là một bảng chọn với ba tiêu chí, mỗi tiêu chí chấm từ 1 đến 5.

**Tiêu chí 1: Kỹ năng này phục vụ mục tiêu đang giữ đến mức nào?**

5 điểm khi giỏi kỹ năng này thì mục tiêu số 1 tiến rõ. 1 điểm khi kỹ năng hay nhưng gần như không chạm tới năm mục tiêu của quý 2.

**Tiêu chí 2: Mình có dùng nó trong công việc hằng tuần không?**

5 điểm khi tuần nào cũng có ít nhất một tình huống thật để dùng. Đây là nguyên tắc trực tiếp của Young: học gần với chỗ sẽ dùng thì dễ đưa vào việc hơn. Kỹ năng chỉ dùng mỗi năm một lần thì khó luyện trong 20 phút mỗi ngày.

**Tiêu chí 3: Trong mười hai tuần, mình có thấy được tiến bộ không?**

5 điểm khi có cách đo rõ (thời gian làm, số lỗi, phản hồi của khách hàng) hoặc có người đủ giỏi để góp ý. Người góp ý từ tuần #0027, nếu đã ghi trên sổ, sẽ hiện lại ở Thứ Sáu.

**Bảng chọn mẫu của một trưởng nhóm kinh doanh**

- Đàm phán giá với khách hàng doanh nghiệp: 5 + 4 + 3 = 12 điểm.
- Đọc báo cáo tài chính của khách hàng: 4 + 2 + 3 = 9 điểm.
- Trình bày đề xuất bằng tiếng Anh: 3 + 2 + 4 = 9 điểm.

Kỹ năng được chọn: đàm phán giá. Hai kỹ năng còn lại vào danh sách học sau, để xem lại vào cuối quý 2. Bảng chỉ mang tính minh hoạ, nhưng cho thấy một điều hay gặp: kỹ năng nghe hấp dẫn nhất chưa chắc là kỹ năng dùng nhiều nhất.

**Ba lưu ý khi chọn**

- **Hai kỹ năng bằng điểm:** chọn kỹ năng gần mục tiêu số 1 hơn.
- **Kỹ năng quá rộng:** thu hẹp lại. "Tiếng Anh" thành "trình bày một đề xuất 5 phút bằng tiếng Anh". "Quản lý" thành "giao việc rõ ràng cho nhân viên mới".
- **Kỹ năng do công ty yêu cầu:** vẫn chấm như bình thường. Thường kỹ năng này được điểm cao ở tiêu chí 1 và 2, và đó là một lựa chọn rất tốt.

**Ngày 2 (20 phút)**

1. Chấm ba kỹ năng đã viết hôm qua theo ba tiêu chí, mỗi tiêu chí từ 1 đến 5.
2. Chọn kỹ năng có tổng điểm cao nhất, thu hẹp lại nếu còn rộng.
3. Viết một câu vì sao kỹ năng này đáng 20 phút mỗi ngày của quý 2.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-2. Kỹ năng đã chọn được lưu cho cả hành trình.

Chia sẻ hôm nay: "Kỹ năng tôi chọn cho quý 2: .... Vì: ...".


## Bài 3: Ngày 3 (Thứ Tư 07/04)
@img 3_ve-ban-do
@pdf 10XHub_SieuHoc_PhieuNgay3_ve-ban-do.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: VẼ BẢN ĐỒ TRƯỚC KHI BẮT ĐẦU HỌC

Nguyên tắc đầu tiên của Young là siêu học trước: trước khi lao vào học, dành một ít thời gian tìm hiểu xem kỹ năng này gồm những phần nào và người giỏi đã học nó ra sao. Young gợi ý dành khoảng 10% tổng thời gian dự kiến cho bước này. Với 20 phút mỗi ngày, sáu ngày mỗi tuần, mười hai tuần, tổng thời gian là khoảng 24 giờ, nên phần vẽ bản đồ vào khoảng hai giờ rưỡi, chia ra vài buổi trong tuần này.

Bản đồ trả lời ba câu hỏi: Vì sao học (đã viết hôm qua), Học những gì, và Học bằng cách nào. Phần "những gì" được chia thành ba loại: khái niệm cần hiểu, dữ kiện cần nhớ, quy trình cần luyện tay. Dưới đây là ba bản đồ làm mẫu.

**Bản đồ 1: Kế toán tổng hợp, kỹ năng "lập báo cáo dòng tiền hằng tuần cho ban giám đốc"**

- Khái niệm: ba dòng tiền hoạt động, đầu tư, tài chính; khác biệt giữa lợi nhuận và tiền.
- Dữ kiện: các khoản mục chính, tài khoản liên quan, hạn chốt số mỗi tuần.
- Quy trình: lấy số từ sổ phụ ngân hàng, đối chiếu, dựng bảng, viết ba dòng nhận xét.
- Học bằng cách nào: một báo cáo mẫu của kế toán trưởng, mỗi tuần dựng một bản và nhờ góp ý.

Phần nặng nhất: quy trình. Vậy 20 phút mỗi ngày nên dành phần lớn cho luyện tay trên số liệu thật.

**Bản đồ 2: Chăm sóc khách hàng, kỹ năng "xử lý cuộc gọi khiếu nại khó"**

- Khái niệm: vì sao khách hàng cần được nghe trước khi nghe giải pháp.
- Dữ kiện: chính sách đổi trả, thời hạn, quyền xử lý của từng cấp.
- Quy trình: bốn bước nghe, xác nhận, đề xuất, chốt.
- Học bằng cách nào: nghe lại các cuộc gọi được trưởng ca chọn làm mẫu (theo quy định của công ty), luyện đóng vai với đồng nghiệp.

Phần nặng nhất: dữ kiện. 20 phút đầu nên dành cho việc tự kiểm tra chính sách cho đến khi trả lời được không cần nhìn.

**Bản đồ 3: Kỹ thuật bảo trì, kỹ năng "đọc bản vẽ điện của dây chuyền mới"**

- Khái niệm: sơ đồ nguyên lý khác sơ đồ lắp đặt ở đâu.
- Dữ kiện: các ký hiệu thường gặp, mã thiết bị.
- Quy trình: lần theo một mạch từ nguồn tới thiết bị.
- Học bằng cách nào: bộ bản vẽ của nhà cung cấp, hỏi kỹ sư đã lắp đặt.

Phần nặng nhất: khái niệm. Mỗi buổi nên kết thúc bằng việc tự giải thích lại một mạch bằng lời của mình, như kiểu Feynman ở tuần #0028.

**Vì sao cần biết phần nào nặng nhất?**

Vì mỗi loại cần một cách học khác. Dữ kiện cần tự kiểm tra và ôn cách quãng. Quy trình cần làm đi làm lại. Khái niệm cần giải thích và ví dụ. Biết phần nặng nhất là biết 20 phút nên dành cho việc gì.

**Ngày 3 (20 phút)**

1. Ghi hai đến ba khái niệm, dữ kiện, quy trình của kỹ năng mình đã chọn.
2. Chọn phần nặng nhất.
3. Chọn một nguồn học chính và một người giỏi có thể hỏi.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-3.

Chia sẻ hôm nay: "Bản đồ kỹ năng ...: phần nặng nhất là .... Nguồn học chính: ...".


## Bài 4: Ngày 4 (Thứ Năm 08/04)
@img 4_chin-nguyen-tac
@pdf 10XHub_SieuHoc_PhieuNgay4_chin-nguyen-tac.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: CHÍN NGUYÊN TẮC VÀ MỘT DỰ ÁN HỌC

Hôm nay là danh sách chín nguyên tắc của siêu học, mỗi nguyên tắc một dòng giải nghĩa và một chỗ gặp lại trên hành trình của chúng ta. Đọc xong, đánh dấu những nguyên tắc mình đang làm, rồi đặt tên cho dự án học của quý 2.

**Chín nguyên tắc**

1. **Siêu học trước.** Vẽ bản đồ trước khi học. Đã làm hôm qua.
2. **Tập trung.** Hai mươi phút cho đúng một việc, tắt thông báo. Gặp lại tuần #0025 Việc sâu.
3. **Trực tiếp.** Học bằng chính việc sẽ làm, trong hoàn cảnh gần với hoàn cảnh sẽ dùng. Dự án học bên dưới là cách giữ nguyên tắc này.
4. **Luyện riêng.** Tách phần yếu nhất ra luyện riêng. Gặp lại tuần #0027 Luyện tập có chủ đích.
5. **Truy hồi.** Tự kiểm tra thay vì đọc lại. Đây là chủ đề của tuần sau.
6. **Phản hồi.** Tìm người góp ý sớm, kể cả khi góp ý khó nghe.
7. **Ghi nhớ.** Ôn cách quãng để điều đã học không trôi đi. Gặp lại lịch ôn ở tuần #0040.
8. **Trực giác.** Hiểu sâu bằng cách tự giải thích và tìm ví dụ, trước khi học thuộc. Gặp lại tuần #0028 Feynman.
9. **Thử nghiệm.** Khi đã vững cơ bản, thử cách làm khác và so sánh xem cách nào hiệu quả hơn.

Nguyên tắc 5, 7 và 8 có nhiều nghiên cứu về trí nhớ và học tập đứng sau. Các nguyên tắc còn lại là kinh nghiệm được Young tổng hợp. Mùa 3 sẽ đi sâu vào từng nhóm.

**Dự án học là gì?**

Dự án học là một sản phẩm cụ thể, dùng được trong công việc thật, mà mình làm ra trong lúc học. Nó giữ cho 20 phút mỗi ngày gắn với việc thật, đúng nguyên tắc trực tiếp. Một dự án học tốt có bốn đặc điểm:

- Có sản phẩm nhìn thấy được: một bộ kịch bản, một bảng tính, một quy trình viết ra, một bài thuyết trình.
- Dùng cho một việc thật, có người nhận hoặc người dùng.
- Xong trước 30.06.2027, ngày cuối của quý 2.
- Chia được thành những bước vừa 20 phút.

Câu mẫu: "Trước 30.06, tôi hoàn thành [sản phẩm], dùng cho [việc thật]."

Ví dụ: "Trước 30.06, tôi hoàn thành bộ kịch bản đàm phán cho ba tình huống khách hàng đề nghị giảm giá, dùng thử với hai khách hàng doanh nghiệp." Hay: "Trước 30.06, tôi hoàn thành mẫu báo cáo dòng tiền tuần, dùng cho cuộc họp giao ban sáng Thứ Hai."

**Ngày 4 (20 phút)**

1. Đánh dấu những nguyên tắc mình đang làm khi học.
2. Chọn hai nguyên tắc muốn làm tốt hơn trong quý 2.
3. Viết câu dự án học theo câu mẫu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-4. Dự án học được lưu cho cả hành trình.

Chia sẻ hôm nay: "Dự án học quý 2 của tôi: .... Hai nguyên tắc tôi muốn làm tốt hơn: ...".

Dự án nhỏ mà xong vẫn tốt hơn dự án lớn mà dở dang, các anh chị và các bạn cứ chọn vừa sức với 20 phút mỗi ngày nha.


## Bài 5: Ngày 5 (Thứ Sáu 09/04)
@img 5_buoi-hoc-dau
@pdf 10XHub_SieuHoc_PhieuNgay5_buoi-hoc-dau.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: HAI BUỔI 20 PHÚT, MỘT BUỔI CÓ CHỦ ĐÍCH

Cùng một người, cùng một kỹ năng, cùng 20 phút. Hôm nay đặt hai buổi học cạnh nhau để thấy khác biệt nằm ở đâu. Người trong ví dụ là một chuyên viên nhân sự đang học kỹ năng phỏng vấn theo hành vi, với dự án học là bộ câu hỏi phỏng vấn cho vị trí trưởng ca.

**Buổi A: 20 phút trôi qua**

- Phút 0 đến 5: mở thư mục tài liệu, phân vân nên đọc bài nào.
- Phút 5 đến 15: đọc lại bài viết về các câu hỏi phỏng vấn, thấy quen, gật gù.
- Phút 15 đến 20: trả lời một tin nhắn vừa đến, rồi đóng máy.

Cuối buổi, cảm giác là đã học. Nhưng không có gì mới được viết ra, không có phần nào được thử, và không biết buổi sau làm gì.

**Buổi B: 20 phút có chủ đích**

- Phút 0 đến 2: mở bản đồ kỹ năng, chọn đúng một phần: đặt câu hỏi đào sâu sau câu trả lời đầu tiên của ứng viên.
- Phút 2 đến 12: luyện riêng phần đó. Viết năm câu hỏi đào sâu cho hai câu trả lời mẫu.
- Phút 12 đến 17: tự kiểm tra. Đóng tài liệu, viết lại cấu trúc một câu hỏi theo hành vi gồm những phần nào.
- Phút 17 đến 20: ghi một dòng gồm điều đã làm được, điều còn vướng, buổi sau làm gì, rồi nhắn hỏi trưởng phòng một câu.

**Bốn khác biệt**

- **Một phần nhỏ, không phải cả kỹ năng.** Buổi B biết chính xác mình luyện phần nào.
- **Làm ra một điều.** Năm câu hỏi đào sâu là một mảnh của dự án học.
- **Tự kiểm tra trước khi đóng máy.** Phút 12 đến 17 cho biết điều gì đã nhớ, điều gì chưa.
- **Có phản hồi và có bước tiếp theo.** Một câu hỏi gửi người giỏi, một dòng cho buổi sau.

Buổi A không sai, ai cũng có những buổi như vậy. Chỉ cần biết rằng cảm giác quen mắt khi đọc lại dễ khiến mình nghĩ là đã học được nhiều hơn thực tế. Tuần sau sẽ nói kỹ về điều này.

**Ngày 5 (20 phút)**

1. Làm một buổi kiểu B với kỹ năng của mình, dùng đồng hồ trên sổ thực hành.
2. Ghi một dòng: điều đã làm được, điều còn vướng, buổi sau làm gì.
3. Xem lại người góp ý trên sổ, gửi họ một câu hỏi ngắn nếu được.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-5.

Chia sẻ hôm nay: "Buổi 20 phút đầu tiên, tôi luyện: .... Buổi sau: ...".


## Bài 6: Ngày 6 (Thứ Bảy 10/04)
@img 6_thu-gui-quy-2
@img2 9_the-thanh-tich
@pdf 10XHub_SieuHoc_PhieuNgay6_thu-gui-quy-2.pdf (phiếu thực hành và bản đồ dự án học in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: LÁ THƯ GỬI MÌNH NGÀY 30.06.2027

Hôm nay viết một lá thư ngắn gửi chính mình, người sẽ mở nó vào ngày 30.06, ngày cuối của quý 2. Lá thư giữ lại điều mình đã chọn trong tuần này: một kỹ năng, một dự án học, 20 phút mỗi ngày sau thói quen then chốt. Gần mười hai tuần nữa, đọc lại lá thư là cách nhìn rõ quãng đường mình đã đi.

**Một lá thư mẫu**

Dưới đây là thư mẫu của một trưởng nhóm kinh doanh, viết theo ngôi "tôi" như cách các anh chị và các bạn sẽ viết cho mình.

"Gửi tôi ngày 30.06.2027,

Hôm nay là Thứ Bảy 10.04. Tôi vừa chọn kỹ năng đàm phán giá với khách hàng doanh nghiệp, vì mục tiêu số 1 của quý 2 là giữ biên lợi nhuận ở các hợp đồng gia hạn. Dự án học của tôi là bộ kịch bản cho ba tình huống khách hàng đề nghị giảm giá, dùng thử với hai khách hàng.

Mỗi sáng, sau khi viết ba việc quan trọng nhất, tôi học 20 phút. Tôi biết sẽ có tuần bận và tuần quên. Khi đó, tôi sẽ học năm phút thay vì bỏ hẳn.

Khi đọc thư này, tôi mong mình đã dùng kịch bản ít nhất một lần trong một cuộc gọi thật, và biết rõ phần nào còn cần luyện tiếp."

**Ba phần của một lá thư**

- **Hôm nay mình chọn gì và vì sao.** Kỹ năng, dự án học, mục tiêu được phục vụ.
- **Mình sẽ giữ nhịp thế nào.** Chỗ đứng của 20 phút, phiên bản tối thiểu cho tuần bận.
- **Mình mong thấy điều gì vào 30.06.** Một việc cụ thể làm được, không phải một con số kết quả.

**Các tuần tiếp theo của Mùa 3**

Kỹ năng và dự án học hôm nay sẽ đi qua các nhóm công thức: kỹ thuật học có bằng chứng, ghi chép và tổ chức kiến thức, nâng tầng hiểu và tự đánh giá, rồi chia sẻ điều đã học. Mùa 3 khép lại vào đầu tháng 7, ngay sau ngày mở thư. Bản đồ dự án học ở phiếu Ngày 6 có sẵn mười hai ô tuần, từ #0047 đến #0058, để ghi lại từng bước.

**Sáng nay (15 phút)**

1. Đọc lại bảng gom tuần này trên sổ thực hành: kỹ năng, dự án học, chỗ đứng của 20 phút.
2. Viết lá thư năm đến bảy câu theo ba phần trên.

**Trước khi nghỉ Chủ Nhật (10 phút)**

In bản đồ dự án học ở phiếu Ngày 6, điền kỹ năng, dự án và các bước dự kiến, kẹp vào sổ kế hoạch cạnh trang tổng kết Mùa 2. Nếu thích, gấp lá thư lại và ghi ngoài bìa "Mở ngày 30.06".

**Tuần sau: Truy hồi chủ động**

Từ Thứ Hai 12.04, 20 phút học sẽ được làm cho hiệu quả hơn bằng một thay đổi nhỏ: bớt đọc lại, thêm tự kiểm tra.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0047-ngay-6.

Chia sẻ hôm nay: "Kỹ năng quý 2: .... Dự án học: .... Gửi tôi ngày 30.06: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích mở Mùa 3 hiện ra: các bậc thang đi lên, chữ MÙA 3 lớn, dòng "BẢN ĐỒ HỌC ĐÃ VẼ", tên mình và kỹ năng của quý 2. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Một mùa mới đã bắt đầu, và các anh chị và các bạn đã có bản đồ cho cả quý 2. Hẹn gặp lại sáng Thứ Hai.
