## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 30/11)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0029_Tien Lieu That Bai_VN.pdf (tài liệu đầy đủ của Công thức #0029)
@pdf 10XHub_TienLieu_PhieuNgay1_hinh-dung.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0029.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi thư điện tử cho cả nhóm

**Tiêu đề bài trên Skool:** NẾU THÓI QUEN DỪNG LẠI, LÝ DO SẼ LÀ GÌ?

*Thứ Bảy, 31.01.2027. Còn khoảng một tuần nữa là Tết Nguyên đán. Mở sổ thực hành ra, bảng hành trình dừng ở giữa tháng 12. Không có ngày nào đáng nhớ, cũng không có quyết định bỏ cuộc nào. Chỉ là một tuần tất niên dày lịch, rồi một chuyến công tác, rồi một kỳ nghỉ, và thói quen lặng lẽ biến mất.*

Đoạn trên là một trang nhật ký chưa ai viết. Tuần này, cả nhóm sẽ viết nó trước, để nó không bao giờ phải xảy ra.

Tuần trước, cả nhóm đã thử giảng lại cho một đồng nghiệp một điều mình học được trên hành trình, bằng lời đơn giản nhất có thể. Khi phải giải thích cho người khác, mình thường mới thấy chỗ nào mình hiểu thật, chỗ nào mình chỉ nghĩ là hiểu. Tuần này dùng đúng tinh thần đó, nhưng soi vào tương lai: tìm chỗ yếu của thói quen trước khi chỗ yếu đó tự lộ ra.

**Nếu mới tham gia:** không cần đọc lại các tuần trước. Hôm nay chỉ cần chọn một việc nhỏ mình muốn làm mỗi ngày làm việc, ví dụ viết ba việc quan trọng nhất trước 8 giờ, rồi viết nó vào ô "Thói quen đang giữ" trên sổ thực hành. Cả tuần sẽ giúp mình bảo vệ chính việc đó qua tháng 12.

**Vì sao lại nói về thất bại vào đầu tháng 12?**

Tháng 12 là tháng có nhiều lý do chính đáng nhất để tạm dừng một thói quen. Họp tổng kết năm, chốt số liệu, tiệc tất niên với khách hàng và đối tác, rồi những ngày nghỉ cuối năm. Mỗi lý do riêng lẻ đều hợp lý. Cộng lại, chúng đủ sức xoá sạch một thói quen đã giữ suốt hai tháng qua.

Phần lớn kế hoạch chỉ viết theo chiều thuận: làm gì, khi nào, ở đâu. Nhà tâm lý học Gary Klein đề nghị viết thêm chiều ngược, gọi là phân tích tiền nghiệm. Trong bài viết trên Harvard Business Review năm 2007, ông mô tả cách làm cho các nhóm dự án: trước khi bắt đầu, cả nhóm hình dung dự án đã thất bại, rồi mỗi người viết ra lý do vì sao nó thất bại. Điểm mấu chốt nằm ở cách đặt câu hỏi. Không hỏi "điều gì có thể sai?", mà nói "dự án đã thất bại, hãy giải thích vì sao".

Klein dựa trên một nghiên cứu năm 1989 của Deborah Mitchell, Jay Russo và Nancy Pennington về "hồi tưởng giả định". Khi người tham gia hình dung một sự kiện như đã chắc chắn xảy ra, họ nêu được nhiều lý do giải thích hơn, khoảng 30%, so với khi chỉ cân nhắc rằng nó có thể xảy ra. Cần nói rõ: nghiên cứu này đo số lượng lý do, không đo độ chính xác của lý do. Nhưng với một thói quen, có thêm vài lý do được nhìn thấy sớm đã là một lợi thế lớn.

**Sáu ngày, một lá chắn**

- Thứ Hai: hình dung ngày 31.01.2027 thói quen đã dừng, viết lý do.
- Thứ Ba: xếp hạng các lý do theo khả năng xảy ra và mức ảnh hưởng.
- Thứ Tư: soạn biện pháp cho ba rủi ro lớn nhất.
- Thứ Năm: lên kế hoạch riêng cho những tuần tất niên dày lịch.
- Thứ Sáu: chọn người nhắc và một tín hiệu cảnh báo sớm.
- Thứ Bảy: gom tất cả vào một lá chắn cuối năm.

Chủ Nhật nghỉ, hoặc làm bù ngày còn thiếu.

**Ngày 1 (25 phút): Viết trang nhật ký chưa xảy ra**

1. Mở sổ thực hành, kiểm tra dòng "Thói quen đang giữ". Ai mới tham gia thì điền câu bản sắc và thói quen của mình vào hai ô ngay bên dưới.
2. Đọc chậm câu này: "Hôm nay là 31.01.2027. Thói quen của tôi đã dừng từ giữa tháng 12."
3. Viết ít nhất năm lý do vì sao nó dừng. Viết như đang kể lại một việc đã xảy ra, không viết "có thể". Ví dụ: "Tuần 21.12 tôi có ba buổi tiệc tối liên tiếp, sáng nào cũng đến muộn và bỏ phiên làm việc sâu."
4. Viết cả những lý do nghe có vẻ nhỏ. Thói quen thường dừng vì những điều rất bình thường: đổi chỗ ngồi, máy tính mang đi sửa, một dự án gấp.

Một lưu ý quan trọng: bài tập này không nhằm dự đoán điều xấu. Nó giúp mình nhìn rõ con đường trước mặt, để những tuần cuối năm 2026 trở thành những tuần thói quen được giữ chắc nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-1.

Chia sẻ hôm nay: "Thói quen tôi đang bảo vệ: .... Nếu nó dừng trước 31.01.2027, lý do dễ xảy ra nhất là: ...". Bình luận kèm câu này để cả nhóm cùng bắt đầu tuần lá chắn nha.


## Bài 2: Ngày 2 (Thứ Ba 01/12)
@img 2_xep-hang
@pdf 10XHub_TienLieu_PhieuNgay2_xep-hang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: RỦI RO NÀO ĐÁNG LO NHẤT?

Hôm nay là ngày đầu tiên của tháng 12. Năm 2026 còn đúng một tháng, và danh sách lý do viết hôm qua là nguyên liệu để chuẩn bị cho tháng đó.

Năm lý do không quan trọng như nhau. Có lý do gần như chắc chắn sẽ đến, như tiệc tất niên. Có lý do ít khi xảy ra nhưng nếu xảy ra thì thói quen dừng hẳn, như một chuyến công tác dài ngày. Hôm nay xếp hạng chúng bằng một bảng chọn hai chiều.

**Chiều thứ nhất: khả năng xảy ra trong tháng 12 và tháng 1**

- Thấp: khó xảy ra, hoặc chỉ xảy ra một lần ngắn. Ví dụ: máy tính hỏng.
- Vừa: có thể xảy ra vài lần. Ví dụ: một buổi họp đột xuất buổi sáng.
- Cao: gần như chắc chắn, đã có trong lịch hoặc năm nào cũng gặp. Ví dụ: tuần chốt số liệu cuối năm.

**Chiều thứ hai: mức ảnh hưởng nếu xảy ra**

- Nhẹ: lỡ một ngày, hôm sau làm lại được ngay.
- Vừa: lỡ vài ngày, cần cố gắng để quay lại.
- Nặng: có thể làm thói quen dừng hẳn, mất cả chuỗi.

**Đặt các lý do vào bảng**

Ghép hai chiều lại, mỗi lý do rơi vào một ô. Ba nhóm cần chú ý theo thứ tự:

1. Khả năng cao, ảnh hưởng nặng: ưu tiên số một, cần biện pháp ngay trong tuần này.
2. Khả năng cao, ảnh hưởng vừa; hoặc khả năng vừa, ảnh hưởng nặng: cần một phương án soạn sẵn.
3. Các ô còn lại: chỉ cần nhận biết, chưa cần làm gì thêm.

Lấy ví dụ một kế toán trưởng có thói quen đối chiếu số liệu 20 phút cuối mỗi ngày. Danh sách của chị có: "tuần chốt sổ cuối năm làm đến tối" (cao, nặng), "tiệc tất niên công ty" (cao, nhẹ, vì chỉ một tối), "đồng nghiệp nghỉ phép, phải làm thay" (vừa, nặng), "quên vì đổi lịch họp" (vừa, nhẹ). Ba rủi ro lớn nhất của chị rõ ngay sau năm phút.

Một sai lầm hay gặp là đánh giá mọi lý do đều "cao" và "nặng". Nếu điều đó xảy ra, hãy hỏi lại: năm ngoái, chuyện này đã thật sự làm mình dừng việc gì chưa? Câu trả lời từ trải nghiệm của chính mình thường đúng hơn cảm giác lo lắng lúc này.

**Ngày 2 (20 phút)**

1. Với mỗi lý do đã viết hôm qua, chọn khả năng xảy ra: thấp, vừa hay cao.
2. Chọn mức ảnh hưởng: nhẹ, vừa hay nặng.
3. Chọn ba lý do đáng lo nhất làm ba rủi ro chính của tuần, sửa lại câu chữ cho ngắn gọn.

Sổ thực hành hiện sẵn các lý do đã viết ở Ngày 1, chỉ cần bấm chọn. Ba rủi ro chọn hôm nay sẽ được lưu cho cả hành trình, để những tuần sau còn quay lại kiểm tra.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-2.

Chia sẻ hôm nay: "Ba rủi ro lớn nhất với thói quen của tôi: ...; ...; ...".


## Bài 3: Ngày 3 (Thứ Tư 02/12)
@img 3_bien-phap
@pdf 10XHub_TienLieu_PhieuNgay3_bien-phap.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: MỖI RỦI RO MỘT BIỆN PHÁP

Có hai cách phản ứng với một rủi ro đã nhìn thấy. Đặt chúng cạnh nhau sẽ thấy khác biệt rất rõ.

**Cách thứ nhất: "Mình sẽ cố gắng hơn"**

Rủi ro: tuần chốt số liệu làm đến tối, sáng hôm sau mệt, bỏ phiên làm việc sâu.
Phản ứng: "Tuần đó mình sẽ cố gắng dậy sớm hơn."

Câu này nghe có trách nhiệm, nhưng nó đặt toàn bộ gánh nặng lên ý chí vào đúng lúc ý chí yếu nhất. Không có gì thay đổi trong lịch, trong chỗ làm việc hay trong cách làm.

**Cách thứ hai: thay đổi điều kiện**

Rủi ro: như trên.
Biện pháp phòng trước: dời phiên làm việc sâu tuần đó sang 13 giờ, ngay sau bữa trưa, và đặt lịch hẹn lặp lại từ hôm nay.
Phương án khi vẫn xảy ra: nếu đến 14 giờ vẫn chưa làm được, làm phiên bản tối thiểu 10 phút trước khi rời văn phòng.

Cách thứ hai không đòi hỏi mình mạnh mẽ hơn. Nó đòi hỏi mình chuẩn bị sớm hơn.

**Ba loại biện pháp hay dùng**

- Dời: chuyển thói quen sang khung giờ không bị rủi ro chạm tới.
- Thu nhỏ: chuẩn bị sẵn một phiên bản rất ngắn cho những ngày khó.
- Chặn trước: hành động ngay hôm nay để rủi ro khó xảy ra hơn, ví dụ báo trước với trưởng nhóm rằng 8 giờ đến 8 giờ 30 là giờ mình không nhận họp.

Ai đã làm tuần #0023 Ý định thực hiện sẽ thấy quen: phương án khi vẫn xảy ra chính là một kế hoạch "Nếu... thì...". Sổ thực hành sẽ hiện lại những kế hoạch đã viết ở tuần đó nếu có. Nhiều kế hoạch cũ vẫn dùng tốt, chỉ cần điều chỉnh cho bối cảnh cuối năm.

**Phép thử cho một biện pháp tốt**

Một biện pháp đạt yêu cầu khi trả lời "có" cho cả ba câu:

1. Có làm được ngay trong tuần này không?
2. Có thay đổi một điều cụ thể (giờ, chỗ, lịch, cách làm), thay vì chỉ thay đổi quyết tâm không?
3. Nếu người khác đọc, họ có hiểu chính xác mình sẽ làm gì không?

Một nhân viên chăm sóc khách hàng có thói quen ghi lại một bài học từ cuộc gọi khó mỗi chiều. Rủi ro lớn nhất của bạn ấy là lượng cuộc gọi tăng mạnh những tuần trước Tết. Biện pháp: để sẵn một mẫu ghi chép ba dòng trên màn hình, chỉ mất ba phút. Phương án khi vẫn xảy ra: ghi bằng giọng nói trên điện thoại khi về đến nhà, sáng hôm sau chép lại.

**Ngày 3 (25 phút)**

1. Với mỗi rủi ro trong ba rủi ro chính, viết một biện pháp phòng trước.
2. Viết một phương án khi rủi ro vẫn xảy ra, theo dạng "Nếu ... thì ...".
3. Làm ngay hôm nay ít nhất một việc chặn trước, ví dụ đặt lịch hẹn lặp lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-3.

Chia sẻ hôm nay: "Rủi ro số 1: .... Biện pháp của tôi: ...".


## Bài 4: Ngày 4 (Thứ Năm 03/12)
@img 4_lich-tat-nien
@pdf 10XHub_TienLieu_PhieuNgay4_lich-tat-nien.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: GIỮ THÓI QUEN QUA MÙA TẤT NIÊN

Lấy một ví dụ giả định. Anh Minh là trưởng phòng kinh doanh. Thói quen then chốt của anh từ tháng 10: mỗi sáng gọi lại hai khách hàng cũ trước 9 giờ. Hai tháng qua, anh giữ được gần như mọi ngày làm việc.

Rồi anh mở lịch tháng 12.

Tuần 07.12: hai buổi gặp khách hàng ở tỉnh. Tuần 14.12: họp tổng kết năm của công ty, ba buổi chiều liên tiếp. Tuần 21.12: bốn buổi tiệc cuối năm với đối tác, buổi nào cũng kéo dài đến tối. Tuần 28.12: chuẩn bị kế hoạch năm 2027, xen giữa là ngày nghỉ Tết Dương lịch.

Nhìn lịch như vậy, có ba cách phản ứng. Cách thứ nhất: tạm dừng thói quen đến tháng 1, "khi nào rảnh lại làm". Cách thứ hai: giữ nguyên như cũ và hy vọng mọi việc ổn. Cách thứ ba, cách anh Minh chọn: chia tháng thành từng tuần và quyết định trước cho từng tuần.

- Tuần gặp khách ở tỉnh: gọi một khách hàng thay vì hai, gọi từ khách sạn trước khi xuất phát.
- Tuần họp tổng kết: buổi sáng vẫn trống, giữ nguyên.
- Tuần tiệc cuối năm: dời sang 10 giờ sáng, gọi một khách hàng, kèm lời chúc cuối năm. Thói quen vẫn chạy, chỉ đổi hình thức.
- Tuần cuối năm: dùng thói quen để gửi lời cảm ơn đến những khách hàng đã đồng hành trong năm 2026.

Anh Minh không cần thói quen giữ nguyên hình dạng suốt tháng 12. Anh chỉ cần nó không bị đứt.

**Bài học từ câu chuyện**

Lịch dày không phải là rủi ro. Lịch dày mà không được nhìn trước mới là rủi ro. Khi đã đánh dấu những tuần khó, mình có thể chọn trước giờ giấc và phiên bản tối thiểu cho từng tuần, thay vì quyết định vội vào mỗi buổi sáng mệt mỏi.

Một điểm nữa: ngày có tiệc tối, thói quen buổi sáng hôm sau dễ bị ảnh hưởng nhất. Nhiều người chọn làm thói quen ngay trong buổi chiều trước tiệc, khi năng lượng còn tốt, thay vì đợi đến sáng hôm sau.

**Bảng hành trình hôm nay**

Tuần này bảng hành trình nằm ở Ngày 4. Bấm vào các ngày đã làm thói quen từ Thứ Hai đến nay. Ngày nào chỉ làm phiên bản tối thiểu vẫn tính là đã làm.

**Ngày 4 (20 phút)**

1. Mở lịch tháng 12 và đầu tháng 1. Đánh dấu những tuần dày lịch, tuần đi công tác, tuần nghỉ phép.
2. Với tuần khó nhất, chọn giờ giữ thói quen và viết phiên bản tối thiểu.
3. Đặt ngay vào lịch những thay đổi đã quyết định.
4. Bấm bảng hành trình cho những ngày đã làm tuần này.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-4.

Chia sẻ hôm nay: "Những tuần cần lưu ý: .... Ngày có tiệc, tôi giữ thói quen vào ... bằng phiên bản: ...".


## Bài 5: Ngày 5 (Thứ Sáu 04/12)
@img 5_canh-bao
@pdf 10XHub_TienLieu_PhieuNgay5_canh-bao.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: NGƯỜI NHẮC VÀ TÍN HIỆU CẢNH BÁO

Hôm nay có ba khái niệm. Mỗi khái niệm kèm một ví dụ trong công việc để dễ dùng ngay.

**Tín hiệu cảnh báo sớm là gì?**

Là một dấu hiệu nhỏ, đến trước khi thói quen dừng hẳn. Trong quản lý dự án, người ta không đợi đến hạn chót mới biết dự án trễ, mà theo dõi những dấu hiệu sớm hơn: một hạng mục chậm hai ngày, một cuộc họp bị hoãn hai lần. Thói quen cũng vậy.

Ví dụ tín hiệu cảnh báo sớm cho thói quen:

- Hai ngày liên tiếp chỉ làm phiên bản tối thiểu.
- Ba ngày liền không bấm bảng hành trình, dù vẫn nghĩ là "có làm".
- Bắt đầu nói với chính mình "tuần sau làm lại cho đầy đủ".

Tín hiệu tốt phải cụ thể đến mức mình không thể tranh cãi với nó. "Thấy mình lười" không phải là tín hiệu. "Hai ngày liên tiếp không mở tệp kế hoạch" là tín hiệu.

**Người nhắc là ai?**

Là một người đồng ý nhắc mình khi tín hiệu cảnh báo xuất hiện. Không phải người giám sát, cũng không phải người phán xét. Chỉ là một người hiểu thói quen của mình và sẵn lòng hỏi một câu đúng lúc.

Người nhắc tốt thường là đồng nghiệp ngồi gần, người cùng tham gia 10X Excellence Hub, hoặc một người bạn trong nghề. Điều quan trọng là người đó biết chính xác phải nhắc khi nào và nhắc bằng câu gì. Vì vậy, nên soạn sẵn câu nhắn cho họ.

Ví dụ một trưởng nhóm nhân sự nhờ đồng nghiệp: "Nếu chiều Thứ Sáu chị thấy em chưa gửi bảng ghi nhận nhân viên trong tuần, chị nhắn giúp em một câu: còn hai mươi phút, gửi bản ngắn thôi."

**Điểm quay lại là gì?**

Là việc đầu tiên mình làm ngay khi thấy tín hiệu cảnh báo. Nó phải nhỏ hơn cả phiên bản tối thiểu, để không có lý do nào từ chối. Ví dụ: mở sổ thực hành và bấm ô của hôm nay sau khi làm năm phút. Một kỹ sư vận hành chọn điểm quay lại là "mở sổ ghi chép cải tiến và viết đúng một dòng". Năm phút, một dòng, và chuỗi được nối lại.

Ba khái niệm này đi cùng nhau: tín hiệu cho biết khi nào, người nhắc giúp mình nhìn thấy, điểm quay lại cho biết làm gì đầu tiên.

**Ngày 5 (20 phút)**

1. Viết một tín hiệu cảnh báo sớm cụ thể cho thói quen của mình.
2. Chọn một người nhắc và soạn sẵn câu nhắn cho họ.
3. Viết điểm quay lại: việc đầu tiên khi tín hiệu xuất hiện.
4. Gửi lời nhờ đến người nhắc ngay hôm nay. Một câu ngắn là đủ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-5.

Chia sẻ hôm nay: "Tín hiệu cảnh báo sớm của tôi: .... Người nhắc: ...".


## Bài 6: Ngày 6 (Thứ Bảy 05/12)
@img 6_la-chan
@img2 9_the-thanh-tich
@pdf 10XHub_TienLieu_PhieuNgay6_la-chan.pdf (phiếu thực hành và trang lá chắn cuối năm để in)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: LÁ CHẮN CUỐI NĂM ĐÃ SẴN SÀNG

Năm ngày qua, mỗi ngày tạo ra một mảnh nhỏ. Hôm nay ghép chúng lại thành một trang. Trước khi ghép, dùng danh sách kiểm tra dưới đây để rà từng mảnh.

**Danh sách kiểm tra lá chắn cuối năm**

- Thói quen đang giữ được viết rõ trong một câu, ai đọc cũng hiểu.
- Có ít nhất năm lý do khiến thói quen có thể dừng, viết như đã xảy ra.
- Ba rủi ro chính đã được chọn qua bảng khả năng và ảnh hưởng.
- Mỗi rủi ro có một biện pháp phòng trước làm được ngay.
- Mỗi rủi ro có một phương án "Nếu ... thì ..." khi vẫn xảy ra.
- Những tuần dày lịch của tháng 12 đã được đánh dấu, có giờ và phiên bản tối thiểu riêng.
- Có một tín hiệu cảnh báo sớm cụ thể, không thể tranh cãi.
- Có một người nhắc đã đồng ý, và họ có sẵn câu nhắn.
- Có một điểm quay lại nhỏ hơn cả phiên bản tối thiểu.

Mục nào chưa có, quay lại đúng ngày đó trên sổ thực hành để bổ sung. Bài cũ không khoá.

**Viết lá chắn trong một câu**

Một trang lá chắn đầy đủ dùng để in và đặt cạnh bàn làm việc. Nhưng mỗi buổi sáng bận rộn, mình chỉ kịp đọc một câu. Vì vậy hôm nay viết thêm một câu tóm tắt cả lá chắn. Ví dụ:

"Tháng 12, tôi giữ thói quen vào 13 giờ những tuần dày lịch, làm bản 10 phút khi có tiệc, và nhờ chị Lan nhắc nếu hai ngày liền tôi chưa mở tệp kế hoạch."

**Sáng nay (15 phút)**

Đi qua danh sách kiểm tra, bổ sung các mục còn thiếu trên sổ thực hành.

**Trước khi nghỉ Chủ Nhật (15 phút)**

Viết câu lá chắn cuối năm. In trang lá chắn trong phiếu đính kèm, điền và đặt ở chỗ dễ thấy. Ngày 31.01.2027, mở lại trang này và đánh dấu: rủi ro nào đã đến, biện pháp nào đã dùng.

Tuần sau, Công thức #0030 về Hiệu ứng việc dở dang sẽ giúp khép những việc còn treo trước khi năm 2026 kết thúc, và thêm cho thói quen một nghi thức kết thúc ngày. Năm 2026 chỉ còn bốn tuần nữa. Một năm khép gọn gàng bắt đầu từ việc khép gọn từng ngày.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0029-ngay-6.

Chia sẻ hôm nay: "Lá chắn cuối năm của tôi: .... Thói quen tôi giữ qua tháng 12: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích Lá chắn cuối năm hiện ra, có con dấu ba rủi ro đã có biện pháp, tên mình và câu lá chắn. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Lá chắn đã dựng xong, tháng 12 cứ đến, thói quen đã có chỗ đứng.
