## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 15/03)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0044_Luat Hick_VN.pdf (tài liệu đầy đủ của Công thức #0044)
@pdf 10XHub_LuatHick_PhieuNgay1_thoi-gian-bat-dau.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0044.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** LUẬT HICK: MỖI LỰA CHỌN THÊM LÀ MỘT NHỊP CHẬM

Tuần trước, cả nhóm đã tập chọn kiểu "đủ tốt" cho những việc nhỏ trong ngày làm việc, để dành sức cho năm mục tiêu lớn. Đó là câu hỏi về sự hài lòng: chọn đến mức nào thì đủ. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành, bài cũ không khoá.

Tuần này đi tiếp sang một câu hỏi khác: chọn nhanh đến mức nào, và làm sao để không phải chọn lại mỗi ngày. Công thức #0044 là Luật Hick và quy tắc mặc định.

**Nếu mới tham gia:** chỉ cần một việc nhỏ trong công việc mà mình muốn làm mỗi ngày, ví dụ dành 20 phút đầu giờ cho một bước của mục tiêu quan trọng nhất. Viết việc đó vào ô thói quen ở đầu Ngày 1 trên sổ thực hành, rồi đo thời gian bắt đầu như mọi người. Tuần này tự đứng được, không cần đọc lại các tuần trước.

**Thử ngay trong 30 giây**

Trước khi đọc tiếp, các anh chị và các bạn thử hình dung hai buổi sáng.

Buổi sáng A: 8 giờ, mở máy, trên màn hình chỉ có một tệp đã mở sẵn từ chiều hôm qua, kèm một dòng ghi chú "bắt đầu từ mục 3".

Buổi sáng B: 8 giờ, mở máy, có 14 email mới, 6 việc trên bảng, ba báo cáo dở dang và một tin nhắn hỏi "anh xem giúp em chưa?".

Ở buổi sáng nào mình bắt tay vào việc quan trọng nhanh hơn? Câu trả lời gần như ai cũng biết. Điều đáng chú ý là khoảng chênh đó có quy luật, và đã được đo từ hơn 70 năm trước.

**Mười bóng đèn của William Hick**

Năm 1952, nhà tâm lý học người Anh William Edmund Hick công bố một thí nghiệm trên tạp chí Quarterly Journal of Experimental Psychology. Người tham gia ngồi trước một dãy bóng đèn, mỗi bóng có một phím riêng. Đèn nào sáng thì bấm đúng phím của đèn đó, càng nhanh càng tốt. Hick thay đổi số bóng đèn có thể sáng, từ 2 lên đến 10.

Kết quả: càng nhiều khả năng, thời gian phản ứng càng dài. Nhưng thời gian không tăng đều theo số lựa chọn. Nó tăng theo hàm logarit: từ 1 lên 2 lựa chọn chậm đi khá rõ, từ 8 lên 9 thì chậm thêm rất ít. Năm 1953, Ray Hyman làm tiếp và cho thấy yếu tố quyết định là lượng thông tin, tức mức không chắc chắn của lựa chọn, chứ không chỉ con số đếm được. Từ đó, quy luật này được gọi là Luật Hick, hay Luật Hick và Hyman.

**Điều Luật Hick không nói**

Luật Hick đo những phản ứng rất đơn giản trong phòng thí nghiệm, tính bằng phần nghìn giây. Nó không cho biết một buổi sáng nhiều việc sẽ làm mình chậm đi bao nhiêu phút. Các nhà nghiên cứu cũng ghi nhận rằng luyện tập nhiều làm mức tăng này nhỏ lại. Vì vậy tuần này dùng Luật Hick như một nguyên lý thiết kế, đúng như cách các nhà thiết kế phần mềm vẫn dùng khi rút gọn danh mục chọn trên màn hình: mỗi lựa chọn thêm vào ngay trước lúc bắt đầu là thêm một nhịp chậm.

**Tuần trước và tuần này khác nhau ở đâu?**

Tuần #0043 hỏi: chọn đến mức nào thì hài lòng? Tuần #0044 hỏi: làm sao để không phải chọn lại? Câu trả lời là quy tắc mặc định: một quyết định đưa ra một lần, dùng lại nhiều lần, chỉ thay đổi khi có lý do rõ ràng. Với thói quen then chốt, đích của tuần rất cụ thể: rút ngắn khoảng thời gian từ lúc định làm đến lúc thật sự bắt đầu.

**Sáu ngày của tuần**

- Thứ Hai: đo thời gian bắt đầu thói quen.
- Thứ Ba: kiểm kê những quyết định lặp lại.
- Thứ Tư: viết quy tắc mặc định cho thói quen then chốt.
- Thứ Năm: lịch mục tiêu theo ngày, sáng nào cũng đã biết làm cho mục tiêu nào.
- Thứ Sáu: thực đơn ngắn cho khoảng thời gian trống, và điều kiện phá lệ.
- Thứ Bảy: đo lại, gom sổ quy tắc mặc định.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Đo thời gian bắt đầu**

1. Mở sổ thực hành, xem lại thói quen đang giữ.
2. Hôm nay, lúc làm thói quen, ghi lại những điều mình phải cân nhắc trước khi bắt đầu: làm lúc nào, cho mục tiêu nào, làm phần nào, ở đâu, bao lâu.
3. Đếm số điều phải cân nhắc, và ước lượng số phút từ lúc định làm đến lúc thật sự bắt đầu.

Không cần chính xác đến từng phút. Con số hôm nay là mốc để so sánh vào Thứ Bảy.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-1.

Chia sẻ hôm nay: "Trước khi bắt đầu thói quen, tôi phải cân nhắc ... điều. Từ lúc định làm đến lúc bắt đầu mất khoảng ... phút".

Con số nào cũng được ghi nhận, các anh chị và các bạn cứ ghi đúng như mình thấy nha.


## Bài 2: Ngày 2 (Thứ Ba 16/03)
@img 2_kiem-ke
@pdf 10XHub_LuatHick_PhieuNgay2_kiem-ke.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: KIỂM KÊ NHỮNG QUYẾT ĐỊNH LẶP LẠI

Hôm nay bắt đầu bằng một trang nhật ký. Đây là nhật ký minh hoạ của một trưởng nhóm kinh doanh, ghi lại những quyết định nhỏ trong 90 phút đầu ngày.

**Nhật ký minh hoạ, một sáng Thứ Ba**

- 7 giờ 50: đến văn phòng. Làm việc ở bàn mình hay phòng họp nhỏ? Chọn bàn mình.
- 7 giờ 55: mở hộp thư trước hay mở bảng việc trước? Mở hộp thư, định xem "một chút".
- 8 giờ 10: có 11 email. Trả lời khách hàng nào trước? Đọc lướt cả 11 để chọn.
- 8 giờ 25: hôm nay làm bước nào cho mục tiêu khách hàng mới? Gọi cho danh sách cũ hay soạn đề xuất mới? Chưa quyết, để sau họp.
- 8 giờ 30: họp giao ban. Báo cáo theo mẫu nào? Mở lại ba mẫu cũ để chọn.
- 9 giờ 05: có 25 phút trống. Làm gì? Xem lại tin nhắn nhóm.
- 9 giờ 20: quay lại câu hỏi lúc 8 giờ 25. Vẫn chưa bắt đầu.

Không quyết định nào trong danh sách là khó. Nhưng cộng lại, hơn một giờ đã trôi qua mà bước cho mục tiêu quan trọng nhất vẫn chưa bắt đầu.

**Ba dấu hiệu của một quyết định nên có quy tắc**

Đọc lại trang nhật ký, những quyết định đáng biến thành quy tắc mặc định thường có cả ba dấu hiệu:

1. Lặp lại gần như mỗi ngày làm việc.
2. Chọn phương án nào thì kết quả cũng không khác nhau nhiều.
3. Mỗi lần chọn vẫn tốn một chút sức, hoặc làm mình chậm bắt đầu việc quan trọng.

Chọn chỗ ngồi, thứ tự mở hộp thư, mẫu báo cáo giao ban, việc làm trong khoảng trống 25 phút đều có đủ ba dấu hiệu.

**Những quyết định không nên đặt mặc định**

Ngược lại, có những quyết định cần được cân nhắc mỗi lần: duyệt một khoản chi lớn, trả lời một khiếu nại nghiêm trọng, đánh giá một nhân sự. Kết quả của chúng khác nhau rất nhiều tuỳ lựa chọn. Quy tắc mặc định không dùng để làm nhanh những quyết định này. Nó dùng để giải phóng sức chú ý cho chúng.

**Ngày 2 (20 phút)**

1. Viết năm quyết định nhỏ mình lặp lại mỗi ngày, ưu tiên những quyết định nằm quanh thói quen then chốt.
2. Ước lượng mỗi ngày mình lặp lại khoảng bao nhiêu quyết định nhỏ như vậy.
3. Chọn một quyết định có đủ ba dấu hiệu để biến thành quy tắc vào ngày mai.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-2.

Chia sẻ hôm nay: "Mỗi ngày tôi lặp lại khoảng ... quyết định nhỏ. Quyết định tôi muốn biến thành quy tắc: ...".


## Bài 3: Ngày 3 (Thứ Tư 17/03)
@img 3_quy-tac-mac-dinh
@pdf 10XHub_LuatHick_PhieuNgay3_quy-tac-mac-dinh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: VIẾT MỘT QUY TẮC MẶC ĐỊNH CHO THÓI QUEN

Một quy tắc mặc định tốt trả lời trước những câu hỏi mà mình vẫn tự hỏi ngay trước lúc bắt đầu. Hôm nay đặt từng cặp cạnh nhau: bên trái là cách nói thường gặp, bên phải là cách viết thành quy tắc.

**Bốn cặp đối chiếu**

- Khi nào. "Cố gắng làm thói quen sớm" → "Mặc định: 8 giờ 15, ngay sau khi rót trà, trước khi mở hộp thư."
- Cho mục tiêu nào. "Làm cho mục tiêu nào đang gấp" → "Mặc định: bước tiếp theo của mục tiêu số 1, đã ghi trên bảng từ chiều hôm trước."
- Bao lâu. "Làm được bao nhiêu thì làm" → "Mặc định: 30 phút. Có thêm thời gian thì làm tiếp, không có thì dừng đúng giờ."
- Bắt đầu từ đâu. "Mở máy rồi tính" → "Mặc định: mở đúng tệp đang dở, đọc dòng ghi chú cuối cùng, làm tiếp từ đó."

Cột bên trái không sai. Nó chỉ để lại một câu hỏi chưa trả lời. Mỗi câu hỏi còn bỏ ngỏ là một lần mình phải quyết định lại, đúng lúc sức chú ý cần dành cho việc chính.

**Mặc định khác gì "Nếu... thì..."?**

Ở Công thức #0023, kế hoạch Nếu... thì... nối một tín hiệu với một hành động: "Nếu họp kéo dài quá 9 giờ, thì tôi làm phiên bản 10 phút sau khi về bàn." Quy tắc mặc định trả lời phần nội dung: làm gì, phần nào, bao lâu, khi không có gì bất thường. Hai công cụ đi cùng nhau rất hợp: mặc định cho ngày bình thường, Nếu... thì... cho ngày khó.

**Vì sao mặc định có sức nặng?**

Các nghiên cứu về hành vi ghi nhận một điều khá ổn định: con người có xu hướng giữ nguyên phương án đã được đặt sẵn. Năm 2001, Brigitte Madrian và Dennis Shea theo dõi một công ty tại Mỹ chuyển chương trình tiết kiệm hưu trí cho nhân viên mới từ "tự đăng ký" sang "tự động tham gia, ai không muốn thì rút ra". Tỷ lệ tham gia của nhân viên mới tăng từ khoảng 37% lên khoảng 86%. Tuần này dùng chính xu hướng đó cho mình: đặt sẵn phương án tốt, để việc giữ nguyên trở thành việc làm thói quen.

**Ngày 3 (20 phút)**

1. Viết một quy tắc mặc định cho thói quen then chốt theo mẫu: "Nếu không có lý do đặc biệt, tôi luôn ...".
2. Kiểm tra quy tắc đã trả lời đủ bốn câu hỏi: khi nào, cho mục tiêu nào, bao lâu, bắt đầu từ đâu.
3. Viết thêm một quy tắc cho quyết định đã chọn hôm qua.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-3. Quy tắc mặc định viết hôm nay được lưu cho cả hành trình, các tuần sau sổ sẽ tự hiện lại.

Chia sẻ hôm nay: "Quy tắc mặc định của tôi: ...".


## Bài 4: Ngày 4 (Thứ Năm 18/03)
@img 4_lich-xoay-vong
@pdf 10XHub_LuatHick_PhieuNgay4_lich-xoay-vong.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: SÁNG NÀO CŨNG ĐÃ BIẾT LÀM CHO MỤC TIÊU NÀO

Thói quen gợi ý của Mùa 2 là "mỗi ngày làm một bước cho một trong năm mục tiêu". Câu này có một chỗ hở rất dễ thấy khi nhìn bằng Luật Hick: mỗi sáng, mình đứng trước năm lựa chọn. Hôm nay là danh sách năm cách cắt tỉa, rồi dùng cách thứ hai để làm lịch mục tiêu theo ngày.

**Năm cách cắt tỉa lựa chọn**

1. **Gộp những lựa chọn giống nhau.** Hai mục tiêu cùng cần gặp khách hàng thì có thể dùng chung một buổi gặp.
2. **Chọn trước một lần cho cả tuần.** Thay vì sáng nào cũng hỏi "hôm nay mục tiêu nào?", đặt sẵn mỗi ngày trong tuần ứng với một mục tiêu. Đây là lịch xoay vòng.
3. **Đặt thứ tự cố định.** Trong một mục tiêu, luôn làm bước tiếp theo đang đứng đầu danh sách, không chọn lại từ đầu.
4. **Giới hạn số phương án.** Khi buộc phải chọn, chỉ chọn trong tối đa ba phương án đã soạn sẵn.
5. **Gắn với một tín hiệu có sẵn.** Thứ Hai có họp giao ban thì bước của ngày Thứ Hai nên là việc làm được trong 20 phút trước giờ họp.

**Lịch xoay vòng trông như thế nào?**

Một ví dụ cho người làm nhân sự có mục tiêu số 1 là giảm tỷ lệ nghỉ việc của nhân viên mới:

- Thứ Hai và Thứ Năm: mục tiêu số 1, mỗi buổi trao đổi với một nhân viên mới.
- Thứ Ba: mục tiêu số 2, hoàn thiện một phần quy trình tuyển dụng.
- Thứ Tư: mục tiêu số 3, đọc 20 trang tài liệu chuyên môn.
- Thứ Sáu: mục tiêu số 4 hoặc số 5, xen kẽ từng tuần.
- Thứ Bảy: phiên bản tối thiểu, xem lại bảng mục tiêu 10 phút.

Mục tiêu số 1 được hai ngày, vì nó quan trọng nhất. Lịch này không cấm làm thêm. Nó chỉ trả lời sẵn câu hỏi đầu tiên của buổi sáng.

**Khi lịch không còn vừa**

Có tuần mục tiêu số 2 có hạn chót gần, cần nhiều ngày hơn. Khi đó sửa lịch một lần vào chiều Thứ Sáu cho tuần sau, thay vì chọn lại mỗi sáng. Quyết định vẫn được đưa ra, chỉ là đưa ra một lần.

**Ngày 4 (20 phút)**

1. Mở sổ thực hành, xem lại năm mục tiêu.
2. Gán mỗi ngày từ Thứ Hai đến Thứ Bảy với một mục tiêu. Mục tiêu số 1 nên có ít nhất hai ngày.
3. Viết lịch lên chỗ mình nhìn thấy mỗi sáng: bìa sổ kế hoạch, góc màn hình, bảng việc.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-4.

Chia sẻ hôm nay: "Lịch mục tiêu của tôi: Thứ Hai mục tiêu ..., Thứ Ba mục tiêu ..., Thứ Tư mục tiêu ..., Thứ Năm mục tiêu ..., Thứ Sáu mục tiêu ...".


## Bài 5: Ngày 5 (Thứ Sáu 19/03)
@img 5_thuc-don-ngan
@pdf 10XHub_LuatHick_PhieuNgay5_thuc-don-ngan.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: THỰC ĐƠN BA VIỆC VÀ ĐIỀU KIỆN PHÁ LỆ

Hôm nay đi theo dạng hỏi đáp, vì quy tắc mặc định thường gặp đúng những câu hỏi này sau vài ngày dùng thử.

**Hỏi: Có 15 phút trống giữa hai cuộc họp, nên làm gì?**

Đáp: Đây là lúc Luật Hick thấy rõ nhất. Mười lăm phút quá ngắn để cân nhắc nhiều phương án, nên thường kết thúc bằng việc xem tin nhắn. Cách sửa là một "thực đơn ngắn": ba việc soạn sẵn, mỗi việc làm xong trong 15 phút. Ví dụ với người làm kế toán: đối chiếu một khoản chênh lệch; trả lời một câu hỏi của bộ phận khác; cập nhật một dòng trong báo cáo tuần. Khi có khoảng trống, chỉ chọn trong ba việc đó.

**Hỏi: Vì sao là ba, không phải mười?**

Đáp: Ba đủ để có lựa chọn phù hợp với tâm trạng và chỗ ngồi, nhưng đủ ít để chọn ngay. Danh sách mười việc lại quay về đúng vấn đề ban đầu.

**Hỏi: Quy tắc mặc định có làm mình cứng nhắc không?**

Đáp: Mặc định không phải lệnh cấm. Nó là phương án được chọn khi không có lý do gì khác. Khi có lý do thật, mình vẫn đổi. Điều quan trọng là viết trước những lý do đó, để việc phá lệ cũng là một quyết định đã có sẵn.

**Hỏi: Điều kiện phá lệ nên viết thế nào?**

Đáp: Ngắn, cụ thể, kiểm tra được. "Khi có việc gấp" quá rộng, ngày nào cũng có thể gọi là gấp. "Khi khách hàng báo sự cố ảnh hưởng tới giao hàng trong ngày" hoặc "khi cấp trên yêu cầu bằng văn bản cho hạn trong buổi sáng" thì rõ hơn nhiều.

**Hỏi: Nếu phá lệ ba ngày liền thì sao?**

Đáp: Khi đó quy tắc chưa vừa với thực tế, ví dụ khung 8 giờ 15 luôn trùng giờ khách gọi. Sửa quy tắc, không bỏ quy tắc. Đổi sang khung 7 giờ 45 hoặc 13 giờ, rồi dùng thử thêm một tuần.

**Hỏi: Có nên đặt mặc định cho cả nhóm?**

Đáp: Rất nên, với những việc lặp lại chung: một mẫu báo cáo giao ban, một giờ cố định để trả lời câu hỏi nội bộ, một thư mục chung đặt tên theo cùng một cách. Nhưng nên bàn và thống nhất trước với nhóm, vì mặc định của một người áp cho người khác thì không còn là mặc định, mà là mệnh lệnh.

**Ngày 5 (20 phút)**

1. Soạn thực đơn ba việc cho khoảng trống 15 phút.
2. Viết một hoặc hai điều kiện phá lệ cho quy tắc mặc định của thói quen.
3. Nhìn lại bốn ngày qua: đã phá lệ lần nào chưa, vì sao.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-5.

Chia sẻ hôm nay: "Khi có 15 phút trống, tôi chọn một trong ba việc: ...; ...; .... Tôi chỉ phá quy tắc khi ...".


## Bài 6: Ngày 6 (Thứ Bảy 20/03)
@img 6_so-quy-tac
@img2 9_the-thanh-tich
@pdf 10XHub_LuatHick_PhieuNgay6_so-quy-tac.pdf (phiếu thực hành và sổ quy tắc mặc định in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: ĐO LẠI VÀ GOM SỔ QUY TẮC MẶC ĐỊNH

**Một tình huống minh hoạ**

Chị Thảo là trưởng nhóm chăm sóc khách hàng. Thói quen then chốt chị giữ từ đầu năm là "mỗi sáng xử lý trước một phản hồi khó nhất". Thứ Hai tuần này, chị đo thử: trước khi bắt đầu, chị phải cân nhắc năm điều. Phản hồi nào khó nhất? Gọi điện hay viết email? Làm ở bàn hay vào phòng nhỏ? Trả lời luôn hay hỏi ý bộ phận kỹ thuật trước? Làm trong bao lâu? Từ lúc định làm đến lúc bắt đầu mất khoảng 20 phút.

Trong tuần, chị viết ba quy tắc. Một: phản hồi khó nhất là phản hồi đã chờ lâu nhất trong danh sách, không cân nhắc lại. Hai: luôn gọi điện trước, chỉ viết email khi khách không nghe máy. Ba: 30 phút, ở phòng họp nhỏ tầng 3, đặt chỗ sẵn cho cả tuần. Thứ Năm, chị làm lịch xoay vòng cho năm mục tiêu. Thứ Sáu, chị soạn thực đơn ba việc cho những lúc chờ khách gọi lại.

Sáng Thứ Bảy, chị đo lại. Chỉ còn một điều phải cân nhắc, và thời gian bắt đầu còn khoảng 5 phút. Điều chị ghi vào sổ không phải con số 15 phút tiết kiệm được, mà là cảm giác bắt đầu ngày mới với một câu trả lời có sẵn.

Tình huống trên là minh hoạ. Con số của mỗi người sẽ khác, và giảm ít hay nhiều đều là thông tin tốt cho tuần sau.

**Sáng nay (15 phút)**

1. Làm thói quen như mọi ngày, và đo lại: còn bao nhiêu điều phải cân nhắc, mất khoảng bao nhiêu phút để bắt đầu.
2. So với con số của Thứ Hai.

**Trước khi nghỉ Chủ Nhật (15 phút)**

Gom sổ quy tắc mặc định. Sổ thực hành đã gom sẵn mọi điều viết trong tuần: quy tắc của thói quen, quy tắc cho quyết định lặp lại, lịch mục tiêu theo ngày, thực đơn ba việc và điều kiện phá lệ. Phiếu Ngày 6 có thêm một trang sổ quy tắc khổ nhỏ để in, đặt cạnh tín hiệu của thói quen.

**Tuần sau: Chỉ số Sao Bắc Cực**

Tuần này giúp bắt đầu nhanh hơn. Tuần sau, Công thức #0045, bắt đầu Thứ Hai 22.03, giúp biết mình có đang đi đúng hướng: mỗi mục tiêu có một con số dẫn đường, và một con số hành động mỗi tuần mà mình kiểm soát được.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0044-ngay-6.

Chia sẻ hôm nay: "Thời gian bắt đầu thói quen: Thứ Hai khoảng ... phút, hôm nay khoảng ... phút. Quy tắc tôi giữ: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: sáu vòng tròn khép kín cho những ngày đã làm thói quen, tên mình và quy tắc mặc định của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Sáng Thứ Hai, quy tắc mặc định sẽ trả lời giúp mình câu hỏi đầu tiên của tuần mới.
