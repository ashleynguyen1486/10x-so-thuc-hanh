## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 28/12)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0033_Suc Manh Thoi Quen_VN.pdf (tài liệu đầy đủ của Công thức #0033)
@pdf 10XHub_SucManhThoiQuen_PhieuNgay1_doc-lai-nam.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0033.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** TUẦN CHUYỂN NĂM: ĐỌC LẠI NĂM 2026 QUA BẢNG HÀNH TRÌNH

Tuần Giáng sinh vừa qua, những lời cảm ơn cụ thể đã đến với đồng nghiệp, khách hàng, đối tác và những người âm thầm hỗ trợ. Dưới bài Thứ Bảy là nhiều lá thư cảm ơn năm 2026 rất chân thành. Lời cảm ơn sau thói quen vẫn đi tiếp trong tuần này, như một phần của thói quen then chốt.

Tuần này là tuần chuyển năm, với hai ngày đặc biệt: Thứ Năm 31.12, ngày cuối cùng của năm 2026, và Thứ Sáu 01.01.2027, ngày nghỉ Tết Dương lịch. Công thức của tuần là #0033, Sức mạnh thói quen, dựa trên cuốn The Power of Habit của Charles Duhigg (2012).

**Nếu mới tham gia:** tuần chuyển năm là thời điểm rất hợp để bắt đầu. Bảng hành trình của người mới còn trống, và điều đó không sao. Hôm nay chỉ cần viết vào sổ thực hành một thói quen then chốt trong công việc mà mình muốn mang vào năm 2027, ví dụ "đọc tài liệu chuyên môn 20 phút trước giờ họp sáng". Thứ Tư, cả nhóm sẽ cùng kiểm tra lại lựa chọn đó.

**Đọc bảng hành trình như đọc một báo cáo năm**

Cuối năm, phòng kế toán đọc báo cáo tài chính để biết doanh nghiệp đã đi được đến đâu. Bảng hành trình trên sổ thực hành cũng là một bản báo cáo, của thói quen. Có bốn chỉ số đáng đọc.

1. Tổng số ngày. Sổ tự đếm. Con số này không dùng để so với người khác. Nó cho thấy khối lượng mình đã tích luỹ, từng ngày một.
2. Chuỗi dài nhất. Tuần nào các ô liền nhau nhất? Tuần đó có điều gì giúp mình giữ đều: một tín hiệu rõ, một khung giờ ổn định, một người cùng theo dõi?
3. Khoảng trống. Những tuần nhiều ô trống thường trùng với lịch công tác, dự án gấp, tiệc tất niên. Ghi lại nguyên nhân, không cần tự trách.
4. Ngày quay lại. Sau mỗi khoảng trống, mình mất bao nhiêu ngày để làm lại? Đây là chỉ số quan trọng nhất, vì ai cũng có ngày lỡ, nhưng không phải ai cũng quay lại sớm.

**Vì sao nhìn lại năm qua thói quen?**

Năm 2002, Wendy Wood và các đồng nghiệp đề nghị người tham gia ghi lại mỗi giờ mình đang làm gì. Kết quả: từ khoảng một phần ba đến một nửa số hành vi được ghi là thói quen, tức là việc làm gần như mỗi ngày, thường ở cùng một chỗ. Nói cách khác, một năm làm việc phần lớn được làm từ những việc lặp lại. Nhìn vào thói quen là nhìn vào phần lớn những gì mình thật sự đã làm.

Charles Duhigg, phóng viên của tờ The New York Times, viết The Power of Habit để giải thích thói quen hình thành ra sao và thay đổi bằng cách nào. Tuần này dùng ba ý chính của cuốn sách: vòng lặp tín hiệu, hành động, phần thưởng; quy tắc vàng để thay đổi thói quen; và thói quen then chốt.

**Sáu ngày của tuần chuyển năm**

- Thứ Hai: đọc lại năm 2026 qua bảng hành trình.
- Thứ Ba: vẽ vòng lặp thói quen của mình.
- Thứ Tư: quyết định cho năm 2027: giữ, nâng cấp hay đổi.
- Thứ Năm 31.12: lá thư gửi chính mình ngày cuối năm.
- Thứ Sáu 01.01.2027, nghỉ Tết: một câu bản sắc cho năm mới, chỉ 5 đến 10 phút.
- Thứ Bảy 02.01: chuẩn bị cho tuần đầu năm 2027.

Chủ Nhật nghỉ.

**Ngày 1 (25 phút): Đọc lại năm 2026**

1. Mở sổ thực hành, Ngày 1. Chép nguyên văn thói quen đang giữ vào ô "Thói quen năm 2026". Sổ sẽ lưu riêng bản này, để Thứ Tư có thể cập nhật thói quen cho năm mới mà không mất bản cũ.
2. Bấm đánh dấu những ngày tuần này đã làm trên bảng hành trình, rồi đọc tổng số ngày sổ đã đếm.
3. Trả lời hai câu: giai đoạn nào mình giữ đều nhất, vì sao; sau ngày lỡ, điều gì giúp mình quay lại.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-1.

Chia sẻ hôm nay: "Năm 2026, tôi đã giữ thói quen ... được ... ngày. Giai đoạn giữ đều nhất: .... Điều giúp tôi quay lại sau ngày lỡ: ...".

Người mới tham gia chưa có số ngày thì chia sẻ phần còn lại, và viết thêm thói quen mình chọn cho năm 2027 nha.


## Bài 2: Ngày 2 (Thứ Ba 29/12)
@img 2_vong-lap
@pdf 10XHub_SucManhThoiQuen_PhieuNgay2_vong-lap.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: MỔ XẺ VÒNG LẶP CỦA MỘT THÓI QUEN

Hôm nay mổ xẻ một thói quen rất quen thuộc ở chỗ làm, từng bước một, theo cách Charles Duhigg mô tả.

**Bước 0: một buổi chiều bình thường**

3 giờ chiều. Một nhân viên kinh doanh đang soạn báo giá cho một khách hàng khó. Đầu óc chậm lại. Tay mở điện thoại, lướt mạng xã hội. Hai mươi phút sau, báo giá vẫn dừng ở dòng cũ.

**Bước 1: tín hiệu**

Tín hiệu là điều khởi động thói quen. Ở đây có hai tín hiệu đi cùng nhau: thời điểm (giữa buổi chiều) và trạng thái (mệt, gặp việc khó). Duhigg chia tín hiệu thành năm nhóm: địa điểm, thời gian, trạng thái cảm xúc, những người xung quanh, và hành động ngay trước đó. Hầu hết thói quen trong công việc bắt đầu từ một trong năm nhóm này.

**Bước 2: hành động**

Hành động là việc mình làm theo quán tính: mở điện thoại. Đây là phần dễ thấy nhất, nên khi muốn bỏ thói quen, mọi người thường chỉ nhìn vào phần này.

**Bước 3: phần thưởng**

Phần thưởng là điều mình nhận được: vài phút thoát khỏi việc khó, cảm giác đổi không khí. Duhigg nhấn mạnh rằng vòng lặp chạy được là nhờ sự thèm muốn phần thưởng: lâu dần, chỉ cần tín hiệu xuất hiện là đã muốn phần thưởng.

**Bước 4: vì sao vòng lặp chạy tự động?**

Duhigg kể lại các thí nghiệm ở phòng thí nghiệm của Ann Graybiel tại Viện Công nghệ Massachusetts (MIT). Chuột học đường đi trong một mê cung hình chữ T để tìm sô cô la. Lúc đầu, não chuột hoạt động mạnh suốt quãng đường. Khi đường đi đã quen, hoạt động trong lúc chạy giảm hẳn, chỉ còn tăng lên ở lúc bắt đầu và lúc tìm thấy phần thưởng. Thói quen giúp não tiết kiệm sức, và cũng vì vậy mà nó khó thay đổi.

**Bước 5: quy tắc vàng**

Duhigg gọi cách thay đổi là quy tắc vàng: giữ nguyên tín hiệu, giữ nguyên phần thưởng, chỉ thay hành động. Với buổi chiều ở trên: 3 giờ chiều, khi gặp việc khó (tín hiệu), đứng dậy đi rót nước và nói chuyện năm phút với một đồng nghiệp (hành động mới), để có cảm giác đổi không khí (phần thưởng cũ). Thói quen then chốt mà mỗi người đang giữ cũng có một vòng lặp như vậy, và hôm nay là lúc vẽ nó ra.

**Ngày 2 (20 phút)**

1. Vẽ vòng lặp của thói quen then chốt: tín hiệu nào khởi động, phần thưởng là gì.
2. Vẽ vòng lặp của một thói quen chưa tốt đang lấy thời gian làm việc của mình.
3. Áp quy tắc vàng: giữ tín hiệu và phần thưởng, viết một hành động mới thay vào.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-2.

Chia sẻ hôm nay: "Vòng lặp của tôi: tín hiệu ... → ... → phần thưởng .... Hành động mới thay cho thói quen chưa tốt: ...".


## Bài 3: Ngày 3 (Thứ Tư 30/12)
@img 3_quyet-dinh
@pdf 10XHub_SucManhThoiQuen_PhieuNgay3_quyet-dinh.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: GIỮ, NÂNG CẤP HAY ĐỔI THÓI QUEN CHO NĂM 2027?

**Một buổi ra mắt nhà đầu tư năm 1987**

Tháng 10 năm 1987, Paul O'Neill, tổng giám đốc mới của tập đoàn nhôm Alcoa, gặp các nhà đầu tư và nhà phân tích ở New York. Mọi người chờ nghe về lợi nhuận, tồn kho, kế hoạch mở rộng. Ông nói về an toàn lao động, và đặt mục tiêu đưa Alcoa thành công ty an toàn nhất nước Mỹ.

Theo Duhigg, nhiều người nghe hôm đó lo lắng. Nhưng O'Neill có lý do. Để mỗi tai nạn được báo cáo lên ông trong vòng 24 giờ, kèm kế hoạch để không lặp lại, cả chuỗi báo cáo, cách các xưởng trao đổi với nhau, cách công nhân góp ý cải tiến đều phải thay đổi. Một thói quen kéo theo nhiều thói quen khác.

Duhigg viết rằng khi O'Neill nghỉ hưu năm 2000, lợi nhuận ròng hằng năm của Alcoa gấp năm lần lúc ông đến và giá trị vốn hoá tăng thêm 27 tỷ đô la Mỹ. Kết quả kinh doanh của một tập đoàn còn chịu tác động của rất nhiều yếu tố khác, nhưng câu chuyện cho thấy điều Duhigg gọi là thói quen then chốt: một thói quen mà khi thay đổi sẽ kéo theo những thay đổi khác.

**Bảng chọn cho năm 2027**

Thói quen mà mỗi người giữ suốt hành trình cũng được chọn với tinh thần đó. Ngày cuối cùng trước khi năm 2026 khép lại, hãy chọn một trong ba hướng.

- **Giữ nguyên.** Hợp khi: đã làm khá đều nhưng chưa thật sự tự động; thói quen vẫn gắn với điều quan trọng nhất của công việc năm tới. Nghiên cứu của Phillippa Lally (2010) cho thấy thời gian để một hành vi trở nên tự động trung bình khoảng 66 ngày và khác nhau rất nhiều giữa từng người, nên giữ thêm vài tháng thường là lựa chọn tốt.
- **Nâng cấp.** Hợp khi: thói quen đã gần như tự động, làm được cả ngày bận. Cách làm: giữ tín hiệu và giờ cũ, tăng một nấc nhỏ. Ví dụ "đọc tài liệu chuyên môn 20 phút" nâng thành "đọc 20 phút và ghi ba ý áp dụng".
- **Đổi thói quen.** Hợp khi: vai trò công việc năm 2027 thay đổi, hoặc thói quen không còn gắn với điều mình muốn đạt. Cách làm theo quy tắc vàng: giữ tín hiệu và khung giờ cũ, đặt thói quen mới vào đúng chỗ đó, để không mất những gì đã xây.

Thứ Hai, sổ thực hành đã lưu riêng thói quen năm 2026. Hôm nay có thể sửa ô thói quen then chốt cho năm 2027 mà không sợ mất bản cũ.

**Ngày 3 (25 phút)**

1. Chấm ba câu trên sổ: thói quen đã tự động đến đâu, còn gắn với công việc năm 2027 không, mình có muốn làm nhiều hơn một chút không.
2. Chọn một hướng: giữ nguyên, nâng cấp hoặc đổi.
3. Viết thói quen then chốt cho năm 2027. Chọn giữ nguyên thì để nguyên câu cũ.
4. Viết một câu giải thích vì sao.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-3.

Chia sẻ hôm nay: "Quyết định của tôi cho năm 2027: .... Thói quen then chốt năm 2027: ...".


## Bài 4: Ngày 4 (Thứ Năm 31/12)
@img 4_la-thu
@pdf 10XHub_SucManhThoiQuen_PhieuNgay4_la-thu.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: 31.12, VIẾT THƯ CHO CHÍNH MÌNH

Hôm nay là ngày cuối cùng của năm 2026. Bài hôm nay không giảng giải. Chỉ có những câu hỏi để viết một lá thư gửi chính mình, người sẽ mở thư vào một ngày của năm 2027.

Các anh chị và các bạn không cần trả lời hết. Chọn những câu chạm đến mình nhất, viết bằng giọng mình vẫn nói với một người bạn thân trong nghề.

**Hôm nay, công việc của mình đang ở đâu?**

Mình đang phụ trách việc gì, đang lo điều gì, đang tự hào về điều gì? Viết cụ thể, như ghi chú cho một người sẽ đọc lại sau sáu tháng.

**Năm 2026 đã dạy mình điều gì về thói quen?**

Có thể là một điều rất nhỏ: một tín hiệu hiệu quả, một phiên bản hai phút đã cứu những ngày bận, một kế hoạch Nếu... thì... đã dùng đến.

**Thói quen nào mình mang vào năm 2027, và vì sao?**

Đây là quyết định từ hôm qua. Viết lại bằng lời của mình, kèm lý do.

**Mình mong khi mở thư, mình đã làm được gì?**

Không cần là một kết quả lớn. Một mong muốn rõ ràng về con người mình muốn trở thành trong công việc là đủ.

**Nếu mở thư ra mà thói quen đã dừng, mình muốn nói gì với chính mình?**

Câu này quan trọng. Một lá thư tốt không trách móc. Nó nhắc chính mình rằng quay lại lúc nào cũng được, và chỉ cần bắt đầu bằng phiên bản nhỏ nhất.

**Một lời cảm ơn gửi chính mình của năm 2026.**

Tuần trước đã cảm ơn rất nhiều người. Hôm nay, đến lượt người đã giữ thói quen qua cả năm.

**Ngày 4 (25 phút)**

1. Viết thư vào ô thư trên sổ thực hành. Ô này được lưu cho cả hành trình, năm sau mở sổ vẫn còn.
2. Chọn ngày mở thư: 30.06.2027 hoặc 31.12.2027. Tạo một lời nhắc trong lịch làm việc cho ngày đó.
3. Chép thêm một bản ra giấy hoặc gửi vào hộp thư của chính mình, vì sổ chỉ lưu trên trình duyệt đang dùng.
4. Chọn một câu trong thư để chia sẻ. Phần còn lại là của riêng mình.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-4.

Chia sẻ hôm nay: "Ngày cuối năm 2026, tôi đã viết thư gửi chính mình và hẹn mở vào .... Một câu trong thư: ...".

Cảm ơn các anh chị và các bạn đã đi cùng nhau trọn năm 2026. Tối nay khép lại một năm làm việc, chúc mọi người một buổi tối thật thảnh thơi nha.


## Bài 5: Ngày 5 (Thứ Sáu 01/01/2027)
@img 5_nam-moi
@pdf 10XHub_SucManhThoiQuen_PhieuNgay5_cau-ban-sac.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: CHÚC MỪNG NĂM MỚI 2027, MỘT CÂU LÀ ĐỦ

Chúc mừng năm mới 2027 đến các anh chị và các bạn.

Hôm nay là ngày nghỉ Tết Dương lịch. Bài hôm nay rất nhẹ, chỉ 5 đến 10 phút, và có đúng một việc: viết một câu bản sắc cho năm mới.

**Một câu, bắt đầu bằng "Năm 2027, tôi là người ..."**

Ở tuần đầu của hành trình, mỗi người đã viết một câu "Tôi là người ...". Hôm nay đọc lại câu đó trên sổ thực hành. Có thể giữ nguyên, có thể viết một câu mới cho năm 2027. Câu bản sắc mô tả con người mình muốn trở thành trong công việc, chứ không phải một chỉ tiêu.

Vài ví dụ theo vị trí:

- Quản lý: "Năm 2027, tôi là người cho nhân viên phản hồi trong tuần, không để đến cuối quý."
- Kinh doanh: "Năm 2027, tôi là người giữ lời hẹn với khách hàng, dù là hẹn gọi lại."
- Kế toán: "Năm 2027, tôi là người phát hiện chênh lệch số liệu trước khi người khác phải hỏi."
- Nhân sự: "Năm 2027, tôi là người ghi nhận đồng nghiệp bằng những việc cụ thể."
- Kỹ thuật: "Năm 2027, tôi là người để lại ghi chú rõ ràng cho ca sau."

**Vì sao đầu năm là lúc hợp để viết câu này?**

Năm 2014, Hengchen Dai, Katherine Milkman và Jason Riis gọi hiện tượng này là hiệu ứng khởi đầu mới. Họ phân tích dữ liệu của một trang web nơi mọi người ký cam kết theo đuổi mục tiêu, và thấy số cam kết mới tăng rõ ở đầu tuần, đầu tháng, và tăng mạnh nhất ở đầu năm. Những mốc thời gian như vậy giúp người ta cảm thấy được bắt đầu lại.

Mốc đầu năm có ích nhất khi nó được gắn vào hệ thống đã có. Câu bản sắc hôm nay không thay cho thói quen then chốt, mà cho thói quen đó một lý do mới.

**Ngày 5 (5 đến 10 phút)**

1. Mở sổ thực hành, đọc câu bản sắc đang dùng.
2. Viết một câu cho năm 2027.
3. Thói quen hôm nay được nghỉ. Ai muốn giữ nhịp thì làm phiên bản hai phút là đủ.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-5.

Chia sẻ hôm nay: "Năm 2027, tôi là người ...".

Chúc các anh chị và các bạn một ngày đầu năm thật trọn vẹn bên gia đình nha.


## Bài 6: Ngày 6 (Thứ Bảy 02/01/2027)
@img 6_tuan-dau
@img2 9_the-thanh-tich
@pdf 10XHub_SucManhThoiQuen_PhieuNgay6_tuan-dau.pdf (phiếu thực hành và trang tổng kết năm 2026, kế hoạch năm 2027)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: SẴN SÀNG CHO TUẦN ĐẦU NĂM 2027

Thứ Hai tới là ngày làm việc đầu tiên trọn vẹn của năm 2027. Bài hôm nay đi theo dạng hỏi đáp, gom những câu hỏi thường gặp khi mang một thói quen sang năm mới.

**Hỏi: Thứ Tư mình đã đổi thói quen. Bảng hành trình có bị mất không?**

Đáp: Không. Bảng hành trình đếm theo ngày, các ô đã đánh dấu của năm 2026 còn nguyên. Thói quen năm 2026 được lưu ở ô riêng từ Thứ Hai. Thẻ thành tích tuần này còn hiện cả năm 2026 trên một tấm lưới để giữ lại làm kỷ niệm.

**Hỏi: Hôm qua nghỉ Tết, không làm thói quen. Có tính là lỡ không?**

Đáp: Một ngày nghỉ không làm hỏng thói quen. Nguyên tắc từ tuần đầu của hành trình vẫn giữ: không lỡ hai lần liên tiếp. Hôm nay làm phiên bản hai phút là đủ để giữ nhịp.

**Hỏi: Thói quen mới có cần tín hiệu mới không?**

Đáp: Nếu được, giữ tín hiệu cũ. Đó là quy tắc vàng của Duhigg từ Ngày 2: tín hiệu và khung giờ đã quen là phần khó xây nhất, nên tận dụng lại. Chỉ cần đặt tín hiệu mới khi tín hiệu cũ không còn, ví dụ chuyển sang làm ở chỗ khác.

**Hỏi: Trước Thứ Hai cần chuẩn bị những gì?**

Đáp: Ba việc. Kiểm tra tín hiệu còn đúng chỗ. Viết phiên bản hai phút cho thói quen năm 2027, nhất là khi vừa nâng cấp hoặc đổi. Báo cho người cùng theo dõi biết thói quen của mình năm nay.

**Hỏi: Lần đầu tiên làm thói quen trong năm mới nên là lúc nào?**

Đáp: Càng cụ thể càng tốt: "Thứ Hai 04.01, 8 giờ sáng, tại bàn làm việc, ngay sau khi pha cà phê". Một lần đầu tiên được hẹn trước thường dễ diễn ra hơn một lần đầu tiên "khi nào rảnh".

**Hỏi: Tuần sau làm gì?**

Đáp: Tuần sau mở Mùa 2 của hành trình với Công thức #0034, Quy tắc 5/25: viết 25 mục tiêu công việc cho năm 2027, khoanh lấy 5, và nối thói quen then chốt với mục tiêu số 1.

**Ngày 6 (20 phút)**

1. Mở sổ thực hành, đọc bảng so sánh năm 2026 và năm 2027: thói quen và câu bản sắc.
2. Đánh dấu ba việc chuẩn bị đã xong.
3. Viết lần đầu tiên làm thói quen trong năm mới, kèm ngày, giờ, chỗ.
4. Đánh dấu trên bảng hành trình nếu hôm qua hoặc hôm nay đã làm.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0033-ngay-6.

Chia sẻ hôm nay: "Tôi mang vào năm 2027 thói quen .... Lần đầu tiên trong năm mới: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích "Năm 2026 của tôi" hiện ra, có tấm lưới cả năm 2026 với những ngày mình đã giữ thói quen, kèm tên và thói quen mang vào năm 2027. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Hẹn gặp lại các anh chị và các bạn ở tuần đầu tiên của năm 2027.
