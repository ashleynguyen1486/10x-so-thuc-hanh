## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 14/06)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0057_Hieu Ung Dunning Kruger_VN.pdf (tài liệu đầy đủ của Công thức #0057)
@pdf 10XHub_DunningKruger_PhieuNgay1_tu-cham-cam-giac.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0057.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** MÌNH ĐÃ THẠO KỸ NĂNG ĐANG HỌC TỚI ĐÂU?

Tuần trước, cả nhóm đã đưa tài liệu học và tài liệu công việc vào bốn ngăn Dự án, Lĩnh vực, Tài nguyên, Lưu trữ. Thư mục dự án học giờ có tên kèm hạn chót, và mỗi người đã đặt một khung 15 phút dọn bốn ngăn mỗi tuần. Ai chưa kịp làm Ngày 6 của tuần trước vẫn mở lại được trên sổ thực hành.

Sau gần mười tuần học có chủ đích, đến lúc đặt một câu hỏi thẳng thắn: kỹ năng đang học của mình đã tới đâu rồi? Công thức #0057 của tuần này là Hiệu ứng Dunning-Kruger và tự đánh giá.

**Nếu mới tham gia:** hãy chọn một kỹ năng đang dùng hằng ngày trong công việc, ví dụ viết email trả lời khách hàng, và viết vào Ngày 1 trên sổ thực hành cùng một thói quen nhỏ mỗi ngày. Sáu ngày tuần này giúp đo mức thạo của chính kỹ năng đó bằng bằng chứng. Không cần đọc lại các tuần trước.

**Một tranh luận khoa học kéo dài hơn hai mươi năm**

Nhiều người đã nghe tới "hiệu ứng Dunning-Kruger", ít người biết quanh nó có một cuộc tranh luận khoa học. Trường mời các anh chị và các bạn đi qua bốn mốc.

**Năm 1999: bài báo gốc.** Justin Kruger và David Dunning, khi đó ở Đại học Cornell, công bố bốn nghiên cứu trên tạp chí Journal of Personality and Social Psychology. Sinh viên làm bài kiểm tra về óc hài hước, lập luận logic, ngữ pháp, rồi tự ước lượng mình đứng ở đâu so với người cùng làm. Nhóm có điểm thấp nhất (một phần tư dưới cùng) đạt điểm ở khoảng phân vị 12 (tức là cao hơn khoảng 12% người cùng làm bài), nhưng tự ước lượng ở khoảng phân vị 62. Nhóm điểm cao nhất lại có xu hướng tự ước lượng hơi thấp hơn thực tế. Cách giải thích của hai tác giả: kỹ năng cần để làm tốt một việc cũng chính là kỹ năng cần để nhận ra mình làm chưa tốt. Trong nghiên cứu thứ tư, khi người điểm thấp được hướng dẫn thêm về lập luận logic, họ tự đánh giá chính xác hơn.

**Năm 2016: câu hỏi về cách đo.** Edward Nuhfer và cộng sự dùng số ngẫu nhiên để mô phỏng, và cho thấy cách vẽ biểu đồ quen thuộc (chia người tham gia theo nhóm điểm rồi so điểm tự chấm trung bình) có thể tạo ra hình dạng rất giống hiệu ứng, ngay cả với dữ liệu ngẫu nhiên. Nguyên nhân là nhiễu đo lường và hiện tượng thống kê gọi là hồi quy về trung bình.

**Năm 2020: kiểm tra bằng phương pháp khác.** Gilles Gignac và Marcin Zajenkowski khảo sát 929 người, so điểm tự đánh giá với điểm một bài trắc nghiệm suy luận. Với các phương pháp thống kê phù hợp hơn, hai tác giả kết luận hiệu ứng phần lớn là kết quả của cách phân tích, và nếu có thì nhỏ hơn nhiều so với mô tả trước đây.

**Năm 2023: tranh luận tiếp tục.** Một nhóm khác lặp lại nghiên cứu và vẫn tìm thấy hiệu ứng ở nhóm điểm thấp, nhưng độ lớn rất nhỏ.

**Vậy điều gì còn đứng vững?**

Độ lớn của hiệu ứng vẫn đang được bàn. Điều ít ai tranh cãi là: tự đánh giá chỉ bằng cảm giác thường không chính xác, có khi cao hơn, có khi thấp hơn thực tế. Cách đáng tin hơn là đặt cảm giác cạnh bằng chứng.

Hình đường cong có "đỉnh núi" phổ biến trên mạng không có trong bài báo gốc năm 1999, nên tuần này không dùng. Và không có ai để chê cười ở đây: hiệu ứng, nếu có, xảy ra với tất cả chúng ta khi bắt đầu một lĩnh vực mới.

**Lớp mới cho hành trình**

Sau 20 phút học mỗi ngày, tuần này thêm một lớp: biết mình đang ở đâu với kỹ năng đang học, bằng ba nguồn bằng chứng là thang mô tả, bài kiểm tra nhỏ và phản hồi của người khác. Biết đúng chỗ mình đứng giúp 20 phút học tuần sau rơi đúng vào phần còn yếu, một bước cụ thể trên đường tới phiên bản 10X của chính mình.

**Sáu ngày của tuần**

- Thứ Hai: tự chấm theo cảm giác.
- Thứ Ba: thang năm mức, mỗi mức một bằng chứng.
- Thứ Tư: bài kiểm tra nhỏ 15 phút.
- Thứ Năm: xin một phản hồi cụ thể.
- Thứ Sáu: đặt cảm giác cạnh bằng chứng.
- Thứ Bảy: vòng tự đánh giá của riêng mình.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Tự chấm theo cảm giác**

1. Ngay sau thói quen then chốt, mở sổ thực hành, xem lại kỹ năng và dự án học.
2. Chia kỹ năng thành ba phần nhỏ. Ví dụ "phân tích số liệu bằng Excel" gồm làm sạch dữ liệu, lập bảng tổng hợp, vẽ biểu đồ.
3. Tự chấm từng phần và cả kỹ năng trên thang 1 đến 5, chỉ theo cảm giác, chưa cần lý do.

Con số này sẽ được dùng lại vào Thứ Sáu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-1.

Chia sẻ hôm nay: "Kỹ năng tôi đang học: .... Tự chấm theo cảm giác hôm nay: .../5".

Không có con số đúng hay sai ở bước này, các anh chị và các bạn cứ chấm thật lòng nha.


## Bài 2: Ngày 2 (Thứ Ba 15/06)
@img 2_nam-muc-thao
@pdf 10XHub_DunningKruger_PhieuNgay2_nam-muc-thao.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: THANG NĂM MỨC, MỖI MỨC MỘT BẰNG CHỨNG

Hôm qua mỗi người tự chấm một con số từ 1 đến 5. Vấn đề là con số "3" của người này có thể rất khác con số "3" của người khác, và khác cả con số "3" của chính mình vào tuần sau. Cách sửa đơn giản là gắn mỗi mức với một mô tả hành vi quan sát được. Hôm nay giải nghĩa từng mức của một thang năm mức mà tuần này dùng.

Thang dưới đây do 10X Excellence Hub biên soạn để thực hành, không phải một thang đo chuẩn của nghiên cứu. Ví dụ đi kèm là kỹ năng "viết email trả lời khiếu nại" của một người làm chăm sóc khách hàng.

**Mức 1: Biết tên.**
Mình hiểu kỹ năng này là gì và vì sao quan trọng, nhưng chưa tự làm được.
Bằng chứng trông như thế nào: giải thích được cho người khác các bước chính, chưa có sản phẩm nào.
Ví dụ: biết một email trả lời khiếu nại tốt cần xin lỗi, nêu nguyên nhân, nêu bước tiếp theo.

**Mức 2: Làm được khi có hướng dẫn.**
Mình làm được nếu có mẫu, có người bên cạnh hoặc có danh sách từng bước.
Bằng chứng: một sản phẩm hoàn thành với sự hỗ trợ.
Ví dụ: viết được email trả lời dựa trên mẫu có sẵn, trưởng nhóm sửa vài chỗ trước khi gửi.

**Mức 3: Tự làm được việc quen.**
Mình tự làm được những tình huống thường gặp, kết quả ổn định.
Bằng chứng: nhiều sản phẩm tự làm, đạt yêu cầu mà không cần sửa nhiều.
Ví dụ: tự viết email cho các khiếu nại về giao hàng chậm, gửi đi không cần duyệt.

**Mức 4: Xử lý được tình huống mới.**
Mình điều chỉnh được khi gặp tình huống chưa từng gặp hoặc khó hơn bình thường.
Bằng chứng: một ví dụ cụ thể về tình huống lạ mà mình đã xử lý tốt.
Ví dụ: trả lời một khách hàng doanh nghiệp khiếu nại lần thứ ba, giữ được quan hệ và có hướng xử lý rõ.

**Mức 5: Hướng dẫn được người khác.**
Mình giải thích được vì sao làm như vậy, và giúp người khác làm được.
Bằng chứng: một người mình hướng dẫn đã tự làm được.
Ví dụ: soạn bộ câu mẫu và kèm một nhân viên mới tự viết email đạt yêu cầu.

**Ba lưu ý khi dùng thang**

- **Chấm theo bằng chứng có thật, không theo điều mình nghĩ mình làm được.** Chưa có sản phẩm thì chưa lên mức 3.
- **Mỗi phần nhỏ của kỹ năng có thể ở mức khác nhau.** Lập bảng tổng hợp ở mức 3 nhưng vẽ biểu đồ mới ở mức 2 là chuyện bình thường.
- **Mức không phải nhãn dán cho con người.** Nó chỉ mô tả hôm nay mình làm được gì với một kỹ năng cụ thể.

**Ngày 2 (20 phút)**

1. Đọc năm mức, viết lại mô tả của từng mức cho đúng kỹ năng mình đang học.
2. Mở thư mục "Sản phẩm" của dự án học, tìm bằng chứng mạnh nhất mình đang có.
3. Chọn mức phù hợp với bằng chứng đó.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-2.

Chia sẻ hôm nay: "Theo thang mô tả, kỹ năng ... của tôi ở mức .... Bằng chứng: ...".

Nếu mức theo bằng chứng thấp hơn con số hôm qua, đó là thông tin rất có ích chứ không phải điều đáng lo nha.


## Bài 3: Ngày 3 (Thứ Tư 16/06)
@img 3_kiem-tra-nho
@pdf 10XHub_DunningKruger_PhieuNgay3_kiem-tra-nho.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: BÀI KIỂM TRA NHỎ MƯỜI LĂM PHÚT

Nguồn bằng chứng thứ hai của tuần là một bài kiểm tra do chính mình soạn. Hôm nay Trường trả lời sáu câu hỏi hay gặp nhất về bài kiểm tra này.

**Hỏi: Đã có thang năm mức rồi, sao còn cần kiểm tra?**

Thang mô tả dựa vào sản phẩm mình đã làm, mà sản phẩm cũ thường là những việc mình đã quen. Bài kiểm tra cho mình làm một việc ngay bây giờ, trong thời gian giới hạn, nên phản ánh sát hơn mức thạo hôm nay.

**Hỏi: Bài kiểm tra nhỏ gồm những gì?**

Năm câu hỏi hoặc năm nhiệm vụ ngắn, lấy từ công việc thật, làm trong khoảng 15 phút. Nên có hai câu ở mức mình thường làm, hai câu khó hơn một chút, và một câu thuộc tình huống mình chưa gặp. Ví dụ với kỹ năng Excel: làm sạch một cột dữ liệu lỗi, lập bảng tổng hợp theo bộ phận, tìm nguyên nhân một con số bất thường.

**Hỏi: Lấy câu hỏi ở đâu?**

Dễ nhất là từ những gì đã có trong Mùa 3: câu hỏi gợi nhớ ở cột trái trang Cornell, thẻ câu hỏi truy hồi, câu hỏi ở các tầng cao của phân loại Bloom. Một bài tập cuối chương của khoá học cũng rất tốt.

**Hỏi: Vì sao phải dự đoán điểm trước khi làm?**

Đây là phần quan trọng nhất của hôm nay. Trước khi làm, ghi ra mình nghĩ sẽ đúng bao nhiêu câu trên năm. Sau khi chấm, so dự đoán với kết quả. Khoảng cách giữa hai con số cho biết cảm giác của mình đang khớp với thực tế tới đâu, đúng với tinh thần của những nghiên cứu về tự đánh giá.

**Hỏi: Tự chấm bài của mình có công bằng không?**

Công bằng hơn nếu viết đáp án hoặc tiêu chí đạt trước khi làm bài. Ví dụ: "bảng tổng hợp đúng nếu tổng khớp với số liệu gốc". Với câu không có đáp án duy nhất, ghi rõ hai hoặc ba dấu hiệu của một câu trả lời tốt.

**Hỏi: Nếu điểm thấp hơn dự đoán thì sao?**

Đó chính là điều bài kiểm tra muốn tìm. Câu sai cho biết chính xác phần nào cần luyện thêm trong 20 phút học những tuần tới. Một bài kiểm tra mà mình luôn đúng hết thì không còn cho mình thông tin gì mới.

**Ngày 3 (20 phút)**

1. Soạn năm câu hỏi hoặc nhiệm vụ, viết đáp án hoặc tiêu chí đạt (khoảng 5 phút).
2. Ghi dự đoán số câu đúng.
3. Làm bài trong 15 phút, chấm theo đáp án đã viết.
4. Đánh dấu bảng hành trình những ngày tuần này đã giữ thói quen và 20 phút học.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-3.

Chia sẻ hôm nay: "Bài kiểm tra nhỏ 5 câu: tôi dự đoán đúng ... câu, thực tế đúng ... câu".

Bài kiểm tra hôm nay chỉ mình mình xem, các anh chị và các bạn cứ chọn câu đủ khó để thật sự học được điều gì đó nha.


## Bài 4: Ngày 4 (Thứ Năm 17/06)
@img 4_xin-phan-hoi
@pdf 10XHub_DunningKruger_PhieuNgay4_xin-phan-hoi.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: XIN MỘT PHẢN HỒI THẬT CỤ THỂ

Nguồn bằng chứng thứ ba đến từ bên ngoài: một người đã thấy mình làm việc đó. Phản hồi của người khác bù cho điều mà tự đánh giá khó thấy nhất, đó là góc nhìn của người nhận kết quả. Nhưng chất lượng phản hồi phụ thuộc rất nhiều vào câu hỏi mình đặt. Hôm nay là bốn cặp đối chiếu.

**Cặp 1: hỏi chung chung và hỏi về một sản phẩm**

- Câu mơ hồ: "Anh thấy em làm Excel thế nào?"
- Câu cụ thể: "Bảng tổng hợp chi phí em gửi hôm Thứ Hai, anh có phải sửa lại chỗ nào trước khi dùng không?"

Câu thứ hai gắn với một sản phẩm thật, người trả lời không phải nhớ lại cả quý.

**Cặp 2: hỏi khen chê và hỏi một điểm cần cải thiện**

- Câu mơ hồ: "Chị thấy email của em ổn không?"
- Câu cụ thể: "Nếu chỉ sửa một điều trong email trả lời khách hàng hôm qua, chị sẽ sửa điều gì?"

"Ổn không" thường nhận về "ổn". Câu hỏi "một điều" giúp người kia dễ nói thẳng mà không ngại.

**Cặp 3: hỏi cảm nhận và hỏi so với chuẩn**

- Câu mơ hồ: "Em trình bày có hay không anh?"
- Câu cụ thể: "So với cách anh muốn một bài trình bày cho khách hàng, phần mở đầu của em thiếu gì?"

Câu thứ hai mời người kia so với tiêu chuẩn họ đang dùng, đúng với điều mình cần biết.

**Cặp 4: xin phản hồi lúc nào cũng được và hẹn một thời điểm**

- Câu mơ hồ: "Khi nào rảnh anh góp ý giúp em nha."
- Câu cụ thể: "Em gửi bảng này, anh xem giúp em trước 16 giờ Thứ Sáu, chỉ cần hai dòng là đủ."

Lời nhờ có thời hạn và có giới hạn công sức thường được trả lời nhanh hơn.

**Chọn ai để hỏi?**

Người đã trực tiếp thấy kết quả công việc của mình: quản lý trực tiếp, đồng nghiệp nhận sản phẩm của mình, một người đi trước trong kỹ năng đó. Không cần là người giỏi nhất công ty, chỉ cần là người thấy rõ việc mình làm. Khi nhận phản hồi, việc đầu tiên là cảm ơn, chưa cần giải thích hay phản biện.

**Ngày 4 (20 phút)**

1. Chọn một sản phẩm gần nhất của dự án học hoặc của kỹ năng đang học.
2. Chọn một người đã thấy kết quả đó.
3. Viết câu hỏi theo kiểu cụ thể: gắn với sản phẩm, hỏi một điều, có chuẩn so sánh, có thời hạn.
4. Gửi đi hôm nay.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-4.

Chia sẻ hôm nay: "Tôi xin phản hồi từ ... với câu hỏi: ...".

Khi chia sẻ, các anh chị và các bạn chỉ cần ghi vai trò của người được hỏi, ví dụ "trưởng nhóm" hay "đồng nghiệp phòng kế toán", không cần ghi tên nha.


## Bài 5: Ngày 5 (Thứ Sáu 18/06)
@img 5_cam-giac-bang-chung
@pdf 10XHub_DunningKruger_PhieuNgay5_cam-giac-bang-chung.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: ĐẶT CẢM GIÁC CẠNH BẰNG CHỨNG

Ba nguồn bằng chứng đã có: thang năm mức (Thứ Ba), bài kiểm tra nhỏ (Thứ Tư), phản hồi (Thứ Năm, có thể chưa nhận được, không sao). Hôm nay đặt chúng cạnh con số tự chấm của Thứ Hai. Để dễ hình dung, đây là hai tình huống minh hoạ đi theo hai hướng ngược nhau.

**Tình huống 1: chị Lan, chăm sóc khách hàng**

Kỹ năng chị Lan học trong Mùa 3 là viết email trả lời khiếu nại. Thứ Hai, chị tự chấm 4 trên 5. Chị đã viết rất nhiều email, và cảm thấy khá tự tin.

Thứ Ba, đối chiếu thang năm mức, chị thấy mình có nhiều email tự gửi đi không cần duyệt cho các tình huống quen: mức 3. Thứ Tư, bài kiểm tra năm tình huống, chị dự đoán đúng cả năm, thực tế đạt ba. Hai câu chưa đạt đều là khiếu nại có nhiều bên liên quan. Thứ Năm, trưởng nhóm trả lời: "Giọng văn tốt, nhưng email nào cũng chưa nói rõ bước tiếp theo và thời hạn."

Chị Lan kết luận: theo bằng chứng, chị ở mức 3. Phần cần luyện thêm: khiếu nại nhiều bên, và câu kết có bước tiếp theo rõ ràng. Hai mươi phút học tuần tới đã có đích cụ thể.

**Tình huống 2: anh Nam, kỹ thuật bảo trì**

Kỹ năng anh Nam học là đọc bản vẽ điện của dây chuyền mới. Thứ Hai, anh chỉ dám tự chấm 2, vì vẫn thấy mình chậm hơn các anh đi trước.

Thang năm mức cho thấy anh đã tự xử lý hai sự cố lạ trong tháng: mức 4. Bài kiểm tra anh dự đoán đúng hai, thực tế đúng bốn. Tổ trưởng phản hồi: "Em đọc bản vẽ chắc rồi, có thể bắt đầu kèm bạn mới."

Anh Nam kết luận: theo bằng chứng, anh ở mức 4. Điều anh cần không phải học lại từ đầu, mà là bắt đầu chia sẻ cách mình đọc bản vẽ.

Hai tình huống trên là minh hoạ, tên nhân vật là giả định.

**Ba khả năng khi đặt hai con số cạnh nhau**

- **Tự chấm cao hơn bằng chứng.** Rất thường gặp với kỹ năng mình làm nhiều nhưng ít được kiểm tra. Bằng chứng chỉ ra phần cần luyện.
- **Khớp nhau.** Cảm giác của mình đang đáng tin với kỹ năng này. Vẫn nên đối chiếu lại sau vài tuần.
- **Tự chấm thấp hơn bằng chứng.** Cũng thường gặp, nhất là với người cẩn thận. Bằng chứng cho phép tự tin hơn và nhận việc khó hơn.

Không khả năng nào là "xấu". Cả ba đều là thông tin để 20 phút học được dùng đúng chỗ.

**Ngày 5 (20 phút)**

1. Xem lại con số tự chấm Thứ Hai, mức theo thang, điểm bài kiểm tra và phản hồi nếu đã có.
2. Chọn mức theo bằng chứng, ghi khoảng cách so với tự chấm.
3. Viết phần cần luyện thêm trong 20 phút học tuần tới.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-5.

Chia sẻ hôm nay: "Tự chấm .../5, theo bằng chứng .../5. Phần tôi cần luyện thêm: ...".

Cuối tuần rồi, ai chưa nhận được phản hồi cứ dùng hai nguồn còn lại trước, khi có phản hồi thì cập nhật sau nha.


## Bài 6: Ngày 6 (Thứ Bảy 19/06)
@img 6_vong-tu-danh-gia
@img2 9_the-thanh-tich
@pdf 10XHub_DunningKruger_PhieuNgay6_vong-tu-danh-gia.pdf (phiếu thực hành và bảng đối chiếu in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: VÒNG TỰ ĐÁNH GIÁ CỦA RIÊNG MÌNH

Một tuần tự đánh giá đã khép lại. Sáng nay không có kiến thức mới, chỉ có năm câu hỏi mở để nhìn lại, và một việc nhỏ để biến tuần này thành một nhịp đều đặn.

**Câu hỏi 1: Điều gì làm mình bất ngờ nhất về mức thạo của chính mình?**

Có người bất ngờ vì mình chưa vững như mình nghĩ ở một phần nhỏ. Có người bất ngờ vì mình đã đi xa hơn mình tưởng. Gọi tên được điều bất ngờ là đã học được điều gì đó về chính mình.

**Câu hỏi 2: Nguồn bằng chứng nào nói với mình nhiều nhất?**

Thang mô tả, bài kiểm tra hay phản hồi? Với mỗi kỹ năng, câu trả lời có thể khác. Kỹ năng có sản phẩm rõ thường hợp với thang mô tả; kỹ năng cần phản xạ nhanh thường hợp với bài kiểm tra; kỹ năng làm việc với người khác thường cần phản hồi.

**Câu hỏi 3: Phần nhỏ nào của kỹ năng cần được 20 phút học tuần tới ưu tiên?**

Câu trả lời cho câu này đã có từ Thứ Sáu. Hôm nay chỉ cần đặt nó vào kế hoạch, ví dụ "ba buổi đầu tuần luyện câu kết email có bước tiếp theo".

**Câu hỏi 4: Mình đã đi được bao xa so với đầu Mùa 3?**

Mười một tuần trước, kỹ năng này mới chỉ là một dòng trên sổ thực hành. Hôm nay mình đã có sản phẩm, có bài kiểm tra, có một mức được chứng minh bằng bằng chứng. Đó là tiến bộ thật, đo được, và là của chính mình.

**Câu hỏi 5: Mình muốn tự đánh giá lại vào lúc nào?**

Tự đánh giá một lần thì cho một bức ảnh. Tự đánh giá đều đặn thì cho một đoạn phim, thấy được mình đang đi lên ở đâu. Đó là việc của sáng nay.

**Sáng nay (15 phút)**

1. Trả lời năm câu hỏi trên sổ thực hành.
2. Viết vòng tự đánh giá của riêng mình: bao lâu một lần, dùng nguồn bằng chứng nào. Ví dụ "cuối mỗi tháng, một bài kiểm tra 5 câu và một câu hỏi xin phản hồi".

**Trước khi nghỉ Chủ Nhật (10 phút)**

In bảng đối chiếu ở phiếu Ngày 6, điền con số của tuần này và kẹp vào thư mục dự án học. Lần tự đánh giá sau chỉ cần điền thêm một cột.

**Tuần sau: Xây dựng công khai, chia sẻ điều mình học**

Anh Nam trong tình huống hôm qua đã được gợi ý bắt đầu chia sẻ cách mình làm. Tuần sau cả nhóm cùng làm điều đó: mỗi người chia sẻ một điều đã học từ dự án học, và xem việc chia sẻ giúp chính mình học sâu hơn như thế nào.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0057-ngay-6.

Chia sẻ hôm nay: "Điều tôi nhận ra về mức thạo của mình: .... Vòng tự đánh giá của tôi: ...".

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích của tuần hiện ra: sáu vòng tròn khép kín theo những ngày đã giữ thói quen, con số ngày của tuần, tên mình và vòng tự đánh giá mình vừa đặt. Tải thẻ về và đăng vào bình luận dưới bài này. Còn thiếu ngày nào thì Chủ Nhật vẫn làm bù được.

Chủ Nhật 20.06 là Ngày của Cha. Chúc các anh chị và các bạn một ngày Chủ Nhật nghỉ ngơi trọn vẹn bên gia đình nha.
