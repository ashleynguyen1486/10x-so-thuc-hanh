## Bài 1: Mở tuần và Ngày 1 (Thứ Hai 10/05)
@img 1_mo-tuan
@pdf 10XHub_CongThuc_0052_Hoc Xen Ke_VN.pdf (tài liệu đầy đủ của Công thức #0052)
@pdf 10XHub_HocXenKe_PhieuNgay1_cac-dang-bai.pdf (phiếu thực hành một trang)
@pdf 10XHub_HuongDan_SoThucHanh_0052.pdf (hướng dẫn sổ thực hành của tuần)
@cat Challenges, ghim bài, bật gửi email cho cả nhóm

**Tiêu đề bài trên Skool:** HỌC XEN KẼ: KHI THẤY KHÓ HƠN LẠI LÀ DẤU HIỆU TỐT

Tuần trước, mỗi người đã dựng một cung điện trí nhớ từ một nơi quen thuộc, đặt vào đó các ý chính của một bài trình bày, một quy trình hay một nhóm số liệu, rồi đưa vào một việc thật. Nhiều cung điện được dựng ngay trên đường vào phòng họp. Cung điện đó đã được lưu trên sổ thực hành và sẽ còn dùng tiếp cho những nội dung mới.

Công thức #0052 của tuần là Học xen kẽ và khó khăn có ích.

**Nếu mới tham gia:** tuần này chỉ cần một kỹ năng mình đang muốn học thêm cho công việc, và 20 phút mỗi ngày. Ở Ngày 1 trên sổ thực hành, hãy viết thói quen nhỏ mình muốn giữ, kỹ năng đó, rồi liệt kê ba, bốn dạng bài tập hay dạng tình huống của kỹ năng. Mọi việc khác trong tuần dựa trên danh sách này.

**Hai buổi học 20 phút, đặt cạnh nhau**

Hôm nay bắt đầu bằng hai buổi học của cùng một người, chị Thảo, chuyên viên phân tích ở phòng kinh doanh, đang học phân tích dữ liệu bằng bảng tính. Kỹ năng của chị có ba dạng bài: lọc dữ liệu, tổng hợp theo nhóm, và vẽ biểu đồ.

**Buổi thứ nhất: học dồn**

- Cách làm: 7 phút chỉ làm bài lọc dữ liệu, 7 phút chỉ làm bài tổng hợp, 6 phút chỉ làm bài vẽ biểu đồ.
- Trong lúc học: bài thứ hai của mỗi dạng đã nhanh hơn bài đầu, bài thứ ba gần như làm theo quán tính.
- Cảm giác cuối buổi: thạo, tự tin, "hôm nay học tốt".

**Buổi thứ hai: học xen kẽ**

- Cách làm: cùng 20 phút, cùng số bài, nhưng thứ tự bị trộn: lọc, biểu đồ, tổng hợp, lọc, tổng hợp, biểu đồ.
- Trong lúc học: mỗi bài mới phải dừng lại một chút để nhận ra "bài này thuộc dạng nào, dùng cách nào". Có lần chọn nhầm cách.
- Cảm giác cuối buổi: chậm hơn, khó hơn, "hình như hôm nay học kém".

Phần lớn chúng ta sẽ đánh giá buổi thứ nhất là buổi học tốt hơn. Nhưng nhiều nghiên cứu trong hơn hai mươi năm qua cho thấy điều ngược lại ở bài kiểm tra vài ngày sau: người học xen kẽ thường làm tốt hơn, nhất là khi phải tự nhận ra dạng bài.

Một ví dụ thường được nhắc: năm 2007, Doug Rohrer và Kelli Taylor cho sinh viên học cách tính thể tích của bốn loại hình khối. Trong lúc luyện, nhóm học dồn làm đúng nhiều hơn. Nhưng ở bài kiểm tra một tuần sau, nhóm học xen kẽ đạt khoảng 63% câu đúng, nhóm học dồn chỉ khoảng 20%.

**Vì sao khó hơn lại tốt hơn?**

Nhà tâm lý học Robert Bjork ở Đại học California, Los Angeles gọi những điều này là "khó khăn có ích": những cách học làm mình thấy khó hơn trong lúc học, nhưng giúp nhớ lâu hơn và dùng linh hoạt hơn sau đó. Học xen kẽ khó hơn vì mỗi bài buộc mình phải chọn cách giải, đúng như điều sẽ xảy ra trong công việc thật, nơi không ai báo trước "việc tiếp theo thuộc dạng nào".

Cần nói rõ ngay từ đầu: không phải khó khăn nào cũng có ích, và học xen kẽ không hợp với mọi loại nội dung. Thứ Sáu sẽ có một danh sách để phân biệt.

**Lớp mới cho hành trình**

Từ #0047, mỗi ngày có 20 phút học có chủ đích ngay sau thói quen then chốt. Tuần này không thêm thời gian. Tuần này chỉ đổi cách sắp xếp bên trong 20 phút: trộn các dạng bài hoặc tình huống thay vì học dồn một dạng, và tập nhìn cảm giác khó như một tín hiệu đang học sâu, không phải tín hiệu thất bại.

**Sáu ngày của tuần**

- Thứ Hai: liệt kê các dạng bài của kỹ năng đang học.
- Thứ Ba: buổi học xen kẽ đầu tiên.
- Thứ Tư: gọi tên dạng bài trước khi làm.
- Thứ Năm: chọn cách trộn cho 20 phút học.
- Thứ Sáu: tự kiểm tra trộn dạng.
- Thứ Bảy: nhìn lại một tuần, khép tuần.

Chủ Nhật nghỉ.

**Ngày 1 (20 phút): Liệt kê các dạng bài**

1. Mở sổ thực hành, xem lại thói quen đang giữ, kỹ năng đang học và cung điện trí nhớ tuần trước.
2. Liệt kê ba hoặc bốn dạng bài tập, dạng tình huống của kỹ năng đang học. Ví dụ với kỹ năng đàm phán: đàm phán giá, đàm phán thời hạn giao hàng, xử lý từ chối.
3. Với mỗi dạng, ghi một bài tập hoặc tình huống mẫu dùng được trong tuần.
4. Chọn dạng mình thấy đã thạo nhất và dạng còn yếu nhất.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-1.

Chia sẻ hôm nay: "Kỹ năng đang học của tôi có các dạng: .... Dạng tôi còn yếu nhất: ...".

Nếu kỹ năng đang học khó chia dạng, các anh chị và các bạn thử nghĩ về những loại khách hàng, loại lỗi, hay loại tài liệu khác nhau mình sẽ gặp khi dùng kỹ năng đó nha.


## Bài 2: Ngày 2 (Thứ Ba 11/05)
@img 2_kho-khan-co-ich
@pdf 10XHub_HocXenKe_PhieuNgay2_buoi-dau.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 2: KHÓ KHĂN CÓ ÍCH NGHĨA LÀ GÌ?

Hôm qua bài viết dùng cụm từ "khó khăn có ích". Hôm nay giải nghĩa từng phần của nó, vì hiểu đúng cụm từ này sẽ giúp buổi học xen kẽ đầu tiên bớt nản.

**"Học" và "thể hiện" là hai việc khác nhau**

Robert Bjork và các cộng sự phân biệt hai điều thường bị gộp làm một. Thể hiện là mình làm tốt đến đâu ngay trong lúc học. Học là điều còn lại sau đó: vài ngày, vài tuần sau, mình còn nhớ và dùng được bao nhiêu. Hai điều này có thể đi ngược nhau. Một buổi học dồn cho thể hiện rất tốt, nhưng điều còn lại sau một tuần có thể ít hơn.

**"Khó khăn"**

Khó khăn ở đây là những điều làm việc học chậm hơn, nhiều lỗi hơn trong lúc học. Năm 1994, Bjork dùng cụm từ khó khăn có ích trong một chương sách về đào tạo, và các nhà nghiên cứu sau này thường nhắc đến một số ví dụ: học cách quãng thay vì học dồn một lần (#0040), tự kiểm tra thay vì đọc lại (#0048), và học xen kẽ nhiều dạng thay vì học từng dạng một.

**"Có ích"**

Chữ quan trọng nhất là chữ này. Một khó khăn có ích khi nó buộc mình làm đúng điều cần làm để nhớ và hiểu: gọi lại từ trí nhớ, so sánh, phân biệt, chọn cách giải. Một khó khăn không có ích khi nó chỉ gây rối mà không đòi hỏi suy nghĩ đó, ví dụ tài liệu viết khó hiểu, phòng làm việc ồn ào, hay bài tập vượt quá xa nền tảng hiện có.

**"Có ích" còn phụ thuộc vào nền tảng**

Nếu một dạng bài mình chưa hiểu gì, trộn nó với các dạng khác chỉ làm rối thêm. Vì vậy cách hợp lý là học hiểu từng dạng trước, làm vài bài mẫu, rồi mới trộn. Học xen kẽ phát huy khi các dạng đã quen ở mức cơ bản, và cái khó nằm ở việc nhận ra dạng nào là dạng nào.

**Cảm giác "học kém" là thông tin, không phải kết luận**

Trong buổi học xen kẽ hôm nay, rất có thể mình sẽ thấy chậm hơn và làm sai nhiều hơn so với học dồn. Hãy ghi lại cảm giác đó bằng một con số, cùng với số bài làm đúng. Cuối tuần, đặt các con số cạnh nhau sẽ thấy rõ hơn.

**Ngày 2 (20 phút)**

1. Chọn ba dạng bài từ danh sách hôm qua, mỗi dạng hai bài hoặc hai tình huống.
2. Trộn thứ tự sáu bài, sao cho không có hai bài cùng dạng đứng liền nhau.
3. Làm lần lượt trong 20 phút, không xem lời giải trước.
4. Ghi mức khó mình cảm thấy (1 rất dễ, 5 rất khó) và số bài làm đúng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-2.

Chia sẻ hôm nay: "Buổi học xen kẽ đầu tiên: mức khó tôi cảm thấy .../5, làm đúng ... bài.".

Thấy khó trong buổi đầu là điều rất bình thường, các anh chị và các bạn cứ ghi đúng con số của mình nha.


## Bài 3: Ngày 3 (Thứ Tư 12/05)
@img 3_phong-tranh
@pdf 10XHub_HocXenKe_PhieuNgay3_goi-ten-dang.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 3: BÀI HỌC TỪ MỘT PHÒNG TRANH

Hãy hình dung mình là người tham gia một thí nghiệm ở Đại học California, Los Angeles, khoảng năm 2007.

Trên màn hình, lần lượt hiện ra những bức tranh phong cảnh, mỗi bức kèm tên một hoạ sĩ. Có 12 hoạ sĩ, phần lớn mình chưa nghe tên bao giờ. Nhiệm vụ là học để sau đó nhận ra phong cách của từng người, kể cả với những bức tranh chưa từng thấy.

Tranh của một nửa số hoạ sĩ được xếp theo kiểu dồn: sáu bức của cùng một người hiện liền nhau, rồi mới sang người khác. Tranh của nửa còn lại được xếp xen kẽ: bức của người này xen với bức của những người khác.

Cuối buổi, mình xem những bức tranh mới và đoán tên hoạ sĩ. Rồi người hướng dẫn hỏi thêm một câu: "Theo bạn, cách xếp nào giúp bạn học tốt hơn?"

**Kết quả**

Đây là thí nghiệm của Nate Kornell và Robert Bjork, công bố năm 2008 trên tạp chí Psychological Science. Ở lần kiểm tra đầu, người tham gia nhận ra đúng khoảng 61% tranh của các hoạ sĩ được học xen kẽ, so với khoảng 35% với các hoạ sĩ được học dồn.

Điều đáng chú ý hơn nằm ở câu hỏi cuối. Khoảng 78% người tham gia cho rằng cách học dồn tốt bằng hoặc tốt hơn cách học xen kẽ, dù chính kết quả của họ cho thấy điều ngược lại. Nói cách khác, cảm giác "mình đang học tốt" đã đánh lừa phần lớn mọi người.

**Vì sao xen kẽ giúp nhận ra phong cách?**

Khi tranh của các hoạ sĩ xen nhau, mắt mình liên tục phải so sánh: bức này khác bức trước ở đâu, nét cọ này giống ai hơn. Chính việc so sánh đó giúp nhận ra điểm riêng của từng người. Khi học dồn, sáu bức của cùng một người liền nhau, mình thấy điểm chung nhưng ít khi để ý điểm khác với người khác.

**Liên hệ với công việc**

Công việc hằng ngày rất giống phòng tranh đó. Một nhân viên chăm sóc khách hàng không nhận khiếu nại theo từng nhóm, mà nhận xen kẽ: lỗi giao hàng, rồi lỗi thanh toán, rồi một câu hỏi về bảo hành. Một kỹ sư bảo trì không gặp từng loại sự cố theo thứ tự. Kỹ năng quan trọng nhất trong những tình huống đó là nhận ra ngay "đây là loại vấn đề nào". Học xen kẽ luyện đúng kỹ năng đó.

**Bước thêm của hôm nay: gọi tên dạng bài**

Để buổi học xen kẽ phát huy, hôm nay thêm một bước nhỏ: trước khi giải mỗi bài, dừng vài giây và tự nói "bài này thuộc dạng ...", kèm một lý do ngắn. Bước này biến việc trộn bài thành việc luyện phân biệt.

**Ngày 3 (20 phút)**

1. Chuẩn bị sáu bài mới, ba dạng, trộn thứ tự như hôm qua.
2. Trước mỗi bài, gọi tên dạng bài và lý do, rồi mới giải.
3. Ghi lại số lần gọi tên đúng dạng ngay từ đầu.
4. Viết một điều mình nhận ra về sự khác nhau giữa các dạng.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-3.

Chia sẻ hôm nay: "Hôm nay trước mỗi bài tôi gọi tên dạng bài. Điều tôi nhận ra: ...".


## Bài 4: Ngày 4 (Thứ Năm 13/05)
@img 4_ba-cach-tron
@pdf 10XHub_HocXenKe_PhieuNgay4_cach-tron.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 4: BA CÁCH TRỘN CHO NGƯỜI ĐI LÀM

Sau hai buổi học xen kẽ, hôm nay chọn cách trộn sẽ dùng cho 20 phút học từ tuần tới. Bài hôm nay là một bảng chọn với ba cách trộn, mỗi cách có điều kiện phù hợp và một ví dụ. Có thể chọn một cách, hoặc kết hợp hai.

**Cách 1: Trộn dạng bài trong một kỹ năng**

- Hợp khi: kỹ năng có các dạng bài rõ ràng, dễ nhầm với nhau.
- Cách làm: mỗi buổi chọn hai, ba dạng, trộn thứ tự, gọi tên dạng trước khi làm.
- Ví dụ: một kế toán học thuế trộn bài tập về thuế giá trị gia tăng, thuế thu nhập doanh nghiệp và thuế thu nhập cá nhân trong cùng một buổi.

**Cách 2: Trộn tình huống công việc**

- Hợp khi: kỹ năng thiên về xử lý tình huống với con người hoặc sự cố.
- Cách làm: viết sẵn một bộ thẻ tình huống, mỗi buổi rút ngẫu nhiên ba, bốn thẻ.
- Ví dụ: một nhân viên kinh doanh luyện xử lý từ chối với bộ thẻ: "giá cao quá", "để tôi hỏi sếp", "đang dùng nhà cung cấp khác", "chưa cần lúc này".

**Cách 3: Trộn bài cũ với bài mới**

- Hợp khi: đang học nối tiếp nhiều phần, sợ quên phần đã học.
- Cách làm: mỗi buổi dành vài phút đầu cho một hai bài của phần cũ, trộn vào giữa các bài của phần mới.
- Ví dụ: một kỹ sư học phần mềm thiết kế, tuần này học phần lắp ráp, mỗi buổi vẫn làm xen một bài vẽ chi tiết của tuần trước. Cách này kết hợp học xen kẽ với lặp lại cách quãng của #0040.

**Ba câu hỏi để chọn**

1. Kỹ năng của mình có các dạng bài dễ nhầm với nhau không? Có thì nghiêng về cách 1.
2. Kỹ năng có dùng chủ yếu trong tình huống với khách hàng, đồng nghiệp hay sự cố không? Có thì nghiêng về cách 2.
3. Mình đang học nối tiếp nhiều phần và hay quên phần cũ không? Có thì thêm cách 3.

**Lịch trộn cho tuần tới**

Sau khi chọn, đánh dấu trên lịch năm buổi học của tuần tới: mỗi buổi sẽ có những dạng nào. Nguyên tắc đơn giản: không buổi nào chỉ có một dạng, và mỗi dạng xuất hiện ít nhất hai buổi trong tuần.

**Ngày 4 (20 phút)**

1. Trả lời ba câu hỏi để chọn cách trộn.
2. Viết cách trộn của mình trong một câu.
3. Đánh dấu lịch trộn cho năm buổi học của tuần tới.
4. Đánh dấu bảng hành trình những ngày tuần này đã làm thói quen.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-4. Cách trộn được lưu cho cả hành trình.

Chia sẻ hôm nay: "Cách trộn của tôi cho 20 phút học: ...".


## Bài 5: Ngày 5 (Thứ Sáu 14/05)
@img 5_kho-khan-nao
@pdf 10XHub_HocXenKe_PhieuNgay5_tu-kiem-tra.pdf (phiếu thực hành một trang)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 5: KHÓ KHĂN NÀO CÓ ÍCH, KHÓ KHĂN NÀO KHÔNG?

Như đã nói từ Thứ Hai, hôm nay là danh sách để phân biệt. Học xen kẽ là một công cụ tốt, nhưng có phạm vi. Năm 2019, Marion Brunmair và Tobias Richter tổng hợp 59 nghiên cứu về học xen kẽ. Kết quả chung là có lợi ở mức trung bình, nhưng rất khác nhau tùy loại nội dung: lợi rõ nhất với việc phân biệt tranh của các hoạ sĩ, có lợi với các bài toán, không rõ ràng với văn bản giải thích, và với việc học từ vựng thì học dồn lại có phần tốt hơn.

Từ đó có sáu dấu hiệu dưới đây.

**Dấu hiệu cho thấy khó khăn đang có ích**

1. **Mình phải dừng lại để nhận ra dạng bài.** Đây chính là điều học xen kẽ luyện. Khó ở bước nhận ra là khó đúng chỗ.
2. **Mình sai, rồi hiểu vì sao sai.** Một lỗi chọn nhầm cách giải, được sửa ngay, thường dạy nhiều hơn mười bài làm đúng theo quán tính.
3. **Các dạng bài dễ nhầm với nhau.** Lợi ích lớn nhất khi các dạng trông giống nhau nhưng cần cách xử lý khác nhau, như các loại thuế, các loại lỗi máy, các kiểu từ chối của khách hàng.

**Dấu hiệu cho thấy khó khăn đang không có ích**

4. **Mình chưa hiểu cách làm của một dạng nào cả.** Khi đó cần quay lại học từng dạng, làm bài mẫu, rồi mới trộn.
5. **Cái khó đến từ bên ngoài bài học.** Tài liệu khó đọc, chỗ ngồi ồn, bị gián đoạn liên tục. Những điều này chỉ làm chậm, không làm nhớ sâu hơn. Hãy gỡ chúng đi.
6. **Nội dung là một danh sách cần thuộc lòng, như từ vựng hay thuật ngữ.** Với loại này, trộn không giúp nhiều. Cung điện trí nhớ của tuần trước, hoặc thẻ tự kiểm tra, phù hợp hơn.

**Một cách kiểm tra đơn giản**

Hỏi mình: "cái khó này buộc mình suy nghĩ về nội dung, hay chỉ làm mình mất thời gian?". Nếu là vế đầu, giữ lại. Nếu là vế sau, gỡ đi.

**Bài tự kiểm tra hôm nay**

Hôm nay kết hợp học xen kẽ với truy hồi chủ động của #0048: một bài tự kiểm tra ngắn, trộn tất cả các dạng đã học trong tuần, không xem lại trước. Đây là cách nhìn gần nhất với điều sẽ xảy ra trong công việc thật.

**Ngày 5 (20 phút)**

1. Chuẩn bị tám bài hoặc tình huống mới, trộn đủ các dạng đã học.
2. Làm liền, không xem ghi chú, gọi tên dạng trước mỗi bài.
3. Ghi số bài làm đúng trên tổng số bài.
4. Đánh dấu những dấu hiệu mình gặp trong tuần, trong danh sách sáu dấu hiệu.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-5.

Chia sẻ hôm nay: "Bài tự kiểm tra trộn dạng: tôi làm đúng ... trên ... bài.".

Con số hôm nay chỉ để mình so với chính mình ở các tuần sau, các anh chị và các bạn không cần so với ai nha.


## Bài 6: Ngày 6 (Thứ Bảy 15/05)
@img 6_nhin-lai
@img2 9_the-thanh-tich
@pdf 10XHub_HocXenKe_PhieuNgay6_nhin-lai.pdf (phiếu thực hành và thẻ lịch trộn in được)
@cat Challenges

**Tiêu đề bài trên Skool:** NGÀY 6: MỘT TUẦN HỌC XEN KẼ, NHÌN LẠI

Hôm nay mở đầu bằng trang nhật ký minh hoạ của anh Phúc, chuyên viên chăm sóc khách hàng của một công ty bán thiết bị gia dụng. Kỹ năng anh chọn ở #0047 là xử lý khiếu nại phức tạp. Ba dạng tình huống của anh: lỗi giao hàng, lỗi sản phẩm, và khiếu nại về hoá đơn.

**Thứ Hai.** Liệt kê ba dạng. Thấy mình thạo nhất là lỗi giao hàng, yếu nhất là khiếu nại hoá đơn, vì ít gặp.

**Thứ Ba.** Buổi xen kẽ đầu tiên với sáu tình huống viết sẵn. Cảm giác khó 4 trên 5. Làm đúng 4 trên 6. Có một lần xử lý khiếu nại hoá đơn theo cách của lỗi giao hàng, xin lỗi về thời gian giao trong khi khách hỏi về thuế. Hơi nản.

**Thứ Tư.** Thêm bước gọi tên dạng trước mỗi tình huống. Nhận ra khiếu nại hoá đơn và lỗi giao hàng hay bị nhầm vì khách thường mở đầu giống nhau: "đơn hàng của tôi có vấn đề". Viết vào sổ: nghe hết câu thứ hai của khách rồi mới gọi tên dạng.

**Thứ Năm.** Chọn cách 2, trộn tình huống công việc. Viết mười hai thẻ tình huống, mỗi buổi tuần tới rút bốn thẻ. Thêm cách 3: mỗi buổi một thẻ của tuần trước.

**Thứ Sáu.** Bài tự kiểm tra tám tình huống trộn. Làm đúng 6 trên 8. Cảm giác khó vẫn là 4, nhưng lần này không còn nhầm hoá đơn với giao hàng.

**Thứ Bảy.** Nhìn lại: cảm giác khó gần như không đổi cả tuần, nhưng số tình huống xử lý đúng tăng lên, và lỗi nhầm dạng biến mất. Điều mình rút ra: cảm giác khó không phải thước đo tốt của việc học.

Trang nhật ký trên là minh hoạ. Điều đáng chú ý là anh Phúc ghi hai loại con số song song: cảm giác khó và kết quả. Chỉ khi đặt cạnh nhau, mình mới thấy điều mà Kornell và Bjork đã thấy ở phòng tranh: cảm giác và kết quả có thể đi theo hai hướng khác nhau.

**Một tuần, một lớp mới**

Thói quen then chốt vẫn ở nguyên khung giờ. Hai mươi phút học vẫn là hai mươi phút. Điều thay đổi là cách sắp xếp bên trong, và cách nhìn cảm giác khó. Mỗi buổi học xen kẽ luyện đúng điều công việc thật đòi hỏi: nhận ra loại vấn đề và chọn cách xử lý. Đó là một bước cụ thể về phía phiên bản 10X của chính mình.

**Sáng nay (20 phút)**

1. Đặt cạnh nhau các con số trong tuần: mức khó cảm thấy (Thứ Ba) và số bài làm đúng (Thứ Ba, Thứ Sáu).
2. Viết một điều rút ra từ tuần học xen kẽ.
3. Xem lại cách trộn đã lưu, sửa nếu cần, và chọn buổi học xen kẽ đầu tiên của tuần tới.

Nếu thích, in thẻ lịch trộn ở trang 2 của phiếu Ngày 6 và đặt cạnh chỗ ngồi học 20 phút.

Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#0052-ngay-6.

Chia sẻ hôm nay: "Một tuần học xen kẽ, điều tôi rút ra: .... Tuần tới tôi giữ cách trộn: ...".

**Tuần sau, Thứ Hai 17.05: #0053 Bản đồ tư duy**

Sau ba tuần về điều gì để học, cách nhớ và cách luyện, tuần sau chuyển sang cách tổ chức kiến thức: tóm một buổi học hay một tài liệu thành một bản đồ một trang để nhìn thấy các liên kết, kết hợp chữ và hình. Và một gợi ý đáng chú ý từ các nghiên cứu: vẽ bản đồ từ trí nhớ, nối với truy hồi chủ động của #0048.

**Thẻ thành tích**

Ai đánh dấu chia sẻ đủ 6 ngày trên sổ thực hành sẽ thấy thẻ thành tích hiện ra: một đường cong đi lên, chữ ABC lớn, dòng "HỌC XEN KẼ", tên mình và cách trộn của mình. Tải thẻ về và đăng vào bình luận dưới bài này. Ngày nào còn thiếu thì Chủ Nhật vẫn làm bù được.

Chủ Nhật nghỉ ngơi trọn vẹn nha. Hẹn gặp lại các anh chị và các bạn sáng Thứ Hai.
