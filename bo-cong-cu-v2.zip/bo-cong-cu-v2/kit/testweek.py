"""Kiểm thử một tuần trên sổ thực hành chạy cục bộ.
python3 testweek.py 0023 2026-10-24   (số tuần, ngày giả lập để xem thẻ thành tích)
- Tạo site tạm từ gh_all (sth.js, weeks.json phải có mục của tuần) và site21/index.html.
- Điền mọi ô có giá trị mẫu, đánh dấu đủ 6 ngày, chụp từng ngày và thẻ thành tích vào wXXXXn/test/.
- In câu chia sẻ từng ngày và lỗi JavaScript nếu có.
"""
import asyncio,datetime,json,os,shutil,sys,subprocess,socket
SP='/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad'
wid=sys.argv[1]; day=sys.argv[2] if len(sys.argv)>2 else None
site=f'{SP}/site_{wid}'; shutil.rmtree(site,ignore_errors=True); os.makedirs(site)
shutil.copy(f'{SP}/site21/index.html',site); shutil.copy(f'{SP}/site21/logo.png',site)
for f in os.listdir(f'{SP}/gh_all'): shutil.copy(f'{SP}/gh_all/{f}',site)
W=json.load(open(f'{site}/{wid}.json'))
wk=[w for w in json.load(open(f'{site}/weeks.json'))['weeks'] if w['id']==wid]
assert wk, 'weeks.json chưa có tuần '+wid
start=wk[0]['start']
s=socket.socket();s.bind(('',0));port=s.getsockname()[1];s.close()
srv=subprocess.Popen([sys.executable,'-m','http.server',str(port)],cwd=site,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
out=f'{SP}/w{wid}n/test';os.makedirs(out,exist_ok=True)
from playwright.async_api import async_playwright
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();pg=await b.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    d0=datetime.date.fromisoformat(start)+datetime.timedelta(days=5)
    await pg.clock.install(time=datetime.datetime(d0.year,d0.month,d0.day,9))
    await pg.goto(f'http://localhost:{port}/#{wid}-ngay-1',wait_until='networkidle');await pg.wait_for_timeout(800)
    await pg.evaluate("()=>localStorage.clear()");await pg.reload(wait_until='networkidle');await pg.wait_for_timeout(1200)
    for d in range(1,len(W['days'])+1):
      await pg.click(f'[data-day="{d}"]');await pg.wait_for_timeout(300)
      for el in await pg.locator('main input[type=text][data-k], main textarea[data-k]').all():
        k=await el.get_attribute('data-k')
        if k=='badgeName':continue
        if not (await el.input_value()): await el.fill('ví dụ '+k)
      for el in await pg.locator('main input[type=number][data-k]').all(): await el.fill('30')
      for el in await pg.locator('main [data-seg]').all():
        bt=el.locator('button').first
        if await bt.get_attribute('aria-pressed')!='true': await bt.click()
      for el in await pg.locator('main [data-jm]').all():
        if await el.get_attribute('aria-pressed')!='true': await el.click()
      for el in await pg.locator('main [data-pk]').all():
        await el.click();break
      for el in await pg.locator('main input[type=checkbox]').all(): await el.check()
      await pg.wait_for_timeout(200)
      print(f'Ngày {d}:', await pg.text_content('#out'))
      await pg.screenshot(path=f'{out}/ngay{d}.png',full_page=True)
      await pg.click('[data-done]');await pg.wait_for_timeout(200)
    await pg.click(f'[data-day="{len(W["days"])}"]');await pg.wait_for_timeout(300)
    await pg.fill('[data-k="badgeName"]','Nguyễn Minh An');await pg.wait_for_timeout(1500)
    await pg.locator('#bcv').screenshot(path=f'{out}/badge.png')
    print('Lỗi JS:',errs);await b.close()
try: asyncio.run(main())
finally: srv.terminate()
