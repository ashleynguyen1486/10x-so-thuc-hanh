# BRIEF: dựng bộ tuần "Công thức thành công của tuần" cho 10X Excellence Hub

SP = /tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad

## 1. Bối cảnh
- 10X Excellence Hub là cộng đồng Skool của John&Partners (Việt Nam). Mục tiêu: thành viên thay đổi thói quen trong 5 năm để 10X tiềm năng.
- Từ #0022, chuỗi là một HÀNH TRÌNH THÓI QUEN: mỗi thành viên giữ MỘT thói quen then chốt trong công việc qua nhiều tuần; mỗi công thức mới thêm một lớp cho chính thói quen đó.
- Mỗi tuần: Thứ Hai đến Thứ Bảy (6 bài), Chủ Nhật nghỉ, không đăng.
  - Thứ Hai = mở tuần + Ngày 1, đính kèm PDF công thức, phiếu Ngày 1 và hướng dẫn sổ thực hành của tuần. Đầu bài có một đoạn ngắn khép tuần trước (nhắc điều cả nhóm đã làm, không nêu số liệu tham gia) và một ô "Nếu mới tham gia" (mỗi tuần viết khác, chỉ cách bắt đầu ngay tuần này, tuần nào cũng tự đứng được).
  - Thứ Ba đến Thứ Sáu = Ngày 2 đến Ngày 5.
  - Thứ Bảy = Ngày 6 + khép tuần + thẻ thành tích (thành viên tự nhận trên sổ khi đánh dấu đủ 6 ngày; Admin chỉ đăng bài).
- Mỗi việc trong ngày 10 đến 45 phút. Ví dụ luôn là tình huống công việc (nhiều vị trí: quản lý, kinh doanh, kế toán, nhân sự, kỹ thuật, chăm sóc khách hàng...).
- Bài đã hoàn chỉnh làm mẫu tham khảo (KHÔNG chép cấu trúc, câu mở, ví dụ): SP/w22n/posts.md, SP/gh_all/0022.json, /tmp/f30/b/c22.py, SP/w22n/sheets22.py, SP/w22n/b/gen.py, SP/guide22n/mk.py và shots.py, SP/w22n/doc0022.txt, SP/w22n/rev0022.txt.

## 2. Luật bắt buộc (vi phạm là phải làm lại)
Ngôn ngữ và giọng
- 100% tiếng Việt. Không từ tiếng Anh (chia sẻ, không check-in; tệp, không file; email (dùng chữ "email", KHÔNG viết "thư điện tử"), hộp thư; thẻ trình duyệt, không tab; Dòng chảy, không Flow). Tên riêng người, sách, tổ chức giữ nguyên.
- Người viết là Trường (nam, chuyên gia tư vấn). Trong lời dẫn KHÔNG xưng "tôi"; nếu cần thì xưng "Trường". Gọi người đọc "các anh chị và các bạn". Dùng "nha" (không "nhé") ở đoạn dặn dò, chia sẻ; không gắn "nha" vào câu kiến thức, số liệu.
- Không câu chào mở cố định. Không bịa chuyện riêng hay khách hàng của Trường. Câu chia sẻ mẫu của thành viên viết theo ngôi "tôi".
- Ngôn ngữ business chuyên nghiệp, dễ hiểu: không Hán Việt hoa mỹ, không văn nói (dùng "điều", "việc", "yếu tố" thay cho "thứ"). Không hứa hẹn kết quả. Giọng tích cực, đồng hành.
- KHÔNG dùng gạch ngang dài (—) hay gạch ngang vừa (–) ở bất cứ đâu; thay bằng dấu phẩy hoặc hai chấm. Mũi tên → dùng được.
- Không nội dung đời tư nhạy cảm (hôn nhân, bệnh tật, sức khỏe tâm thần...). Năng lượng/nghỉ ngơi chỉ nói ở mức thói quen làm việc, không lời khuyên y khoa.
- Mọi con số, năm, tên nghiên cứu phải đúng. Dùng WebSearch để đối chiếu điểm quan trọng. Câu nói gán cho người nổi tiếng mà chưa xác minh được thì ghi rõ "thường được gán cho ... nhưng chưa có bằng chứng". Ghi nguồn trong trang tài liệu tham khảo của PDF và trong tệp rà soát.
- Không bao giờ để một cụm từ bị tách ra hai dòng (thói quen, hợp đồng, kế hoạch, mục tiêu...). Mọi HTML dựng PDF/hình đều đi qua keep() trong /tmp/f30/b/vnkeep.py; bổ sung cụm mới của tuần (ví dụ "việc dở dang", "ý định thực hiện") vào tệp /tmp/f30/b/vnkeep_extra/<số>.txt, mỗi dòng một cụm; KHÔNG sửa vnkeep.py.

Không lặp khuôn ("AI template")
- Sáu bài trong tuần mỗi bài một dạng (kể tình huống, hỏi đáp, danh sách, đối chiếu, giải nghĩa, câu hỏi mở, thư, nhật ký, bảng chọn...). Và khác với các tuần khác: đọc kế hoạch 12 tuần bên dưới, đừng dùng lại dạng của Thứ Hai tuần 0022 (so sánh hai câu), hỏi đáp Thứ Ba, kể nghiên cứu Thứ Tư...
- Bài đủ dài: Thứ Hai khoảng 600 đến 900 chữ, các ngày khác 400 đến 700 chữ.
- 7 hình của tuần: 7 bố cục khác nhau, và khác các bố cục đã dùng (mục 6).
- Phiếu thực hành: thiết kế riêng của tuần, khác kiểu dải đầu trang (0021) và cột dọc bên trái (0022).

## 3. Hành trình thói quen trên sổ thực hành (tệp JSON tuần)
- Trang https://10xexcellence.co/so-thuc-hanh đọc sth.js + weeks.json + <số>.json. Bạn CHỈ viết SP/gh_all/<số>.json. KHÔNG sửa sth.js, weeks.json.
- Cấu trúc: xem SP/gh_all/0022.json. Trường cấp tuần: id, name, storeKey ("sth-<số>-6n"), kicker ("Công thức #<số>"), title, sub, badge, days[6]. Mỗi ngày: label (Thứ Hai...), kick, title, time ("Khoảng 20 phút"), cards[{h, items[]}], checkin[{tpl, need[]}], hint.
- Loại item: note{text}; tx/ta{k,q,ph}; cb{k,label}; show{text,need} (ghép câu tự động từ các khoá); seg{k,q,opts,hints?} (mỗi lựa chọn phải có định nghĩa/ví dụ trong hints hoặc note gần đó); pick{k,kp,n,empty} (chọn 1 trong các ô kp1..kpn); timer{k,dk,def,opts}; nums{items[{k,q}]}; rate{kp,head,rows,scale}; sum{head,rows[{label,keys}]}; cal{k,mark,max,cols,rows}; compare{cols,rows[{label,keys}]}; matrix; rows; track{note} (bảng hành trình 6 ngày của tuần, dùng chung mọi tuần).
- Token trong tpl/show: {khoá}, {khoá|mặc định}, {sum:a,b}, {cal:k}, {jweek} (số ngày đã làm thói quen trong tuần), {jtotal} (tổng ngày cả hành trình), {jstreak}.
- Khoá bắt đầu bằng "j_" được lưu cho cả hành trình (mọi tuần thấy). Đã có: j_identity, j_habit, j_when, j_where, j_after, j_cue, j_like, j_buddy, j_two, j_miss, j_reward, j_marks. Mỗi tuần thêm khoá j_ riêng theo kế hoạch mục 7, đừng đặt trùng khoá của tuần khác.
- Ngày 1 mỗi tuần phải hiện lại thói quen đang giữ (show "Thói quen đang giữ: {j_habit}") VÀ có ô tx j_habit để người mới điền (người mới cũng cần j_identity). Thêm track ở ít nhất một ngày trong tuần (ngày nào là tuỳ tuần, đừng luôn là Ngày 5).
- badge: {"style": <theo kế hoạch>, "big": "...", "unit": "...", "line": "...", ...}. Kiểu có sẵn: ring{big,ratio,of,unit}, bars{big,unit}, seal{big,unit,ring}, diag{big,unit}, year{big,unit,sub,year}, frame{big,unit,sub}, sun{big,unit}, ladder{big,unit}, quote{big,unit,quote}, loops{big,unit}, card{big,unit,word}, curve{big,unit}. big/line/quote/sub chấp nhận token.
- Sau khi tạo JSON, áp keep() cho mọi chuỗi trừ các khoá tpl,k,kp,dk,f,id,storeKey,style,line,need,keys (xem đoạn K() cuối SP/gh22b/mk22.py). Câu tpl không dùng keep.
- Kiểm thử: `cd SP/kit && python3 testweek.py <số>`; đọc câu chia sẻ in ra, xem ảnh SP/w<số>n/test/*.png và badge.png. Không có lỗi JS. Câu chia sẻ trên sổ phải khớp câu "Chia sẻ hôm nay" trong bài đăng.

## 4. Sản phẩm mỗi tuần (đặt trong SP/w<số>n/)
Tiền tố tên tệp P = "10XHub_<TenNgan>_" (TenNgan theo mục 7).
1. posts.md: 6 mục "## Bài N: ... (Thứ X dd/mm)" giống định dạng SP/w22n/posts.md với các dòng @img, @img2 (Thứ Bảy: 9_the-thanh-tich), @pdf, @cat. Dòng "**Tiêu đề bài trên Skool:** ..." (IN HOA). Mỗi bài có "Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#<số>-ngay-<n>." và "Chia sẻ hôm nay: "...".". Không dùng bảng markdown, không dùng dấu > trích dẫn (Skool không hiển thị).
2. Công thức PDF: script /tmp/f30/b/c<số>n.py dùng /tmp/f30/b/tpl.py (giữ nguyên mẫu: page, cover, disclaimer, build; xem c22.py) + keep(). Xuất thẳng ra SP/w<số>n/formula/<tên PDF theo mục 7>. Khoảng 18 đến 24 trang: bìa; mở đầu theo cách khác các tuần khác; nội dung khoa học có nguồn; liên hệ hành trình thói quen (lớp tuần này thêm gì); áp dụng theo vị trí công việc; lộ trình 6 ngày (Thứ Hai đến Thứ Bảy, Chủ Nhật nghỉ, hoặc làm bù); 6 trang ngày; một trang công cụ in được; trang nối sang tuần sau; tuyên bố miễn trừ trách nhiệm có tài liệu tham khảo. Cờ "overflow [1]" của tpl là báo giả nếu trang hiển thị đúng; vẫn phải xem ảnh trang.
3. Sổ thực hành: SP/gh_all/<số>.json (mục 3).
4. Hình: SP/w<số>n/b/gen.py tạo 7 tệp html bằng bkit (`from bkit import page, render`, xem docstring /tmp/f30/b/bkit.py), chép SP/kit/img vào SP/w<số>n/b/img, rồi render ra b/out/P1_<slug>.png ... P6_<slug>.png và P9_the-thanh-tich.png (3840x2160).
   - Tiêu đề trên hình: IN HOA, 25 đến 35 ký tự, class "fit" (tự giữ một dòng, chỉ xuống 2 dòng khi thu nhỏ vẫn không vừa; KHÔNG dùng <br>). Báo cáo của render phải là '1' hoặc '2', không có 'TRAN'. Nếu 2 dòng mà chữ nhỏ dưới 64px thì rút gọn câu chữ hoặc nới khung.
   - Màu: đỏ thương hiệu #862222 / #7b1f23, trắng, kem #FBF5F4, mực #231F20 (các sắc đỏ nhạt để phân lớp). Không nền đen, không màu vàng. Logo 10X trên mọi hình (logo_c_crop trên nền sáng, logo_w_crop trên nền đỏ). Không ảnh chụp người thật của khách; được phép không dùng ảnh.
   - Ghép bảng xem nhanh và tự xem bằng Read: dấu tiếng Việt, tràn chữ, chồng lấn, khoảng trống thừa, cụm từ bị tách.
5. Phiếu thực hành: SP/w<số>n/sheets.py → SP/w<số>n/pdf/P"PhieuNgay<n>_<slug>.pdf" (A4, mỗi ngày 1 trang; ngày có công cụ in được thì thêm trang). Thiết kế riêng của tuần. Có câu chia sẻ và đường dẫn sổ của ngày.
6. Hướng dẫn sổ thực hành riêng của tuần: SP/w<số>n/guide/10XHub_HuongDan_SoThucHanh_<số>.pdf, 3 đến 5 trang A4, mô phỏng theo SP/guide22n (chụp màn hình sổ của CHÍNH tuần này từ site cục bộ do testweek.py tạo ở SP/site_<số>, khoanh đỏ nút cần bấm; các bước dùng sổ; một trang "Công cụ riêng của tuần"; hỏi nhanh theo nội dung tuần). Giọng Trường, 100% tiếng Việt.
7. Word: `cd SP/w<số>n && cp -r ../kit/img . && mkdir -p docjpg word` ; tạo docjpg/<P><n>_<slug>.jpg (1600x900) từ hình; `PFX=<P> LABEL="<tên thử thách>" NODE_PATH=../kit/node_modules node ../kit/mkdocx.js word`.
8. Văn bản Google Doc bài đăng: SP/w<số>n/doc<số>.txt (định dạng như SP/w22n/doc0022.txt: phần đầu gồm tên tuần, người viết Trường, lịch đăng, hành trình, thẻ thành tích, sổ thực hành, tệp đính kèm; rồi từng bài với Banner, PDF đính kèm, Danh mục Skool, Tiêu đề, toàn văn, bỏ ký hiệu ** *).
9. Văn bản rà soát: SP/w<số>n/rev<số>.txt (như rev0022.txt + phần nguồn đã đối chiếu kèm đường link, và các điểm cần Ashley kiểm tra thêm).

## 5. Tự kiểm tra trước khi báo xong
- Quét mọi văn bản (posts.md, json, html của PDF/hình/phiếu, doc, rev): không "nhé", không — –, không " tôi " trong lời dẫn (chỉ trong câu mẫu của thành viên), không "thứ" theo nghĩa đồ vật, không từ tiếng Anh ngoài tên riêng/tên sách/trích dẫn tài liệu.
- Xem ảnh mọi trang PDF công thức, mọi phiếu, mọi hình, hướng dẫn.
- Chạy testweek.py, xem ảnh.
- Báo cáo cuối (ngắn): danh sách tệp, các điểm nghi ngờ về nguồn, câu chữ cần Ashley xem.

## 6. Bố cục hình đã dùng (KHÔNG dùng lại)
Xem hết các bảng hình bo-cong-cu-v2/mau/b_*.jpg (b_35: 0035 đến 0037, b_38: 0038 đến 0040, b_41: 0041 đến 0043, b_44: 0044 đến 0046, b_47: 0047 đến 0049, b_50: 0050 đến 0052, b_53: 0053 đến 0055, b_56: 0056 đến 0058). Không dùng lại bố cục nào trong đó. Mỗi tuần dùng các ý tưởng hình gợi ý ở mục 7 (hoặc ý mới tương đương) để các tuần đang làm song song không đụng nhau. Được dùng ảnh chụp chung chung (toà nhà, văn phòng, thành phố) ở SP/kit/img/p_*.jpg cho tối đa 1 đến 2 hình mỗi tuần, phủ màu đỏ thương hiệu. Nếu ảnh có người: người châu Á, mặc trang phục công sở (không quần đùi, không trang phục xuề xoà), không ảnh thật của khách hàng.
Lưu ý kỹ thuật: thẻ kiểu card trong sth.js vẽ chữ cỡ cố định, nên chữ word của thẻ card phải thật ngắn (tối đa khoảng 8 ký tự). /tmp/f30/b/vnkeep.py nay ưu tiên cụm dài, cứ thêm cụm của tuần vào vnkeep_extra.

## 7. Kế hoạch 12 tuần (#0047 đến #0058), Năm 1, Mùa 3 "Học nhanh, nhớ lâu" (05.04 đến 04.07.2027)
Dòng chảy đã có (đọc SP/w0046n/posts.md, nhất là bài Thứ Bảy, và SP/gh_all/0046.json, 0045.json trước khi làm):
- Mùa 1 (#0021 đến #0033) xây một thói quen then chốt qua nhiều lớp (bản sắc, bốn quy luật, Nếu... thì..., năng lượng, việc sâu, ăn con ếch, luyện tập có chủ đích #0027 (khoá j_skill), giảng lại kiểu Feynman #0028, tiên liệu, khép việc dở, cải tiến, biết ơn, tổng kết năm).
- Mùa 2 (#0034 đến #0046) đưa 5 mục tiêu 2027 vào vận hành: 5/25, Kanban, gan góc, ranh giới, tự trắc ẩn qua Tết, kết nối, đường cong quên và lặp lại cách quãng #0040 (khoá j_review), sổ đầu dòng, hộp thời gian, nghịch lý lựa chọn, quy tắc mặc định, chỉ số Sao Bắc Cực, khép quý 1 bằng giữ, sửa, bỏ mục tiêu (j_q1_keep, j_q1_drop).
- Mùa 3 (12 tuần này và #0059 do lịch tự động soạn sau): thói quen then chốt thêm lớp mới "mỗi ngày học có chủ đích 20 phút", gắn ngay sau thói quen then chốt cũ (xếp chồng) và phục vụ mục tiêu đang giữ sau quý 1. Mạch 12 tuần: chọn một kỹ năng và dự án học cho quý (#0047) → kỹ thuật học có bằng chứng (#0048, #0051, #0052, #0053) → ghi chép và tổ chức kiến thức (#0049, #0055, #0056) → nâng tầng hiểu và tự đánh giá (#0054, #0057) → chia sẻ điều đã học (#0058). Mỗi tuần nhắc lại kỹ năng và dự án học đã chọn ở #0047 (khoá j_learn_skill, j_learn_project) để dòng chảy liền mạch, và cho thấy thành viên đang tiến về phía phiên bản 10X của chính mình (tiềm năng 10X): nói bằng việc làm cụ thể, không hứa hẹn kết quả.
- Mùa 3 khép ở #0059 (28.06 đến 03.07, ngày Gia đình Việt Nam 28.06, khép quý 2 ngày 30.06). Bài Thứ Bảy #0058 nối sang tuần khép mùa nhưng chưa nêu tên công thức.
Lịch (đã kiểm tra): Giỗ Tổ Hùng Vương Thứ Sáu 16.04 (nghỉ lễ, bài nhẹ); 30.4 Thứ Sáu và 1.5 Thứ Bảy (nghỉ lễ, bài nhẹ 5 đến 10 phút); Ngày của Mẹ Chủ Nhật 09.05; Quốc tế Thiếu nhi Thứ Ba 01.06; Ngày của Cha Chủ Nhật 20.06; Ngày Báo chí Cách mạng Việt Nam Thứ Hai 21.06. Chỉ dùng như điểm nhấn nhẹ, chuyên nghiệp, gắn công việc; không chính trị, không đời tư nhạy cảm.

| Số | Tuần | Công thức | TenNgan | Tên PDF công thức | Thẻ | Khoá j_ mới |
|---|---|---|---|---|---|---|
| 0047 | 05.04 đến 10.04.2027 | Siêu học | SieuHoc | 10XHub_CongThuc_0047_Sieu Hoc_VN.pdf | ladder | j_learn_skill, j_learn_project |
| 0048 | 12.04 đến 17.04 | Truy hồi chủ động | TruyHoi | 10XHub_CongThuc_0048_Truy Hoi Chu Dong_VN.pdf | check | j_recall |
| 0049 | 19.04 đến 24.04 | Ghi chép Cornell | Cornell | 10XHub_CongThuc_0049_Ghi Chep Cornell_VN.pdf | diag | j_cornell |
| 0050 | 26.04 đến 01.05 | Xếp chồng kỹ năng | XepChongKyNang | 10XHub_CongThuc_0050_Xep Chong Ky Nang_VN.pdf | ring | j_stack |
| 0051 | 03.05 đến 08.05 | Cung điện trí nhớ | CungDienTriNho | 10XHub_CongThuc_0051_Cung Dien Tri Nho_VN.pdf | seal | j_palace |
| 0052 | 10.05 đến 15.05 | Học xen kẽ và khó khăn có ích | HocXenKe | 10XHub_CongThuc_0052_Hoc Xen Ke_VN.pdf | curve | j_mix |
| 0053 | 17.05 đến 22.05 | Bản đồ tư duy | BanDoTuDuy | 10XHub_CongThuc_0053_Ban Do Tu Duy_VN.pdf | bars | j_map |
| 0054 | 24.05 đến 29.05 | Phân loại Bloom | PhanLoaiBloom | 10XHub_CongThuc_0054_Phan Loai Bloom_VN.pdf | sun | j_bloom |
| 0055 | 31.05 đến 05.06 | Zettelkasten, hộp thẻ ghi chú | Zettelkasten | 10XHub_CongThuc_0055_Zettelkasten_VN.pdf | card (word ngắn, ví dụ "TÒ MÒ") | j_zk |
| 0056 | 07.06 đến 12.06 | Phương pháp PARA | PARA | 10XHub_CongThuc_0056_Phuong Phap PARA_VN.pdf | quote | j_para |
| 0057 | 14.06 đến 19.06 | Hiệu ứng Dunning-Kruger và tự đánh giá | DunningKruger | 10XHub_CongThuc_0057_Hieu Ung Dunning Kruger_VN.pdf | loops | j_meta |
| 0058 | 21.06 đến 26.06 | Xây dựng công khai: chia sẻ điều mình học | XayCongKhai | 10XHub_CongThuc_0058_Xay Dung Cong Khai_VN.pdf | chain | j_share |

### #0047 Siêu học, 05.04 đến 10.04 (mở Mùa 3)
- Bài Thứ Hai khép #0046 (giữ, sửa, bỏ mục tiêu; Mùa 2 đã khép) và mở Mùa 3. Lớp: thêm "20 phút học có chủ đích" ngay sau thói quen then chốt; chọn một kỹ năng phục vụ mục tiêu đang giữ và một dự án học nhỏ trong quý 2. Khoá j_learn_skill, j_learn_project.
- Nguồn: Scott H. Young 2019 "Ultralearning" (9 nguyên tắc: siêu học trước, tập trung, trực tiếp, luyện riêng, truy hồi, phản hồi, ghi nhớ, trực giác, thử nghiệm). Diễn giải chính xác, không phóng đại câu chuyện cá nhân của tác giả. Liên hệ #0027 luyện tập có chủ đích.
- Thẻ ladder. Hình: bản đồ dự án học một quý, thang chín bậc, bàn học công sở, lịch 20 phút.

### #0048 Truy hồi chủ động, 12.04 đến 17.04
- Lớp: thay 20 phút đọc lại bằng tự kiểm tra (đóng sách, tự viết ra, tự đặt câu hỏi). Thứ Sáu 16.04 Giỗ Tổ Hùng Vương: bài nhẹ. Khoá j_recall.
- Nguồn: Roediger và Karpicke 2006 (Psychological Science); Karpicke và Blunt 2011 (Science, truy hồi so với lập bản đồ khái niệm); Dunlosky và cộng sự 2013 (đánh giá 10 kỹ thuật học, xếp tự kiểm tra và học cách quãng ở mức hiệu quả cao). #0040 đã nhắc lặp lại cách quãng và có nhắc Roediger và Karpicke: viết sâu hơn, khác hẳn, nối lại với lịch ôn j_review.
- Thẻ check. Hình: trang giấy gập che đáp án, thẻ câu hỏi, cột "nhớ được / chưa nhớ", bàn tay viết trên giấy trắng.

### #0049 Ghi chép Cornell, 19.04 đến 24.04
- Lớp: mỗi buổi học 20 phút có một trang Cornell (ghi, câu hỏi gợi nhớ, tóm tắt), dùng cột câu hỏi để truy hồi như #0048. Khoá j_cornell.
- Nguồn: Walter Pauk, "How to Study in College" (bản đầu 1962), Đại học Cornell. Nghiên cứu đánh giá có kết quả lẫn lộn (ví dụ Jacobs 2008; tham khảo thêm bằng WebSearch): nói rõ, không phóng đại. Áp dụng cho họp, đào tạo nội bộ, đọc tài liệu.
- Thẻ diag. Hình: trang giấy chia ba vùng, biên bản họp kiểu Cornell, cột câu hỏi bên trái, dải tóm tắt cuối trang.

### #0050 Xếp chồng kỹ năng, 26.04 đến 01.05 (tuần lễ 30.4 và 1.5)
- Thứ Sáu 30.4 và Thứ Bảy 1.5 nghỉ lễ: việc rất nhẹ 5 đến 10 phút, bài ấm áp, chúc kỳ nghỉ. Lớp: nhìn tổng thể bộ kỹ năng của mình, thấy kỹ năng đang học (j_learn_skill) cộng thêm vào đâu để tạo lợi thế riêng trong công việc. Khoá j_stack.
- Nguồn: Scott Adams, "How to Fail at Almost Everything and Still Win Big" (2013), khái niệm talent stack (ghi tên gốc một lần trong PDF). Bổ sung góc nhìn kỹ năng chữ T (T-shaped) có nguồn. Không chính trị, không bình luận về cá nhân tác giả.
- Thẻ ring. Hình: các khối kỹ năng chồng lên nhau, sơ đồ chữ T, vòng tròn giao nhau ba kỹ năng, lịch nghỉ lễ khoanh nhẹ.

### #0051 Cung điện trí nhớ, 03.05 đến 08.05
- Tuần đầu sau kỳ nghỉ lễ. Lớp: dùng phương pháp định vị để nhớ các ý chính của bài thuyết trình, quy trình, số liệu cần dùng trong công việc. Khoá j_palace.
- Nguồn: phương pháp định vị (method of loci) từ thời Hy Lạp cổ (Simonides, ghi chép của Cicero); Maguire và cộng sự 2003 (Nature Neuroscience, người nhớ giỏi dùng chiến lược không gian); Dresler và cộng sự 2017 (Neuron, 6 tuần luyện tập). Không biến thành mẹo thi cử; gắn với công việc.
- Thẻ seal. Hình: mặt bằng văn phòng với các điểm dừng đánh số, hành lang có các cửa, đường đi nét đứt qua phòng họp.

### #0052 Học xen kẽ và khó khăn có ích, 10.05 đến 15.05
- Lớp: trong 20 phút học, trộn các dạng bài hoặc tình huống thay vì học dồn một dạng; chấp nhận cảm giác khó hơn là dấu hiệu học sâu. Khoá j_mix. (Ngày của Mẹ là Chủ Nhật 09.05, trước tuần: chỉ cần một câu nhẹ ở bài Thứ Hai nếu tự nhiên, không bắt buộc.)
- Nguồn: Robert Bjork 1994 (khó khăn có ích); Rohrer và Taylor 2007 (học xen kẽ trong toán); Kornell và Bjork 2008 (học nhận diện phong cách hội hoạ); Brown, Roediger, McDaniel 2014 "Make It Stick". Nói rõ phạm vi hiệu ứng.
- Thẻ curve. Hình: hai dải màu so sánh học dồn và học xen kẽ, đường cảm giác dễ và kết quả thật, ô lịch trộn màu.

### #0053 Bản đồ tư duy, 17.05 đến 22.05
- Lớp: tóm một buổi học hoặc một tài liệu thành một bản đồ một trang để nhìn liên kết; kết hợp chữ và hình. Khoá j_map.
- Nguồn: Tony Buzan (phổ biến bản đồ tư duy từ thập niên 1970, "Use Your Head" 1974); Nesbit và Adesope 2006 (tổng hợp về bản đồ khái niệm và nút); Paivio, mã hoá kép. Phân biệt bản đồ tư duy và bản đồ khái niệm; Karpicke và Blunt 2011 cho thấy truy hồi hơn lập bản đồ khi chỉ để nhớ: gợi ý vẽ bản đồ từ trí nhớ (nối với #0048).
- Thẻ bars. Hình: nhánh toả từ trung tâm, bản đồ vẽ tay trên bảng trắng phòng họp, so sánh danh sách dọc và bản đồ.

### #0054 Phân loại Bloom, 24.05 đến 29.05
- Lớp: đẩy 20 phút học lên tầng cao hơn: từ nhớ, hiểu sang vận dụng, phân tích, đánh giá, sáng tạo; tự đặt câu hỏi theo từng tầng cho kỹ năng đang học. Khoá j_bloom.
- Nguồn: Bloom và cộng sự 1956; Anderson và Krathwohl 2001 (bản sửa đổi, động từ). Không vẽ kim tự tháp như chân lý tuyệt đối: nói rõ các tầng không phải lúc nào cũng tuần tự.
- Thẻ sun. Hình: sáu bậc động từ, bảng câu hỏi theo tầng, mũi tên đi lên từ ghi nhớ đến sáng tạo (không dùng kim tự tháp đã dùng ở #0036).

### #0055 Zettelkasten, hộp thẻ ghi chú, 31.05 đến 05.06
- Lớp: mỗi buổi học kết thúc bằng một thẻ ghi chú viết bằng lời của mình và nối với thẻ cũ; hộp thẻ thành kho ý tưởng cho công việc. Thứ Ba 01.06 Quốc tế Thiếu nhi: điểm nhấn nhẹ về sự tò mò khi học, chuyên nghiệp. Khoá j_zk.
- Nguồn: Niklas Luhmann (khoảng 90.000 thẻ, kiểm tra con số bằng nguồn uy tín); Sönke Ahrens 2017 "How to Take Smart Notes". Không phụ thuộc phần mềm.
- Thẻ card với word ngắn (ví dụ "TÒ MÒ"). Hình: hộp thẻ gỗ nét mảnh, các thẻ nối bằng mũi tên, mã số thẻ kiểu Luhmann (1, 1a, 1a1).

### #0056 Phương pháp PARA, 07.06 đến 12.06
- Lớp: sắp xếp tài liệu học và tài liệu công việc theo bốn nhóm Dự án, Lĩnh vực, Tài nguyên, Lưu trữ để tìm lại nhanh; dọn thư mục của dự án học (j_learn_project). Khoá j_para.
- Nguồn: Tiago Forte 2022 "Building a Second Brain" (PARA, CODE). Nối với sổ đầu dòng #0041 và Zettelkasten #0055: mỗi công cụ một vai trò.
- Thẻ quote. Hình: bốn ngăn tủ hồ sơ, cây thư mục bốn nhánh, mũi tên chuyển dự án xong sang lưu trữ.

### #0057 Hiệu ứng Dunning-Kruger và tự đánh giá, 14.06 đến 19.06
- Lớp: tự đánh giá mức thạo của kỹ năng đang học bằng bằng chứng (bài kiểm tra nhỏ, phản hồi của người khác) thay vì cảm giác. Khoá j_meta.
- Nguồn: Kruger và Dunning 1999 (Journal of Personality and Social Psychology); nói rõ tranh luận: Nuhfer và cộng sự 2016, Gignac và Zajenkowski 2020 cho thấy một phần là hiệu ứng thống kê. Không dùng hình đường cong "đỉnh núi ngu ngơ" phổ biến trên mạng vì không có trong bài gốc. Không chế giễu ai.
- Thẻ loops. Hình: hai cột tự chấm và chấm thật, thước đo có vạch bằng chứng, vòng phản hồi.

### #0058 Xây dựng công khai: chia sẻ điều mình học, 21.06 đến 26.06
- Thứ Hai 21.06 là Ngày Báo chí Cách mạng Việt Nam: mở bài nhẹ về giá trị của việc viết và chia sẻ thông tin chính xác. Lớp: mỗi tuần chia sẻ một điều đã học từ dự án học (j_learn_project) với nhóm hoặc cộng đồng 10X; ghi lại nhịp chia sẻ. Khoá j_share. Bài Thứ Bảy nhìn lại 12 tuần của Mùa 3 đến nay và nối sang tuần khép mùa (chưa nêu tên công thức).
- Nguồn: Austin Kleon 2014 "Show Your Work!"; hiệu ứng học nhờ giảng lại (Nestojko và cộng sự 2014, kỳ vọng phải dạy lại giúp nhớ tốt hơn); nối với Feynman #0028. Không khuyến khích khoe khoang; tôn trọng bảo mật thông tin công ty và khách hàng.
- Thẻ chain. Hình: dòng thời gian bài chia sẻ hằng tuần, bảng tin nhóm, chuỗi mắt xích học, chia sẻ, phản hồi.

## 8. Không được làm
- Không đụng Google Drive, GitHub, trình duyệt, lịch tự động. Không sửa sth.js, weeks.json, tpl.py, bkit.py, tệp của tuần khác. Chỉ ghi vào SP/w<số>n/, SP/gh_all/<số>.json, /tmp/f30/b/c<số>n.py, và /tmp/f30/b/vnkeep_extra/<số>.txt.
