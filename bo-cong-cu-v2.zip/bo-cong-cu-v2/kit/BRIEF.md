# BRIEF: dựng bộ tuần "Công thức thành công của tuần" cho 10X Excellence Hub

SP = /tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad

## 1. Bối cảnh
- 10X Excellence Hub là cộng đồng Skool của John&Partners (Việt Nam). Mục tiêu: thành viên thay đổi thói quen trong 5 năm để 10X tiềm năng.
- Từ #0022, chuỗi là một HÀNH TRÌNH THÓI QUEN: mỗi thành viên giữ MỘT thói quen then chốt trong công việc qua nhiều tuần; mỗi công thức mới thêm một lớp cho chính thói quen đó.
- Mỗi tuần: Thứ Hai đến Thứ Bảy (6 bài), Chủ Nhật nghỉ, không đăng.
  - Thứ Hai = mở tuần + Ngày 1, đính kèm PDF công thức, phiếu Ngày 1 và hướng dẫn sổ thực hành của tuần. Đầu bài có một đoạn ngắn khép tuần trước (nhắc điều cả nhóm đã làm, không nêu số liệu tham gia) và một ô "Nếu mới tham gia" (mỗi tuần viết khác, chỉ cách bắt đầu ngay tuần này, tuần nào cũng tự đứng được).
  - Thứ Ba đến Thứ Sáu = Ngày 2 đến Ngày 5.
  - Thứ Bảy = Ngày 6 + khép tuần + thẻ thành tích (thành viên tự nhận trên sổ khi đánh dấu đủ 6 ngày; Admin chỉ đăng bài).
- Mỗi việc trong ngày 10 đến 45 phút. Ví dụ luôn là tình huống công việc (nhiều vị trí: quản lý, kinh doanh, kế toán, nhân sự, kỹ thuật, chăm sóc khách hàng...).
- Bài đã hoàn chỉnh làm mẫu tham khảo (KHÔNG chép cấu trúc, câu mở, ví dụ): SP/w22n/posts.md, SP/gh_all/0022.json, /tmp/f30/b/c22.py, SP/w22n/sheets22.py, SP/w22n/b/gen.py, SP/guide22n/mk.py và shots.py, SP/w22n/doc0022.txt, SP/w22n/rev0022.txt.

## 2. Luật bắt buộc (vi phạm là phải làm lại)
Ngôn ngữ và giọng
- 100% tiếng Việt. Không từ tiếng Anh (chia sẻ, không check-in; tệp, không file; email (dùng chữ "email", KHÔNG viết "thư điện tử"), hộp thư; thẻ trình duyệt, không tab; Dòng chảy, không Flow). Tên riêng người, sách, tổ chức giữ nguyên.
- Người viết là Trường (nam, chuyên gia tư vấn). Trong lời dẫn KHÔNG xưng "tôi"; nếu cần thì xưng "Trường". Gọi người đọc "các anh chị và các bạn". Dùng "nha" (không "nhé") ở đoạn dặn dò, chia sẻ; không gắn "nha" vào câu kiến thức, số liệu.
- Không câu chào mở cố định. Không bịa chuyện riêng hay khách hàng của Trường. Câu chia sẻ mẫu của thành viên viết theo ngôi "tôi".
- Ngôn ngữ business chuyên nghiệp, dễ hiểu: không Hán Việt hoa mỹ, không văn nói (dùng "điều", "việc", "yếu tố" thay cho "thứ"). Không hứa hẹn kết quả. Giọng tích cực, đồng hành.
- KHÔNG dùng gạch ngang dài (—) hay gạch ngang vừa (–) ở bất cứ đâu; thay bằng dấu phẩy hoặc hai chấm. Mũi tên → dùng được.
- Không nội dung đời tư nhạy cảm (hôn nhân, bệnh tật, sức khỏe tâm thần...). Năng lượng/nghỉ ngơi chỉ nói ở mức thói quen làm việc, không lời khuyên y khoa.
- Mọi con số, năm, tên nghiên cứu phải đúng. Dùng WebSearch để đối chiếu điểm quan trọng. Câu nói gán cho người nổi tiếng mà chưa xác minh được thì ghi rõ "thường được gán cho ... nhưng chưa có bằng chứng". Ghi nguồn trong trang tài liệu tham khảo của PDF và trong tệp rà soát.
- Không bao giờ để một cụm từ bị tách ra hai dòng (thói quen, hợp đồng, kế hoạch, mục tiêu...). Mọi HTML dựng PDF/hình đều đi qua keep() trong /tmp/f30/b/vnkeep.py; bổ sung cụm mới của tuần (ví dụ "việc dở dang", "ý định thực hiện") vào tệp /tmp/f30/b/vnkeep_extra/<số>.txt, mỗi dòng một cụm; KHÔNG sửa vnkeep.py.

Không lặp khuôn ("AI template")
- Sáu bài trong tuần mỗi bài một dạng (kể tình huống, hỏi đáp, danh sách, đối chiếu, giải nghĩa, câu hỏi mở, thư, nhật ký, bảng chọn...). Và khác với các tuần khác: đọc kế hoạch 12 tuần bên dưới, đừng dùng lại dạng của Thứ Hai tuần 0022 (so sánh hai câu), hỏi đáp Thứ Ba, kể nghiên cứu Thứ Tư...
- Bài đủ dài: Thứ Hai khoảng 600 đến 900 chữ, các ngày khác 400 đến 700 chữ.
- 7 hình của tuần: 7 bố cục khác nhau, và khác các bố cục đã dùng (mục 6).
- Phiếu thực hành: thiết kế riêng của tuần, khác kiểu dải đầu trang (0021) và cột dọc bên trái (0022).

## 3. Hành trình thói quen trên sổ thực hành (tệp JSON tuần)
- Trang https://10xexcellence.co/so-thuc-hanh đọc sth.js + weeks.json + <số>.json. Bạn CHỈ viết SP/gh_all/<số>.json. KHÔNG sửa sth.js, weeks.json.
- Cấu trúc: xem SP/gh_all/0022.json. Trường cấp tuần: id, name, storeKey ("sth-<số>-6n"), kicker ("Công thức #<số>"), title, sub, badge, days[6]. Mỗi ngày: label (Thứ Hai...), kick, title, time ("Khoảng 20 phút"), cards[{h, items[]}], checkin[{tpl, need[]}], hint.
- Loại item: note{text}; tx/ta{k,q,ph}; cb{k,label}; show{text,need} (ghép câu tự động từ các khoá); seg{k,q,opts,hints?} (mỗi lựa chọn phải có định nghĩa/ví dụ trong hints hoặc note gần đó); pick{k,kp,n,empty} (chọn 1 trong các ô kp1..kpn); timer{k,dk,def,opts}; nums{items[{k,q}]}; rate{kp,head,rows,scale}; sum{head,rows[{label,keys}]}; cal{k,mark,max,cols,rows}; compare{cols,rows[{label,keys}]}; matrix; rows; track{note} (bảng hành trình 6 ngày của tuần, dùng chung mọi tuần).
- Token trong tpl/show: {khoá}, {khoá|mặc định}, {sum:a,b}, {cal:k}, {jweek} (số ngày đã làm thói quen trong tuần), {jtotal} (tổng ngày cả hành trình), {jstreak}.
- Khoá bắt đầu bằng "j_" được lưu cho cả hành trình (mọi tuần thấy). Đã có: j_identity, j_habit, j_when, j_where, j_after, j_cue, j_like, j_buddy, j_two, j_miss, j_reward, j_marks. Mỗi tuần thêm khoá j_ riêng theo kế hoạch mục 7, đừng đặt trùng khoá của tuần khác.
- Ngày 1 mỗi tuần phải hiện lại thói quen đang giữ (show "Thói quen đang giữ: {j_habit}") VÀ có ô tx j_habit để người mới điền (người mới cũng cần j_identity). Thêm track ở ít nhất một ngày trong tuần (ngày nào là tuỳ tuần, đừng luôn là Ngày 5).
- badge: {"style": <theo kế hoạch>, "big": "...", "unit": "...", "line": "...", ...}. Kiểu có sẵn: ring{big,ratio,of,unit}, bars{big,unit}, seal{big,unit,ring}, diag{big,unit}, year{big,unit,sub,year}, frame{big,unit,sub}, sun{big,unit}, ladder{big,unit}, quote{big,unit,quote}, loops{big,unit}, card{big,unit,word}, curve{big,unit}. big/line/quote/sub chấp nhận token.
- Sau khi tạo JSON, áp keep() cho mọi chuỗi trừ các khoá tpl,k,kp,dk,f,id,storeKey,style,line,need,keys (xem đoạn K() cuối SP/gh22b/mk22.py). Câu tpl không dùng keep.
- Kiểm thử: `cd SP/kit && python3 testweek.py <số>`; đọc câu chia sẻ in ra, xem ảnh SP/w<số>n/test/*.png và badge.png. Không có lỗi JS. Câu chia sẻ trên sổ phải khớp câu "Chia sẻ hôm nay" trong bài đăng.

## 4. Sản phẩm mỗi tuần (đặt trong SP/w<số>n/)
Tiền tố tên tệp P = "10XHub_<TenNgan>_" (TenNgan theo mục 7).
1. posts.md: 6 mục "## Bài N: ... (Thứ X dd/mm)" giống định dạng SP/w22n/posts.md với các dòng @img, @img2 (Thứ Bảy: 9_the-thanh-tich), @pdf, @cat. Dòng "**Tiêu đề bài trên Skool:** ..." (IN HOA). Mỗi bài có "Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#<số>-ngay-<n>." và "Chia sẻ hôm nay: "...".". Không dùng bảng markdown, không dùng dấu > trích dẫn (Skool không hiển thị).
2. Công thức PDF: script /tmp/f30/b/c<số>n.py dùng /tmp/f30/b/tpl.py (giữ nguyên mẫu: page, cover, disclaimer, build; xem c22.py) + keep(). Xuất thẳng ra SP/w<số>n/formula/<tên PDF theo mục 7>. Khoảng 18 đến 24 trang: bìa; mở đầu theo cách khác các tuần khác; nội dung khoa học có nguồn; liên hệ hành trình thói quen (lớp tuần này thêm gì); áp dụng theo vị trí công việc; lộ trình 6 ngày (Thứ Hai đến Thứ Bảy, Chủ Nhật nghỉ, hoặc làm bù); 6 trang ngày; một trang công cụ in được; trang nối sang tuần sau; tuyên bố miễn trừ trách nhiệm có tài liệu tham khảo. Cờ "overflow [1]" của tpl là báo giả nếu trang hiển thị đúng; vẫn phải xem ảnh trang.
3. Sổ thực hành: SP/gh_all/<số>.json (mục 3).
4. Hình: SP/w<số>n/b/gen.py tạo 7 tệp html bằng bkit (`from bkit import page, render`, xem docstring /tmp/f30/b/bkit.py), chép SP/kit/img vào SP/w<số>n/b/img, rồi render ra b/out/P1_<slug>.png ... P6_<slug>.png và P9_the-thanh-tich.png (3840x2160).
   - Tiêu đề trên hình: IN HOA, 25 đến 35 ký tự, class "fit" (tự giữ một dòng, chỉ xuống 2 dòng khi thu nhỏ vẫn không vừa; KHÔNG dùng <br>). Báo cáo của render phải là '1' hoặc '2', không có 'TRAN'. Nếu 2 dòng mà chữ nhỏ dưới 64px thì rút gọn câu chữ hoặc nới khung.
   - Màu: đỏ thương hiệu #862222 / #7b1f23, trắng, kem #FBF5F4, mực #231F20 (các sắc đỏ nhạt để phân lớp). Không nền đen, không màu vàng. Logo 10X trên mọi hình (logo_c_crop trên nền sáng, logo_w_crop trên nền đỏ). Không ảnh chụp người thật của khách; được phép không dùng ảnh.
   - Ghép bảng xem nhanh và tự xem bằng Read: dấu tiếng Việt, tràn chữ, chồng lấn, khoảng trống thừa, cụm từ bị tách.
5. Phiếu thực hành: SP/w<số>n/sheets.py → SP/w<số>n/pdf/P"PhieuNgay<n>_<slug>.pdf" (A4, mỗi ngày 1 trang; ngày có công cụ in được thì thêm trang). Thiết kế riêng của tuần. Có câu chia sẻ và đường dẫn sổ của ngày.
6. Hướng dẫn sổ thực hành riêng của tuần: SP/w<số>n/guide/10XHub_HuongDan_SoThucHanh_<số>.pdf, 3 đến 5 trang A4, mô phỏng theo SP/guide22n (chụp màn hình sổ của CHÍNH tuần này từ site cục bộ do testweek.py tạo ở SP/site_<số>, khoanh đỏ nút cần bấm; các bước dùng sổ; một trang "Công cụ riêng của tuần"; hỏi nhanh theo nội dung tuần). Giọng Trường, 100% tiếng Việt.
7. Word: `cd SP/w<số>n && cp -r ../kit/img . && mkdir -p docjpg word` ; tạo docjpg/<P><n>_<slug>.jpg (1600x900) từ hình; `PFX=<P> LABEL="<tên thử thách>" NODE_PATH=../kit/node_modules node ../kit/mkdocx.js word`.
8. Văn bản Google Doc bài đăng: SP/w<số>n/doc<số>.txt (định dạng như SP/w22n/doc0022.txt: phần đầu gồm tên tuần, người viết Trường, lịch đăng, hành trình, thẻ thành tích, sổ thực hành, tệp đính kèm; rồi từng bài với Banner, PDF đính kèm, Danh mục Skool, Tiêu đề, toàn văn, bỏ ký hiệu ** *).
9. Văn bản rà soát: SP/w<số>n/rev<số>.txt (như rev0022.txt + phần nguồn đã đối chiếu kèm đường link, và các điểm cần Ashley kiểm tra thêm).

## 5. Tự kiểm tra trước khi báo xong
- Quét mọi văn bản (posts.md, json, html của PDF/hình/phiếu, doc, rev): không "nhé", không — –, không " tôi " trong lời dẫn (chỉ trong câu mẫu của thành viên), không "thứ" theo nghĩa đồ vật, không từ tiếng Anh ngoài tên riêng/tên sách/trích dẫn tài liệu.
- Xem ảnh mọi trang PDF công thức, mọi phiếu, mọi hình, hướng dẫn.
- Chạy testweek.py, xem ảnh.
- Báo cáo cuối (ngắn): danh sách tệp, các điểm nghi ngờ về nguồn, câu chữ cần Ashley xem.

## 6. Bố cục hình đã dùng (KHÔNG dùng lại)
Xem hết các bảng hình bo-cong-cu-v2/mau/b_*.jpg (b_29: 0029 đến 0031, b_32: 0032 đến 0034, b_35: 0035 đến 0037, b_38: 0038 đến 0040, b_41: 0041 đến 0043, b_44: 0044 đến 0046). Không dùng lại bố cục nào trong đó. Mỗi tuần dùng các ý tưởng hình gợi ý ở mục 7 (hoặc ý mới tương đương) để các tuần đang làm song song không đụng nhau. Được dùng ảnh chụp chung chung (toà nhà, văn phòng, thành phố) ở SP/kit/img/p_*.jpg cho tối đa 1 đến 2 hình mỗi tuần, phủ màu đỏ thương hiệu, không ảnh người thật của khách.

## 7. Kế hoạch 12 tuần (#0035 đến #0046), Năm 1, Mùa 2 "Mục tiêu và ưu tiên năm mới" (04.01 đến 04.04.2027)
Dòng chảy đã có: #0022 đến #0033 xây thói quen then chốt qua nhiều lớp (bản sắc, bốn quy luật, Nếu... thì..., năng lượng, việc sâu, ăn con ếch, luyện tập, giảng lại, tiên liệu, khép việc dở, cải tiến, biết ơn, tổng kết năm và chọn thói quen 2027); #0034 Quy tắc 5/25 chọn 5 mục tiêu 2027 (khoá j_goal1..5, j_avoid) và nối thói quen then chốt với mục tiêu số 1. Thói quen gợi ý của Mùa 2: "mỗi ngày làm một bước cho một trong năm mục tiêu". 12 tuần này đưa 5 mục tiêu vào vận hành, giữ thói quen qua Tết, khởi động lại sau Tết và khép quý 1. Đọc SP/w0033n/posts.md và SP/w0034n/posts.md, SP/gh_all/0034.json trước khi làm.
Lịch âm 2027 (đã kiểm tra): 23 tháng Chạp (Ông Công Ông Táo) là Thứ Bảy 30.01; giao thừa là tối Thứ Sáu 05.02 (năm này không có ngày 30 Tết); mùng 1 Tết Đinh Mùi là Thứ Bảy 06.02; mùng 3 là Thứ Hai 08.02; Rằm tháng Giêng là Thứ Bảy 20.02. Ngày Quốc tế Phụ nữ 08.03 là Thứ Hai. Quý 1 khép ngày 31.03 (Thứ Tư). Mùa 3 "Học nhanh, nhớ lâu" mở từ 05.04.

| Số | Tuần | Công thức | TenNgan | Tên PDF công thức |
|---|---|---|---|---|
| 0035 | 11.01 đến 16.01.2027 | Bảng Kanban cá nhân | Kanban | 10XHub_CongThuc_0035_Bang Kanban Ca Nhan_VN.pdf |
| 0036 | 18.01 đến 23.01 | Gan góc | GanGoc | 10XHub_CongThuc_0036_Gan Goc_VN.pdf |
| 0037 | 25.01 đến 30.01 | Đặt ranh giới | RanhGioi | 10XHub_CongThuc_0037_Dat Ranh Gioi_VN.pdf |
| 0038 | 01.02 đến 06.02 | Tự trắc ẩn trong công việc | TuTracAn | 10XHub_CongThuc_0038_Tu Trac An_VN.pdf |
| 0039 | 08.02 đến 13.02 | Đừng bao giờ ăn một mình | KetNoi | 10XHub_CongThuc_0039_Dung Bao Gio An Mot Minh_VN.pdf |
| 0040 | 15.02 đến 20.02 | Đường cong quên và lặp lại cách quãng | LapLaiCachQuang | 10XHub_CongThuc_0040_Duong Cong Quen_VN.pdf |
| 0041 | 22.02 đến 27.02 | Sổ đầu dòng (Bullet Journal) | SoDauDong | 10XHub_CongThuc_0041_So Dau Dong_VN.pdf |
| 0042 | 01.03 đến 06.03 | Quy luật Parkinson và hộp thời gian | HopThoiGian | 10XHub_CongThuc_0042_Quy Luat Parkinson Hop Thoi Gian_VN.pdf |
| 0043 | 08.03 đến 13.03 | Nghịch lý lựa chọn | NghichLyLuaChon | 10XHub_CongThuc_0043_Nghich Ly Lua Chon_VN.pdf |
| 0044 | 15.03 đến 20.03 | Luật Hick và quy tắc mặc định | LuatHick | 10XHub_CongThuc_0044_Luat Hick_VN.pdf |
| 0045 | 22.03 đến 27.03 | Chỉ số Sao Bắc Đẩu cho mục tiêu | SaoBacDau | 10XHub_CongThuc_0045_Chi So Sao Bac Dau_VN.pdf |
| 0046 | 29.03 đến 03.04 | Sai lầm chi phí chìm và nhìn lại quý 1 | ChiPhiChim | 10XHub_CongThuc_0046_Sai Lam Chi Phi Chim_VN.pdf |

### #0035 Bảng Kanban cá nhân, 11.01 đến 16.01
- Tuần làm việc trọn vẹn đầu tiên của 2027. Lớp: đưa 5 mục tiêu và các bước nhỏ lên một bảng ba cột (Cần làm, Đang làm, Xong), giới hạn số việc dở. Khoá: j_wip (giới hạn việc dở), j_board (nơi đặt bảng).
- Nguồn: Taiichi Ohno và hệ thống Toyota (kanban trong sản xuất); David J. Anderson 2010 "Kanban"; Jim Benson và Tonianne DeMaria Barry 2011 "Personal Kanban" (hai quy tắc: nhìn thấy việc, giới hạn việc dở). John&Partners có chuyên môn Lean: viết chuẩn xác.
- Ngày gợi ý: dựng bảng; tách mục tiêu số 1 thành bước nhỏ; đặt giới hạn việc dở; buổi sáng nhìn bảng 5 phút; xử lý việc tắc; nhìn lại luồng việc tuần.
- Thẻ: diag. Hình: ba cột thẻ dán, mũi tên luồng việc, nút cổ chai, bảng trắng có nam châm.

### #0036 Gan góc, 18.01 đến 23.01
- Giữa tháng 1, quyết tâm đầu năm thường chững lại. Lớp: giữ thói quen khi hứng khởi giảm, nối mục tiêu với ý nghĩa dài hạn. Khoá: j_why_long (lý do dài hạn), j_hard (việc khó luyện mỗi tuần).
- Nguồn: Angela Duckworth 2016 "Grit"; Duckworth và cộng sự 2007 (Journal of Personality and Social Psychology); nhắc chừng mực các tranh luận (Credé và cộng sự 2017 cho thấy gan góc trùng nhiều với tính tận tâm). Không hứa hẹn.
- Ngày: thang đo gan góc tự chấm (tham khảo, không chẩn đoán); đam mê và kiên trì khác nhau thế nào; mục tiêu tầng trên, tầng giữa, tầng dưới; luyện việc khó; ngày nản thì làm phiên bản tối thiểu; thư gửi chính mình tháng 6.
- Thẻ: ladder. Hình: núi nhiều tầng, đường dài có cột mốc, kim tự tháp mục tiêu ba tầng, dây leo.

### #0037 Đặt ranh giới, 25.01 đến 30.01
- Tuần nước rút trước Tết: chốt việc, bàn giao để nghỉ Tết trọn vẹn. Thứ Bảy 30.01 là 23 tháng Chạp (Ông Công Ông Táo): điểm nhấn nhẹ về dọn dẹp, tiễn năm cũ. Lớp: ranh giới bảo vệ thói quen và giờ làm việc sâu; kế hoạch bàn giao. Khoá: j_boundary, j_handover.
- Nguồn: Henry Cloud và John Townsend "Boundaries" (1992); nghiên cứu về ngắt kết nối sau giờ làm (Sonnentag); quy tắc trả lời email sau giờ. Không đời tư nhạy cảm.
- Ngày: liệt kê những điều đang lấn vào giờ quan trọng; câu nói ranh giới lịch sự; hộp thư tự động ngày nghỉ Tết; danh sách bàn giao; một cuộc trao đổi với cấp trên hoặc đồng nghiệp; tiễn năm cũ, dọn bàn làm việc.
- Thẻ: seal. Hình: đường viền và cổng, hàng rào nét mảnh, lịch Tết khoanh vùng nghỉ, phong bì bàn giao.

### #0038 Tự trắc ẩn trong công việc, 01.02 đến 06.02
- Tuần giáp Tết, việc RẤT nhẹ (5 đến 15 phút). Thứ Sáu 05.02 là 29 Tết, tối giao thừa; Thứ Bảy 06.02 là mùng 1 Tết: bài chúc Tết ấm áp, việc 5 phút. Lớp: nhìn lại một năm làm việc công bằng với chính mình, giữ thói quen qua kỳ nghỉ bằng phiên bản tối thiểu kiểu Tết. Khoá: j_kind (câu tự nhắc tử tế), j_tet_mini (phiên bản Tết của thói quen).
- Nguồn: Kristin Neff 2003 (ba thành phần: tử tế với bản thân, nhân tính chung, chánh niệm); Breines và Chen 2012 (tự trắc ẩn và động lực sửa sai). Chỉ ở mức công việc, không nội dung sức khoẻ tâm thần.
- Thẻ: card (word "Chúc mừng năm mới"). Hình: hoa mai, hoa đào nét mảnh đỏ trắng, bao lì xì, câu đối, bàn trà Tết (không nền đen, không vàng: dùng đỏ, trắng, kem).

### #0039 Đừng bao giờ ăn một mình, 08.02 đến 13.02
- Mùng 3 đến mùng 8 Tết, nhiều nơi còn nghỉ đến giữa tuần: việc nhẹ, khai xuân, chúc Tết đối tác, đồng nghiệp, khách hàng. Lớp: mỗi tuần kết nối lại một người, ghép vào thói quen. Khoá: j_people (danh sách người cần giữ liên lạc), j_reach (nhịp kết nối).
- Nguồn: Keith Ferrazzi 2005 "Never Eat Alone"; Granovetter 1973 "Sức mạnh của mối quan hệ yếu". Không bán hàng.
- Thẻ: ring. Hình: mạng lưới chấm nối, bàn tròn khai xuân, thiệp chúc xuân, sơ đồ vòng tròn quan hệ.

### #0040 Đường cong quên và lặp lại cách quãng, 15.02 đến 20.02
- Tuần làm việc lại đầy đủ đầu tiên sau Tết. Rằm tháng Giêng Thứ Bảy 20.02. Lớp: khởi động lại thói quen sau kỳ nghỉ, ôn lại các công thức đã học bằng lặp lại cách quãng. Khoá: j_review (lịch ôn).
- Nguồn: Hermann Ebbinghaus 1885; Cepeda và cộng sự 2006 (tổng hợp về lặp lại cách quãng); Murre và Dros 2015 (lặp lại thí nghiệm của Ebbinghaus). Bắc cầu sang Mùa 3 "Học nhanh, nhớ lâu".
- Thẻ: curve. Hình: đường cong quên với các mốc ôn, lịch ôn 1, 3, 7, 14 ngày, thẻ ghi nhớ lật.

### #0041 Sổ đầu dòng, 22.02 đến 27.02
- Lớp: một hệ thống ghi chép ngày, tháng để không rơi mất các bước của 5 mục tiêu; "chuyển việc" cuối tháng. Khoá: j_log (nơi ghi), j_migrate (ngày chuyển việc).
- Nguồn: Ryder Carroll 2018 "The Bullet Journal Method". Không phụ thuộc giấy hay ứng dụng.
- Thẻ: bars. Hình: trang sổ chấm có ký hiệu, dòng việc chuyển tiếp, lịch tháng một trang, chỉ mục.

### #0042 Quy luật Parkinson và hộp thời gian, 01.03 đến 06.03
- #0013 đã đăng Quy luật Parkinson ở mức cơ bản; tuần này ở mức sâu: hộp thời gian cho từng bước của mục tiêu, hạn chót tự đặt. Lớp: mỗi bước có hộp thời gian trên lịch. Khoá: j_timebox.
- Nguồn: C. Northcote Parkinson 1955 (The Economist); Ariely và Wertenbroch 2002 (hạn chót tự đặt). Viết khác hẳn #0013.
- Thẻ: sun. Hình: đồng hồ cát, khối lịch có viền hộp, đồng hồ đếm ngược, thước đo thời gian.

### #0043 Nghịch lý lựa chọn, 08.03 đến 13.03
- Thứ Hai 08.03 là Ngày Quốc tế Phụ nữ: mở bài bằng lời tri ân các đồng nghiệp nữ, chuyên nghiệp, khác cách viết ngày 20.10 ở #0023. Lớp: bớt lựa chọn để giữ ưu tiên; chọn "đủ tốt" cho việc nhỏ, dành sức cho mục tiêu lớn. Khoá: j_enough (việc chọn kiểu đủ tốt).
- Nguồn: Barry Schwartz 2004 "The Paradox of Choice"; Iyengar và Lepper 2000 (thí nghiệm mứt); Scheibehenne và cộng sự 2010 (tổng hợp: hiệu ứng trung bình gần bằng 0, phụ thuộc bối cảnh): nói rõ tranh luận.
- Thẻ: quote. Hình: kệ nhiều lựa chọn thu về một, phễu chọn, hai con đường tối đa hoá và đủ tốt.

### #0044 Luật Hick và quy tắc mặc định, 15.03 đến 20.03
- Lớp: biến quyết định lặp lại thành quy tắc mặc định để rút ngắn thời gian bắt đầu thói quen. Khoá: j_default (quy tắc mặc định).
- Nguồn: William Edmund Hick 1952; Ray Hyman 1953 (thời gian phản ứng tăng theo số lựa chọn); ứng dụng trong thiết kế. Phân biệt rõ với #0043 (tuần trước bàn về sự hài lòng, tuần này bàn về tốc độ ra quyết định và quy tắc).
- Thẻ: loops. Hình: biểu đồ thời gian theo số lựa chọn, menu ngắn, công tắc mặc định, cây quyết định cắt tỉa.

### #0045 Chỉ số Sao Bắc Đẩu cho mục tiêu, 22.03 đến 27.03
- Lớp: mỗi mục tiêu có một chỉ số dẫn đường và chỉ số hành động hằng tuần (chỉ số dẫn trước và chỉ số kết quả). Khoá: j_northstar, j_lead.
- Nguồn: khái niệm North Star Metric trong quản trị sản phẩm (Sean Ellis, Amplitude); chỉ số dẫn trước và chỉ số kết quả trong "The 4 Disciplines of Execution" (McChesney, Covey, Huling 2012). Áp vào mục tiêu cá nhân trong công việc.
- Thẻ: chain. Hình: ngôi sao dẫn đường và la bàn, bảng điểm hai cột, đồng hồ đo, bản đồ có sao.

### #0046 Sai lầm chi phí chìm và nhìn lại quý 1, 29.03 đến 03.04
- Khép quý 1 (31.03) và khép Mùa 2. Lớp: rà 5 mục tiêu sau một quý, mạnh dạn bỏ hoặc sửa mục tiêu không còn đúng, giữ thói quen. Mở Mùa 3 "Học nhanh, nhớ lâu" (05.04). Khoá: j_q1_keep, j_q1_drop.
- Nguồn: Arkes và Blumer 1985 (chi phí chìm); Staw 1976 (leo thang cam kết).
- Thẻ: frame (big "Q1", unit "QUÝ 1 ĐÃ KHÉP"). Hình: cánh cửa khép và mở, bảng giữ và bỏ, lịch quý 1 khoanh tròn, cán cân.

## 8. Không được làm
- Không đụng Google Drive, GitHub, trình duyệt, lịch tự động. Không sửa sth.js, weeks.json, tpl.py, bkit.py, tệp của tuần khác. Chỉ ghi vào SP/w<số>n/, SP/gh_all/<số>.json, /tmp/f30/b/c<số>n.py, và /tmp/f30/b/vnkeep_extra/<số>.txt.
