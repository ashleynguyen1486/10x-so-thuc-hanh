# BRIEF: dựng bộ tuần "Công thức thành công của tuần" cho 10X Excellence Hub

SP = /tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad

## 1. Bối cảnh
- 10X Excellence Hub là cộng đồng Skool của John&Partners (Việt Nam). Mục tiêu: thành viên thay đổi thói quen trong 5 năm để 10X tiềm năng.
- Từ #0022, chuỗi là một HÀNH TRÌNH THÓI QUEN: mỗi thành viên giữ MỘT thói quen then chốt trong công việc qua nhiều tuần; mỗi công thức mới thêm một lớp cho chính thói quen đó.
- Mỗi tuần: Thứ Hai đến Thứ Bảy (6 bài), Chủ Nhật nghỉ, không đăng.
  - Thứ Hai = mở tuần + Ngày 1, đính kèm PDF công thức, phiếu Ngày 1 và hướng dẫn sổ thực hành của tuần. Đầu bài có một đoạn ngắn khép tuần trước (nhắc điều cả nhóm đã làm, không nêu số liệu tham gia) và một ô "Nếu mới tham gia" (mỗi tuần viết khác, chỉ cách bắt đầu ngay tuần này, tuần nào cũng tự đứng được).
  - Thứ Ba đến Thứ Sáu = Ngày 2 đến Ngày 5.
  - Thứ Bảy = Ngày 6 + khép tuần + thẻ thành tích (thành viên tự nhận trên sổ khi đánh dấu đủ 6 ngày; Admin chỉ đăng bài).
- Mỗi việc trong ngày 10 đến 45 phút. Ví dụ luôn là tình huống công việc (nhiều vị trí: quản lý, kinh doanh, kế toán, nhân sự, kỹ thuật, chăm sóc khách hàng...).
- Bài đã hoàn chỉnh làm mẫu tham khảo (KHÔNG chép cấu trúc, câu mở, ví dụ): SP/w22n/posts.md, SP/gh_all/0022.json, /tmp/f30/b/c22.py, SP/w22n/sheets22.py, SP/w22n/b/gen.py, SP/guide22n/mk.py và shots.py, SP/w22n/doc0022.txt, SP/w22n/rev0022.txt.

## 2. Luật bắt buộc (vi phạm là phải làm lại)
Ngôn ngữ và giọng
- 100% tiếng Việt. Không từ tiếng Anh (chia sẻ, không check-in; tệp, không file; email (dùng chữ "email", KHÔNG viết "thư điện tử"), hộp thư; thẻ trình duyệt, không tab; Dòng chảy, không Flow). Tên riêng người, sách, tổ chức giữ nguyên.
- Người viết là Trường (nam, chuyên gia tư vấn). Trong lời dẫn KHÔNG xưng "tôi"; nếu cần thì xưng "Trường". Gọi người đọc "các anh chị và các bạn". Dùng "nha" (không "nhé") ở đoạn dặn dò, chia sẻ; không gắn "nha" vào câu kiến thức, số liệu.
- Không câu chào mở cố định. Không bịa chuyện riêng hay khách hàng của Trường. Câu chia sẻ mẫu của thành viên viết theo ngôi "tôi".
- Ngôn ngữ business chuyên nghiệp, dễ hiểu: không Hán Việt hoa mỹ, không văn nói (dùng "điều", "việc", "yếu tố" thay cho "thứ"). Không hứa hẹn kết quả. Giọng tích cực, đồng hành.
- KHÔNG dùng gạch ngang dài (—) hay gạch ngang vừa (–) ở bất cứ đâu; thay bằng dấu phẩy hoặc hai chấm. Mũi tên → dùng được.
- Không nội dung đời tư nhạy cảm (hôn nhân, bệnh tật, sức khỏe tâm thần...). Năng lượng/nghỉ ngơi chỉ nói ở mức thói quen làm việc, không lời khuyên y khoa.
- Mọi con số, năm, tên nghiên cứu phải đúng. Dùng WebSearch để đối chiếu điểm quan trọng. Câu nói gán cho người nổi tiếng mà chưa xác minh được thì ghi rõ "thường được gán cho ... nhưng chưa có bằng chứng". Ghi nguồn trong trang tài liệu tham khảo của PDF và trong tệp rà soát.
- Không bao giờ để một cụm từ bị tách ra hai dòng (thói quen, hợp đồng, kế hoạch, mục tiêu...). Mọi HTML dựng PDF/hình đều đi qua keep() trong /tmp/f30/b/vnkeep.py; bổ sung cụm mới của tuần (ví dụ "việc dở dang", "ý định thực hiện") vào tệp /tmp/f30/b/vnkeep_extra/<số>.txt, mỗi dòng một cụm; KHÔNG sửa vnkeep.py.

Không lặp khuôn ("AI template")
- Sáu bài trong tuần mỗi bài một dạng (kể tình huống, hỏi đáp, danh sách, đối chiếu, giải nghĩa, câu hỏi mở, thư, nhật ký, bảng chọn...). Và khác với các tuần khác: đọc kế hoạch 12 tuần bên dưới, đừng dùng lại dạng của Thứ Hai tuần 0022 (so sánh hai câu), hỏi đáp Thứ Ba, kể nghiên cứu Thứ Tư...
- Bài đủ dài: Thứ Hai khoảng 600 đến 900 chữ, các ngày khác 400 đến 700 chữ.
- 7 hình của tuần: 7 bố cục khác nhau, và khác các bố cục đã dùng (mục 6).
- Phiếu thực hành: thiết kế riêng của tuần, khác kiểu dải đầu trang (0021) và cột dọc bên trái (0022).

## 3. Hành trình thói quen trên sổ thực hành (tệp JSON tuần)
- Trang https://10xexcellence.co/so-thuc-hanh đọc sth.js + weeks.json + <số>.json. Bạn CHỈ viết SP/gh_all/<số>.json. KHÔNG sửa sth.js, weeks.json.
- Cấu trúc: xem SP/gh_all/0022.json. Trường cấp tuần: id, name, storeKey ("sth-<số>-6n"), kicker ("Công thức #<số>"), title, sub, badge, days[6]. Mỗi ngày: label (Thứ Hai...), kick, title, time ("Khoảng 20 phút"), cards[{h, items[]}], checkin[{tpl, need[]}], hint.
- Loại item: note{text}; tx/ta{k,q,ph}; cb{k,label}; show{text,need} (ghép câu tự động từ các khoá); seg{k,q,opts,hints?} (mỗi lựa chọn phải có định nghĩa/ví dụ trong hints hoặc note gần đó); pick{k,kp,n,empty} (chọn 1 trong các ô kp1..kpn); timer{k,dk,def,opts}; nums{items[{k,q}]}; rate{kp,head,rows,scale}; sum{head,rows[{label,keys}]}; cal{k,mark,max,cols,rows}; compare{cols,rows[{label,keys}]}; matrix; rows; track{note} (bảng hành trình 6 ngày của tuần, dùng chung mọi tuần).
- Token trong tpl/show: {khoá}, {khoá|mặc định}, {sum:a,b}, {cal:k}, {jweek} (số ngày đã làm thói quen trong tuần), {jtotal} (tổng ngày cả hành trình), {jstreak}.
- Khoá bắt đầu bằng "j_" được lưu cho cả hành trình (mọi tuần thấy). Đã có: j_identity, j_habit, j_when, j_where, j_after, j_cue, j_like, j_buddy, j_two, j_miss, j_reward, j_marks. Mỗi tuần thêm khoá j_ riêng theo kế hoạch mục 7, đừng đặt trùng khoá của tuần khác.
- Ngày 1 mỗi tuần phải hiện lại thói quen đang giữ (show "Thói quen đang giữ: {j_habit}") VÀ có ô tx j_habit để người mới điền (người mới cũng cần j_identity). Thêm track ở ít nhất một ngày trong tuần (ngày nào là tuỳ tuần, đừng luôn là Ngày 5).
- badge: {"style": <theo kế hoạch>, "big": "...", "unit": "...", "line": "...", ...}. Kiểu có sẵn: ring{big,ratio,of,unit}, bars{big,unit}, seal{big,unit,ring}, diag{big,unit}, year{big,unit,sub,year}, frame{big,unit,sub}, sun{big,unit}, ladder{big,unit}, quote{big,unit,quote}, loops{big,unit}, card{big,unit,word}, curve{big,unit}. big/line/quote/sub chấp nhận token.
- Sau khi tạo JSON, áp keep() cho mọi chuỗi trừ các khoá tpl,k,kp,dk,f,id,storeKey,style,line,need,keys (xem đoạn K() cuối SP/gh22b/mk22.py). Câu tpl không dùng keep.
- Kiểm thử: `cd SP/kit && python3 testweek.py <số>`; đọc câu chia sẻ in ra, xem ảnh SP/w<số>n/test/*.png và badge.png. Không có lỗi JS. Câu chia sẻ trên sổ phải khớp câu "Chia sẻ hôm nay" trong bài đăng.

## 4. Sản phẩm mỗi tuần (đặt trong SP/w<số>n/)
Tiền tố tên tệp P = "10XHub_<TenNgan>_" (TenNgan theo mục 7).
1. posts.md: 6 mục "## Bài N: ... (Thứ X dd/mm)" giống định dạng SP/w22n/posts.md với các dòng @img, @img2 (Thứ Bảy: 9_the-thanh-tich), @pdf, @cat. Dòng "**Tiêu đề bài trên Skool:** ..." (IN HOA). Mỗi bài có "Làm bài trên sổ thực hành: https://10xexcellence.co/so-thuc-hanh#<số>-ngay-<n>." và "Chia sẻ hôm nay: "...".". Không dùng bảng markdown, không dùng dấu > trích dẫn (Skool không hiển thị).
2. Công thức PDF: script /tmp/f30/b/c<số>n.py dùng /tmp/f30/b/tpl.py (giữ nguyên mẫu: page, cover, disclaimer, build; xem c22.py) + keep(). Xuất thẳng ra SP/w<số>n/formula/<tên PDF theo mục 7>. Khoảng 18 đến 24 trang: bìa; mở đầu theo cách khác các tuần khác; nội dung khoa học có nguồn; liên hệ hành trình thói quen (lớp tuần này thêm gì); áp dụng theo vị trí công việc; lộ trình 6 ngày (Thứ Hai đến Thứ Bảy, Chủ Nhật nghỉ, hoặc làm bù); 6 trang ngày; một trang công cụ in được; trang nối sang tuần sau; tuyên bố miễn trừ trách nhiệm có tài liệu tham khảo. Cờ "overflow [1]" của tpl là báo giả nếu trang hiển thị đúng; vẫn phải xem ảnh trang.
3. Sổ thực hành: SP/gh_all/<số>.json (mục 3).
4. Hình: SP/w<số>n/b/gen.py tạo 7 tệp html bằng bkit (`from bkit import page, render`, xem docstring /tmp/f30/b/bkit.py), chép SP/kit/img vào SP/w<số>n/b/img, rồi render ra b/out/P1_<slug>.png ... P6_<slug>.png và P9_the-thanh-tich.png (3840x2160).
   - Tiêu đề trên hình: IN HOA, 25 đến 35 ký tự, class "fit" (tự giữ một dòng, chỉ xuống 2 dòng khi thu nhỏ vẫn không vừa; KHÔNG dùng <br>). Báo cáo của render phải là '1' hoặc '2', không có 'TRAN'. Nếu 2 dòng mà chữ nhỏ dưới 64px thì rút gọn câu chữ hoặc nới khung.
   - Màu: đỏ thương hiệu #862222 / #7b1f23, trắng, kem #FBF5F4, mực #231F20 (các sắc đỏ nhạt để phân lớp). Không nền đen, không màu vàng. Logo 10X trên mọi hình (logo_c_crop trên nền sáng, logo_w_crop trên nền đỏ). Không ảnh chụp người thật của khách; được phép không dùng ảnh.
   - Ghép bảng xem nhanh và tự xem bằng Read: dấu tiếng Việt, tràn chữ, chồng lấn, khoảng trống thừa, cụm từ bị tách.
5. Phiếu thực hành: SP/w<số>n/sheets.py → SP/w<số>n/pdf/P"PhieuNgay<n>_<slug>.pdf" (A4, mỗi ngày 1 trang; ngày có công cụ in được thì thêm trang). Thiết kế riêng của tuần. Có câu chia sẻ và đường dẫn sổ của ngày.
6. Hướng dẫn sổ thực hành riêng của tuần: SP/w<số>n/guide/10XHub_HuongDan_SoThucHanh_<số>.pdf, 3 đến 5 trang A4, mô phỏng theo SP/guide22n (chụp màn hình sổ của CHÍNH tuần này từ site cục bộ do testweek.py tạo ở SP/site_<số>, khoanh đỏ nút cần bấm; các bước dùng sổ; một trang "Công cụ riêng của tuần"; hỏi nhanh theo nội dung tuần). Giọng Trường, 100% tiếng Việt.
7. Word: `cd SP/w<số>n && cp -r ../kit/img . && mkdir -p docjpg word` ; tạo docjpg/<P><n>_<slug>.jpg (1600x900) từ hình; `PFX=<P> LABEL="<tên thử thách>" NODE_PATH=../kit/node_modules node ../kit/mkdocx.js word`.
8. Văn bản Google Doc bài đăng: SP/w<số>n/doc<số>.txt (định dạng như SP/w22n/doc0022.txt: phần đầu gồm tên tuần, người viết Trường, lịch đăng, hành trình, thẻ thành tích, sổ thực hành, tệp đính kèm; rồi từng bài với Banner, PDF đính kèm, Danh mục Skool, Tiêu đề, toàn văn, bỏ ký hiệu ** *).
9. Văn bản rà soát: SP/w<số>n/rev<số>.txt (như rev0022.txt + phần nguồn đã đối chiếu kèm đường link, và các điểm cần Ashley kiểm tra thêm).

## 5. Tự kiểm tra trước khi báo xong
- Quét mọi văn bản (posts.md, json, html của PDF/hình/phiếu, doc, rev): không "nhé", không — –, không " tôi " trong lời dẫn (chỉ trong câu mẫu của thành viên), không "thứ" theo nghĩa đồ vật, không từ tiếng Anh ngoài tên riêng/tên sách/trích dẫn tài liệu.
- Xem ảnh mọi trang PDF công thức, mọi phiếu, mọi hình, hướng dẫn.
- Chạy testweek.py, xem ảnh.
- Báo cáo cuối (ngắn): danh sách tệp, các điểm nghi ngờ về nguồn, câu chữ cần Ashley xem.

## 6. Bố cục hình đã dùng (KHÔNG dùng lại)
0021: ảnh văn phòng chia đôi; ma trận 2x2; vòng tròn số phút; danh sách gạch đầu dòng trên nền đỏ; 5 thẻ dọc đánh số; ảnh toà nhà + câu hỏi; con dấu tròn số 6.
0022: dòng thời gian dọc 6 chấm; câu điền chỗ trống gạch chân; hai vòng tròn giao nhau; cột giảm dần 60 → 2 phút; lưới ô tích T2 đến T7; tờ giấy hợp đồng nghiêng; con dấu chữ chạy vòng 6/6.
Mỗi nhóm tuần chỉ dùng các ý tưởng hình gợi ý ở mục 7 cho tuần của mình (hoặc ý mới tương đương), để các tuần không đụng nhau.

## 7. Kế hoạch 12 tuần (#0023 đến #0034)
Lịch Việt Nam cần dùng để tăng cảm xúc: 20.10 Ngày Phụ nữ Việt Nam; 20.11 Ngày Nhà giáo Việt Nam; tháng 12 mùa cuối năm, tất niên; 24 và 25.12 Giáng sinh; 31.12 cuối năm; 01.01.2027 Tết Dương lịch (Thứ Sáu, ngày nghỉ, bài rất nhẹ); tuần đầu năm 2027 đặt mục tiêu. Dùng tinh tế, chuyên nghiệp, gắn với công việc và thói quen.

| Số | Tuần | Công thức | TenNgan | Tên PDF công thức |
|---|---|---|---|---|
| 0023 | 19.10 đến 24.10.2026 | Ý định thực hiện (Nếu... thì...) | YDinhThucHien | 10XHub_CongThuc_0023_Y Dinh Thuc Hien_VN.pdf |
| 0024 | 26.10 đến 31.10 | Quản lý năng lượng | NangLuong | 10XHub_CongThuc_0024_Quan Ly Nang Luong_VN.pdf |
| 0025 | 02.11 đến 07.11 | Công việc sâu | CongViecSau | 10XHub_CongThuc_0025_Cong Viec Sau_VN.pdf |
| 0026 | 09.11 đến 14.11 | Ăn con ếch | AnConEch | 10XHub_CongThuc_0026_Ky Thuat An Con Ech_VN.pdf |
| 0027 | 16.11 đến 21.11 | Luyện tập có chủ đích | LuyenTap | 10XHub_CongThuc_0027_Luyen Tap Co Chu Dich_VN.pdf |
| 0028 | 23.11 đến 28.11 | Kỹ thuật Feynman | Feynman | 10XHub_CongThuc_0028_Phuong phap Feynman_VN.pdf |
| 0029 | 30.11 đến 05.12 | Tiên liệu thất bại | TienLieu | 10XHub_CongThuc_0029_Tien Lieu That Bai_VN.pdf |
| 0030 | 07.12 đến 12.12 | Hiệu ứng việc dở dang | ViecDoDang | 10XHub_CongThuc_0030_Hieu Ung Viec Do Dang_VN.pdf |
| 0031 | 14.12 đến 19.12 | Kaizen, cải tiến liên tục | Kaizen | 10XHub_CongThuc_0031_Kaizen_VN.pdf |
| 0032 | 21.12 đến 26.12 | Lòng biết ơn trong công việc | BietOn | 10XHub_CongThuc_0032_Long Biet On_VN.pdf |
| 0033 | 28.12.2026 đến 02.01.2027 | Sức mạnh thói quen | SucManhThoiQuen | 10XHub_CongThuc_0033_Suc Manh Thoi Quen_VN.pdf |
| 0034 | 04.01 đến 09.01.2027 | Quy tắc 5/25 | QuyTac525 | 10XHub_CongThuc_0034_Quy Tac 5-25_VN.pdf |

### #0023 Ý định thực hiện, 19.10 đến 24.10
- Lớp hành trình: soạn sẵn kế hoạch "Nếu [trở ngại] thì [phiên bản tối thiểu]" cho thói quen. Khoá: j_if1..3, j_then1..3.
- Khoa học: Gollwitzer 1999 (American Psychologist); Gollwitzer & Sheeran 2006 tổng hợp 94 nghiên cứu, hiệu ứng mức trung bình đến lớn. Kiểm tra số liệu.
- Ngày gợi ý: T2 đọc lại bảng hành trình tuần trước, ngày nào lỡ và vì sao; T3 (20.10) ba kế hoạch Nếu... thì..., mở bài bằng lời tri ân các đồng nghiệp nữ nhân Ngày Phụ nữ Việt Nam, nhẹ nhàng, chuyên nghiệp; T4 ngày họp dồn, đi công tác; T5 khi người khác chen ngang: câu từ chối lịch sự soạn sẵn; T6 dùng thử kế hoạch, ghi lại; T7 thẻ Nếu... thì... đặt trên bàn + track.
- Thẻ: ring. Ý tưởng hình: ngã rẽ, mũi tên rẽ nhánh, công tắc bật tắt, biển chỉ đường, thẻ bài hai mặt.

### #0024 Quản lý năng lượng, 26.10 đến 31.10
- Lớp: đặt thói quen vào khung giờ năng lượng cao nhất, thêm nghỉ ngắn có chủ đích. Khoá: j_peak, j_recharge.
- Khoa học: Loehr & Schwartz 2003 "The Power of Full Engagement" (bốn nguồn năng lượng: thể chất, cảm xúc, trí tuệ, ý nghĩa); Schwartz & McCarthy 2007 HBR "Manage Your Energy, Not Your Time". Không lời khuyên y khoa.
- Ngày: đo năng lượng 3 lần/ngày; tìm giờ vàng và dời thói quen vào; nghỉ ngắn giữa phiên; một việc tiếp sức cảm xúc trong công việc; nối thói quen với ý nghĩa; lịch năng lượng tuần sau.
- Thẻ: bars. Hình: thanh pin, đường sóng năng lượng trong ngày, bốn vòng đồng tâm, đồng hồ có vùng tô.

### #0025 Công việc sâu, 02.11 đến 07.11
- Lớp: nâng thói quen thành một khối làm việc sâu được bảo vệ trong lịch. Khoá: j_deep (khung giờ sâu), j_ritual.
- Khoa học: Cal Newport 2016 "Deep Work"; Sophie Leroy 2009 (dư âm chú ý). Nối với tuần Dòng chảy #0021. Cẩn thận con số "23 phút" (chỉ dùng nếu xác minh đúng nguồn).
- Ngày: phân loại việc sâu và việc nông; chọn nhịp lịch; nghi thức bắt đầu; gom việc nông; nghi thức kết thúc; đo giờ sâu cả tuần.
- Thẻ: diag. Hình: các lớp chồng mờ dần (chiều sâu), thẻ treo cửa "đang làm việc sâu", khối lịch tô đậm, vòng đồng tâm hội tụ.

### #0026 Ăn con ếch, 09.11 đến 14.11
- Lớp: việc quan trọng nhất làm đầu ngày, ngay cạnh thói quen. Khoá: j_frog.
- Khoa học/nguồn: Brian Tracy 2001 "Eat That Frog!" (phương pháp ABCDE). Câu "con ếch" thường được gán cho Mark Twain nhưng chưa có bằng chứng: nói rõ.
- Ngày: danh sách việc và chấm ABCDE; chuẩn bị ếch từ chiều hôm trước; ăn ếch trước 10 giờ; ếch quá lớn thì cắt lát; ghép ếch với thói quen then chốt; nhìn lại tuần.
- Thẻ: sun. Hình: mặt trời mọc trên trục giờ, bậc xếp hạng ABCDE, đĩa chia lát, số 1 khổ lớn (không vẽ ếch hoạt hình).

### #0027 Luyện tập có chủ đích, 16.11 đến 21.11
- Lớp: chọn một kỹ năng con trong thói quen để luyện có mục tiêu và phản hồi. Khoá: j_skill, j_coach.
- Khoa học: Ericsson, Krampe & Tesch-Römer 1993; Ericsson & Pool 2016 "Peak"; quy tắc 10.000 giờ là cách hiểu phổ biến bị chính Ericsson phản biện.
- Ngày 5 là Thứ Sáu 20.11, Ngày Nhà giáo Việt Nam: xin phản hồi từ người hướng dẫn và gửi lời cảm ơn người thầy, người dẫn dắt đã giúp mình trong nghề. Đây là điểm cảm xúc của tuần.
- Thẻ: ladder. Hình: bậc thang, bia ngắm, vòng phản hồi, thiệp cảm ơn người thầy.

### #0028 Kỹ thuật Feynman, 23.11 đến 28.11
- Lớp: bản sắc "người chia sẻ kiến thức": giảng lại điều học được từ hành trình cho đồng nghiệp. Khoá: j_teach.
- Nguồn: Richard Feynman; "kỹ thuật Feynman" 4 bước là cách hệ thống hoá về sau, không phải tên do Feynman đặt: nói rõ.
- Ngày: chọn một điều đã học trong các tuần trước; giải thích bằng lời đơn giản cho người mới vào nghề; tìm chỗ hổng và quay lại tài liệu; rút gọn kèm ví dụ; dạy lại một đồng nghiệp 10 phút; chia sẻ bản giải thích trong cộng đồng để giúp người mới.
- Thẻ: quote. Hình: bảng trắng có nét vẽ tay trên nền kem, bong bóng lời thoại, phễu từ phức tạp đến đơn giản, trang sổ có gạch xoá.

### #0029 Tiên liệu thất bại, 30.11 đến 05.12
- Lớp: bảo vệ thói quen trước mùa cuối năm và Tết. Khoá: j_risk1..3, j_guard.
- Khoa học: Gary Klein 2007 HBR "Performing a Project Premortem"; Mitchell, Russo & Pennington 1989 (hồi tưởng giả định). Kiểm tra con số 30%.
- Ngày: hình dung ngày 31.01.2027 thói quen đã dừng, viết lý do; xếp hạng rủi ro; biện pháp cho 3 rủi ro lớn; kế hoạch cho lịch tất niên dày đặc; người nhắc và tín hiệu cảnh báo sớm; "lá chắn cuối năm".
- Thẻ: seal. Hình: trang báo từ tương lai (viết tích cực), lịch đếm ngược, khiên kèm danh sách, kính lúp soi rủi ro.

### #0030 Hiệu ứng việc dở dang, 07.12 đến 12.12
- Lớp: nghi thức kết thúc ngày gắn với thói quen, khép việc treo trước cuối năm. Khoá: j_shutdown.
- Khoa học: Zeigarnik 1927; Masicampo & Baumeister 2011 (lập kế hoạch cụ thể giảm suy nghĩ chen ngang); quy tắc 2 phút của David Allen. Nhịp cảm xúc: còn ba tuần nữa là hết năm 2026.
- Ngày: gom mọi việc dở ra giấy; phân loại làm ngay, lên lịch, giao, bỏ; khép 3 việc treo lâu nhất; nghi thức kết thúc ngày; dừng giữa chừng có chủ đích để mai dễ bắt đầu; danh sách việc khép năm 2026.
- Thẻ: loops. Hình: vòng tròn chưa khép, thanh tiến độ dở, ngoặc mở và đóng, khay hồ sơ.

### #0031 Kaizen, 14.12 đến 19.12
- Lớp: cải tiến nhỏ nhất cho thói quen mỗi tuần, nhìn lại năm theo tinh thần cải tiến. Khoá: j_kaizen.
- Nguồn: Masaaki Imai 1986 "Kaizen: The Key to Japan's Competitive Success"; Toyota; chu trình PDCA (Shewhart, Deming). Phép tính 1,01 mũ 365 chỉ là minh hoạ, không phải lời hứa.
- Ngày: nhìn lại năm, 3 việc mình đã làm tốt hơn; chọn một cải tiến nhỏ nhất cho thói quen; một vòng PDCA trong một ngày; cải tiến chỗ làm việc theo 5S nhỏ; xin một góp ý từ đồng nghiệp; sổ cải tiến năm.
- Thẻ: curve. Hình: đường cong tích luỹ, bánh xe PDCA, chuỗi bậc rất nhỏ, trước và sau của bàn làm việc.

### #0032 Lòng biết ơn trong công việc, 21.12 đến 26.12
- Tuần Giáng sinh, việc nhẹ và ấm. Lớp: một lời cảm ơn cụ thể sau khi làm thói quen. Khoá: j_thanks.
- Khoa học: Emmons & McCullough 2003; Grant & Gino 2010 (lời cảm ơn làm tăng hành vi giúp đỡ). Kiểm tra con số.
- Ngày: ba điều biết ơn trong công việc năm nay; cảm ơn cụ thể một đồng nghiệp; cảm ơn một khách hàng hoặc đối tác; Thứ Năm 24.12 cảm ơn người âm thầm hỗ trợ (bảo vệ, tạp vụ, kỹ thuật); Thứ Sáu 25.12 nhìn lại hành trình của chính mình; Thứ Bảy lá thư cảm ơn năm 2026 gửi cộng đồng.
- Thẻ: card. Hình: phong bì, bưu thiếp, dây treo thiệp, thẻ quà đỏ trắng (Giáng sinh tinh tế, không cây thông hoạt hình).

### #0033 Sức mạnh thói quen, 28.12.2026 đến 02.01.2027
- Tuần chuyển năm. Lớp: tổng kết năm 2026 bằng bảng hành trình, quyết định thói quen then chốt cho 2027 (giữ, nâng cấp hay đổi). Khoá: j_habit_2026 (lưu bản cũ), j_identity_2027, j_letter. Có thể cập nhật j_habit.
- Nguồn: Charles Duhigg 2012 "The Power of Habit" (vòng lặp tín hiệu, hành động, phần thưởng; thói quen then chốt; câu chuyện Paul O'Neill ở Alcoa).
- Ngày: T2 nhìn lại năm qua bảng hành trình; T3 vòng lặp thói quen của mình; T4 quyết định cho 2027; T5 (Thứ Năm 31.12) thư gửi chính mình ngày cuối năm; T6 (Thứ Sáu 01.01.2027, ngày nghỉ Tết Dương lịch) một câu bản sắc cho năm mới, 5 đến 10 phút; T7 (02.01) tuần đầu năm 2027.
- Thẻ: year (year 2026, unit "NĂM 2026 CỦA TÔI"). Hình: lưới 365 ô, 2026 chuyển 2027, pháo hoa nét mảnh đỏ trắng, phong bì gửi tương lai.

### #0034 Quy tắc 5/25, 04.01 đến 09.01.2027
- Mở Năm 1 / Mùa 2. Lớp: nối thói quen then chốt với mục tiêu số 1 của năm. Khoá: j_top5 (hoặc j_goal1..5), j_avoid.
- Nguồn: câu chuyện Warren Buffett và phi công Mike Flint, được lan truyền rộng (Scott Dinsmore, James Clear), chưa có xác nhận trực tiếp từ Buffett: nói rõ.
- Ngày: viết 25 mục tiêu công việc 2027; khoanh 5; 20 việc còn lại là danh sách "tránh"; nối thói quen với mục tiêu số 1; kế hoạch quý 1; thẻ 5 mục tiêu.
- Thẻ: frame (big "5", unit "MỤC TIÊU", sub "năm 2027"). Hình: 25 giấy ghi chú gạch còn 5, hai cột danh sách, số 2027 cỡ lớn, phễu lọc.

## 8. Không được làm
- Không đụng Google Drive, GitHub, trình duyệt, lịch tự động. Không sửa sth.js, weeks.json, tpl.py, bkit.py, tệp của tuần khác. Chỉ ghi vào SP/w<số>n/, SP/gh_all/<số>.json, /tmp/f30/b/c<số>n.py, và /tmp/f30/b/vnkeep_extra/<số>.txt.
