#!/bin/bash
# Dựng lại môi trường làm việc đúng các đường dẫn mà BRIEF.md và các script mẫu đang dùng.
# Chạy từ thư mục gốc của kho đã clone:  bash bo-cong-cu-v2/setup.sh
set -e
REPO=$(cd "$(dirname "$0")/.." && pwd)
K="$REPO/bo-cong-cu-v2"
SP=/tmp/claude-0/-home-claude/68411cb2-7c4d-5001-8534-192a07485fcf/scratchpad
mkdir -p /tmp/f30/b "$SP/kit" "$SP/site21" "$SP/gh_all"
cp -r "$K/f30/." /tmp/f30/b/
cp -r "$K/kit/." "$SP/kit/"
cp -r "$K/site21/." "$SP/site21/"
cp "$REPO"/sth.js "$REPO"/weeks.json "$REPO"/0*.json "$SP/gh_all/"
cp -r "$K/mau/w0034n" "$SP/w0034n"
cd "$SP/kit" && npm install --silent docx@8 >/dev/null 2>&1 || npm install docx
python3 -c "import playwright" 2>/dev/null || pip install playwright --break-system-packages -q
echo "SP=$SP"
echo "Moi truong san sang."
