# Lịch tự động: soạn một tuần mới cho "Công thức thành công của tuần"

Tài liệu này dành cho phiên chạy theo lịch (mỗi Thứ Hai). Mỗi lần chạy soạn ĐÚNG MỘT tuần mới, giữ khoảng đệm khoảng 12 tuần soạn sẵn trước ngày đăng.

## 0. Chuẩn bị
1. `git clone https://github.com/ashleynguyen1486/10x-so-thuc-hanh.git kho && cd kho`
2. `unzip -o bo-cong-cu-v2.zip && bash bo-cong-cu-v2/setup.sh`
3. Đọc KỸ TOÀN BỘ `bo-cong-cu-v2/kit/BRIEF.md` (bản đầy đủ luật viết, giọng Trường, thiết kế, sổ thực hành, sản phẩm, tự kiểm tra). Mọi luật ở đó vẫn áp dụng. Bỏ qua bảng kế hoạch 12 tuần ở mục 7 của BRIEF (đã soạn xong), dùng mục 2 dưới đây để chọn tuần mới.
4. Đọc `bo-cong-cu-v2/mau/posts00*.md` của ít nhất 4 tuần gần nhất và các bảng hình `mau/b_*.jpg`, cùng hình của những tuần mới hơn trên Drive (tải bằng download_file_content), để KHÔNG lặp câu mở, dạng bài, bố cục hình, kiểu phiếu, kiểu thẻ thành tích.

## 1. Quyết định có soạn hay không
- Tuần mới = số lớn nhất trong weeks.json + 1. Ngày Thứ Hai của tuần mới = "start" của tuần lớn nhất + 7 ngày.
- Nếu Thứ Hai đó còn cách hôm nay hơn 13 tuần: KHÔNG soạn, báo "Đã đủ khoảng đệm" và dừng.

## 2. Chọn công thức
- Đã duyệt sẵn: #0035 Bảng Kanban cá nhân (11.01.2027); #0036 Gan góc (18.01); #0037 Đặt ranh giới, bàn giao trước Tết (25.01); #0038 Tự trắc ẩn trong công việc, tuần giáp Tết, mùng 1 Tết là Thứ Bảy 06.02.2027, bài nhẹ (01.02); #0039 Đừng bao giờ ăn một mình, đầu xuân gặp gỡ chúc Tết đối tác (08.02); #0040 Đường cong quên và lặp lại cách quãng, khởi động lại sau Tết (15.02).
- Sau #0040: đọc Google Sheet "Lộ trình 5 năm - Công thức thành công của tuần" (id 1sG2-C8Pk4K3buhDa_YiztO8JZcoEOnFm_3sFOHv2hLQ) và Masterlist (id 1TDbhOJmfyoVTQCE5bfM5myQMrolvAWZAx09SEwCS-hM) để chọn công thức đúng năm và mùa: Năm 1 Làm chủ bản thân, Năm 2 Tư duy, Năm 3 Giao tiếp và ảnh hưởng, Năm 4 Dẫn dắt đội nhóm và cải tiến, Năm 5 Tạo giá trị và sự nghiệp; mỗi năm 4 mùa. Ưu tiên công thức có sẵn trong kho (cột "Tệp nguồn trong kho"), không trùng chủ đề đã đăng. Công thức phải nối được với hành trình thói quen then chốt (thêm một lớp cho thói quen).
- Luôn để ý lịch Việt Nam và lịch năm để tăng cảm xúc (Tết Nguyên đán, 8.3, 30.4 và 1.5, 2.9, 20.10, 20.11, Giáng sinh, cuối năm, đầu năm, cuối quý).

## 3. Soạn
- Làm đủ 9 sản phẩm ở mục 4 của BRIEF cho tuần mới, theo đúng mục 5 tự kiểm tra (chạy `cd $SP/kit && python3 testweek.py <số>`).
- Thêm mục mới vào `$SP/gh_all/weeks.json`: {"id","label":"Từ ngày dd.mm - dd.mm.yyyy" (Thứ Hai đến Thứ Bảy),"file","show": ngày hôm nay,"start"}. Chọn kiểu thẻ thành tích khác 4 tuần gần nhất (12 kiểu có sẵn trong sth.js).
- Thêm cụm từ của tuần vào /tmp/f30/b/vnkeep_extra/<số>.txt.

## 4. Đưa lên trang sổ thực hành
- Chép `<số>.json` và `weeks.json` vào thư mục kho, commit "Cong thuc #<số>: hanh trinh thoi quen 6 ngay" và `git push origin main`. Cập nhật luôn vnkeep_extra mới vào bo-cong-cu-v2.zip nếu push được.
- Sau khi push: `curl -s https://purge.jsdelivr.net/gh/ashleynguyen1486/10x-so-thuc-hanh@main/sth.js`.
- Nếu không push được (không có quyền ghi): tải hai tệp JSON lên thư mục "Bài đăng mỗi ngày" của tuần trên Drive và ghi rõ trong báo cáo rằng Admin cần đưa lên GitHub.

## 5. Google Drive (thư mục gốc "Công thức thành công của tuần", id 1RyX_S_2Mod1rmk41fqNqZuINCHJQRpOl)
Dùng kết nối Google Drive (create_file; tệp nhị phân dùng base64Content và disableConversionToGoogleType true; Doc dùng textContent với contentMimeType text/plain).
1. Tạo thư mục tuần "<năm>_Tháng <mm>_Từ ngày <dd.mm Thứ Hai> đến ngày <dd.mm Thứ Bảy>" (nếu chưa có).
2. Đặt PDF công thức ở thư mục tuần.
3. Tạo thư mục con "Bài đăng mỗi ngày", trong đó tạo 6 thư mục "Ngày 1 - Thứ Hai dd.mm" ... "Ngày 6 - Thứ Bảy dd.mm".
4. Mỗi thư mục ngày: hình của ngày, phiếu PDF của ngày, tệp Word của bài; Ngày 1 thêm hướng dẫn sổ thực hành của tuần; Ngày 6 thêm hình thẻ thành tích.
5. Hai Google Doc ở thư mục "Bài đăng mỗi ngày": "Tuần <số> - <chủ đề> - Bài đăng (Thứ Hai dd/mm đến Thứ Bảy dd/mm)" từ doc<số>.txt, và "Tuần <số> - Rà soát công thức" từ rev<số>.txt. Ghi đúng đường dẫn thư mục theo ngày trong phần đầu doc.
6. Không xoá, không di chuyển, không sửa tệp có sẵn trên Drive.

## 6. Báo cáo (tiếng Việt, ngắn)
Số và tên công thức, tuần đăng, đường link thư mục tuần và hai Google Doc, trạng thái đưa lên sổ thực hành (đã push hay cần Admin), các điểm nguồn cần Ashley xem, và dòng cần thêm vào Masterlist (Admin cập nhật vì kết nối không sửa được Sheet).
