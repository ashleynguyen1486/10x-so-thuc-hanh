import re
W="""thói quen|hợp đồng|bản sắc|quy luật|liên tiếp|làm việc|công việc|phiên bản|hai phút|tín hiệu|xếp chồng|hấp dẫn|thỏa mãn|theo dõi|ghi nhận|kế hoạch|hộp thư|đồng nghiệp|thực hiện|ý định|cộng đồng|then chốt|chia sẻ|thực hành|hành trình|công thức|thành tích|mục tiêu|động lực|quan trọng|kiểm soát|chuẩn bị|ma sát|khách hàng|báo cáo|trình duyệt|thông báo|điện thoại|cà phê|phần thưởng|nghiên cứu|tự động|hành vi|thay đổi|trở thành|con người|nhân viên|tài liệu|số liệu|lịch giấy|bàn phím|màn hình|ngăn kéo|cam kết|ký tên|tuần sau|hôm sau|Chủ Nhật|Thứ Hai|Thứ Ba|Thứ Tư|Thứ Năm|Thứ Sáu|Thứ Bảy|Excellence Hub|James Clear|Atomic Habits|Dòng chảy|bốn quy luật|việc thích|nên làm"""
import glob,os
for _f in glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)),'vnkeep_extra','*.txt')):
    _x=[l.strip() for l in open(_f,encoding='utf-8') if l.strip()]
    if _x: W=W+'|'+'|'.join(_x)
_L=sorted(set(x.replace('\\.','.') for x in W.split('|') if x),key=len,reverse=True)  # cụm dài được ưu tiên trước cụm ngắn
W='|'.join(re.escape(x).replace('\\ ',' ') for x in _L)
RX=re.compile(r'(?<![\wÀ-ỹ])('+W.replace(' ',r'[ \xa0]')+r')(?![\wÀ-ỹ])',re.I)
def keep(html):
    parts=re.split(r'(<[^>]+>)',html)
    return ''.join(p if p.startswith('<') else RX.sub(lambda m:m.group(0).replace(' ','\xa0'),p) for p in parts)
