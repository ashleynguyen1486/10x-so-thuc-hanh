"""Bộ dựng banner chung cho 10X Excellence Hub (1920x1080 css, xuất 3840x2160).

Cách dùng:
    import sys; sys.path.insert(0,'/tmp/f30/b'); from bkit import page, render
    open('b/1_mo-tuan.html','w').write(page(BODY_HTML, extra_css=''))
    render('b', '10XHub_<Tien to>_')   # ghi b/out/<tien to><ten>.png và in báo cáo tiêu đề

Tiêu đề: đặt class "fit" và thuộc tính data-max (cỡ chữ lớn nhất, px), data-min (nhỏ nhất).
Script tự giữ tiêu đề trên MỘT dòng, thu nhỏ dần tới data-min. Chỉ khi vẫn không vừa
mới cho xuống tối đa 2 dòng, cân đối, và không bao giờ tách một cụm từ (keep() nối cụm bằng
khoảng trắng không ngắt). KHÔNG dùng <br> trong tiêu đề.
Logo: img/logo_c_crop.png (nền sáng), img/logo_w_crop.png (nền đỏ). Thư mục img nằm cạnh file html.
"""
import os, glob, asyncio, sys
sys.path.insert(0, '/tmp/f30/b')
from vnkeep import keep

RED = '#862222'; RED2 = '#7b1f23'; CREAM = '#FBF5F4'; INK = '#231F20'

HEAD = '''<!doctype html><html><head><meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800;900&family=Noto+Serif:ital,wght@0,500;0,700;1,500&display=swap" rel="stylesheet">
<style>*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1920px;height:1080px;overflow:hidden;font-family:'Be Vietnam Pro',sans-serif;color:#231F20;background:#FBF5F4;position:relative}
.abs{position:absolute}.serif{font-family:'Noto Serif',serif}
.k{font-size:28px;font-weight:700;letter-spacing:.22em;text-transform:uppercase}
.t,.fit{font-weight:900;text-transform:uppercase;line-height:1.1;letter-spacing:-.015em}
%s
</style>
<script>
function fitAll(){document.querySelectorAll('.fit').forEach(el=>{
  const mx=+el.dataset.max||110, mn=+el.dataset.min||Math.round(mx*0.62);
  el.style.whiteSpace='nowrap'; let s=mx;
  for(;s>=mn;s-=2){el.style.fontSize=s+'px'; if(el.scrollWidth<=el.clientWidth+1) {el.dataset.lines=1;return}}
  el.style.whiteSpace='normal'; el.style.textWrap='balance';
  for(s=mx;s>=Math.round(mn*0.8);s-=2){el.style.fontSize=s+'px'; const lh=parseFloat(getComputedStyle(el).lineHeight);
    if(el.scrollWidth<=el.clientWidth+1 && el.scrollHeight<=lh*2.4){el.dataset.lines=2;return}}
  el.dataset.lines='TRAN';
});document.body.dataset.ready=1}
window.addEventListener('load',()=>document.fonts.ready.then(fitAll));
</script></head><body>'''


def page(body, extra_css=''):
    return HEAD % extra_css + keep(body) + '</body></html>'


async def _render(d, prefix):
    from playwright.async_api import async_playwright
    os.makedirs(os.path.join(d, 'out'), exist_ok=True)
    rep = []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1920, 'height': 1080}, device_scale_factor=2)
        for f in sorted(glob.glob(os.path.join(d, '*.html'))):
            await pg.goto('file://' + os.path.abspath(f))
            await pg.wait_for_load_state('networkidle')
            await pg.wait_for_function('document.body.dataset.ready==1', timeout=15000)
            await pg.wait_for_timeout(300)
            info = await pg.evaluate("[...document.querySelectorAll('.fit')].map(e=>[e.innerText.length,e.dataset.lines,parseInt(e.style.fontSize)])")
            name = os.path.basename(f)[:-5]
            await pg.screenshot(path=os.path.join(d, 'out', prefix + name + '.png'))
            rep.append((name, info))
        await b.close()
    for n, i in rep:
        print(n, i)
    return rep


def render(d, prefix):
    return asyncio.run(_render(d, prefix))
