# Template "Công thức thành công của tuần" 10X Excellence Hub (khớp bản ReportLab gốc)
import asyncio, os
RED = '#7b1f23'
CSS = """
@font-face{font-family:L;font-weight:300;src:url(lato-light.woff2)}
@font-face{font-family:L;font-weight:400;src:url(lato-normal.woff2)}
@font-face{font-family:L;font-weight:400;font-style:italic;src:url(lato-normal-italic.woff2)}
@font-face{font-family:L;font-weight:300;font-style:italic;src:url(lato-light-italic.woff2)}
@font-face{font-family:L;font-weight:700;src:url(lato-bold.woff2)}
@font-face{font-family:L;font-weight:700;font-style:italic;src:url(lato-bold-italic.woff2)}
@font-face{font-family:L;font-weight:900;src:url(lato-black.woff2)}
@page{size:A4;margin:0}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#fff}
body{font-family:L;color:#1a1a1a;font-size:11pt;line-height:18pt}
.pg{position:relative;width:595.28pt;height:841.89pt;overflow:hidden;page-break-after:always;background:#fff}
.wm{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%) rotate(-45deg);font-weight:900;font-size:60pt;
 color:rgba(123,31,35,.06);white-space:pre;z-index:5;pointer-events:none;line-height:1}
.hb{position:absolute;top:0;left:0;width:100%;height:20pt;background:#7b1f23;color:#fff;font-weight:700;font-size:8pt;
 display:flex;justify-content:space-between;align-items:center;padding:0 65pt;letter-spacing:.1pt}
.ft{position:absolute;left:65pt;right:65pt;top:802pt;border-top:.5pt solid #7b1f23;height:30pt}
.ft .a{position:absolute;left:0;top:3pt;font-weight:700;font-size:8pt;color:#7b1f23}
.ft .b{position:absolute;left:102pt;top:3.5pt;font-size:7.5pt;color:#666;line-height:8.5pt}
.ft .b span{display:block;padding-left:23pt}
.ft .n{position:absolute;right:0;top:6pt;font-weight:700;font-size:9pt;color:#7b1f23}
.bd{position:absolute;top:40pt;left:65pt;width:465pt;height:752pt}
h1{font-weight:900;font-size:24pt;line-height:29pt;color:#7b1f23;text-transform:uppercase;margin-bottom:7pt}
.lead{font-weight:300;font-size:15pt;line-height:22pt;margin-bottom:9pt}
.sub{font-weight:300;font-size:14pt;line-height:20pt;margin:-3pt 0 10pt}
p{text-align:justify;margin-bottom:8pt}
h2{font-weight:700;font-size:14pt;line-height:18pt;color:#7b1f23;text-transform:uppercase;margin:16pt 0 8pt}
ul.b{list-style:none;margin:0 0 8pt}
ul.b li{position:relative;padding-left:24pt;margin-bottom:8pt;text-align:justify}
ul.b li:before{content:"\\2022";position:absolute;left:10pt}
ol.n{list-style:none;counter-reset:k;margin:0 0 8pt}
ol.n li{counter-increment:k;position:relative;padding-left:22pt;margin-bottom:7pt;text-align:justify}
ol.n li:before{content:counter(k)".";position:absolute;left:4pt;font-weight:700;color:#7b1f23}
.box{border:.5pt solid #7b1f23;margin:12pt 0;break-inside:avoid}
.box .h{background:#7b1f23;color:#fff;font-weight:700;font-size:8.5pt;text-transform:uppercase;padding:0 9pt;height:26pt;display:flex;align-items:center;letter-spacing:.2pt}
.box .c{background:#fbeded;padding:9pt 11pt;font-size:10pt;line-height:16pt}
.box .c p{margin-bottom:6pt}.box .c p:last-child{margin-bottom:0}
.box .c ul.b li{margin-bottom:4pt;padding-left:16pt}.box .c ul.b li:before{left:3pt}
.q{padding:4pt 14pt;margin:14pt 0 12pt}
.q .t{font-weight:700;font-style:italic;font-size:14pt;line-height:22pt;color:#7b1f23}
.q .s{font-style:italic;font-size:10pt;color:#666;margin-top:6pt}
.note{font-weight:700;color:#7b1f23;font-size:10.5pt;line-height:17pt;margin-top:10pt;text-align:justify}
table.t{width:100%;border-collapse:collapse;border:.5pt solid #7b1f23;font-size:9.5pt;line-height:14pt;margin:10pt 0}
table.t th{background:#7b1f23;color:#fff;font-weight:700;font-size:8.5pt;text-align:left;padding:8pt 8pt;text-transform:uppercase}
table.t td{padding:8pt 8pt;border-top:.3pt solid #e6e6e6;border-left:.3pt solid #e6e6e6;vertical-align:top}
table.t tr:nth-child(even) td{background:#fbeded}
table.t td.k{font-weight:700;color:#7b1f23}
.stats{display:flex;gap:10pt;margin:14pt 0}
.stats div{flex:1;text-align:center;border-top:2pt solid #7b1f23;padding-top:6pt}
.stats b{display:block;font-weight:900;font-size:22pt;line-height:26pt;color:#7b1f23}
.stats span{font-size:8.5pt;color:#666;line-height:11pt;display:block}
/* trang ngày */
.dh{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2pt solid #7b1f23;padding-bottom:5pt;margin-bottom:12pt}
.dh .d{font-weight:900;font-size:44pt;line-height:46pt;color:#7b1f23}
.dh .tag{font-weight:700;font-size:8pt;color:#7b1f23;text-transform:uppercase;margin-top:8pt;letter-spacing:.3pt}
.dh .tm{text-align:right;font-size:10pt;line-height:13pt}.dh .tm b{display:block;font-size:12pt;color:#7b1f23}
.dt{font-weight:700;font-size:14pt;line-height:19pt;color:#7b1f23;margin-bottom:3pt}
.di{font-style:italic;font-size:9pt;color:#666;margin-bottom:10pt}
.ci{border:.5pt solid #7b1f23;border-left:3pt solid #7b1f23;background:#fbeded;padding:8pt 11pt;font-size:10pt;line-height:15pt;margin:12pt 0}
.ci b{color:#7b1f23}
.fill{border-bottom:.6pt solid #999;height:22pt}
/* bìa */
.cv .top{position:absolute;left:0;top:0;width:100%;height:397pt;background:#7b1f23;color:#fff}
.cv .x{position:absolute;left:91pt;right:80pt}
.cv .bot{position:absolute;left:0;top:805pt;width:100%;height:37pt;background:#7b1f23;color:#fff;font-weight:700;font-size:8.5pt;
 display:flex;justify-content:space-between;align-items:center;padding:0 91pt}
"""
WM = '10X  EXCELLENCE  HUB'

def page(n, num, inner, hb='CÔNG THỨC THÀNH CÔNG CỦA TUẦN'):
    return f'''<div class="pg"><div class="hb"><span>10X EXCELLENCE HUB&nbsp; •&nbsp; {hb}</span><span>CÔNG THỨC #{num}</span></div>
<div class="bd">{inner}</div>
<div class="ft"><div class="a">10X YOUR POTENTIAL</div><div class="b">Skills&nbsp; •&nbsp; Income&nbsp; •&nbsp; Impact<span>Tài liệu dành riêng cho thành viên cộng đồng 10X Excellence Hub</span></div><div class="n">{n}</div></div>
<div class="wm">{WM}</div></div>'''

def cover(num, title_lines, subtitle, method, source):
    t = '<br>'.join(title_lines)
    return f'''<div class="pg cv"><div class="top">
<div class="x" style="top:26pt;font-weight:700;font-size:9pt">10X EXCELLENCE HUB&nbsp; •&nbsp; 10X YOUR POTENTIAL</div>
<div class="x" style="right:20pt;top:84pt;font-weight:900;font-size:33pt;line-height:40pt">CÔNG THỨC THÀNH CÔNG<br>CỦA TUẦN</div>
<div class="x" style="top:174pt;font-weight:300;font-size:14pt">Mỗi tuần một công thức</div>
<div style="position:absolute;left:91pt;top:218pt;width:170pt;border-top:.6pt solid #fff"></div>
<div class="x" style="top:228pt;font-weight:900;font-size:36pt;line-height:44pt">Công thức #{num}</div>
<div class="x" style="top:335pt;font-size:10pt;line-height:16pt">Một ấn phẩm của cộng đồng 10X Excellence Hub<br>Tài liệu nội bộ. Vui lòng không sao chép ra ngoài cộng đồng.</div>
</div>
<div class="x" style="top:404pt;font-weight:900;font-size:42pt;line-height:48pt;color:#7b1f23">{t}</div>
<div class="x" style="top:{404+48*len(title_lines)+4}pt;font-weight:300;font-size:17pt;line-height:24pt">{subtitle}</div>
<div class="x" id="meta" style="top:{404+48*len(title_lines)+4+24*2+12}pt;color:#666">
<div style="font-weight:700;font-size:11pt;line-height:16pt;margin-bottom:2pt">{method}</div>
<div style="font-style:italic;font-size:10pt;line-height:14pt">{source}</div></div>
<div class="bot"><span>SKILLS&nbsp; •&nbsp; INCOME&nbsp; •&nbsp; IMPACT</span><span>10X Excellence Hub&nbsp; /&nbsp; Công thức #{num}</span></div>
<div class="wm">{WM}</div></div>'''

def disclaimer(n, num, doc_title, sources_html):
    sec = lambda h, b: f'<div style="font-weight:700;font-size:11.5pt;color:#a52a2e;margin:10pt 0 2pt">{h}</div><p>{b}</p>'
    inner = f'''<h1 style="margin-top:-3pt">TUYÊN BỐ MIỄN TRỪ TRÁCH NHIỆM</h1>
<div style="font-style:italic;font-size:10pt;color:#666;margin-top:-4pt">Tài liệu này thuộc cộng đồng 10X Excellence Hub.</div>
{sec('Tài liệu nội bộ: không sao chép', f'Tài liệu "{doc_title}" (thuộc bộ tài liệu <i>Công thức Thành công của Tuần</i>) được biên soạn dành riêng cho thành viên cộng đồng <b>10X Excellence Hub</b>. Vui lòng <b>không sao chép, phân phối, đăng tải, hay sử dụng cho mục đích thương mại nào nếu không có sự đồng ý bằng văn bản</b>.')}
{sec('Tính chất giáo dục: không phải lời khuyên chuyên môn', 'Nội dung trong tài liệu mang tính giáo dục, truyền cảm hứng và phát triển bản thân. Đây <b>không phải</b> lời khuyên y tế, tâm lý học, tài chính hay nghề nghiệp. Trước khi áp dụng cho lĩnh vực có rủi ro, vui lòng tham vấn chuyên gia.')}
{sec('Kết quả khác nhau ở mỗi người', 'Các kết quả, số liệu và ví dụ được trích dẫn trong tài liệu này mang tính tham khảo và lấy từ các nguồn công khai. Hiệu quả thực tế phụ thuộc nỗ lực, hoàn cảnh và sự kiên trì của mỗi người.')}
{sec('Nguồn tham khảo (đã kiểm chứng qua tìm kiếm trên mạng)', sources_html)}
{sec('Trách nhiệm cá nhân &amp; Sở hữu trí tuệ', 'Bằng việc đọc và áp dụng tài liệu, bạn đồng ý mọi <b>quyết định và hành động</b> thuộc trách nhiệm của bạn. Bản quyền các tác phẩm gốc của các cá nhân được trích dẫn thuộc sở hữu của họ. Phần biên soạn lại (cấu trúc, ngữ điệu, bài tập, biểu đồ) thuộc cộng đồng 10X Excellence Hub.')}
<div style="background:#7b1f23;color:#fff;text-align:center;padding:16pt 0;margin-top:18pt"><div style="font-weight:700;font-size:12pt">10X Excellence Hub</div><div style="font-weight:700;font-size:10pt">10X Your Potential. Skills, Income, and Impact</div></div>'''
    return page(n, num, inner, hb='TUYÊN BỐ MIỄN TRỪ TRÁCH NHIỆM').replace('<div class="ft">', '<div class="ft" style="display:none">')

def build(pages, html_path, pdf_path):
    html = f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{"".join(pages)}</body></html>'
    open(html_path, 'w').write(html)
    from playwright.async_api import async_playwright
    async def go():
        async with async_playwright() as p:
            b = await p.chromium.launch()
            pg = await b.new_page()
            await pg.goto('file://' + os.path.abspath(html_path))
            await pg.evaluate('document.fonts.ready')
            over = await pg.evaluate('''[...document.querySelectorAll('.pg')].map((g,i)=>{const d=g.querySelector('.bd');
              if(!d) {const m=g.querySelector('#meta'); return m? (m.getBoundingClientRect().bottom > g.getBoundingClientRect().top+800 ? i+1 : 0):0}
              return d.scrollHeight>d.clientHeight+1 ? (i+1)+':'+(d.scrollHeight-d.clientHeight) : 0}).filter(x=>x)''')
            await pg.pdf(path=pdf_path, prefer_css_page_size=True, print_background=True)
            await b.close()
            return over
    return asyncio.run(go())
